# Amp Ohm — Cable Loss Calculator: Accuracy Audit & Simplification Report

**Application:** Amp Ohm Pro Audio Toolkit  
**Component:** Speaker Cable Recommendation & Loss Calculator  
**Files Audited:** `src/calculators/calculations.ts`, `src/components/calculators/CableLossCalculatorView.tsx`, `flutter_app/lib/calculators/cable_loss_calculator.dart`  
**Date:** October 15, 2026  
**Status:** COMPLETED, AUDITED & VERIFIED  

---

## 1. Executive Summary & Verification of User Screenshot Configuration

### Screenshot Test Configuration
* **Amplifier RMS Power:** 500 W
* **Speaker Configuration:** 4 speakers × 8 Ω in parallel = **2.0 Ω load**
* **One-Way Cable Distance:** 20 meters (40 m loop)
* **Cable Conductor Material:** Pure OFC Copper ($\rho = 0.0175\ \Omega\cdot\text{mm}^2/\text{m}$)
* **User Selected Target:** 5% Maximum Resistance Ratio

### Verification of Displayed Values for Recommended Cable (10.0 mm²)
| Metric | Formula | Exact Value | UI Display | Verification Status |
|---|---|---|---|---|
| **Conductor Size** | Smallest gauge with Ratio $\le 5\%$ | 10.0 mm² (7 AWG) | **10.0 mm²** | MATCH & CONFIRMED |
| **Loop Resistance** | $(2 \times 0.0175 \times 20) / 10$ | $0.0700\ \Omega$ | **0.070 Ω** | MATCH (exact) |
| **Circuit Impedance** | $R_{\text{load}} + R_{\text{loop}}$ | $2.0700\ \Omega$ | **2.07 Ω** | MATCH |
| **Source Voltage** | $\sqrt{500 \times 2.0}$ | $31.6228\text{ V}$ | Internal | MATCH |
| **Circuit Current** | $31.6228 / 2.0700$ | $15.2767\text{ A}$ | Internal | MATCH |
| **Voltage Drop** | $15.2767\text{ A} \times 0.070\ \Omega$ | $1.0694\text{ V}$ | **1.1 V** (rounded) | MATCH |
| **Power Dissipated** | $(15.2767)^2 \times 0.0700$ | $16.3157\text{ W}$ | **16.3 W** | MATCH |
| **Delivered Power** | $(15.2767)^2 \times 2.0000$ | $483.684\text{ W}$ | **483.7 W** | MATCH |
| **Cable Resistance Ratio** | $(0.0700 / 2.0) \times 100$ | $3.5000\%$ | **3.5%** | MATCH ($\le 5\%$ Target) |
| **Actual Power Loss %** | $0.0700 / 2.0700 \times 100$ | $3.3816\%$ | **3.4%** | MATCH (3.38% ≈ 3.4%) |
| **Level Loss (dB)** | $20 \times \log_{10}(2.0 / 2.0700)$ | $-0.2991\text{ dB}$ | **-0.30 dB** | MATCH |
| **Target Compliance** | $3.50\% \le 5.0\%$ | Compliant | **Meets Target (GREEN)** | MATCH |

### Why 10.0 mm² is the Smallest Available Size Meeting the 5% Target
Evaluating all standard cable sizes for this configuration:
* **1.5 mm²:** $R_{\text{loop}} = 0.4667\ \Omega$, Resistance Ratio = **23.33%** (Exceeds 5%) ❌
* **2.5 mm²:** $R_{\text{loop}} = 0.2800\ \Omega$, Resistance Ratio = **14.00%** (Exceeds 5%) ❌
* **4.0 mm²:** $R_{\text{loop}} = 0.1750\ \Omega$, Resistance Ratio = **8.75%** (Exceeds 5%) ❌
* **6.0 mm²:** $R_{\text{loop}} = 0.1167\ \Omega$, Resistance Ratio = **5.83%** (Exceeds 5%) ❌
* **10.0 mm²:** $R_{\text{loop}} = 0.0700\ \Omega$, Resistance Ratio = **3.50%** (Compliant $\le 5\%$) ✅

Conclusion: **10.0 mm² is undeniably the smallest standard gauge that satisfies the 5% resistance ratio target.**

---

## 2. Technical Formulas & Calculations

### A. Two-Conductor Loop Resistance
$$R_{\text{loop}} = \frac{2 \times \rho \times L}{A}$$
* $\rho$ (resistivity):
  * Pure OFC Copper: $0.0175\ \Omega\cdot\text{mm}^2/\text{m}$ (IEC 60028 at ~25°C)
  * CCA (Copper Clad Aluminium): $0.0280\ \Omega\cdot\text{mm}^2/\text{m}$ (62.5% IACS conductivity, exactly $1.600\times$ copper)
* $L$: One-way length in meters
* $A$: Conductor cross-sectional area in mm²
* Factor of 2 accounts for both outgoing and return conductors once and only once.

### B. Cable Resistance Ratio vs. Actual Power Loss
1. **Cable Resistance Ratio (%):**
   $$\text{Resistance Ratio (\%)} = \left(\frac{R_{\text{loop}}}{R_{\text{load}}}\right) \times 100$$
   Used exclusively to evaluate design target compliance (3%, 5%, 10%).

2. **Actual Power Loss (%):**
   $$\text{Actual Power Loss (\%)} = \left(\frac{R_{\text{loop}}}{R_{\text{load}} + R_{\text{loop}}}\right) \times 100$$
   Represents the physical fraction of electrical power dissipated as heat in the cable conductors.

### C. Electrical Power Scaling & Voltage Source
$$V_{\text{source}} = \sqrt{P_{\text{ideal}} \times R_{\text{load}}}$$
$$I = \frac{V_{\text{source}}}{R_{\text{load}} + R_{\text{loop}}}$$
$$P_{\text{loss}} = I^2 \times R_{\text{loop}}$$
$$P_{\text{speaker}} = I^2 \times R_{\text{load}}$$

Clearly distinguishes ideal amplifier capability from actual power delivered to the speaker.

### D. Signal Level Reduction (dB)
$$\text{Level Loss (dB)} = 20 \times \log_{10}\left(\frac{R_{\text{load}}}{R_{\text{load}} + R_{\text{loop}}}\right)$$
Represents acoustic level reduction compared to a zero-resistance direct connection.

---

## 3. Tier Recommendation & Target Agreement Rules

1. **Target Compliance:**
   Evaluated strictly on unrounded `(R_loop / R_load) * 100 <= selectedTarget`.
2. **Recommended Cable Size:**
   The smallest standard cable gauge satisfying the target.
   * If no cable meets the target: `null` ("No available cable meets this target").
   * 10 mm² is displayed as the lowest-loss alternative, explicitly marked non-compliant.
3. **Minimum Acceptable Size:**
   Matches the smallest compliant gauge. Strictly `null` if no cable meets the target.
4. **Professional Choice:**
   Represents touring-grade low resistance ($\le 2.5\%$ ratio for punchy low-end and tight damping factor).
   * If a compliant cable achieves $\le 2.5\%$ ratio, the smallest such gauge is selected.
   * If $\le 2.5\%$ cannot be reached within standard gauges but cables do meet the user target, Pro Choice selects the best available compliant cable (10 mm²).
   * If NO cable meets the target, Pro Choice is strictly `null` — never contradicting the user's design target.

---

## 4. Full Regression Test Suite Execution

All 9 regression tests were executed and validated:

### Test 1: 500 W, 2 Ω, 30 m, OFC, 5% Resistance-Ratio Target
* **Loop R (10 mm²):** $0.105\ \Omega$
* **Resistance Ratio:** $5.25\%$ (> 5.0% target)
* **Actual Loss:** $5.0\%$
* **Level Loss:** $-0.44\text{ dB}$
* **Power Dissipated:** $23.7\text{ W}$ | Delivered: $451.4\text{ W}$
* **Compliance:** FALSE. Recommended: None. Alternative: 10 mm² (non-compliant).
* **Min Acceptable:** None | **Pro Choice:** None.

### Test 2: 2000 W, 2 Ω, 30 m, OFC, 5% Resistance-Ratio Target
* **Resistance Ratio:** $5.25\%$ (Identical to 500 W)
* **Actual Loss:** $5.0\%$ (Identical to 500 W)
* **Level Loss:** $-0.44\text{ dB}$ (Identical to 500 W)
* **Power Dissipated:** $94.8\text{ W}$ ($4\times$ the 500 W loss, matching $P \propto I^2$)
* **Delivered Power:** $1805.5\text{ W}$
* **Compliance:** FALSE. Target status unchanged by power change.

### Test 3: OFC Cable Length Scaling (4 Ω Load, 500 W, 5% Target)
* **10 m:**
  * 1.5 mm²: $R_{\text{loop}} = 0.233\ \Omega$, Ratio = $5.83\%$ (Exceeds)
  * 2.5 mm²: $R_{\text{loop}} = 0.140\ \Omega$, Ratio = $3.50\%$ (Compliant)
  * 4.0 mm²: $R_{\text{loop}} = 0.088\ \Omega$, Ratio = $2.19\%$ (Compliant $\le 2.5\%$)
  * Recommended: **2.5 mm²** | Min: 2.5 mm² | Pro: **4.0 mm²**
* **20 m:**
  * 2.5 mm²: $R_{\text{loop}} = 0.280\ \Omega$, Ratio = $7.00\%$ (Exceeds)
  * 4.0 mm²: $R_{\text{loop}} = 0.175\ \Omega$, Ratio = $4.38\%$ (Compliant)
  * Recommended: **4.0 mm²** | Min: 4.0 mm² | Pro: **10.0 mm²**
* **30 m:**
  * 4.0 mm²: $R_{\text{loop}} = 0.263\ \Omega$, Ratio = $6.56\%$ (Exceeds)
  * 6.0 mm²: $R_{\text{loop}} = 0.175\ \Omega$, Ratio = $4.38\%$ (Compliant)
  * Recommended: **6.0 mm²** | Min: 6.0 mm² | Pro: **10.0 mm²**

### Test 4: CCA Conductor at 30 m, 4 Ω
* **3% Target:** 10 mm² gives 4.20% ratio. Compliant: FALSE. Recommended: None.
* **5% Target:** 10 mm² gives 4.20% ratio. Compliant: TRUE. Recommended: **10 mm²**, Pro: **10 mm²**.
* **10% Target:** 6 mm² gives 7.00% ratio. Compliant: TRUE. Recommended: **6 mm²**, Pro: **10 mm²**.

### Test 5: Speaker Loads 2 Ω, 4 Ω, 8 Ω (20 m, OFC, 5% Target)
* **2 Ω:** Recommended = **10.0 mm²** (Ratio = $3.50\%$, Loss = $3.38\%$, $-0.30\text{ dB}$, $16.3\text{ W}$)
* **4 Ω:** Recommended = **4.0 mm²** (Ratio = $4.38\%$, Loss = $4.19\%$, $-0.37\text{ dB}$, $20.1\text{ W}$)
* **8 Ω:** Recommended = **2.5 mm²** (Ratio = $3.50\%$, Loss = $3.38\%$, $-0.30\text{ dB}$, $16.3\text{ W}$)

### Test 6: Conductor Scaling Verification (20 m, 4 mm²)
* **OFC Resistance:** $0.1750\ \Omega$
* **CCA Resistance:** $0.2800\ \Omega$
* **Ratio $\rho_{\text{CCA}} / \rho_{\text{OFC}}$:** $1.6000\times$ (Exact verified constant)

### Test 7: Switching Between OFC and CCA
* Dynamically updates loop resistance, ratios, and recommendation tiers immediately without page reload.

### Test 8: English and Hindi Language Switching
* All technical labels, badges, tips, warnings, and matrix headers render accurately in both English and Hindi without missing translations.

### Test 9: Input Validation & Boundary Conditions
* Cable length $\le 0$ clamped safely to 0.1 m.
* Power $\le 0$ clamped safely to 1 W.
* Load < 2 Ω or > 16 Ω alerts user with clear guidance.

---

## 5. Technical Assumptions Note

* **Nominal Resistive Load Assumption:** Calculations assume a simplified nominal resistive speaker load driven by an ideal voltage source. Dynamic loudspeakers exhibit complex frequency-dependent impedance curves due to voice-coil inductance and cabinet acoustic resonance. Practical audio installations should treat these numbers as rigorous engineering baselines.

---

**Amp Ohm Pro Audio Engineering Audit Team**  
Verified against IEC 60028 and AES Recommended Practices.
