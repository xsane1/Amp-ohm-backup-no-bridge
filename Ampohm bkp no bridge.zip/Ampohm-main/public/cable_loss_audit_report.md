# Cable Loss Calculator — Calculation Logic Audit & Verification Report

**Application:** Amp Ohm Pro Audio Toolkit (`com.ampohm.app`)  
**Component:** Speaker Cable Loss Calculator (`flutter_app/lib/calculators/cable_loss_calculator.dart`)  
**Date:** October 14, 2026  
**Status:** AUDITED & VERIFIED

---

## 1. Electrical Formulas & Physics Derivations

The calculator implements standard transmission-line physics and Thévenin circuit analysis for audio power amplifiers driving loudspeaker loads:

### A. Conductor & Loop Resistance ($R_{\text{loop}}$)
$$R_{\text{loop}} = \frac{2 \cdot \rho \cdot L}{A}$$
* **$L$**: One-way cable length entered by the user (meters).
* **$A$**: Conductor cross-sectional area ($\text{mm}^2$).
* **Factor of 2**: Fully accounts for both the outbound and return conductors (complete round-trip circuit).
* **Material Resistivity ($\rho$):**
  * **Pure OFC Copper:** $\rho = 0.0175 \ \Omega\cdot\text{mm}^2/\text{m}$ (IEC 60028 annealed copper standard at typical operating temperatures).
  * **CCA (Copper Clad Aluminium):** $\rho = 0.0280 \ \Omega\cdot\text{mm}^2/\text{m}$ (~62.5% IACS electrical conductivity, exactly $1.6\times$ OFC copper resistance).

### B. Amplifier Terminal Voltage ($V_{\text{RMS}}$)
$$V_{\text{RMS}} = \sqrt{P_{\text{RMS}} \cdot R_{\text{load}}}$$
* Audio power amplifiers function as constant-voltage sources across their rated impedance range ($2\Omega$ to $16\Omega$).

### C. Loop Current ($I$)
$$Z_{\text{total}} = R_{\text{load}} + R_{\text{loop}}$$
$$I = \frac{V_{\text{RMS}}}{Z_{\text{total}}} = \frac{\sqrt{P_{\text{RMS}} \cdot R_{\text{load}}}}{R_{\text{load}} + R_{\text{loop}}}$$

### D. Voltage Drop ($V_{\text{drop}}$)
$$V_{\text{drop}} = I \cdot R_{\text{loop}} = V_{\text{RMS}} \cdot \left(\frac{R_{\text{loop}}}{R_{\text{load}} + R_{\text{loop}}}\right)$$

### E. Cable Power Loss ($P_{\text{loss}}$) & Speaker Power ($P_{\text{speaker}}$)
$$P_{\text{loss}} = I^2 \cdot R_{\text{loop}}$$
$$P_{\text{speaker}} = I^2 \cdot R_{\text{load}}$$
$$P_{\text{total}} = P_{\text{loss}} + P_{\text{speaker}} = I^2 \cdot Z_{\text{total}}$$

### F. Loss Percentage ($\text{Loss}\%$) & Efficiency ($\text{Efficiency}\%$)
$$\text{Loss}\% = \frac{P_{\text{loss}}}{P_{\text{total}}} \cdot 100\% = \frac{R_{\text{loop}}}{R_{\text{load}} + R_{\text{loop}}} \cdot 100\% \equiv \frac{V_{\text{drop}}}{V_{\text{RMS}}} \cdot 100\%$$
$$\text{Efficiency}\% = 100\% - \text{Loss}\% = \frac{R_{\text{load}}}{R_{\text{load}} + R_{\text{loop}}} \cdot 100\%$$
* $\text{Loss}\% + \text{Efficiency}\% = 100.0\%$ holds true across every size and reference.

---

## 2. Amplifier Power & Load Handling Documentation

1. **Continuous RMS Rating:** Amplifier power input ($P$) represents continuous RMS wattage into a nominal resistive load ($R_{\text{load}}$). Peak/burst numbers are not mixed with steady-state thermal and voltage drop equations.
2. **Nominal Resistive Load Assumption:** Calculations assume nominal pure resistive loudspeaker impedance ($2\Omega, 4\Omega, 8\Omega, \text{or } 16\Omega$). While real physical loudspeakers exhibit frequency-dependent complex impedance curves $Z(f)$ and acoustic back-EMF, nominal resistive load is the universal international engineering standard for loudspeaker transmission line sizing.
3. **Linearity with Power:** Changing power from 500 W to 2000 W doubles circuit current ($15.02\text{ A} \to 30.05\text{ A}$) and doubles voltage drop ($1.6\text{ V} \to 3.2\text{ V}$), and quadruples power loss in watts ($23.7\text{ W} \to 94.8\text{ W}$), while **loss percentage remains identical** ($4.988\% \approx 5.0\%$).

---

## 3. Cable Length & Material Scaling

* **One-Way Distance Scaling:**
  * 10 m (1.5 mm² OFC): $R_{\text{loop}} = 0.233\ \Omega$
  * 20 m (1.5 mm² OFC): $R_{\text{loop}} = 0.467\ \Omega$ ($2\times$)
  * 30 m (1.5 mm² OFC): $R_{\text{loop}} = 0.700\ \Omega$ ($3\times$)
* **OFC Pure Copper vs CCA:**
  * For any cable size and distance, CCA produces exactly $1.600\times$ the resistance of pure OFC copper ($0.0280 / 0.0175 = 1.6$).
  * Switching material dynamically updates all dependent outputs: resistance, loop current, voltage drop, power loss in watts, loss percentage, and recommended gauge.

---

## 4. Recommendation & Target Compliance

* **Full-Precision Evaluation:** Compliance is evaluated using unrounded loss percentages ($\text{rawLossPct} \le \text{targetLoss}$).
  * *Example:* 10 mm² OFC at 30 m into 2Ω has an unrounded loss of **4.988%**. Since $4.988\% \le 5.000\%$, it is compliant (displayed rounded as 5.0%).
* **Non-Compliant States:** If no available size meets the target (e.g. 30 m CCA at 3% or 5% target):
  * `meetsTarget` is set to `false`.
  * The UI displays `TARGET EXCEEDED (> target%)` with a distinct warning badge.
  * The lowest-loss option (10 mm²) is identified as `(Lowest loss option)` rather than falsely claimed to be compliant.
  * `Min Acceptable` = `None` (Hindi: `उपलब्ध नहीं`).
  * `Pro Choice` = `None` (Hindi: `उपलब्ध नहीं`).
* **Agreement:** The recommendation card, tier pills, and 5-gauge comparison matrix remain 100% consistent under all test scenarios.

---

## 5. Mandatory Test Cases Execution & Computed Values

All test cases were executed directly against the mathematical engine:

### Test A: 500 W/ch, 2Ω Load, 30 m One-Way, OFC, 5% Target
* Amplifier Output Voltage: **31.62 V RMS**

| Cable Size | Loop $R$ ($\Omega$) | Current ($A$) | $V_{\text{drop}}$ (V) | $P_{\text{loss}}$ (W) | Loss % (Display) | Unrounded Loss % | Meets 5% Target? |
|---|---|---|---|---|---|---|---|
| **1.5 mm²** | 0.700 $\Omega$ | 11.71 A | 8.2 V | 96.0 W | 25.9% | 25.926% | ❌ No |
| **2.5 mm²** | 0.420 $\Omega$ | 13.07 A | 5.5 V | 71.7 W | 17.4% | 17.355% | ❌ No |
| **4.0 mm²** | 0.263 $\Omega$ | 13.98 A | 3.7 V | 51.3 W | 11.6% | 11.602% | ❌ No |
| **6.0 mm²** | 0.175 $\Omega$ | 14.54 A | 2.5 V | 37.0 W | 8.0% | 8.046% | ❌ No |
| **10.0 mm²**| 0.105 $\Omega$ | 15.02 A | 1.6 V | 23.7 W | 5.0% | **4.988%** | **✅ Yes** |

* **Compliant Size Available:** Yes
* **Recommended Cable Size:** **10 mm²** (7 AWG)
* **Min Acceptable:** 10 mm²
* **Pro Choice:** 10 mm²

---

### Test B: 2000 W/ch, 2Ω Load, 30 m One-Way, OFC, 5% Target
* Amplifier Output Voltage: **63.25 V RMS**

| Cable Size | Loop $R$ ($\Omega$) | Current ($A$) | $V_{\text{drop}}$ (V) | $P_{\text{loss}}$ (W) | Loss % (Display) | Unrounded Loss % | Meets 5% Target? |
|---|---|---|---|---|---|---|---|
| **1.5 mm²** | 0.700 $\Omega$ | 23.42 A | 16.4 V | 384.1 W | 25.9% | 25.926% | ❌ No |
| **2.5 mm²** | 0.420 $\Omega$ | 26.13 A | 11.0 V | 286.9 W | 17.4% | 17.355% | ❌ No |
| **4.0 mm²** | 0.263 $\Omega$ | 27.95 A | 7.3 V | 205.1 W | 11.6% | 11.602% | ❌ No |
| **6.0 mm²** | 0.175 $\Omega$ | 29.08 A | 5.1 V | 148.0 W | 8.0% | 8.046% | ❌ No |
| **10.0 mm²**| 0.105 $\Omega$ | 30.05 A | 3.2 V | 94.8 W | 5.0% | **4.988%** | **✅ Yes** |

* **Compliant Size Available:** Yes
* **Recommended Cable Size:** **10 mm²** (7 AWG)
* **Min Acceptable:** 10 mm²
* **Pro Choice:** 10 mm²

---

### Test C1: 500 W/ch, 2Ω Load, 10 m One-Way, OFC, 5% Target
* Amplifier Output Voltage: **31.62 V RMS**

| Cable Size | Loop $R$ ($\Omega$) | Current ($A$) | $V_{\text{drop}}$ (V) | $P_{\text{loss}}$ (W) | Loss % (Display) | Unrounded Loss % | Meets 5% Target? |
|---|---|---|---|---|---|---|---|
| **1.5 mm²** | 0.233 $\Omega$ | 14.16 A | 3.3 V | 46.8 W | 10.4% | 10.448% | ❌ No |
| **2.5 mm²** | 0.140 $\Omega$ | 14.78 A | 2.1 V | 30.6 W | 6.5% | 6.542% | ❌ No |
| **4.0 mm²** | 0.088 $\Omega$ | 15.15 A | 1.3 V | 20.1 W | 4.2% | **4.192%** | **✅ Yes** |
| **6.0 mm²** | 0.058 $\Omega$ | 15.36 A | 0.9 V | 13.8 W | 2.8% | 2.834% | ✅ Yes |
| **10.0 mm²**| 0.035 $\Omega$ | 15.54 A | 0.5 V | 8.5 W | 1.7% | 1.720% | ✅ Yes ($\le 2.5\%$) |

* **Compliant Size Available:** Yes
* **Recommended Cable Size:** **4 mm²** (Smallest size meeting $\le 5\%$)
* **Min Acceptable:** 4 mm²
* **Pro Choice:** 10 mm² (Touring grade $\le 2.5\%$)

---

### Test C2: 500 W/ch, 2Ω Load, 20 m One-Way, OFC, 5% Target
* Amplifier Output Voltage: **31.62 V RMS**

| Cable Size | Loop $R$ ($\Omega$) | Current ($A$) | $V_{\text{drop}}$ (V) | $P_{\text{loss}}$ (W) | Loss % (Display) | Unrounded Loss % | Meets 5% Target? |
|---|---|---|---|---|---|---|---|
| **1.5 mm²** | 0.467 $\Omega$ | 12.82 A | 6.0 V | 76.7 W | 18.9% | 18.919% | ❌ No |
| **2.5 mm²** | 0.280 $\Omega$ | 13.87 A | 3.9 V | 53.9 W | 12.3% | 12.281% | ❌ No |
| **4.0 mm²** | 0.175 $\Omega$ | 14.54 A | 2.5 V | 37.0 W | 8.0% | 8.046% | ❌ No |
| **6.0 mm²** | 0.117 $\Omega$ | 14.94 A | 1.7 V | 26.0 W | 5.5% | 5.512% | ❌ No |
| **10.0 mm²**| 0.070 $\Omega$ | 15.28 A | 1.1 V | 16.3 W | 3.4% | **3.382%** | **✅ Yes** |

* **Compliant Size Available:** Yes
* **Recommended Cable Size:** **10 mm²**
* **Min Acceptable:** 10 mm²
* **Pro Choice:** 10 mm²

---

### Test D: 500 W/ch, 2Ω Load, 30 m One-Way, CCA across 3%, 5%, and 10% Targets
* Amplifier Output Voltage: **31.62 V RMS**

| Cable Size | Loop $R$ ($\Omega$) | Current ($A$) | $V_{\text{drop}}$ (V) | $P_{\text{loss}}$ (W) | Loss % (Display) | Unrounded Loss % |
|---|---|---|---|---|---|---|
| **1.5 mm²** | 1.120 $\Omega$ | 10.14 A | 11.4 V | 115.1 W | 35.9% | 35.897% |
| **2.5 mm²** | 0.672 $\Omega$ | 11.83 A | 8.0 V | 94.1 W | 25.1% | 25.150% |
| **4.0 mm²** | 0.420 $\Omega$ | 13.07 A | 5.5 V | 71.7 W | 17.4% | 17.355% |
| **6.0 mm²** | 0.280 $\Omega$ | 13.87 A | 3.9 V | 53.9 W | 12.3% | 12.281% |
| **10.0 mm²**| 0.168 $\Omega$ | 14.59 A | 2.5 V | 35.7 W | 7.7% | **7.749%** |

* **Test D1 (Target 3%):**
  * Compliant Size Available: **NO** ($7.749\% > 3.0\%$)
  * Result: Shows `TARGET EXCEEDED (> 3%)`, 10 mm² labeled `(Lowest loss option)`
  * Min Acceptable: **None**
  * Pro Choice: **None**

* **Test D2 (Target 5%):**
  * Compliant Size Available: **NO** ($7.749\% > 5.0\%$)
  * Result: Shows `TARGET EXCEEDED (> 5%)`, 10 mm² labeled `(Lowest loss option)`
  * Min Acceptable: **None**
  * Pro Choice: **None**

* **Test D3 (Target 10%):**
  * Compliant Size Available: **YES** ($7.749\% \le 10.0\%$)
  * Recommended Cable Size: **10 mm²** (Compliant)
  * Min Acceptable: **10 mm²**
  * Pro Choice: **10 mm²**

---

## 6. Summary of Code & Documentation Status

* **Calculation File:** `flutter_app/lib/calculators/cable_loss_calculator.dart`
  * Added complete technical derivation specification, physics equations, assumptions, and limitations.
  * Verified full-precision unrounded target compliance and truthful recommendation fallback.
* **UI Preserved:** No layout, color, styling, card, button, or animation changes were made.
* **Feature Isolation:** Unrelated modules (Ohm Calculator, Amplifier Calculator, DMX Calculator, Sound Guide, Ads, Subscriptions) were completely untouched.
* **Build Status:** Verified passing compilation and lint checks.
