# ProAudio Toolkit (Flutter Android Mobile Application)

Professional Audio & Lighting Engineering Toolkit for Sound Engineers, DJ Operators, and PA Technicians.

---

## 📱 Features

1. **OHM CALCULATOR**: Speaker wiring configurations (Parallel, Series, Series-Parallel), total impedance calculation, power distribution per speaker, and amplifier minimum load safety validation.
2. **AMPLIFIER CALCULATOR**: Recommends amplifier power targets with customizable headroom (1.25x - 2.0x), calculates clip voltage, peak current, and limiter thresholds.
3. **TOP SPEAKER CALCULATOR**: Continuous and peak power ratings, single/multi-cabinet array coupling, and distance SPL attenuation with hearing safety status.
4. **SPEAKER CABLE LOSS CALCULATOR**: AWG 10-18 wire resistance modeling, loop impedance, percentage voltage drop, power dissipation in watts, insertion loss (dB), and amplifier effective damping factor.
5. **DMX ADDRESS CALCULATOR**: Channel footprint addressing, universe allocation, sequential patch list, and interactive field checklist.
6. **GLOBAL BILINGUAL SUPPORT**: Instant global switching between English and Hindi (हिन्दी) with local persistence via `SharedPreferences`.
7. **OFFLINE-FIRST ARCHITECTURE**: Zero network latency. All calculations run strictly on-device in CPU memory.

---

## 🏗️ Clean Architecture Structure

\`\`\`
flutter_app/
├── android/
│   └── app/src/main/AndroidManifest.xml
├── pubspec.yaml
└── lib/
    ├── main.dart                      # App entry point & navigation
    ├── models/
    │   └── models.dart                # Status levels, calculation results
    ├── services/
    │   └── preference_service.dart    # Persistent language & local storage
    ├── localization/
    │   └── app_localizations.dart     # English & Hindi translation delegate
    ├── calculators/
    │   ├── ohm_calculator.dart        # Speaker impedance & wiring math
    │   ├── amplifier_calculator.dart  # Headroom & limiter calculations
    │   ├── top_speaker_calculator.dart# SPL & inverse square law
    │   ├── cable_loss_calculator.dart # Wire loop resistance & damping factor
    │   └── dmx_calculator.dart        # 512-ch patch calculation & universe allocator
    ├── widgets/
    │   ├── status_badge.dart          # Green (Safe), Yellow (Warn), Red (Danger)
    │   └── tool_card.dart             # Touch ripple cards with Royal Blue theme
    └── screens/
        ├── home_screen.dart           # Home view with category chips & cards
        ├── more_tools_screen.dart     # Searchable tools catalogue
        ├── settings_screen.dart       # Language selector & app services
        ├── ohm_calculator_screen.dart
        ├── amplifier_calculator_screen.dart
        ├── top_speaker_screen.dart
        ├── cable_loss_screen.dart
        └── dmx_screen.dart
\`\`\`

---

## 🚀 Building & Running on Android

### 1. Prerequisites
- Flutter SDK (version >= 3.2.0)
- Android Studio with Android SDK (API 34+)

### 2. Get Dependencies
\`\`\`bash
cd flutter_app
flutter pub get
\`\`\`

### 3. Run in Debug Mode
Connect an Android device or start an Android emulator:
\`\`\`bash
flutter run
\`\`\`

### 4. Build Release APK (Direct Install)
\`\`\`bash
flutter build apk --release
\`\`\`
Output APK: `build/app/outputs/flutter-apk/app-release.apk`

### 5. Build Google Play App Bundle (.aab)
\`\`\`bash
flutter build appbundle --release
\`\`\`
Output AAB: `build/app/outputs/bundle/release/app-release.aab`
Upload this bundle to the **Google Play Console** for store distribution.

---

## 🔌 Future Scalability Ready
- **AdMob**: Plug into `main.dart` using `google_mobile_ads`.
- **RevenueCat**: In-app purchase hooks prepared in `settings_screen.dart`.
- **Firebase Analytics**: Can be wired into the service layer without modifying UI screens.
