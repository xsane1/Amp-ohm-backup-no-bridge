import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'localization/app_localizations.dart';
import 'screens/home_screen.dart';
import 'screens/splash_screen.dart';
import 'screens/history_screen.dart';
import 'screens/guide_screen.dart';
import 'services/preference_service.dart';
import 'services/subscription_service.dart';
import 'services/analytics_service.dart';
import 'services/history_service.dart';
import 'services/admob_service.dart';
import 'utils/app_typography.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Color(0xFF070B14),
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  final prefService = PreferenceService();
  await prefService.init();

  final adMobService = AdMobService();
  await adMobService.init();

  final historyService = HistoryService();
  await historyService.init();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: prefService),
        ChangeNotifierProvider.value(value: adMobService),
        ChangeNotifierProvider.value(value: historyService),
        ChangeNotifierProvider(create: (_) => SubscriptionService()),
        ChangeNotifierProvider(create: (_) => AnalyticsService()),
      ],
      child: const AmpOhmApp(),
    ),
  );
}

class AmpOhmApp extends StatelessWidget {
  static final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  const AmpOhmApp({super.key});

  @override
  Widget build(BuildContext context) {
    final prefService = Provider.of<PreferenceService>(context);

    return MaterialApp(
      navigatorKey: navigatorKey,
      title: 'AMP OHM',
      debugShowCheckedModeBanner: false,
      locale: prefService.locale,
      themeMode: prefService.isNightMode ? ThemeMode.dark : ThemeMode.light,
      supportedLocales: const [
        Locale('en', ''),
        Locale('hi', ''),
      ],
      localizationsDelegates: const [
        AppLocalizationsDelegate(),
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        useMaterial3: true,
        fontFamilyFallback: AppTypography.hindiFontFallback,
        brightness: Brightness.light,
        scaffoldBackgroundColor: const Color(0xFFD6E4F4),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF2563EB), // Royal Blue
          brightness: Brightness.light,
          primary: const Color(0xFF2563EB),
          secondary: const Color(0xFFFBBF24), // Amber / Gold
          surface: Colors.white,
          onSurface: const Color(0xFF0F172A),
        ),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        fontFamilyFallback: AppTypography.hindiFontFallback,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF070B14),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF38BDF8), // Sky Blue in dark mode
          secondary: Color(0xFFFBBF24), // Gold
          surface: Color(0xFF101726),
          onSurface: Colors.white,
        ),
      ),
      home: const SplashScreen(),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = const [
    HomeScreen(),
    HistoryScreen(),
    GuideScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final prefService = Provider.of<PreferenceService>(context);
    final isNight = prefService.isNightMode;
    final isHindi = prefService.locale.languageCode == 'hi';

    return Scaffold(
      backgroundColor: isNight ? const Color(0xFF070B14) : const Color(0xFFD6E4F4),
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: isNight ? const Color(0xFF070B14) : Colors.white,
          border: Border(
            top: BorderSide(
              color: isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0),
              width: 0.8,
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: isNight ? Colors.black.withOpacity(0.5) : const Color(0x0E0F172A),
              blurRadius: 16,
              offset: const Offset(0, -4),
            ),
          ],
        ),
        child: SafeArea(
          top: false,
          child: SizedBox(
            height: 64,
            child: Row(
              children: [
                // Tab 1: Home
                Expanded(
                  child: _buildNavItem(
                    index: 0,
                    icon: Icons.home_outlined,
                    activeIcon: Icons.home_rounded,
                    label: isHindi ? 'होम' : 'Home',
                    isNight: isNight,
                    isHindi: isHindi,
                  ),
                ),
                // Tab 2: History
                Expanded(
                  child: _buildNavItem(
                    index: 1,
                    icon: Icons.history_rounded,
                    activeIcon: Icons.history_rounded,
                    label: isHindi ? 'हिस्ट्री' : 'History',
                    isNight: isNight,
                    isHindi: isHindi,
                  ),
                ),
                // Tab 3: Guide
                Expanded(
                  child: _buildNavItem(
                    index: 2,
                    icon: Icons.menu_book_outlined,
                    activeIcon: Icons.menu_book_rounded,
                    label: isHindi ? 'गाइड' : 'Guide',
                    isNight: isNight,
                    isHindi: isHindi,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem({
    required int index,
    required IconData icon,
    required IconData activeIcon,
    required String label,
    required bool isNight,
    required bool isHindi,
  }) {
    final isSelected = _currentIndex == index;

    final activeColor = isNight ? const Color(0xFF38BDF8) : const Color(0xFF2563EB);
    final inactiveColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);
    final activeBg = isNight ? const Color(0x330284C7) : const Color(0xFFEFF6FF);

    return InkWell(
      onTap: () => setState(() => _currentIndex = index),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 4),
            decoration: BoxDecoration(
              color: isSelected ? activeBg : Colors.transparent,
              borderRadius: BorderRadius.circular(16),
              border: isSelected
                  ? Border.all(
                      color: isNight ? const Color(0x4438BDF8) : const Color(0xFFBFDBFE),
                      width: 0.8,
                    )
                  : null,
            ),
            child: Icon(
              isSelected ? activeIcon : icon,
              size: 22,
              color: isSelected ? activeColor : inactiveColor,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              fontWeight: isSelected
                  ? (isHindi ? FontWeight.w600 : FontWeight.w800)
                  : (isHindi ? FontWeight.w500 : FontWeight.w600),
              color: isSelected ? activeColor : inactiveColor,
              fontFamilyFallback: AppTypography.hindiFontFallback,
            ),
          ),
        ],
      ),
    );
  }
}
