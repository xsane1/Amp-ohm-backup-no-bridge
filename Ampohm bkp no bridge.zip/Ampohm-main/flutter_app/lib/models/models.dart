import 'dart:math';

enum StatusLevel {
  safe,
  warning,
  danger,
  info,
}

enum OhmLoadCategory {
  extreme,       // < 2Ω (Red / Danger)
  requires2Ohm,  // 2Ω (Yellow / Caution)
  highCurrent,   // > 2Ω and < 4Ω (Yellow / Caution)
  safe,          // 4Ω to 8Ω (Green / Safe)
  proLoad,       // > 8Ω and <= 16Ω (Blue / Info)
  uncommon,      // > 16Ω (Blue / Info)
}

extension OhmLoadCategoryExtension on OhmLoadCategory {
  String get displayName {
    switch (this) {
      case OhmLoadCategory.extreme:
        return 'EXTREME LOAD (< 2Ω DANGER)';
      case OhmLoadCategory.requires2Ohm:
        return 'REQUIRED 2 OHM STABLE AMPLIFIER';
      case OhmLoadCategory.highCurrent:
        return 'HIGH CURRENT (2Ω STABLE AMP REQUIRED)';
      case OhmLoadCategory.safe:
        return 'SAFE OPERATING LOAD (4Ω–8Ω)';
      case OhmLoadCategory.proLoad:
        return 'PROFESSIONAL LOAD (8Ω–16Ω)';
      case OhmLoadCategory.uncommon:
        return 'UNCOMMON LOAD (> 16Ω)';
    }
  }
}

enum WiringConfiguration {
  parallel,
  series,
  seriesParallel,
}

enum ApplicationUsageType {
  liveSound,
  djElectronic,
  speechMonitor,
}

class OhmCalculationResult {
  final double totalImpedance;
  final double speakerRms;
  final int speakerCount;
  final double totalSystemRms;
  final double perSpeakerPower;
  final WiringConfiguration wiring;
  final double speakerImpedance;
  final OhmLoadCategory loadCategory;
  final StatusLevel status;
  final String statusTitleKey;
  final String statusDescriptionKey;
  final bool canRecommendAmp;

  const OhmCalculationResult({
    required this.totalImpedance,
    required this.speakerRms,
    required this.speakerCount,
    required this.totalSystemRms,
    required this.perSpeakerPower,
    required this.wiring,
    required this.speakerImpedance,
    required this.loadCategory,
    required this.status,
    required this.statusTitleKey,
    required this.statusDescriptionKey,
    required this.canRecommendAmp,
  });

  String get formattedImpedance => totalImpedance.truncateToDouble() == totalImpedance
      ? totalImpedance.toInt().toString()
      : totalImpedance.toStringAsFixed(2);

  double get totalRms => totalSystemRms;
}

class AmpCalculationResult {
  final double speakerRms;
  final int speakerCount;
  final double totalSystemRms;
  final double speakerImpedance;
  final WiringConfiguration wiring;
  final double headroom;
  final double finalLoad;
  final double recommendedAmpPower;
  final OhmLoadCategory loadCategory;
  final StatusLevel status;
  final String statusTitleKey;
  final String statusDescriptionKey;
  final bool isRecommendationAvailable;

  const AmpCalculationResult({
    required this.speakerRms,
    required this.speakerCount,
    required this.totalSystemRms,
    required this.speakerImpedance,
    required this.wiring,
    required this.headroom,
    required this.finalLoad,
    required this.recommendedAmpPower,
    required this.loadCategory,
    required this.status,
    required this.statusTitleKey,
    required this.statusDescriptionKey,
    required this.isRecommendationAvailable,
  });

  double get headroomMultiplier => headroom;
  double get totalImpedance => finalLoad;
  double get recommendedPowerPerChannel => recommendedAmpPower;

  String get formattedImpedance => finalLoad.truncateToDouble() == finalLoad
      ? finalLoad.toInt().toString()
      : finalLoad.toStringAsFixed(2);

  static String formatWatts(double val) {
    if (val.truncateToDouble() == val) {
      return val.toInt().toString();
    }
    return val.toStringAsFixed(2);
  }

  String get formattedAmpPower => formatWatts(recommendedAmpPower);
  String get formattedTotalSystemRms => formatWatts(totalSystemRms);
  String get formattedSpeakerRms => formatWatts(speakerRms);
  double get recommendedContinuousPower => recommendedAmpPower;
}

class TopSpeakerResult {
  final double speakerRms;
  final int speakerCount;
  final double programPower;
  final double peakPower;
  final double totalRms;
  final double totalProgram;
  final double totalPeak;
  final double recommendedAmpPower;

  const TopSpeakerResult({
    required this.speakerRms,
    required this.speakerCount,
    required this.programPower,
    required this.peakPower,
    required this.totalRms,
    required this.totalProgram,
    required this.totalPeak,
    required this.recommendedAmpPower,
  });

  double get suggestedAmpPower => recommendedAmpPower;
  double get totalRmsPower => totalRms;
}

class CableSizeAnalysis {
  final double size;
  final String awg;
  final double loopResistance;
  final double resistanceRatioPercent;
  final double actualPowerLossPercent;
  final double levelLossDb;
  final double voltageDrop;
  final double powerLossWatts;
  final double powerDeliveredWatts;
  final double powerLossPercent;
  final double estimatedEfficiency;
  final bool isCompliant;
  final String statusBadge; // 'excellent', 'recommended', 'acceptable', 'high_loss', 'not_recommended'
  final String badgeLabel;

  const CableSizeAnalysis({
    required this.size,
    required this.awg,
    required this.loopResistance,
    this.resistanceRatioPercent = 0.0,
    this.actualPowerLossPercent = 0.0,
    this.levelLossDb = 0.0,
    required this.voltageDrop,
    required this.powerLossWatts,
    this.powerDeliveredWatts = 0.0,
    required this.powerLossPercent,
    required this.estimatedEfficiency,
    this.isCompliant = true,
    required this.statusBadge,
    required this.badgeLabel,
  });
}

class CableLossResult {
  final double cableLength;
  final double power;
  final double load;
  final double cableSize;
  final double loopResistance;
  final double resistanceRatioPercent;
  final double actualPowerLossPercent;
  final double levelLossDb;
  final double voltageDrop;
  final double voltageDropPercent;
  final double powerLossWatts;
  final double powerLossPercent;
  final double estimatedEfficiency;
  final double powerDeliveredWatts;
  final double recommendedCableSize;
  final String warningLevel; // 'green', 'yellow', 'red'
  final String statusTitleKey;
  final String statusMessageKey;
  final String material; // 'copper' or 'cca'
  final double maxAcceptableLoss;
  final double? minimumAcceptableSize;
  final double? professionalChoiceSize;
  final List<CableSizeAnalysis> allSizes;
  final bool meetsTarget;
  final int speakerQuantity;
  final double perSpeakerImpedance;
  final String wiring;

  const CableLossResult({
    required this.cableLength,
    required this.power,
    required this.load,
    required this.cableSize,
    required this.loopResistance,
    this.resistanceRatioPercent = 0.0,
    this.actualPowerLossPercent = 0.0,
    this.levelLossDb = 0.0,
    required this.voltageDrop,
    required this.voltageDropPercent,
    required this.powerLossWatts,
    required this.powerLossPercent,
    required this.estimatedEfficiency,
    this.powerDeliveredWatts = 0.0,
    required this.recommendedCableSize,
    required this.warningLevel,
    required this.statusTitleKey,
    required this.statusMessageKey,
    this.material = 'copper',
    this.maxAcceptableLoss = 5.0,
    this.minimumAcceptableSize,
    this.professionalChoiceSize,
    this.allSizes = const [],
    this.meetsTarget = true,
    this.speakerQuantity = 1,
    this.perSpeakerImpedance = 8.0,
    this.wiring = 'parallel',
  });

  double get speakerLoad => load;
  double get efficiencyPercent => estimatedEfficiency;
  double get powerAtSpeakerWatts => powerDeliveredWatts > 0 ? powerDeliveredWatts : double.parse((power - powerLossWatts).clamp(0, power).toStringAsFixed(1));
  String get recommendedGauge => '${recommendedCableSize} mm²';
  String get materialType => material;
  double get lossPercentage => powerLossPercent;
  double get powerLostWatts => powerLossWatts;
}

class DmxFixtureSequence {
  final int fixtureNumber;
  final int startAddress;
  final int endAddress;
  final int nextAddress;
  final String rangeString;

  const DmxFixtureSequence({
    required this.fixtureNumber,
    required this.startAddress,
    required this.endAddress,
    required this.nextAddress,
    required this.rangeString,
  });
}

class DmxResult {
  final int currentAddress;
  final int channelCount;
  final int nextFixtureAddress;
  final String addressRange;
  final int endAddress;
  final bool isValid;
  final List<DmxFixtureSequence> subsequentFixtures;
  final int fixtureCount;

  const DmxResult({
    required this.currentAddress,
    required this.channelCount,
    required this.nextFixtureAddress,
    required this.addressRange,
    required this.endAddress,
    required this.isValid,
    required this.subsequentFixtures,
    this.fixtureCount = 1,
  });

  int get startAddress => currentAddress;
  int get totalChannelsUsed => endAddress;
}

class DmxPatchEntry {
  final int fixtureIndex;
  final int startChannel;
  final int endChannel;
  final int universe;

  const DmxPatchEntry({
    required this.fixtureIndex,
    required this.startChannel,
    required this.endChannel,
    required this.universe,
  });
}
