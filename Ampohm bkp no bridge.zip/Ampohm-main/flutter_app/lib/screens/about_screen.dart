import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/preference_service.dart';
import '../widgets/calculator_hero_header.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final prefService = Provider.of<PreferenceService>(context);
    final isNight = prefService.isNightMode;
    final scaffoldBg = isNight ? const Color(0xFF0B111C) : const Color(0xFFF1F5F9);
    final sheetBg = isNight ? const Color(0xFF0F172A) : Colors.white;
    final cardBg = isNight ? const Color(0xFF141C30) : Colors.white;
    final cardBorder = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final titleColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final subColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);
    final bodyColor = isNight ? const Color(0xFFCBD5E1) : const Color(0xFF334155);

    return Scaffold(
      backgroundColor: scaffoldBg,
      body: SafeArea(
        child: Column(
          children: [
            // Hero Header
            CalculatorHeroHeader(
              title: 'About AMP OHM Toolkit',
              subtitle: 'Version 1.0.4 • Live Sound Engineering',
              onBack: () => Navigator.pop(context),
            ),

            // Curved Sheet
            Expanded(
              child: Transform.translate(
                offset: const Offset(0, -20),
                child: Container(
                  decoration: BoxDecoration(
                    color: sheetBg,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: isNight ? Colors.black.withOpacity(0.4) : const Color(0x140F172A),
                        blurRadius: 20,
                        offset: const Offset(0, -6),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(16, 24, 16, 32),
                      children: [
                        // Application & Version
                        Container(
                          padding: const EdgeInsets.all(18),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: cardBorder),
                            boxShadow: [
                              BoxShadow(
                                color: isNight ? Colors.black.withOpacity(0.2) : const Color(0x060F172A),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'APPLICATION NAME',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  color: subColor,
                                  letterSpacing: 1.1,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                'AMP OHM ProAudio Toolkit',
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w900,
                                  color: titleColor,
                                ),
                              ),
                              const SizedBox(height: 10),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF1D4ED8),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: const Text(
                                  'Version 1.0.4 (Production / Android Ready)',
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),

                        // Purpose & Mission
                        Container(
                          padding: const EdgeInsets.all(18),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: cardBorder),
                            boxShadow: [
                              BoxShadow(
                                color: isNight ? Colors.black.withOpacity(0.2) : const Color(0x060F172A),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'PURPOSE & MISSION',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  color: subColor,
                                  letterSpacing: 1.1,
                                ),
                              ),
                              const SizedBox(height: 10),
                              Text(
                                'ProAudio Toolkit is engineered specifically for live sound engineers, audio rental companies, DJ operators, and stage technicians.',
                                style: TextStyle(
                                  fontSize: 13,
                                  height: 1.5,
                                  color: bodyColor,
                                ),
                              ),
                              const SizedBox(height: 10),
                              Text(
                                'Designed to eliminate guessing under high-pressure gig conditions, the toolkit handles loudspeaker power ratings, amplifier sizing, cable line loss, impedance calculations, and DMX address configurations.',
                                style: TextStyle(
                                  fontSize: 13,
                                  height: 1.5,
                                  color: bodyColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),

                        // Developer Information
                        Container(
                          padding: const EdgeInsets.all(18),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: cardBorder),
                            boxShadow: [
                              BoxShadow(
                                color: isNight ? Colors.black.withOpacity(0.2) : const Color(0x060F172A),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'DEVELOPER INFORMATION',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  color: subColor,
                                  letterSpacing: 1.1,
                                ),
                              ),
                              const SizedBox(height: 10),
                              Text(
                                'AudioXpert',
                                style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  color: titleColor,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'Dedicated professional suite crafted for live sound engineers, DJs, festival crews, and stage technicians.',
                                style: TextStyle(fontSize: 12, height: 1.4, color: subColor),
                              ),
                              const SizedBox(height: 12),
                              Divider(height: 1, color: isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0)),
                              const SizedBox(height: 12),
                              Text(
                                'OFFICIAL CONNECT',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  color: subColor,
                                  letterSpacing: 1.1,
                                ),
                              ),
                              const SizedBox(height: 8),
                              _buildConnectRow(isNight, Icons.camera_alt_outlined, 'Instagram', '@audio_xpert', const Color(0xFFE1306C)),
                              const SizedBox(height: 6),
                              _buildConnectRow(isNight, Icons.video_library_rounded, 'YouTube', '@audioxpertt', const Color(0xFFEF4444)),
                              const SizedBox(height: 6),
                              _buildConnectRow(isNight, Icons.mail_outline_rounded, 'Email', 'audioxpert123@gmail.com', const Color(0xFF2563EB)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildConnectRow(bool isNight, IconData icon, String label, String handle, Color accent) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: isNight ? const Color(0xFF0F1626) : const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Icon(icon, size: 16, color: accent),
              const SizedBox(width: 8),
              Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: isNight ? Colors.white : const Color(0xFF334155),
                ),
              ),
            ],
          ),
          Text(
            handle,
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: accent),
          ),
        ],
      ),
    );
  }
}
