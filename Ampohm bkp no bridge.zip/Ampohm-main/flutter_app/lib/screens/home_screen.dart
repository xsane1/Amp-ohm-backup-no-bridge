import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/preference_service.dart';
import '../services/subscription_service.dart';
import '../services/admob_service.dart';
import '../widgets/equipment_artworks.dart';
import '../widgets/ad_banner_widget.dart';
import 'ohm_calculator_screen.dart';
import 'amplifier_calculator_screen.dart';
import 'cable_loss_screen.dart';
import 'dmx_screen.dart';
import 'settings_screen.dart';
import 'paywall_screen.dart';
import '../utils/app_typography.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  void _openCalculator(Widget screen) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => screen));
  }

  @override
  Widget build(BuildContext context) {
    final prefService = Provider.of<PreferenceService>(context);
    final isHindi = prefService.locale.languageCode == 'hi';
    final isNight = prefService.isNightMode;

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: isNight
              ? const [
                  Color(0xFF0B111C),
                  Color(0xFF070B12),
                  Color(0xFF030508),
                ]
              : const [
                  Color(0xFFE6EFF8),
                  Color(0xFFDDE6F2),
                  Color(0xFFD4E1EE),
                ],
        ),
      ),
      child: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 6, 16, 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // 1. TOP HEADER: Brand Logo Pill + AMP OHM Typography + 3 Pill Buttons
              Padding(
                padding: const EdgeInsets.only(top: 2, bottom: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                              // Brand Mark: Royal Blue Vertical Pill with Gold Cap + Text
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(right: 6),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(9),
                                child: Image.asset(
                                  'assets/images/app_logo.png',
                                  width: 38,
                                  height: 38,
                                  fit: BoxFit.contain,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Flexible(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    RichText(
                                      text: TextSpan(
                                        style: const TextStyle(
                                          fontSize: 19,
                                          fontWeight: FontWeight.w900,
                                          letterSpacing: -0.4,
                                          height: 1.0,
                                        ),
                                        children: [
                                          TextSpan(
                                            text: 'AMP ',
                                            style: TextStyle(
                                              color: isNight ? Colors.white : const Color(0xFF0F172A),
                                            ),
                                          ),
                                          TextSpan(
                                            text: 'OHM',
                                            style: TextStyle(
                                              color: isNight ? const Color(0xFF38BDF8) : const Color(0xFF2563EB),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(height: 2),
                                    Text(
                                      'Audio & Lighting Tools',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontSize: 9.5,
                                        fontWeight: FontWeight.w600,
                                        color: isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B),
                                        letterSpacing: -0.2,
                                        height: 1.0,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      // Right Actions: 4 Floating Buttons (King/Pro + Moon/Sun + Language + Settings)
                      Row(
                        children: [
                          // 0. King Crown (Premium Pro Subscription) Button
                          _buildHeaderCircularButton(
                            isNight: isNight,
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (_) => const PaywallScreen()),
                              );
                            },
                            bgColor: isNight ? const Color(0xFF261D0F) : const Color(0xFFFFFBEB),
                            borderColor: isNight
                                ? const Color(0xFFF59E0B).withOpacity(0.45)
                                : const Color(0xFFFDE68A),
                            child: const KingCrownIcon(size: 18),
                          ),
                          const SizedBox(width: 7),

                          // 1. Day / Night Toggle Circular Button
                          _buildHeaderCircularButton(
                            isNight: isNight,
                            onTap: () => prefService.toggleTheme(),
                            child: Icon(
                              isNight ? Icons.light_mode_rounded : Icons.nightlight_round,
                              size: 16,
                              color: isNight ? const Color(0xFFFBBF24) : const Color(0xFF334155),
                            ),
                          ),
                          const SizedBox(width: 7),

                          // 2. Bilingual Hindi / ENG Switcher Pill
                          InkWell(
                            onTap: () {
                              final nextLang = isHindi ? 'en' : 'hi';
                              prefService.setLocale(Locale(nextLang, ''));
                            },
                            borderRadius: BorderRadius.circular(20),
                            child: Container(
                              height: 36,
                              padding: const EdgeInsets.symmetric(horizontal: 11),
                              decoration: BoxDecoration(
                                color: isNight ? const Color(0xFF1E293B) : Colors.white,
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                  color: isNight ? const Color(0xFF334155) : Colors.white,
                                  width: 1.2,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: isNight ? Colors.black.withOpacity(0.3) : const Color(0x120F172A),
                                    blurRadius: 8,
                                    offset: const Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: Row(
                                children: [
                                  Icon(
                                    Icons.translate_rounded,
                                    size: 14.5,
                                    color: isNight ? const Color(0xFF38BDF8) : const Color(0xFF2563EB),
                                  ),
                                  const SizedBox(width: 5),
                                  Text(
                                    isHindi ? 'हिन्दी' : 'ENG',
                                    style: TextStyle(
                                      fontSize: 11.5,
                                      fontWeight: isHindi ? FontWeight.w600 : FontWeight.w800,
                                      color: isNight ? Colors.white : const Color(0xFF0F172A),
                                      fontFamilyFallback: AppTypography.hindiFontFallback,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(width: 7),

                          // 3. Settings Gear Circular Button
                          _buildHeaderCircularButton(
                            isNight: isNight,
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (_) => const SettingsScreen()),
                              );
                            },
                            child: Icon(
                              Icons.settings_outlined,
                              size: 17,
                              color: isNight ? const Color(0xFF94A3B8) : const Color(0xFF475569),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),



              // 2. SECTION: Audio Tools
              Padding(
                padding: const EdgeInsets.only(left: 2, top: 4, bottom: 8),
                child: Text(
                  isHindi ? 'ऑडियो टूल्स' : 'Audio Tools',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: isHindi ? FontWeight.w600 : FontWeight.w800,
                    color: isNight ? Colors.white : const Color(0xFF0F172A),
                    letterSpacing: isHindi ? 0.0 : -0.2,
                    fontFamilyFallback: AppTypography.hindiFontFallback,
                  ),
                ),
              ),

              // 3. ROW 1: OHM CALCULATOR & AMPLIFIER CALCULATOR (Two Grid Cards)
              Row(
                children: [
                  // Card 1: OHM CALCULATOR
                  Expanded(
                    child: _buildSquareCard(
                      isNight: isNight,
                      title: isHindi ? 'ओम\nकैलकुलेटर' : 'OHM\nCALCULATOR',
                      description: isHindi ? 'स्पीकर लोड (ओम)\nचेक करें' : 'Calculate speaker\nimpedance',
                      artwork: WooferArt(size: 88, isNightMode: isNight),
                      artRight: 0,
                      artBottom: 0,
                      onTap: () => _openCalculator(const OhmCalculatorScreen()),
                    ),
                  ),
                  const SizedBox(width: 12),

                  // Card 2: AMPLIFIER CALCULATOR
                  Expanded(
                    child: _buildSquareCard(
                      isNight: isNight,
                      title: isHindi ? 'एम्पलीफायर\nकैलकुलेटर' : 'AMPLIFIER\nCALCULATOR',
                      description: isHindi ? 'सही एम्पलीफायर\nपावर चुनें' : 'Match amp power\ncorrectly',
                      artwork: RackAmplifierArt(width: 104, height: 86, isNightMode: isNight),
                      artRight: -2,
                      artBottom: 0,
                      onTap: () => _openCalculator(const AmplifierCalculatorScreen()),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 12),

              // 4. CARD 3: SPEAKER CABLE LOSS CALCULATOR (Full Width Card)
              _buildWideCard(
                isNight: isNight,
                title: isHindi ? 'स्पीकर केबल लॉस कैलकुलेटर' : 'SPEAKER CABLE LOSS CALCULATOR',
                description: isHindi
                    ? 'सही केबल साइज चुनें और पावर लॉस रोकें'
                    : 'Choose right cable size & avoid power loss',
                artwork: CableLossArt(size: 118, isNightMode: isNight),
                artRight: 6,
                artBottom: 2,
                onTap: () => _openCalculator(const CableLossScreen()),
              ),

              const SizedBox(height: 20),

              // 5. SECTION: Lighting Tools
              Padding(
                padding: const EdgeInsets.only(left: 2, bottom: 8),
                child: Text(
                  isHindi ? 'लाइटिंग टूल्स' : 'Lighting Tools',
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: isHindi ? FontWeight.w600 : FontWeight.w800,
                    color: isNight ? Colors.white : const Color(0xFF0F172A),
                    letterSpacing: isHindi ? 0.0 : -0.2,
                    fontFamilyFallback: AppTypography.hindiFontFallback,
                  ),
                ),
              ),

              // 6. CARD 4: DMX ADDRESS CALCULATOR
              _buildWideCard(
                isNight: isNight,
                title: isHindi ? 'DMX एड्रेस कैलकुलेटर' : 'DMX ADDRESS CALCULATOR',
                description: isHindi ? 'लाइटिंग DMX एड्रेस सेट करें' : 'Calculate DMX address',
                artwork: DmxStageArt(size: 118, isNightMode: isNight),
                artRight: 12,
                artBottom: 4,
                onTap: () => _openCalculator(const DmxScreen()),
              ),
              ],
            ),
          ),
        ),
      );
  }

  // Helper: Header Circular Button
  Widget _buildHeaderCircularButton({
    required bool isNight,
    required VoidCallback onTap,
    required Widget child,
    Color? bgColor,
    Color? borderColor,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        width: 36,
        height: 36,
        decoration: BoxDecoration(
          color: bgColor ?? (isNight ? const Color(0xFF1E293B) : Colors.white),
          shape: BoxShape.circle,
          border: Border.all(
            color: borderColor ?? (isNight ? const Color(0xFF334155) : Colors.white),
            width: 1.2,
          ),
          boxShadow: [
            BoxShadow(
              color: isNight ? Colors.black.withOpacity(0.3) : const Color(0x120F172A),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Center(child: child),
      ),
    );
  }

  // Helper: Grid Card (OHM & AMPLIFIER, Height ~190px)
  Widget _buildSquareCard({
    required bool isNight,
    required String title,
    required String description,
    required Widget artwork,
    required double artRight,
    required double artBottom,
    required VoidCallback onTap,
  }) {
    final cardBg = isNight ? const Color(0xFF101726) : Colors.white;
    const borderColor = Colors.black;
    final accentBarColor = isNight ? const Color(0xFF38BDF8) : const Color(0xFF2563EB);
    final titleColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final descColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(24),
      child: Container(
        height: 190,
        decoration: BoxDecoration(
          color: cardBg,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: borderColor.withOpacity(0.65), width: 0.5),
          boxShadow: [
            BoxShadow(
              color: isNight ? Colors.black.withOpacity(0.5) : const Color(0x0E0F172A),
              blurRadius: 16,
              offset: const Offset(0, 4),
            ),
            BoxShadow(
              color: isNight ? Colors.transparent : const Color(0x060F172A),
              blurRadius: 4,
              offset: const Offset(0, 1),
            ),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          children: [
            // Equipment Artwork at Bottom Right Corner
            Positioned(
              right: artRight,
              bottom: artBottom,
              child: IgnorePointer(child: artwork),
            ),

            // Top-Right Circular Amber Button
            Positioned(
              top: 10,
              right: 10,
              child: _buildAmberArrowButton(),
            ),

            // Content Area (Top-Left)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 38, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Blue Accent Pill Bar
                  Container(
                    width: 26,
                    height: 4,
                    decoration: BoxDecoration(
                      color: accentBarColor,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(height: 8),

                  // Title
                  Builder(
                    builder: (context) {
                      final isHindiTitle = title.contains(RegExp(r'[\u0900-\u097F]'));
                      return Text(
                        title,
                        style: TextStyle(
                          fontSize: isHindiTitle ? 15.5 : 16.5,
                          fontWeight: isHindiTitle ? FontWeight.w600 : FontWeight.w800,
                          color: titleColor,
                          letterSpacing: isHindiTitle ? 0.0 : -0.3,
                          height: isHindiTitle ? 1.25 : 1.15,
                          fontFamilyFallback: AppTypography.hindiFontFallback,
                        ),
                        maxLines: 2,
                      );
                    },
                  ),
                  const SizedBox(height: 5),

                  // Description
                  Builder(
                    builder: (context) {
                      final isHindiDesc = description.contains(RegExp(r'[\u0900-\u097F]'));
                      return Text(
                        description,
                        style: TextStyle(
                          fontSize: 11.5,
                          fontWeight: isHindiDesc ? FontWeight.w500 : FontWeight.w600,
                          color: descColor,
                          height: isHindiDesc ? 1.25 : 1.2,
                          fontFamilyFallback: AppTypography.hindiFontFallback,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Helper: Full Width Card (CABLE LOSS & DMX ADDRESS, Height ~142px)
  Widget _buildWideCard({
    required bool isNight,
    required String title,
    required String description,
    required Widget artwork,
    required double artRight,
    required double artBottom,
    required VoidCallback onTap,
  }) {
    final cardBg = isNight ? const Color(0xFF101726) : Colors.white;
    const borderColor = Colors.black;
    final accentBarColor = isNight ? const Color(0xFF38BDF8) : const Color(0xFF2563EB);
    final titleColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final descColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    final isHindiTitle = title.contains(RegExp(r'[\u0900-\u097F]'));
    final isHindiDesc = description.contains(RegExp(r'[\u0900-\u097F]'));

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(24),
      child: Container(
        height: 142,
        decoration: BoxDecoration(
          color: cardBg,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: borderColor.withOpacity(0.65), width: 0.5),
          boxShadow: [
            BoxShadow(
              color: isNight ? Colors.black.withOpacity(0.5) : const Color(0x0E0F172A),
              blurRadius: 16,
              offset: const Offset(0, 4),
            ),
            BoxShadow(
              color: isNight ? Colors.transparent : const Color(0x060F172A),
              blurRadius: 4,
              offset: const Offset(0, 1),
            ),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          children: [
            // Equipment Artwork at Bottom Right
            Positioned(
              right: artRight,
              bottom: artBottom,
              child: IgnorePointer(child: artwork),
            ),

            // Top-Right Circular Amber Button
            Positioned(
              top: 10,
              right: 10,
              child: _buildAmberArrowButton(),
            ),

            // Content Area (Top-Left)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 125, 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Blue Accent Pill Bar
                  Container(
                    width: 26,
                    height: 4,
                    decoration: BoxDecoration(
                      color: accentBarColor,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(height: 7),

                  // Title
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: isHindiTitle ? 15 : 16,
                      fontWeight: isHindiTitle ? FontWeight.w600 : FontWeight.w800,
                      color: titleColor,
                      letterSpacing: isHindiTitle ? 0.0 : -0.2,
                      height: isHindiTitle ? 1.25 : 1.15,
                      fontFamilyFallback: AppTypography.hindiFontFallback,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 5),

                  // Description
                  Text(
                    description,
                    style: TextStyle(
                      fontSize: 11.5,
                      fontWeight: isHindiDesc ? FontWeight.w500 : FontWeight.w600,
                      color: descColor,
                      height: isHindiDesc ? 1.25 : 1.2,
                      fontFamilyFallback: AppTypography.hindiFontFallback,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Circular Amber Action Arrow Button in Card Corner
  Widget _buildAmberArrowButton() {
    return Container(
      width: 32,
      height: 32,
      decoration: BoxDecoration(
        color: const Color(0xFFFBBF24),
        shape: BoxShape.circle,
        border: Border.all(color: const Color(0xFFFDE68A), width: 0.8),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.14),
            blurRadius: 4,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: const Center(
        child: Icon(
          Icons.chevron_right_rounded,
          size: 22,
          color: Color(0xFF0F172A),
        ),
      ),
    );
  }
}

/// Custom Vector King Crown Icon in Gold / Amber
class KingCrownIcon extends StatelessWidget {
  final double size;
  final Color? color;

  const KingCrownIcon({super.key, this.size = 18, this.color});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: Size(size, size * 0.85),
      painter: _CrownPainter(color: color ?? const Color(0xFFF59E0B)),
    );
  }
}

class _CrownPainter extends CustomPainter {
  final Color color;

  _CrownPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final w = size.width;
    final h = size.height;

    final path = Path();
    // Base bottom
    path.moveTo(w * 0.12, h * 0.88);
    path.lineTo(w * 0.88, h * 0.88);
    // Right upward to right peak
    path.lineTo(w * 0.94, h * 0.34);
    // Inner right valley
    path.lineTo(w * 0.68, h * 0.58);
    // Center high king peak
    path.lineTo(w * 0.50, h * 0.18);
    // Inner left valley
    path.lineTo(w * 0.32, h * 0.58);
    // Left upward to left peak
    path.lineTo(w * 0.06, h * 0.34);
    path.close();

    canvas.drawPath(path, paint);

    // Jewel pearls on top of the 3 main peaks
    final pearlPaint = Paint()
      ..color = const Color(0xFFFBBF24)
      ..style = PaintingStyle.fill;

    canvas.drawCircle(Offset(w * 0.06, h * 0.32), w * 0.07, pearlPaint);
    canvas.drawCircle(Offset(w * 0.50, h * 0.16), w * 0.08, pearlPaint);
    canvas.drawCircle(Offset(w * 0.94, h * 0.32), w * 0.07, pearlPaint);

    // Bottom decorative band
    final bandPaint = Paint()
      ..color = const Color(0xFFD97706)
      ..style = PaintingStyle.stroke
      ..strokeWidth = w * 0.08
      ..strokeCap = StrokeCap.round;

    canvas.drawLine(
      Offset(w * 0.18, h * 0.88),
      Offset(w * 0.82, h * 0.88),
      bandPaint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
