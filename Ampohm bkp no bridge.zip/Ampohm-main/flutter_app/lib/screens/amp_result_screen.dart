import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/preference_service.dart';
import '../localization/app_localizations.dart';
import '../models/models.dart';
import '../widgets/calculator_hero_header.dart';
import '../widgets/share_result_button.dart';
import '../widgets/ad_banner_widget.dart';
import '../utils/app_typography.dart';

class AmpResultScreen extends StatelessWidget {
  final AmpCalculationResult result;

  const AmpResultScreen({
    super.key,
    required this.result,
  });

  String _generateShareText() {
    final wiringStr = result.wiring == WiringConfiguration.parallel ? 'Parallel' : 'Series';
    final ampPowerLine = result.isRecommendationAvailable
        ? '• RECOMMENDED AMP POWER: ${result.formattedAmpPower}W RMS @ ${result.formattedImpedance}Ω'
        : '• RECOMMENDED AMP POWER: Not Recommended (Sub-2Ω Load)';
    return '''
==============================
AMP OHM - AMPLIFIER MATCHING REPORT
==============================
System Specifications:
• Driver Configuration: ${result.speakerCount} ${result.speakerCount == 1 ? "Speaker" : "Speakers"} @ ${result.speakerImpedance % 1 == 0 ? result.speakerImpedance.toInt() : result.speakerImpedance.toStringAsFixed(1)}Ω
• Cabinet Wiring: $wiringStr
• Combined Channel Load: ${result.formattedImpedance}Ω
• Speaker RMS Power: ${result.formattedSpeakerRms}W each (${result.formattedTotalSystemRms}W Total)
• Headroom Applied: ${result.headroom}x (${((result.headroom - 1.0) * 100).toInt()}% Safety Headroom)

Amplifier Sizing:
$ampPowerLine
• System Classification: ${result.loadCategory.displayName}

Calculated with AMP OHM - Developed by AudioXpert
━━━━━━━━━━━━━━━━━━
📱 AMP OHM App:
https://play.google.com/store/apps/details?id=com.ampohm.app

📸 Instagram:
https://instagram.com/audio_xpert

▶️ YouTube:
https://youtube.com/@audioxpertt
==============================''';
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    final isHindi = Localizations.localeOf(context).languageCode == 'hi';

    // Color and visuals matching web classification exactly
    List<Color> bannerGradient;
    Color badgeBg;
    Color badgeColor;
    Color borderColor;
    IconData statusIcon;

    switch (result.loadCategory) {
      case OhmLoadCategory.extreme:
        bannerGradient = const [Color(0xFF550C16), Color(0xFF821422), Color(0xFF36080E)];
        badgeBg = const Color(0xFFDC2626);
        badgeColor = Colors.white;
        borderColor = const Color(0xFFEF4444);
        statusIcon = Icons.warning_amber_rounded;
        break;
      case OhmLoadCategory.requires2Ohm:
      case OhmLoadCategory.highCurrent:
      case OhmLoadCategory.uncommon:
        bannerGradient = const [Color(0xFF522004), Color(0xFF85360A), Color(0xFF331302)];
        badgeBg = const Color(0xFFF59E0B);
        badgeColor = const Color(0xFF0F172A);
        borderColor = const Color(0xFFFBBF24);
        statusIcon = Icons.warning_amber_rounded;
        break;
      case OhmLoadCategory.safe:
      case OhmLoadCategory.proLoad:
      default:
        bannerGradient = const [Color(0xFF064E3B), Color(0xFF065F46), Color(0xFF022C22)];
        badgeBg = const Color(0xFF059669);
        badgeColor = Colors.white;
        borderColor = const Color(0xFF34D399);
        statusIcon = Icons.check_circle_rounded;
        break;
    }

    String getLocalizedTitle() {
      switch (result.statusTitleKey) {
        case 'ampClassExtremeTitle':
          return l10n.ampClassExtremeTitle;
        case 'ohmClassRequires2Ohm':
          return l10n.ohmClassRequires2Ohm;
        case 'ohmClassHighCurrent':
          return l10n.ohmClassHighCurrent;
        case 'ohmClassSafe':
          return l10n.ohmClassSafe;
        case 'ohmClassProLoad':
          return l10n.ohmClassProLoad;
        case 'ampClassUncommonTitle':
          return l10n.ampClassUncommonTitle;
        default:
          return result.statusTitleKey;
      }
    }

    String getLocalizedDesc() {
      switch (result.statusDescriptionKey) {
        case 'ampClassExtremeMsg':
          return l10n.ampClassExtremeMsg;
        case 'ohmClassRequires2OhmMsg':
          return l10n.ohmClassRequires2OhmMsg;
        case 'ohmClassHighCurrentMsg':
          return l10n.ohmClassHighCurrentMsg;
        case 'ohmClassSafeMsg':
          return l10n.ohmClassSafeMsg;
        case 'ohmClass16OhmMsg':
          return l10n.ohmClass16OhmMsg;
        case 'ampClass16OhmMsg':
          return l10n.ampClass16OhmMsg;
        case 'ohmClassProLoadMsg':
          return l10n.ohmClassProLoadMsg;
        case 'ampClassUncommonMsg':
          return l10n.ampClassUncommonMsg;
        default:
          return result.statusDescriptionKey;
      }
    }

    final localizedTitle = getLocalizedTitle();
    final localizedDesc = AppLocalizations.interpolateLoad(getLocalizedDesc(), result.finalLoad);

    final prefService = Provider.of<PreferenceService>(context);
    final isNight = prefService.isNightMode;

    final bgColor = isNight ? const Color(0xFF070B14) : const Color(0xFFF1F5F9);
    final sheetBg = isNight ? const Color(0xFF0E1526) : Colors.white;
    final cardBg = isNight ? const Color(0xFF141C30) : Colors.white;
    final borderColorCard = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final textColor = isNight ? Colors.white : const Color(0xFF0F172A);

    return Scaffold(
      backgroundColor: bgColor,
      body: SafeArea(
        child: Column(
          children: [
            // 1. Curved Hero Header exactly like Web
            CalculatorHeroHeader(
              title: l10n.ampResultTitle,
              subtitle: isHindi
                  ? 'सही एम्पलीफायर पावर और लोड डिटेल्स'
                  : 'Recommended amplifier power & circuit analysis',
              onBack: () => Navigator.pop(context),
            ),

            // 2. Curved Sheet for Results
            Expanded(
              child: Transform.translate(
                offset: const Offset(0, -20),
                child: Container(
                  decoration: BoxDecoration(
                    color: sheetBg,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: isNight ? Colors.black.withOpacity(0.5) : const Color(0x140F172A),
                        blurRadius: 20,
                        offset: const Offset(0, -6),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
                      children: [
                        // CARD 1: RECOMMENDED AMPLIFIER POWER
                        if (result.isRecommendationAvailable) ...[
                          Container(
                            padding: const EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: bannerGradient,
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(28),
                              border: Border.all(color: borderColor.withOpacity(0.8), width: 1.5),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.2),
                                  blurRadius: 16,
                                  offset: const Offset(0, 6),
                                ),
                              ],
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Wrap(
                                  alignment: WrapAlignment.spaceBetween,
                                  crossAxisAlignment: WrapCrossAlignment.center,
                                  spacing: 8,
                                  runSpacing: 6,
                                  children: [
                                    Wrap(
                                      crossAxisAlignment: WrapCrossAlignment.center,
                                      spacing: 6,
                                      runSpacing: 4,
                                      children: [
                                        Text(
                                          l10n.ampCard1Title.toUpperCase(),
                                          style: TextStyle(
                                            fontSize: 11,
                                            fontWeight: isHindi ? FontWeight.w600 : FontWeight.bold,
                                            letterSpacing: isHindi ? 0.0 : 0.8,
                                            color: Colors.white.withOpacity(0.8),
                                            fontFamilyFallback: AppTypography.hindiFontFallback,
                                          ),
                                        ),
                                        Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                          decoration: BoxDecoration(
                                            color: Colors.white.withOpacity(0.2),
                                            borderRadius: BorderRadius.circular(12),
                                          ),
                                          child: Text(
                                            l10n.perChannelBadge.toUpperCase(),
                                            style: const TextStyle(
                                              fontSize: 9.5,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: badgeBg,
                                        borderRadius: BorderRadius.circular(16),
                                      ),
                                      child: Text(
                                        '${result.headroomMultiplier}X HEADROOM',
                                        style: TextStyle(
                                          fontSize: 10.5,
                                          fontWeight: FontWeight.w900,
                                          color: badgeColor,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),

                                const SizedBox(height: 12),

                                // Big Wattage Display (FittedBox scales down cleanly to prevent any overflow)
                                FittedBox(
                                  fit: BoxFit.scaleDown,
                                  alignment: Alignment.centerLeft,
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment: CrossAxisAlignment.baseline,
                                    textBaseline: TextBaseline.alphabetic,
                                    children: [
                                      Text(
                                        result.formattedAmpPower,
                                        style: const TextStyle(
                                          fontSize: 48,
                                          fontWeight: FontWeight.w900,
                                          color: Colors.white,
                                          letterSpacing: -1.0,
                                          height: 1.0,
                                        ),
                                      ),
                                      const SizedBox(width: 6),
                                      const Text(
                                        'WATTS',
                                        style: TextStyle(
                                          fontSize: 22,
                                          fontWeight: FontWeight.w900,
                                          color: Color(0xFFFBBF24),
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Text(
                                        '@ ${result.totalImpedance.toStringAsFixed(result.totalImpedance.truncateToDouble() == result.totalImpedance ? 0 : 2)}Ω',
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.white.withOpacity(0.85),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),

                                const SizedBox(height: 14),

                                // Status description note
                                Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: Colors.black.withOpacity(0.35),
                                    borderRadius: BorderRadius.circular(14),
                                    border: Border.all(color: Colors.white.withOpacity(0.12)),
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Icon(statusIcon, color: borderColor, size: 20),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              localizedTitle,
                                              style: TextStyle(
                                                fontSize: 12.5,
                                                fontWeight: FontWeight.bold,
                                                color: borderColor,
                                              ),
                                            ),
                                            const SizedBox(height: 2),
                                            Text(
                                              localizedDesc,
                                              style: TextStyle(
                                                fontSize: 11,
                                                color: Colors.white.withOpacity(0.9),
                                                height: 1.35,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 16),
                        ] else ...[
                          // EXTREME LOAD / DANGER WARNING BANNER (When Impedance < 2Ω or Uncommon)
                          Container(
                            padding: const EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: bannerGradient,
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(28),
                              border: Border.all(color: borderColor.withOpacity(0.8), width: 1.5),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.2),
                                  blurRadius: 16,
                                  offset: const Offset(0, 6),
                                ),
                              ],
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Wrap(
                                  alignment: WrapAlignment.spaceBetween,
                                  crossAxisAlignment: WrapCrossAlignment.center,
                                  spacing: 8,
                                  runSpacing: 6,
                                  children: [
                                    Wrap(
                                      crossAxisAlignment: WrapCrossAlignment.center,
                                      spacing: 6,
                                      runSpacing: 4,
                                      children: [
                                        Text(
                                          (isHindi ? 'लोड चेतावनी' : 'LOAD WARNING').toUpperCase(),
                                          style: TextStyle(
                                            fontSize: 11,
                                            fontWeight: FontWeight.bold,
                                            letterSpacing: 0.8,
                                            color: Colors.white.withOpacity(0.8),
                                          ),
                                        ),
                                        Container(
                                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                          decoration: BoxDecoration(
                                            color: Colors.white.withOpacity(0.2),
                                            borderRadius: BorderRadius.circular(12),
                                          ),
                                          child: Text(
                                            l10n.perChannelBadge.toUpperCase(),
                                            style: const TextStyle(
                                              fontSize: 9.5,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                      decoration: BoxDecoration(
                                        color: badgeBg,
                                        borderRadius: BorderRadius.circular(16),
                                      ),
                                      child: Text(
                                        localizedTitle.toUpperCase(),
                                        style: TextStyle(
                                          fontSize: 10.5,
                                          fontWeight: FontWeight.w900,
                                          color: badgeColor,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),

                                const SizedBox(height: 12),

                                // Big Impedance Display
                                FittedBox(
                                  fit: BoxFit.scaleDown,
                                  alignment: Alignment.centerLeft,
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment: CrossAxisAlignment.baseline,
                                    textBaseline: TextBaseline.alphabetic,
                                    children: [
                                      Text(
                                        result.totalImpedance.toStringAsFixed(2),
                                        style: const TextStyle(
                                          fontSize: 48,
                                          fontWeight: FontWeight.w900,
                                          color: Colors.white,
                                          letterSpacing: -1.0,
                                          height: 1.0,
                                        ),
                                      ),
                                      const SizedBox(width: 4),
                                      const Text(
                                        'Ω',
                                        style: TextStyle(
                                          fontSize: 26,
                                          fontWeight: FontWeight.bold,
                                          color: Color(0xFFFBBF24),
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Text(
                                        l10n.perChannelSuffix,
                                        style: TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w600,
                                          color: Colors.white.withOpacity(0.7),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),

                                const SizedBox(height: 14),

                                // Status description note
                                Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: Colors.black.withOpacity(0.35),
                                    borderRadius: BorderRadius.circular(14),
                                    border: Border.all(color: Colors.white.withOpacity(0.12)),
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Icon(statusIcon, color: borderColor, size: 22),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              localizedTitle,
                                              style: TextStyle(
                                                fontSize: 12.5,
                                                fontWeight: FontWeight.bold,
                                                color: borderColor,
                                              ),
                                            ),
                                            const SizedBox(height: 4),
                                            Text(
                                              localizedDesc,
                                              style: TextStyle(
                                                fontSize: 11,
                                                color: Colors.white.withOpacity(0.9),
                                                height: 1.35,
                                              ),
                                            ),
                                            const SizedBox(height: 8),
                                            Container(
                                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                              decoration: BoxDecoration(
                                                color: Colors.black.withOpacity(0.4),
                                                borderRadius: BorderRadius.circular(6),
                                              ),
                                              child: Text(
                                                l10n.ampCard1NotAvailable.toUpperCase(),
                                                style: const TextStyle(
                                                  fontSize: 10,
                                                  fontWeight: FontWeight.bold,
                                                  color: Color(0xFFF87171),
                                                  letterSpacing: 0.5,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 16),
                        ],

                        // Google AdMob Banner Centered directly below colored result box
                        const Center(
                          child: AdBannerWidget(placement: 'amp_result'),
                        ),

                        const SizedBox(height: 16),

                        // System Breakdown Card
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(color: borderColorCard),
                            boxShadow: [
                              BoxShadow(
                                color: isNight ? Colors.black.withOpacity(0.3) : const Color(0x080F172A),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(
                                    Icons.analytics_rounded,
                                    size: 16,
                                    color: isNight ? const Color(0xFF38BDF8) : const Color(0xFF2563EB),
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      l10n.ampCard2Title.toUpperCase(),
                                      style: TextStyle(
                                        fontSize: 11.5,
                                        fontWeight: FontWeight.w800,
                                        letterSpacing: 0.6,
                                        color: textColor,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),

                              _buildSummaryTile(
                                label: l10n.ampCard2TotalRms,
                                value: '${result.formattedTotalSystemRms} Watts Total',
                                isHighlight: true,
                                isNight: isNight,
                              ),
                              const SizedBox(height: 8),
                              _buildSummaryTile(
                                label: l10n.ampCard2TotalLoad,
                                value: '${result.totalImpedance.toStringAsFixed(2)} Ω',
                                isNight: isNight,
                              ),
                              const SizedBox(height: 8),
                              _buildSummaryTile(
                                label: l10n.ampCard2HeadroomFactor,
                                value: '${result.headroomMultiplier}x Multiplier',
                                isNight: isNight,
                              ),
                              const SizedBox(height: 8),
                              _buildSummaryTile(
                                label: isHindi ? 'स्पीकर सेटअप' : 'Speaker Setup',
                                value: '${result.speakerCount} × ${result.speakerImpedance.toInt()}Ω (${result.wiring == WiringConfiguration.parallel ? "Parallel" : "Series"})',
                                isNight: isNight,
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 16),

                        // Share / Clipboard Action Button
                        ShareResultButton(
                          title: isHindi ? 'रिजल्ट शेयर करें' : 'SHARE AMPLIFIER SPECIFICATION',
                          shareText: _generateShareText(),
                        ),

                        const SizedBox(height: 16),

                        // Action 1: Modify Inputs (Gold Button)
                        InkWell(
                          onTap: () => Navigator.pop(context),
                          borderRadius: BorderRadius.circular(22),
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFBBF24),
                              borderRadius: BorderRadius.circular(22),
                              border: Border.all(color: const Color(0xFFF59E0B)),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFFF59E0B).withOpacity(0.35),
                                  blurRadius: 10,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.tune_rounded, size: 20, color: Color(0xFF0F172A)),
                                const SizedBox(width: 8),
                                Flexible(
                                  child: Text(
                                    isHindi ? 'इनपुट बदलें' : 'MODIFY INPUTS',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                                      letterSpacing: isHindi ? 0.2 : 0.5,
                                      color: const Color(0xFF0F172A),
                                      fontFamilyFallback: AppTypography.hindiFontFallback,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryTile({
    required String label,
    required String value,
    bool isHighlight = false,
    bool isNight = false,
  }) {
    final tileBg = isHighlight
        ? (isNight ? const Color(0xFF1E3A8A).withOpacity(0.35) : const Color(0xFFEFF6FF))
        : (isNight ? const Color(0xFF0F172A) : const Color(0xFFF8FAFC));
    final tileBorder = isHighlight
        ? (isNight ? const Color(0xFF3B82F6).withOpacity(0.5) : const Color(0xFFBFDBFE))
        : (isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0));
    final labelColor = isHighlight
        ? (isNight ? const Color(0xFF93C5FD) : const Color(0xFF1E40AF))
        : (isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B));
    final valueColor = isHighlight
        ? (isNight ? const Color(0xFF60A5FA) : const Color(0xFF1D4ED8))
        : (isNight ? Colors.white : const Color(0xFF0F172A));

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      decoration: BoxDecoration(
        color: tileBg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: tileBorder),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w600,
                color: labelColor,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Flexible(
            child: FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerRight,
              child: Text(
                value,
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: valueColor,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
