import 'package:flutter/material.dart';
import '../localization/app_localizations.dart';
import '../widgets/tool_card.dart';
import 'ohm_calculator_screen.dart';
import 'amplifier_calculator_screen.dart';
import 'top_speaker_screen.dart';
import 'cable_loss_screen.dart';
import 'dmx_screen.dart';

class MoreToolsScreen extends StatefulWidget {
  const MoreToolsScreen({super.key});

  @override
  State<MoreToolsScreen> createState() => _MoreToolsScreenState();
}

class _MoreToolsScreenState extends State<MoreToolsScreen> {
  String _searchQuery = '';

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(t.navMoreTools),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Search Bar
          TextField(
            decoration: InputDecoration(
              hintText: 'Search audio and lighting calculators...',
              prefixIcon: const Icon(Icons.search),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            ),
            onChanged: (val) => setState(() => _searchQuery = val.toLowerCase()),
          ),
          const SizedBox(height: 16),

          ToolCard(
            title: t.ohmTitle,
            description: t.ohmDesc,
            category: 'Audio Tool',
            badge: 'Impedance & Load',
            icon: Icons.electric_bolt,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const OhmCalculatorScreen()),
              );
            },
          ),
          const SizedBox(height: 12),

          ToolCard(
            title: t.ampTitle,
            description: t.ampDesc,
            category: 'Audio Tool',
            badge: 'Headroom & Power',
            icon: Icons.speaker_group,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AmplifierCalculatorScreen()),
              );
            },
          ),
          const SizedBox(height: 12),

          ToolCard(
            title: t.topSpeakerTitle,
            description: t.topSpeakerDesc,
            category: 'Audio Tool',
            badge: 'Cabinet SPL',
            icon: Icons.volume_up,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const TopSpeakerScreen()),
              );
            },
          ),
          const SizedBox(height: 12),

          ToolCard(
            title: t.cableTitle,
            description: t.cableDesc,
            category: 'Audio Tool',
            badge: 'Wire & Damping',
            icon: Icons.timeline,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const CableLossScreen()),
              );
            },
          ),
          const SizedBox(height: 12),

          ToolCard(
            title: t.dmxTitle,
            description: t.dmxDesc,
            category: 'Lighting Tool',
            badge: 'Patch & Addressing',
            icon: Icons.settings_input_component,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const DmxScreen()),
              );
            },
          ),
        ],
      ),
    );
  }
}
