import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../localization/app_localizations.dart';
import '../calculators/top_speaker_calculator.dart';
import '../services/preference_service.dart';
import '../services/subscription_service.dart';
import '../services/admob_service.dart';
import '../services/history_service.dart';
import '../widgets/calculator_unlock_dialog.dart';
import '../utils/app_typography.dart';
import 'top_speaker_result_screen.dart';

class TopSpeakerScreen extends StatefulWidget {
  const TopSpeakerScreen({super.key});

  @override
  State<TopSpeakerScreen> createState() => _TopSpeakerScreenState();
}

class _TopSpeakerScreenState extends State<TopSpeakerScreen> {
  final TextEditingController _rmsController = TextEditingController(text: '500');
  double _speakerRms = 500.0;
  int _speakerCount = 2;

  @override
  void dispose() {
    _rmsController.dispose();
    super.dispose();
  }

  bool get _isRmsValid => _speakerRms >= 200.0;

  void _handleReset() {
    setState(() {
      _speakerRms = 500.0;
      _rmsController.text = '500';
      _speakerCount = 2;
    });
  }

  void _calculateAndNavigate() {
    if (!_isRmsValid) return;

    // 1. Active subscribers bypass ad checks
    final subService = Provider.of<SubscriptionService>(context, listen: false);
    if (subService.isPremium) {
      _executeCalculation();
      return;
    }

    // 2. If 60-minute unlock is still active across all calculators, show result immediately
    final adMobService = Provider.of<AdMobService>(context, listen: false);
    if (adMobService.hasActiveRewardPass) {
      _executeCalculation();
      return;
    }

    final prefService = Provider.of<PreferenceService>(context, listen: false);
    final isHindi = prefService.isHindi;

    CalculatorUnlockDialog.show(
      context,
      calculatorTitle: isHindi ? 'टॉप स्पीकर्स कैलकुलेटर' : 'Top Speaker Calculator',
      onUnlocked: () {
        _executeCalculation();
      },
    );
  }

  void _executeCalculation() {
    final result = TopSpeakerCalculator.calculate(
      speakerRms: _speakerRms,
      speakerCount: _speakerCount,
    );

    // Save to calculation history
    final isHindi = Provider.of<PreferenceService>(context, listen: false).isHindi;
    HistoryService().addItem(
      HistoryItem(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        title: isHindi
            ? 'टॉप स्पीकर्स (${result.totalRms.toInt()}W)'
            : 'Top Speaker System (${result.totalRms.toInt()}W)',
        subtitle: '${_speakerCount}x ${_speakerRms.toInt()}W Tops • Amp: ${result.recommendedAmpPower.toInt()}W',
        calculatorId: 'calc_top_speaker',
        timestamp: DateTime.now(),
        payload: {
          'speakerRms': _speakerRms,
          'speakerCount': _speakerCount,
        },
      ),
    );

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => TopSpeakerResultScreen(result: result),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final prefService = Provider.of<PreferenceService>(context);
    final isHindi = prefService.isHindi;
    final isNight = prefService.isNightMode;

    // Theme Tokens (Dynamic Day / Night Mode)
    final bgColor = isNight ? const Color(0xFF070B14) : const Color(0xFFF1F5F9);
    final headerGradient = isNight
        ? const [Color(0xFF0C1935), Color(0xFF070B14)]
        : const [Color(0xFF1E3A8A), Color(0xFF1D4ED8)];
    final cardBg = isNight ? const Color(0xFF0D172B) : Colors.white;
    final cardBorder = isNight ? const Color(0xFF1E2B48) : const Color(0xFFE2E8F0);
    final stepperBtnBg = isNight ? const Color(0xFF182440) : const Color(0xFFF1F5F9);
    final stepperIconColor = isNight ? Colors.white : const Color(0xFF334155);
    final textColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final subtextColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    return Scaffold(
      backgroundColor: bgColor,
      body: SafeArea(
        child: Column(
          children: [
            // Top App Bar / Hero Header
            Container(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: headerGradient,
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Top Navigation Row
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // Circular Back Button
                      InkWell(
                        onTap: () => Navigator.pop(context),
                        borderRadius: BorderRadius.circular(20),
                        child: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.15),
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white.withOpacity(0.20)),
                          ),
                          child: const Icon(
                            Icons.chevron_left_rounded,
                            color: Colors.white,
                            size: 26,
                          ),
                        ),
                      ),

                      // Language Toggle Pill [ English | हिंदी ]
                      Container(
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          color: isNight ? const Color(0xFF0F182B) : Colors.black.withOpacity(0.20),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: isNight ? const Color(0xFF1E2B48) : Colors.white.withOpacity(0.25),
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            InkWell(
                              onTap: () => prefService.setLocale(const Locale('en', '')),
                              borderRadius: BorderRadius.circular(16),
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                decoration: BoxDecoration(
                                  color: !isHindi ? Colors.white : Colors.transparent,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: Text(
                                  'English',
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                    color: !isHindi ? const Color(0xFF0F172A) : Colors.white70,
                                  ),
                                ),
                              ),
                            ),
                            InkWell(
                              onTap: () => prefService.setLocale(const Locale('hi', '')),
                              borderRadius: BorderRadius.circular(16),
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                decoration: BoxDecoration(
                                  color: isHindi ? Colors.white : Colors.transparent,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: Text(
                                  'हिंदी',
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                    color: isHindi ? const Color(0xFF0F172A) : Colors.white70,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 14),

                  // Header Title & Subtitle
                  Text(
                    t.topSpeakerTitle,
                    style: TextStyle(
                      fontSize: isHindi ? 21 : 26,
                      fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: isHindi ? 0.0 : -0.5,
                      fontFamilyFallback: AppTypography.hindiFontFallback,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    isHindi
                        ? 'टॉप स्पीकर्स के लिए कुल RMS पावर और सही एम्पलीफायर'
                        : 'Calculate combined RMS power & recommended amplifier specs for tops',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: const Color(0xFFE2E8F0),
                      fontFamilyFallback: AppTypography.hindiFontFallback,
                    ),
                  ),
                ],
              ),
            ),

            // Scrollable Inputs Area
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
                children: [
                  // Section 1: Speaker RMS Power
                  _buildSectionHeader(
                    step: '1',
                    title: isHindi
                        ? 'स्पीकर RMS पावर (प्रति कैबिनेट)'
                        : 'Loudspeaker RMS Power (Per Cabinet)',
                    isNight: isNight,
                  ),
                  const SizedBox(height: 8),

                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    decoration: BoxDecoration(
                      color: cardBg,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(
                        color: _isRmsValid ? cardBorder : const Color(0xFFEF4444),
                        width: 1.5,
                      ),
                      boxShadow: [
                        if (!isNight)
                          BoxShadow(
                            color: Colors.black.withOpacity(0.04),
                            blurRadius: 10,
                            offset: const Offset(0, 2),
                          ),
                      ],
                    ),
                    child: Row(
                      children: [
                        // Minus 50W
                        InkWell(
                          onTap: () {
                            setState(() {
                              _speakerRms = (_speakerRms - 50).clamp(50.0, 20000.0);
                              _rmsController.text = _speakerRms.toInt().toString();
                            });
                          },
                          borderRadius: BorderRadius.circular(16),
                          child: Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: stepperBtnBg,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: Icon(Icons.remove, size: 20, color: stepperIconColor),
                          ),
                        ),

                        // Central RMS Input
                        Expanded(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.baseline,
                            textBaseline: TextBaseline.alphabetic,
                            children: [
                              Container(
                                width: 90,
                                decoration: const BoxDecoration(
                                  border: Border(
                                    bottom: BorderSide(
                                      color: Color(0xFF2563EB),
                                      width: 2.0,
                                    ),
                                  ),
                                ),
                                child: TextField(
                                  controller: _rmsController,
                                  keyboardType: TextInputType.number,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontSize: 26,
                                    fontWeight: FontWeight.w900,
                                    color: textColor,
                                    letterSpacing: -0.5,
                                  ),
                                  decoration: const InputDecoration(
                                    border: InputBorder.none,
                                    isDense: true,
                                    contentPadding: EdgeInsets.only(bottom: 2),
                                  ),
                                  onChanged: (val) {
                                    final parsed = double.tryParse(val);
                                    if (parsed != null) {
                                      setState(() {
                                        _speakerRms = parsed;
                                      });
                                    }
                                  },
                                ),
                              ),
                              const SizedBox(width: 6),
                              Text(
                                'Watts',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: subtextColor,
                                ),
                              ),
                            ],
                          ),
                        ),

                        // Plus 50W
                        InkWell(
                          onTap: () {
                            setState(() {
                              _speakerRms = (_speakerRms + 50).clamp(50.0, 20000.0);
                              _rmsController.text = _speakerRms.toInt().toString();
                            });
                          },
                          borderRadius: BorderRadius.circular(16),
                          child: Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: stepperBtnBg,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: Icon(Icons.add, size: 20, color: stepperIconColor),
                          ),
                        ),
                      ],
                    ),
                  ),

                  if (!_isRmsValid) ...[
                    const SizedBox(height: 6),
                    Padding(
                      padding: const EdgeInsets.only(left: 4),
                      child: Text(
                        t.topSpeakerRmsMinWarning,
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFEF4444),
                        ),
                      ),
                    ),
                  ],

                  // Quick presets
                  const SizedBox(height: 10),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [300, 500, 800, 1000, 1200, 1500].map((val) {
                        final isSelected = _speakerRms == val.toDouble();
                        return Padding(
                          padding: const EdgeInsets.only(right: 6),
                          child: InkWell(
                            onTap: () {
                              setState(() {
                                _speakerRms = val.toDouble();
                                _rmsController.text = val.toString();
                              });
                            },
                            borderRadius: BorderRadius.circular(14),
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? (isNight ? const Color(0xFF0F2244) : const Color(0xFFEFF6FF))
                                    : cardBg,
                                borderRadius: BorderRadius.circular(14),
                                border: Border.all(
                                  color: isSelected ? const Color(0xFF2563EB) : cardBorder,
                                  width: isSelected ? 2 : 1,
                                ),
                              ),
                              child: Text(
                                '${val}W',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w800,
                                  color: isSelected
                                      ? (isNight ? const Color(0xFF60A5FA) : const Color(0xFF1D4ED8))
                                      : textColor,
                                ),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // Section 2: Number of Loudspeakers
                  _buildSectionHeader(
                    step: '2',
                    title: isHindi ? 'टॉप स्पीकर्स की संख्या' : 'Number of Loudspeakers',
                    isNight: isNight,
                  ),
                  const SizedBox(height: 8),

                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    decoration: BoxDecoration(
                      color: cardBg,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: cardBorder, width: 1.5),
                      boxShadow: [
                        if (!isNight)
                          BoxShadow(
                            color: Colors.black.withOpacity(0.04),
                            blurRadius: 10,
                            offset: const Offset(0, 2),
                          ),
                      ],
                    ),
                    child: Row(
                      children: [
                        // Decrement button
                        InkWell(
                          onTap: _speakerCount > 1
                              ? () => setState(() => _speakerCount--)
                              : null,
                          borderRadius: BorderRadius.circular(16),
                          child: Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: stepperBtnBg,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: Icon(
                              Icons.remove,
                              size: 20,
                              color: _speakerCount > 1
                                  ? stepperIconColor
                                  : (isNight ? const Color(0xFF475569) : const Color(0xFFCBD5E1)),
                            ),
                          ),
                        ),

                        // Speaker count display
                        Expanded(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.baseline,
                            textBaseline: TextBaseline.alphabetic,
                            children: [
                              Text(
                                '$_speakerCount',
                                style: TextStyle(
                                  fontSize: 26,
                                  fontWeight: FontWeight.w900,
                                  color: textColor,
                                ),
                              ),
                              const SizedBox(width: 6),
                              Text(
                                _speakerCount == 1 ? 'speaker' : 'speakers',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: subtextColor,
                                ),
                              ),
                            ],
                          ),
                        ),

                        // Increment button
                        InkWell(
                          onTap: _speakerCount < 32
                              ? () => setState(() => _speakerCount++)
                              : null,
                          borderRadius: BorderRadius.circular(16),
                          child: Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: stepperBtnBg,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: Icon(
                              Icons.add,
                              size: 20,
                              color: _speakerCount < 32
                                  ? stepperIconColor
                                  : (isNight ? const Color(0xFF475569) : const Color(0xFFCBD5E1)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 28),

                  // Action Button: CALCULATE TOP SPEAKER SYSTEM
                  InkWell(
                    onTap: _isRmsValid ? _calculateAndNavigate : null,
                    borderRadius: BorderRadius.circular(22),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      decoration: BoxDecoration(
                        color: _isRmsValid ? const Color(0xFFFBBF24) : (isNight ? const Color(0xFF1E2B48) : const Color(0xFFE2E8F0)),
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(
                          color: _isRmsValid ? const Color(0xFFF59E0B) : (isNight ? const Color(0xFF334155) : const Color(0xFFCBD5E1)),
                        ),
                        boxShadow: [
                          if (_isRmsValid)
                            BoxShadow(
                              color: const Color(0xFFF59E0B).withOpacity(0.35),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                        ],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.speaker_group_rounded,
                            size: 20,
                            color: _isRmsValid ? const Color(0xFF0F172A) : const Color(0xFF94A3B8),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            isHindi ? 'टॉप स्पीकर्स कैलकुलेट करें' : 'CALCULATE TOP SPEAKERS',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: isHindi ? FontWeight.w600 : FontWeight.w800,
                              letterSpacing: isHindi ? 0.0 : 0.5,
                              color: _isRmsValid ? const Color(0xFF0F172A) : const Color(0xFF94A3B8),
                              fontFamilyFallback: AppTypography.hindiFontFallback,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 12),

                  // Reset Button
                  Center(
                    child: TextButton.icon(
                      onPressed: _handleReset,
                      icon: Icon(Icons.refresh_rounded, size: 16, color: subtextColor),
                      label: Text(
                        isHindi ? 'रीसेट करें' : 'Reset Values',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: subtextColor,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader({
    required String step,
    required String title,
    required bool isNight,
  }) {
    return Row(
      children: [
        Container(
          width: 20,
          height: 20,
          decoration: const BoxDecoration(
            color: Color(0xFF1D4ED8),
            shape: BoxShape.circle,
          ),
          child: Center(
            child: Text(
              step,
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            title,
            style: TextStyle(
              fontSize: 13.5,
              fontWeight: AppTypography.isDevanagari(title) ? FontWeight.w600 : FontWeight.w800,
              color: isNight ? Colors.white : const Color(0xFF0F172A),
              fontFamilyFallback: AppTypography.hindiFontFallback,
            ),
          ),
        ),
      ],
    );
  }
}
