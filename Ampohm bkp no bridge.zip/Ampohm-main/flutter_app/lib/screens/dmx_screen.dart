import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../localization/app_localizations.dart';
import '../calculators/dmx_calculator.dart';
import '../services/preference_service.dart';
import '../services/subscription_service.dart';
import '../services/admob_service.dart';
import '../services/history_service.dart';
import '../widgets/calculator_unlock_dialog.dart';
import '../utils/app_typography.dart';
import 'dmx_result_screen.dart';

class DmxScreen extends StatefulWidget {
  const DmxScreen({super.key});

  @override
  State<DmxScreen> createState() => _DmxScreenState();
}

class _DmxScreenState extends State<DmxScreen> {
  final TextEditingController _startController = TextEditingController(text: '1');
  final TextEditingController _countController = TextEditingController(text: '16');
  final TextEditingController _fixtureController = TextEditingController(text: '4');

  int _startAddress = 1;
  int _channelCount = 16;
  int _fixtureCount = 4;

  @override
  void dispose() {
    _startController.dispose();
    _countController.dispose();
    _fixtureController.dispose();
    super.dispose();
  }

  bool get _isStartValid => _startAddress >= 1 && _startAddress <= 512;
  bool get _isCountValid => _channelCount >= 1 && _channelCount <= 64;
  bool get _isFixtureValid => _fixtureCount >= 1 && _fixtureCount <= 64;
  int get _endAddress => _startAddress + _channelCount - 1;
  int get _totalPatchEnd => _startAddress + (_channelCount * _fixtureCount) - 1;
  bool get _exceedsUniverse => _endAddress > 512 || _startAddress > 512;
  bool get _totalExceedsUniverse => _totalPatchEnd > 512 && !_exceedsUniverse;
  bool get _isValid => _isStartValid && _isCountValid && _isFixtureValid && !_exceedsUniverse;

  void _handleReset() {
    setState(() {
      _startAddress = 1;
      _channelCount = 16;
      _fixtureCount = 4;
      _startController.text = '1';
      _countController.text = '16';
      _fixtureController.text = '4';
    });
  }

  void _calculateAndNavigate() {
    if (!_isValid) return;

    // 1. Active subscribers bypass ad checks
    final subService = Provider.of<SubscriptionService>(context, listen: false);
    if (subService.isPremium) {
      _executeCalculation();
      return;
    }

    // 2. If 60-minute unlock is still active across all calculators, show result immediately
    final adMobService = Provider.of<AdMobService>(context, listen: false);
    if (adMobService.hasActiveRewardPass) {
      _executeCalculation();
      return;
    }

    final prefService = Provider.of<PreferenceService>(context, listen: false);
    final isHindi = prefService.isHindi;

    CalculatorUnlockDialog.show(
      context,
      calculatorTitle: isHindi ? 'DMX एड्रेस कैलकुलेटर' : 'DMX Calculator',
      onUnlocked: () {
        _executeCalculation();
      },
    );
  }

  void _executeCalculation() {
    final result = DmxCalculator.calculate(
      startAddress: _startAddress,
      channelCount: _channelCount,
      fixtureCount: _fixtureCount,
    );

    // Save to calculation history
    final isHindi = Provider.of<PreferenceService>(context, listen: false).isHindi;
    HistoryService().addItem(
      HistoryItem(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        title: isHindi
            ? 'DMX पैच (${_fixtureCount} फिक्सचर्स)'
            : 'DMX Patch (${_fixtureCount} Fixtures)',
        subtitle: 'Start: $_startAddress • ${_channelCount}ch/fixture • End: ${result.endAddress}',
        calculatorId: 'calc_dmx',
        timestamp: DateTime.now(),
        payload: {
          'startAddress': _startAddress,
          'channelCount': _channelCount,
          'fixtureCount': _fixtureCount,
        },
      ),
    );

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => DmxResultScreen(result: result),
      ),
    );
  }

  final List<int> _channelPresets = [1, 3, 4, 7, 12, 16, 24, 32];
  final List<int> _fixturePresets = [2, 4, 6, 8, 12, 16];

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final prefService = Provider.of<PreferenceService>(context);
    final isHindi = prefService.isHindi;
    final isNight = prefService.isNightMode;

    // Theme Tokens (Dynamic Day / Night Mode)
    final bgColor = isNight ? const Color(0xFF070B14) : const Color(0xFFF1F5F9);
    final headerGradient = isNight
        ? const [Color(0xFF0C1935), Color(0xFF070B14)]
        : const [Color(0xFF1E3A8A), Color(0xFF1D4ED8)];
    final cardBg = isNight ? const Color(0xFF0D172B) : Colors.white;
    final cardBorder = isNight ? const Color(0xFF1E2B48) : const Color(0xFFE2E8F0);
    final stepperBtnBg = isNight ? const Color(0xFF182440) : const Color(0xFFF1F5F9);
    final stepperIconColor = isNight ? Colors.white : const Color(0xFF334155);
    final textColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final subtextColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    return Scaffold(
      backgroundColor: bgColor,
      body: SafeArea(
        child: Column(
          children: [
            // Top App Bar / Hero Header
            Container(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: headerGradient,
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Top Navigation Row
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // Circular Back Button
                      InkWell(
                        onTap: () => Navigator.pop(context),
                        borderRadius: BorderRadius.circular(20),
                        child: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.15),
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white.withOpacity(0.20)),
                          ),
                          child: const Icon(
                            Icons.chevron_left_rounded,
                            color: Colors.white,
                            size: 26,
                          ),
                        ),
                      ),

                      // Language Toggle Pill [ English | हिंदी ]
                      Container(
                        padding: const EdgeInsets.all(3),
                        decoration: BoxDecoration(
                          color: isNight ? const Color(0xFF0F182B) : Colors.black.withOpacity(0.20),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: isNight ? const Color(0xFF1E2B48) : Colors.white.withOpacity(0.25),
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            InkWell(
                              onTap: () => prefService.setLocale(const Locale('en', '')),
                              borderRadius: BorderRadius.circular(16),
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                decoration: BoxDecoration(
                                  color: !isHindi ? Colors.white : Colors.transparent,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: Text(
                                  'English',
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                    color: !isHindi ? const Color(0xFF0F172A) : Colors.white70,
                                  ),
                                ),
                              ),
                            ),
                            InkWell(
                              onTap: () => prefService.setLocale(const Locale('hi', '')),
                              borderRadius: BorderRadius.circular(16),
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                decoration: BoxDecoration(
                                  color: isHindi ? Colors.white : Colors.transparent,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: Text(
                                  'हिंदी',
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                    color: isHindi ? const Color(0xFF0F172A) : Colors.white70,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 14),

                  // Header Title & Subtitle
                  Text(
                    t.dmxTitle,
                    style: TextStyle(
                      fontSize: isHindi ? 21 : 26,
                      fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: isHindi ? 0.0 : -0.5,
                      fontFamilyFallback: AppTypography.hindiFontFallback,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    isHindi
                        ? 'DMX 512 एड्रेसिंग, फिक्स्चर पैच और चैनल ब्रेकडाउन'
                        : 'Calculate DMX address blocks, fixture patch & universe map',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: const Color(0xFFE2E8F0),
                      fontFamilyFallback: AppTypography.hindiFontFallback,
                    ),
                  ),
                ],
              ),
            ),

            // Scrollable Inputs Area
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
                children: [
                  // INPUT 1: Start Address (1-512)
                  _buildSectionHeader(
                    step: '1',
                    title: isHindi ? 'DMX स्टार्ट एड्रेस (1 - 512)' : 'Start DMX Address (1 - 512)',
                    isNight: isNight,
                  ),
                  const SizedBox(height: 8),

                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    decoration: BoxDecoration(
                      color: cardBg,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(
                        color: _isStartValid ? cardBorder : const Color(0xFFEF4444),
                        width: 1.5,
                      ),
                      boxShadow: [
                        if (!isNight)
                          BoxShadow(
                            color: Colors.black.withOpacity(0.04),
                            blurRadius: 10,
                            offset: const Offset(0, 2),
                          ),
                      ],
                    ),
                    child: Row(
                      children: [
                        // Minus 1
                        InkWell(
                          onTap: _startAddress > 1
                              ? () {
                                  setState(() {
                                    _startAddress = (_startAddress - 1).clamp(1, 512);
                                    _startController.text = _startAddress.toString();
                                  });
                                }
                              : null,
                          borderRadius: BorderRadius.circular(16),
                          child: Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: stepperBtnBg,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: Icon(
                              Icons.remove,
                              size: 20,
                              color: _startAddress > 1
                                  ? stepperIconColor
                                  : (isNight ? const Color(0xFF475569) : const Color(0xFFCBD5E1)),
                            ),
                          ),
                        ),

                        // Central Start Address Input
                        Expanded(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.baseline,
                            textBaseline: TextBaseline.alphabetic,
                            children: [
                              Container(
                                width: 90,
                                decoration: const BoxDecoration(
                                  border: Border(
                                    bottom: BorderSide(
                                      color: Color(0xFF2563EB),
                                      width: 2.0,
                                    ),
                                  ),
                                ),
                                child: TextField(
                                  controller: _startController,
                                  keyboardType: TextInputType.number,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontSize: 26,
                                    fontWeight: FontWeight.w900,
                                    color: textColor,
                                    letterSpacing: -0.5,
                                  ),
                                  decoration: const InputDecoration(
                                    border: InputBorder.none,
                                    isDense: true,
                                    contentPadding: EdgeInsets.only(bottom: 2),
                                  ),
                                  onChanged: (val) {
                                    final parsed = int.tryParse(val);
                                    setState(() {
                                      _startAddress = parsed ?? 1;
                                    });
                                  },
                                ),
                              ),
                              const SizedBox(width: 6),
                              Text(
                                'DMX',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: subtextColor,
                                ),
                              ),
                            ],
                          ),
                        ),

                        // Plus 1
                        InkWell(
                          onTap: _startAddress < 512
                              ? () {
                                  setState(() {
                                    _startAddress = (_startAddress + 1).clamp(1, 512);
                                    _startController.text = _startAddress.toString();
                                  });
                                }
                              : null,
                          borderRadius: BorderRadius.circular(16),
                          child: Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: stepperBtnBg,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: Icon(
                              Icons.add,
                              size: 20,
                              color: _startAddress < 512
                                  ? stepperIconColor
                                  : (isNight ? const Color(0xFF475569) : const Color(0xFFCBD5E1)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  if (!_isStartValid) ...[
                    const SizedBox(height: 6),
                    Padding(
                      padding: const EdgeInsets.only(left: 4),
                      child: Text(
                        t.dmxStartWarning,
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFEF4444),
                        ),
                      ),
                    ),
                  ],

                  const SizedBox(height: 20),

                  // INPUT 2: Fixture Channel Footprint
                  _buildSectionHeader(
                    step: '2',
                    title: isHindi ? 'लाइट चैनल फुटप्रिंट (1 - 64)' : 'Fixture Channels (Footprint)',
                    isNight: isNight,
                  ),
                  const SizedBox(height: 8),

                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    decoration: BoxDecoration(
                      color: cardBg,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(
                        color: _isCountValid ? cardBorder : const Color(0xFFEF4444),
                        width: 1.5,
                      ),
                      boxShadow: [
                        if (!isNight)
                          BoxShadow(
                            color: Colors.black.withOpacity(0.04),
                            blurRadius: 10,
                            offset: const Offset(0, 2),
                          ),
                      ],
                    ),
                    child: Row(
                      children: [
                        // Minus 1
                        InkWell(
                          onTap: _channelCount > 1
                              ? () {
                                  setState(() {
                                    _channelCount = (_channelCount - 1).clamp(1, 64);
                                    _countController.text = _channelCount.toString();
                                  });
                                }
                              : null,
                          borderRadius: BorderRadius.circular(16),
                          child: Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: stepperBtnBg,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: Icon(
                              Icons.remove,
                              size: 20,
                              color: _channelCount > 1
                                  ? stepperIconColor
                                  : (isNight ? const Color(0xFF475569) : const Color(0xFFCBD5E1)),
                            ),
                          ),
                        ),

                        // Central Channel Count Input
                        Expanded(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.baseline,
                            textBaseline: TextBaseline.alphabetic,
                            children: [
                              Container(
                                width: 90,
                                decoration: const BoxDecoration(
                                  border: Border(
                                    bottom: BorderSide(
                                      color: Color(0xFF2563EB),
                                      width: 2.0,
                                    ),
                                  ),
                                ),
                                child: TextField(
                                  controller: _countController,
                                  keyboardType: TextInputType.number,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontSize: 26,
                                    fontWeight: FontWeight.w900,
                                    color: textColor,
                                    letterSpacing: -0.5,
                                  ),
                                  decoration: const InputDecoration(
                                    border: InputBorder.none,
                                    isDense: true,
                                    contentPadding: EdgeInsets.only(bottom: 2),
                                  ),
                                  onChanged: (val) {
                                    final parsed = int.tryParse(val);
                                    setState(() {
                                      _channelCount = parsed ?? 1;
                                    });
                                  },
                                ),
                              ),
                              const SizedBox(width: 6),
                              Text(
                                'CH',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: subtextColor,
                                ),
                              ),
                            ],
                          ),
                        ),

                        // Plus 1
                        InkWell(
                          onTap: _channelCount < 64
                              ? () {
                                  setState(() {
                                    _channelCount = (_channelCount + 1).clamp(1, 64);
                                    _countController.text = _channelCount.toString();
                                  });
                                }
                              : null,
                          borderRadius: BorderRadius.circular(16),
                          child: Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: stepperBtnBg,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: Icon(
                              Icons.add,
                              size: 20,
                              color: _channelCount < 64
                                  ? stepperIconColor
                                  : (isNight ? const Color(0xFF475569) : const Color(0xFFCBD5E1)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  if (!_isCountValid) ...[
                    const SizedBox(height: 6),
                    Padding(
                      padding: const EdgeInsets.only(left: 4),
                      child: Text(
                        t.dmxChannelCountWarning,
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFEF4444),
                        ),
                      ),
                    ),
                  ],

                  // Channel Quick Presets
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: _channelPresets.map((ch) {
                      final isSelected = _channelCount == ch;
                      return InkWell(
                        onTap: () {
                          setState(() {
                            _channelCount = ch;
                            _countController.text = ch.toString();
                          });
                        },
                        borderRadius: BorderRadius.circular(14),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? (isNight ? const Color(0xFF0F2244) : const Color(0xFFEFF6FF))
                                : cardBg,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: isSelected ? const Color(0xFF2563EB) : cardBorder,
                            ),
                          ),
                          child: Text(
                            '${ch}CH',
                            style: TextStyle(
                              fontSize: 11.5,
                              fontWeight: FontWeight.w800,
                              color: isSelected
                                  ? (isNight ? const Color(0xFF60A5FA) : const Color(0xFF1D4ED8))
                                  : (isNight ? const Color(0xFF94A3B8) : const Color(0xFF475569)),
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),

                  const SizedBox(height: 20),

                  // INPUT 3: Number of Fixtures (Restored)
                  _buildSectionHeader(
                    step: '3',
                    title: isHindi ? 'फिक्स्चर संख्या' : 'Number of Fixtures',
                    isNight: isNight,
                  ),
                  const SizedBox(height: 8),

                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    decoration: BoxDecoration(
                      color: cardBg,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(
                        color: _isFixtureValid ? cardBorder : const Color(0xFFEF4444),
                        width: 1.5,
                      ),
                      boxShadow: [
                        if (!isNight)
                          BoxShadow(
                            color: Colors.black.withOpacity(0.04),
                            blurRadius: 10,
                            offset: const Offset(0, 2),
                          ),
                      ],
                    ),
                    child: Row(
                      children: [
                        // Minus 1
                        InkWell(
                          onTap: _fixtureCount > 1
                              ? () {
                                  setState(() {
                                    _fixtureCount = (_fixtureCount - 1).clamp(1, 64);
                                    _fixtureController.text = _fixtureCount.toString();
                                  });
                                }
                              : null,
                          borderRadius: BorderRadius.circular(16),
                          child: Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: stepperBtnBg,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: Icon(
                              Icons.remove,
                              size: 20,
                              color: _fixtureCount > 1
                                  ? stepperIconColor
                                  : (isNight ? const Color(0xFF475569) : const Color(0xFFCBD5E1)),
                            ),
                          ),
                        ),

                        // Central Fixture Count Input
                        Expanded(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.baseline,
                            textBaseline: TextBaseline.alphabetic,
                            children: [
                              Container(
                                width: 90,
                                decoration: const BoxDecoration(
                                  border: Border(
                                    bottom: BorderSide(
                                      color: Color(0xFF2563EB),
                                      width: 2.0,
                                    ),
                                  ),
                                ),
                                child: TextField(
                                  controller: _fixtureController,
                                  keyboardType: TextInputType.number,
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                    fontSize: 26,
                                    fontWeight: FontWeight.w900,
                                    color: textColor,
                                    letterSpacing: -0.5,
                                  ),
                                  decoration: const InputDecoration(
                                    border: InputBorder.none,
                                    isDense: true,
                                    contentPadding: EdgeInsets.only(bottom: 2),
                                  ),
                                  onChanged: (val) {
                                    final parsed = int.tryParse(val);
                                    setState(() {
                                      _fixtureCount = (parsed ?? 1).clamp(1, 64);
                                    });
                                  },
                                ),
                              ),
                              const SizedBox(width: 6),
                              Text(
                                _fixtureCount == 1 ? 'Fixture' : 'Fixtures',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: subtextColor,
                                ),
                              ),
                            ],
                          ),
                        ),

                        // Plus 1
                        InkWell(
                          onTap: _fixtureCount < 64
                              ? () {
                                  setState(() {
                                    _fixtureCount = (_fixtureCount + 1).clamp(1, 64);
                                    _fixtureController.text = _fixtureCount.toString();
                                  });
                                }
                              : null,
                          borderRadius: BorderRadius.circular(16),
                          child: Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: stepperBtnBg,
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: Icon(
                              Icons.add,
                              size: 20,
                              color: _fixtureCount < 64
                                  ? stepperIconColor
                                  : (isNight ? const Color(0xFF475569) : const Color(0xFFCBD5E1)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Fixture Quick Presets
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: _fixturePresets.map((cnt) {
                      final isSelected = _fixtureCount == cnt;
                      return InkWell(
                        onTap: () {
                          setState(() {
                            _fixtureCount = cnt;
                            _fixtureController.text = cnt.toString();
                          });
                        },
                        borderRadius: BorderRadius.circular(14),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? (isNight ? const Color(0xFF0F2244) : const Color(0xFFEFF6FF))
                                : cardBg,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: isSelected ? const Color(0xFF2563EB) : cardBorder,
                            ),
                          ),
                          child: Text(
                            '$cnt Fixtures',
                            style: TextStyle(
                              fontSize: 11.5,
                              fontWeight: FontWeight.w800,
                              color: isSelected
                                  ? (isNight ? const Color(0xFF60A5FA) : const Color(0xFF1D4ED8))
                                  : (isNight ? const Color(0xFF94A3B8) : const Color(0xFF475569)),
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),

                  // Universe overflow warning
                  if (_exceedsUniverse) ...[
                    const SizedBox(height: 14),
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: isNight ? const Color(0xFF22090C) : const Color(0xFFFEF2F2),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(
                          color: isNight ? const Color(0xFFDC2626) : const Color(0xFFFCA5A5),
                          width: 1.5,
                        ),
                        boxShadow: [
                          if (isNight)
                            BoxShadow(
                              color: const Color(0xFFDC2626).withOpacity(0.2),
                              blurRadius: 10,
                            ),
                        ],
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.warning_amber_rounded, color: Color(0xFFDC2626), size: 22),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              t.dmxExceedWarning,
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                color: isNight ? const Color(0xFFFCA5A5) : const Color(0xFF991B1B),
                                height: 1.35,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ] else if (_totalExceedsUniverse) ...[
                    const SizedBox(height: 14),
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: isNight ? const Color(0xFF2B1808) : const Color(0xFFFEF3C7),
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(
                          color: isNight ? const Color(0xFFF59E0B) : const Color(0xFFFDE68A),
                          width: 1.5,
                        ),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.info_outline_rounded, color: Color(0xFFD97706), size: 22),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              isHindi
                                  ? 'सूचना: $_fixtureCount फिक्सचर्स का कुल पैच DMX 512 (यूनिवर्स 1) को पार करेगा। अतिरिक्त फिक्सचर्स यूनिवर्स 2 पर पैच होंगे।'
                                  : 'Notice: Total patch for $_fixtureCount fixtures spans beyond DMX 512. Subsequent fixtures will patch into Universe 2.',
                              style: TextStyle(
                                fontSize: 11.5,
                                fontWeight: FontWeight.w600,
                                color: isNight ? const Color(0xFFFDE68A) : const Color(0xFF92400E),
                                height: 1.35,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],

                  const SizedBox(height: 28),

                  // Action Button: CALCULATE DMX ADDRESS & PATCH
                  InkWell(
                    onTap: _isValid ? _calculateAndNavigate : null,
                    borderRadius: BorderRadius.circular(22),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      decoration: BoxDecoration(
                        color: _isValid ? const Color(0xFFFBBF24) : (isNight ? const Color(0xFF1E2B48) : const Color(0xFFE2E8F0)),
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(
                          color: _isValid ? const Color(0xFFF59E0B) : (isNight ? const Color(0xFF334155) : const Color(0xFFCBD5E1)),
                        ),
                        boxShadow: [
                          if (_isValid)
                            BoxShadow(
                              color: const Color(0xFFF59E0B).withOpacity(0.35),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                        ],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.tune_rounded,
                            size: 20,
                            color: _isValid ? const Color(0xFF0F172A) : const Color(0xFF94A3B8),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            isHindi ? 'DMX एड्रेस व पैच निकालें' : 'CALCULATE DMX ADDRESS & PATCH',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: isHindi ? FontWeight.w600 : FontWeight.w800,
                              letterSpacing: isHindi ? 0.0 : 0.5,
                              color: _isValid ? const Color(0xFF0F172A) : const Color(0xFF94A3B8),
                              fontFamilyFallback: AppTypography.hindiFontFallback,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 12),

                  // Reset Button
                  Center(
                    child: TextButton.icon(
                      onPressed: _handleReset,
                      icon: Icon(Icons.refresh_rounded, size: 16, color: subtextColor),
                      label: Text(
                        isHindi ? 'रीसेट करें' : 'Reset Values',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: subtextColor,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader({
    required String step,
    required String title,
    required bool isNight,
  }) {
    return Row(
      children: [
        Container(
          width: 20,
          height: 20,
          decoration: const BoxDecoration(
            color: Color(0xFF1D4ED8),
            shape: BoxShape.circle,
          ),
          child: Center(
            child: Text(
              step,
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            title,
            style: TextStyle(
              fontSize: 13.5,
              fontWeight: AppTypography.isDevanagari(title) ? FontWeight.w600 : FontWeight.w800,
              color: isNight ? Colors.white : const Color(0xFF0F172A),
              fontFamilyFallback: AppTypography.hindiFontFallback,
            ),
          ),
        ),
      ],
    );
  }
}
