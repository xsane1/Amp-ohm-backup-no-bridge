import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/preference_service.dart';
import '../widgets/calculator_hero_header.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final prefService = Provider.of<PreferenceService>(context);
    final isNight = prefService.isNightMode;
    final isHindi = prefService.isHindi;
    final scaffoldBg = isNight ? const Color(0xFF0B111C) : const Color(0xFFF1F5F9);
    final sheetBg = isNight ? const Color(0xFF0F172A) : Colors.white;

    return Scaffold(
      backgroundColor: scaffoldBg,
      body: SafeArea(
        child: Column(
          children: [
            // Hero Header
            CalculatorHeroHeader(
              title: isHindi ? 'प्राइवेसी पॉलिसी' : 'Privacy Policy',
              subtitle: isHindi ? 'डेटा सुरक्षा और प्राइवेसी मानक' : 'Data security & privacy standards',
              onBack: () => Navigator.pop(context),
            ),

            // Curved Sheet
            Expanded(
              child: Transform.translate(
                offset: const Offset(0, -20),
                child: Container(
                  decoration: BoxDecoration(
                    color: sheetBg,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: isNight ? Colors.black.withOpacity(0.4) : const Color(0x140F172A),
                        blurRadius: 20,
                        offset: const Offset(0, -6),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(16, 24, 16, 32),
                      children: [
                        // Local execution notice
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                          decoration: BoxDecoration(
                            color: isNight ? const Color(0xFF064E3B).withOpacity(0.3) : const Color(0xFFECFDF5),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: isNight ? const Color(0xFF065F46) : const Color(0xFFA7F3D0)),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Icon(Icons.lock_outline_rounded, color: isNight ? const Color(0xFF34D399) : const Color(0xFF065F46), size: 20),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  'Privacy by Design: All audio and lighting calculation formulas execute strictly locally in volatile device memory (RAM). Zero calculation inputs or project specifications are transmitted to external servers.',
                                  style: TextStyle(
                                    fontSize: 11.5,
                                    color: isNight ? const Color(0xFF6EE7B7) : const Color(0xFF065F46),
                                    fontWeight: FontWeight.w600,
                                    height: 1.35,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),

                        _buildPolicyCard(
                          isNight,
                          '1. Introduction',
                          'Amp Ohm is developed by AudioXpert to provide sound engineers, audio operators, DJs, and stage lighting technicians with fast, reliable calculation tools. These include loudspeaker impedance (Series, Parallel, and Series-Parallel), amplifier power and headroom matching, top speaker array loading, speaker cable resistance and voltage drop, and DMX 512 fixture addressing. We respect your privacy and are committed to transparent, privacy-centric data practices.',
                        ),
                        const SizedBox(height: 12),

                        _buildPolicyCard(
                          isNight,
                          '2. Information and Data Handling',
                          'To provide complete transparency, we distinguish how different categories of data are processed:\n\n'
                          '• Calculator Inputs & Outputs: Any numerical parameters entered into calculators (such as wattage ratings, speaker impedances, driver counts, cable run distances, wire gauges, or DMX channels) are processed transiently in device RAM. They are not stored on remote servers, recorded in external databases, or linked to your personal identity.\n\n'
                          '• Locally Stored On-Device Preferences: Amp Ohm utilizes secure on-device sandboxed storage (SharedPreferences) solely for basic operational preferences. This includes your theme setting (Night Mode / Light Mode), language selection, a temporary 60-minute rewarded ad pass expiration timestamp (ampohm_reward_pass_expiry_ms), cached subscription entitlement status (rc_is_premium, rc_active_tier, rc_expiration_date) to allow seamless offline launches, and optional VIP verification email (vip_verified_email) if you enter an authorized VIP pass.\n\n'
                          '• Information Processed by Third-Party SDKs: Integrated third-party SDKs (Google AdMob, Google Play Billing, RevenueCat, and Firebase) collect standardized telemetry and anonymous device identifiers necessary to deliver advertisements, process in-app purchases, verify entitlements, and retrieve remote configuration flags.\n\n'
                          '• Data Amp Ohm Itself Collects: Amp Ohm does not require account creation, user registration, social login, passwords, telephone numbers, or profile creation. We do not maintain user accounts or personal profiles on our servers.',
                        ),
                        const SizedBox(height: 12),

                        _buildPolicyCard(
                          isNight,
                          '3. Calculator Data',
                          'All mathematical calculations and formulas run entirely on your local device. Your audio rig configurations, stage setups, speaker wiring combinations, and calculation results remain strictly on your phone. No project files, calculation histories, or technical schematics are transmitted to AudioXpert or any third party.',
                        ),
                        const SizedBox(height: 12),

                        _buildPolicyCard(
                          isNight,
                          '4. Advertising (Google AdMob)',
                          'The free version of Amp Ohm is supported by advertising delivered via Google AdMob (Google LLC). The implemented ad formats are:\n\n'
                          '• Banner Ads: Non-intrusive banner advertisements displayed at the bottom of calculation result screens for free-tier users.\n\n'
                          '• Rewarded Video Ads: User-initiated, opt-in rewarded video ads. When using a calculator, free-tier users can voluntarily choose to watch a short video ad to unlock a full 60-minute ad-free pass across all calculators in the app.\n\n'
                          '• Ad-Free Experience for Subscribers: Active Amp Ohm Pro subscribers receive a completely ad-free experience; all banner ads and rewarded video prompts are disabled throughout the entire app.\n\n'
                          '• Data Processing by Google AdMob: Google Mobile Ads SDK may automatically collect and process anonymous device identifiers (such as Google Advertising ID / AAID on Android), IP addresses for approximate geographic location and fraud prevention, device hardware specifications, and ad interaction metrics.\n\n'
                          'To learn how Google collects and uses advertising data, please review Google’s Privacy & Terms: https://policies.google.com/technologies/ads',
                        ),
                        const SizedBox(height: 12),

                        _buildPolicyCard(
                          isNight,
                          '5. In-App Purchases & Subscriptions (Google Play & RevenueCat)',
                          'Amp Ohm offers an optional "Amp Ohm Pro" upgrade providing 100% ad-free usage and unrestricted access to all calculators and export tools.\n\n'
                          '• Payment Processing by Google Play: All subscription purchases and billing transactions are processed exclusively through Google Play Billing (Google LLC). AudioXpert and Amp Ohm never collect, view, process, or store your payment cards, bank account details, UPI credentials, or financial information.\n\n'
                          '• Subscription Verification via RevenueCat: We integrate the RevenueCat SDK (RevenueCat, Inc.) to validate store receipts, manage subscription states, verify the active "ampohm Pro" entitlement, and support purchase restorations. RevenueCat processes an anonymous app user identifier and receipt tokens generated by Google Play.\n\n'
                          '• Available Subscription Plans: Options include Pro Monthly (ampohm_pro_monthly, fallback ₹49 / Month) and Pro Yearly (ampohm_pro_annual, fallback ₹399 / Year) auto-renewing subscriptions.\n\n'
                          '• Automatic Renewal: Recurring monthly and yearly subscriptions automatically renew through Google Play unless cancelled by the user at least 24 hours prior to the end of the current billing cycle.\n\n'
                          '• Cancellation: Subscriptions may be cancelled at any time directly through Google Play Store (Account > Payments & subscriptions > Subscriptions).\n\n'
                          '• Access Following Cancellation: Cancelling auto-renewal stops future billing; your Pro entitlement remains active and completely ad-free until the verified expiration date of the currently paid billing period.\n\n'
                          '• Purchase Restoration: You can restore an active subscription on any device using the same Google Play account by tapping "Restore Purchases" in the app.',
                        ),
                        const SizedBox(height: 12),

                        _buildPolicyCard(
                          isNight,
                          '6. Data Security',
                          'We take reasonable and appropriate technical measures to safeguard application operations. All external network communications (Google Play Billing, RevenueCat entitlement checks, Google AdMob ad requests, and Firebase remote config lookups) occur exclusively over encrypted HTTPS/TLS connections. Device preferences are stored within sandboxed operating system storage. While we implement industry-standard practices, no electronic transmission or local mobile storage can be guaranteed to be 100% secure.',
                        ),
                        const SizedBox(height: 12),

                        _buildPolicyCard(
                          isNight,
                          '7. Children’s Privacy',
                          'Amp Ohm is a professional calculation and engineering utility designed specifically for audio engineers, sound technicians, DJs, and stage electricians. The application is not directed to or intended for children under 13 years of age. We do not knowingly collect or solicit personal information from children under 13.',
                        ),
                        const SizedBox(height: 12),

                        _buildPolicyCard(
                          isNight,
                          '8. Third-Party Services',
                          'The application utilizes strictly the following verified third-party services:\n\n'
                          '• Google AdMob (Google LLC) – Advertising delivery and monetization for free-tier users.\n'
                          '• Google Play Billing (Google LLC) – In-app purchase and subscription payment processing.\n'
                          '• RevenueCat (RevenueCat, Inc.) – Subscription entitlement management and receipt verification.\n'
                          '• Google Firebase / Cloud Firestore (Google LLC) – Anonymous read-only remote configuration checks (app_config/ads_settings and app_config/version_control) and optional VIP pass verification.',
                        ),
                        const SizedBox(height: 12),

                        _buildPolicyCard(
                          isNight,
                          '9. Changes to This Privacy Policy',
                          'AudioXpert may update this Privacy Policy from time to time to reflect operational, legal, or regulatory updates. The most current version will always be accessible directly through the application’s Settings & Information section. Continued use of Amp Ohm following any revisions indicates your acknowledgment and acceptance of the updated policy.',
                        ),
                        const SizedBox(height: 12),

                        _buildPolicyCard(
                          isNight,
                          '10. Contact Information',
                          'If you have any questions, concerns, or inquiries regarding this Privacy Policy or data handling in Amp Ohm, please contact AudioXpert directly at:\n\nEmail: audioxpert123@gmail.com',
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPolicyCard(bool isNight, String title, String body) {
    final cardBg = isNight ? const Color(0xFF141C30) : Colors.white;
    final cardBorder = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final titleColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final bodyColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF475569);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: cardBorder),
        boxShadow: [
          BoxShadow(
            color: isNight ? Colors.black.withOpacity(0.2) : const Color(0x060F172A),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.bold,
              color: titleColor,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            body,
            style: TextStyle(
              fontSize: 12,
              height: 1.5,
              color: bodyColor,
            ),
          ),
        ],
      ),
    );
  }
}
