import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../localization/app_localizations.dart';
import '../services/preference_service.dart';
import '../services/subscription_service.dart';
import '../services/admob_service.dart';
import '../services/analytics_service.dart';
import '../services/mail_service.dart';
import '../widgets/calculator_hero_header.dart';
import '../widgets/settings_modals.dart';
import 'paywall_screen.dart';
import '../utils/app_typography.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final prefService = Provider.of<PreferenceService>(context);
    final subService = Provider.of<SubscriptionService>(context);
    final adMobService = Provider.of<AdMobService>(context);
    final analytics = Provider.of<AnalyticsService>(context);
    final isHindi = prefService.locale.languageCode == 'hi';
    final isNight = prefService.isNightMode;

    final scaffoldBg = isNight ? const Color(0xFF0B111C) : const Color(0xFFF1F5F9);
    final sheetBg = isNight ? const Color(0xFF0F172A) : Colors.white;
    final cardBg = isNight ? const Color(0xFF141C30) : Colors.white;
    final cardBorder = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final headerTextColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);
    final dividerColor = isNight ? const Color(0xFF1E293B) : const Color(0xFFF1F5F9);

    return Scaffold(
      backgroundColor: scaffoldBg,
      body: SafeArea(
        child: Column(
          children: [
            // 1. Curved Hero Header matching Web
            CalculatorHeroHeader(
              title: isHindi ? 'सेटिंग्स एवं जानकारी' : 'Settings & Information',
              subtitle: isHindi
                  ? 'भाषा, सपोर्ट, कनेक्ट और एप्लिकेशन विवरण'
                  : 'Language, support, connect and application details',
              onBack: () => Navigator.pop(context),
            ),

            // 2. Curved Sheet for Settings Content
            Expanded(
              child: Transform.translate(
                offset: const Offset(0, -20),
                child: Container(
                  decoration: BoxDecoration(
                    color: sheetBg,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: isNight ? Colors.black.withOpacity(0.4) : const Color(0x140F172A),
                        blurRadius: 20,
                        offset: const Offset(0, -6),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(16, 24, 16, 32),
                      children: [
                        // Card 1: Language Selection Card
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: cardBorder),
                            boxShadow: [
                              BoxShadow(
                                color: isNight ? Colors.black.withOpacity(0.2) : const Color(0x060F172A),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(7),
                                    decoration: BoxDecoration(
                                      color: isNight ? const Color(0xFF1E293B) : const Color(0xFFEFF6FF),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: const Icon(Icons.language, size: 18, color: Color(0xFF1D4ED8)),
                                  ),
                                  const SizedBox(width: 10),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        isHindi ? 'ऐप की भाषा' : 'App Language',
                                        style: TextStyle(
                                          fontSize: 13.5,
                                          fontWeight: isHindi ? FontWeight.w600 : FontWeight.bold,
                                          color: isNight ? Colors.white : const Color(0xFF0F172A),
                                          fontFamilyFallback: AppTypography.hindiFontFallback,
                                        ),
                                      ),
                                      Text(
                                        isHindi ? 'अंग्रेजी या सरल पेशेवर हिन्दी' : 'Choose English or Professional Hindi',
                                        style: TextStyle(
                                          fontSize: 10.5,
                                          color: headerTextColor,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              const SizedBox(height: 14),

                              Row(
                                children: [
                                  // English
                                  Expanded(
                                    child: InkWell(
                                      onTap: () {
                                        prefService.setLocale(const Locale('en', ''));
                                        analytics.logLanguageChange('hi', 'en');
                                      },
                                      borderRadius: BorderRadius.circular(14),
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
                                        decoration: BoxDecoration(
                                          color: !isHindi 
                                              ? const Color(0xFF1D4ED8) 
                                              : (isNight ? const Color(0xFF0F1626) : const Color(0xFFF8FAFC)),
                                          borderRadius: BorderRadius.circular(14),
                                          border: Border.all(
                                            color: !isHindi 
                                                ? const Color(0xFF1D4ED8) 
                                                : cardBorder,
                                          ),
                                        ),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Expanded(
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    'English',
                                                    style: TextStyle(
                                                      fontSize: 12.5,
                                                      fontWeight: FontWeight.bold,
                                                      color: !isHindi 
                                                          ? Colors.white 
                                                          : (isNight ? Colors.white : const Color(0xFF0F172A)),
                                                    ),
                                                  ),
                                                  Text(
                                                    'Standard Audio',
                                                    style: TextStyle(
                                                      fontSize: 9.5,
                                                      color: !isHindi 
                                                          ? const Color(0xFFDBEAFE) 
                                                          : (isNight ? const Color(0xFF94A3B8) : const Color(0xFF94A3B8)),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            if (!isHindi)
                                              const Icon(Icons.check_circle_rounded, color: Color(0xFFFBBF24), size: 18),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 10),

                                  // Hindi
                                  Expanded(
                                    child: InkWell(
                                      onTap: () {
                                        prefService.setLocale(const Locale('hi', ''));
                                        analytics.logLanguageChange('en', 'hi');
                                      },
                                      borderRadius: BorderRadius.circular(14),
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
                                        decoration: BoxDecoration(
                                          color: isHindi 
                                              ? const Color(0xFF1D4ED8) 
                                              : (isNight ? const Color(0xFF0F1626) : const Color(0xFFF8FAFC)),
                                          borderRadius: BorderRadius.circular(14),
                                          border: Border.all(
                                            color: isHindi 
                                                ? const Color(0xFF1D4ED8) 
                                                : cardBorder,
                                          ),
                                        ),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Expanded(
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    'हिन्दी (Hindi)',
                                                    style: TextStyle(
                                                      fontSize: 12.5,
                                                      fontWeight: isHindi ? FontWeight.w600 : FontWeight.bold,
                                                      color: isHindi 
                                                          ? Colors.white 
                                                          : (isNight ? Colors.white : const Color(0xFF0F172A)),
                                                      fontFamilyFallback: AppTypography.hindiFontFallback,
                                                    ),
                                                  ),
                                                  Text(
                                                    'सरल पेशेवर भाषा',
                                                    style: TextStyle(
                                                      fontSize: 9.5,
                                                      color: isHindi 
                                                          ? const Color(0xFFDBEAFE) 
                                                          : (isNight ? const Color(0xFF94A3B8) : const Color(0xFF94A3B8)),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            if (isHindi)
                                              const Icon(Icons.check_circle_rounded, color: Color(0xFFFBBF24), size: 18),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 14),

                        // Section 1: Support & App Info (सपोर्ट एवं ऐप जानकारी)
                        Container(
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: cardBorder),
                            boxShadow: [
                              BoxShadow(
                                color: isNight ? Colors.black.withOpacity(0.2) : const Color(0x060F172A),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.fromLTRB(16, 12, 16, 6),
                                child: Text(
                                  isHindi ? 'सपोर्ट एवं ऐप जानकारी' : 'SUPPORT & APP INFO',
                                  style: TextStyle(
                                    fontSize: 10.5,
                                    fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                                    color: headerTextColor,
                                    letterSpacing: isHindi ? 0.2 : 1.0,
                                    fontFamilyFallback: AppTypography.hindiFontFallback,
                                  ),
                                ),
                              ),
                              Divider(height: 1, color: dividerColor),

                              // 1. Contact Us
                              _buildSettingRow(
                                isNight: isNight,
                                icon: Icons.mail_rounded,
                                iconColor: const Color(0xFF2563EB),
                                title: isHindi ? 'संपर्क करें (Contact Us)' : 'Contact Us',
                                subtitle: 'audioxpert123@gmail.com',
                                onTap: () => SettingsModals.showContact(context, isNight: isNight, isHindi: isHindi),
                              ),
                              Divider(height: 1, indent: 56, endIndent: 16, color: dividerColor),

                              // 2. Send Feedback (Direct 1-tap email with prefilled subject)
                              _buildSettingRow(
                                isNight: isNight,
                                icon: Icons.send_rounded,
                                iconColor: const Color(0xFF10B981),
                                title: isHindi ? 'फीडबैक भेजें (Send Feedback)' : 'Send Feedback',
                                subtitle: isHindi ? 'अपने सुझाव और अनुभव साझा करें' : 'Share your ideas & suggestions',
                                onTap: () => MailService.sendFeedback(),
                              ),
                              Divider(height: 1, indent: 56, endIndent: 16, color: dividerColor),

                              // 3. Report Issue (Direct 1-tap email with prefilled subject)
                              _buildSettingRow(
                                isNight: isNight,
                                icon: Icons.error_outline_rounded,
                                iconColor: const Color(0xFFF59E0B),
                                title: isHindi ? 'समस्या रिपोर्ट करें (Report Issue)' : 'Report Issue',
                                subtitle: isHindi ? 'कोई बग या गणना में कमी बताएं' : 'Report bugs or formula issues',
                                onTap: () => MailService.reportIssue(),
                              ),
                              Divider(height: 1, indent: 56, endIndent: 16, color: dividerColor),

                              // 4. Remove Ads / Pro Pass
                              _buildSettingRow(
                                isNight: isNight,
                                icon: Icons.stars_rounded,
                                iconColor: const Color(0xFFF59E0B),
                                title: t.removeAds,
                                subtitle: subService.isPremium 
                                    ? 'Pro Active (${subService.activeTier.toUpperCase()})' 
                                    : 'Monthly & Annual Pro plans',
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(builder: (_) => const PaywallScreen()),
                                  );
                                },
                              ),
                              Divider(height: 1, indent: 56, endIndent: 16, color: dividerColor),

                              // 4b. Watch Reward Video Ad (Google AdMob Test Rewarded Ad)
                              _buildSettingRow(
                                isNight: isNight,
                                icon: Icons.play_circle_fill_rounded,
                                iconColor: const Color(0xFF10B981),
                                title: isHindi ? 'रिवॉर्ड वीडियो ऐड (Test Ad)' : 'Watch Rewarded Video Ad',
                                subtitle: isHindi
                                    ? 'Google AdMob टेस्ट रिवॉर्ड वीडियो चलाएं और टेस्ट करें'
                                    : 'Test Google AdMob full-screen rewarded video ad',
                                trailing: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF10B981).withOpacity(0.15),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Text(
                                    isHindi ? 'टेस्ट करें' : 'TEST AD',
                                    style: const TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xFF10B981),
                                    ),
                                  ),
                                ),
                                onTap: () {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(isHindi ? 'रिवॉर्ड वीडियो लोड हो रहा है...' : 'Loading Rewarded Video Ad...'),
                                      duration: const Duration(seconds: 2),
                                    ),
                                  );
                                  adMobService.showRewardedAdWithLoadingDialog(
                                    context,
                                    onResult: (success, msg) {
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(
                                          content: Text(msg),
                                          backgroundColor: success ? const Color(0xFF10B981) : const Color(0xFFEF4444),
                                        ),
                                      );
                                    },
                                  );
                                },
                              ),
                              Divider(height: 1, indent: 56, endIndent: 16, color: dividerColor),

                              // 5. Rate App
                              _buildSettingRow(
                                isNight: isNight,
                                icon: Icons.star_rate_rounded,
                                iconColor: const Color(0xFFF59E0B),
                                title: t.rateApp,
                                subtitle: 'Rate on Google Play Store',
                                onTap: () {
                                  showDialog(
                                    context: context,
                                    builder: (_) => AlertDialog(
                                      backgroundColor: cardBg,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(20),
                                        side: BorderSide(color: cardBorder),
                                      ),
                                      title: Text(
                                        'Rate AMP OHM',
                                        style: TextStyle(color: isNight ? Colors.white : const Color(0xFF0F172A), fontWeight: FontWeight.bold),
                                      ),
                                      content: Text(
                                        'Thank you! This launches the Google Play In-App Review flow in production.',
                                        style: TextStyle(color: isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B)),
                                      ),
                                      actions: [
                                        TextButton(
                                          onPressed: () => Navigator.pop(context),
                                          child: const Text('OK', style: TextStyle(fontWeight: FontWeight.bold)),
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                              Divider(height: 1, indent: 56, endIndent: 16, color: dividerColor),

                              // 6. Share App (Native System Share Sheet)
                              _buildSettingRow(
                                isNight: isNight,
                                icon: Icons.share_rounded,
                                iconColor: const Color(0xFF2563EB),
                                title: 'Share App',
                                subtitle: 'Share toolkit with sound crew & DJs',
                                onTap: () {
                                  Share.share(
                                    'Check out AMP OHM - Professional Sound & Lighting Tools for audio crew, DJs and technicians! https://play.google.com/store/apps/details?id=com.ampohm.app',
                                    subject: 'AMP OHM Audio & Lighting Tools',
                                  );
                                },
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 14),

                        // Section 2: Legal & Transparency (कानूनी व पारदर्शिता)
                        Container(
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: cardBorder),
                            boxShadow: [
                              BoxShadow(
                                color: isNight ? Colors.black.withOpacity(0.2) : const Color(0x060F172A),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.fromLTRB(16, 12, 16, 6),
                                child: Text(
                                  isHindi ? 'कानूनी व पारदर्शिता' : 'LEGAL & TRANSPARENCY',
                                  style: TextStyle(
                                    fontSize: 10.5,
                                    fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                                    color: headerTextColor,
                                    letterSpacing: isHindi ? 0.2 : 1.0,
                                    fontFamilyFallback: AppTypography.hindiFontFallback,
                                  ),
                                ),
                              ),
                              Divider(height: 1, color: dividerColor),

                              // About App
                              _buildSettingRow(
                                isNight: isNight,
                                icon: Icons.info_outline_rounded,
                                iconColor: const Color(0xFF2563EB),
                                title: isHindi ? 'AMP OHM के बारे में (About)' : 'About AMP OHM',
                                subtitle: 'Version, mission & AudioXpert engineering',
                                onTap: () => SettingsModals.showAbout(context, isNight: isNight, isHindi: isHindi),
                              ),
                              Divider(height: 1, indent: 56, endIndent: 16, color: dividerColor),

                              // Privacy Policy
                              _buildSettingRow(
                                isNight: isNight,
                                icon: Icons.shield_outlined,
                                iconColor: const Color(0xFF10B981),
                                title: isHindi ? 'प्राइवेसी पॉलिसी (Privacy)' : 'Privacy Policy',
                                subtitle: 'Local calculations, zero telemetry & policies',
                                onTap: () => SettingsModals.showPrivacy(context, isNight: isNight, isHindi: isHindi),
                              ),
                              Divider(height: 1, indent: 56, endIndent: 16, color: dividerColor),

                              // Terms & Conditions
                              _buildSettingRow(
                                isNight: isNight,
                                icon: Icons.gavel_rounded,
                                iconColor: const Color(0xFF2563EB),
                                title: isHindi ? 'नियम एवं शर्तें (Terms)' : 'Terms & Conditions',
                                subtitle: 'Application license & operational responsibility',
                                onTap: () => SettingsModals.showTerms(context, isNight: isNight, isHindi: isHindi),
                              ),
                              Divider(height: 1, indent: 56, endIndent: 16, color: dividerColor),

                              // Disclaimer
                              _buildSettingRow(
                                isNight: isNight,
                                icon: Icons.warning_amber_rounded,
                                iconColor: const Color(0xFFF59E0B),
                                title: isHindi ? 'डिस्क्लेमर (Disclaimer)' : 'Disclaimer',
                                subtitle: 'Loudspeaker & amplifier safety notice',
                                onTap: () => SettingsModals.showDisclaimer(context, isNight: isNight, isHindi: isHindi),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 20),

                        // Connect Section
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: cardBorder),
                            boxShadow: [
                              BoxShadow(
                                color: isNight ? Colors.black.withOpacity(0.2) : const Color(0x060F172A),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                isHindi ? 'कनेक्ट (Connect)' : 'Connect',
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w900,
                                  color: isNight ? Colors.white : const Color(0xFF0F172A),
                                ),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                isHindi ? 'AudioXpert के ऑफिशियल चैनलों से जुड़ें' : 'Follow official AudioXpert channels',
                                style: TextStyle(
                                  fontSize: 11,
                                  color: headerTextColor,
                                ),
                              ),
                              const SizedBox(height: 12),
                              _buildSocialRow(isNight, Icons.camera_alt_outlined, 'Instagram', '@audio_xpert', const Color(0xFFE1306C)),
                              const SizedBox(height: 8),
                              _buildSocialRow(isNight, Icons.video_library_rounded, 'YouTube', '@audioxpertt', const Color(0xFFEF4444)),
                              const SizedBox(height: 8),
                              _buildSocialRow(isNight, Icons.mail_outline_rounded, 'Email', 'audioxpert123@gmail.com', const Color(0xFF2563EB)),
                            ],
                          ),
                        ),

                        const SizedBox(height: 24),

                        // Developer Credits & Footer (Unified to v1.0.4)
                        Center(
                          child: Column(
                            children: [
                              RichText(
                                text: TextSpan(
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    color: isNight ? const Color(0xFFCBD5E1) : const Color(0xFF334155),
                                  ),
                                  children: const [
                                    TextSpan(text: 'Developed by '),
                                    TextSpan(
                                      text: 'AudioXpert',
                                      style: TextStyle(color: Color(0xFF2563EB), fontWeight: FontWeight.w900),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 3),
                              Text(
                                'AMP OHM • Audio & Lighting Tools • v1.0.4',
                                style: TextStyle(
                                  fontSize: 10,
                                  fontWeight: FontWeight.w500,
                                  color: isNight ? const Color(0xFF64748B) : const Color(0xFF94A3B8),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSettingRow({
    required bool isNight,
    required IconData icon,
    required Color iconColor,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    Widget? trailing,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: iconColor.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, size: 20, color: iconColor),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Builder(
                    builder: (context) {
                      final isHindiTitle = AppTypography.isDevanagari(title);
                      return Text(
                        title,
                        style: TextStyle(
                          fontSize: 13.5,
                          fontWeight: isHindiTitle ? FontWeight.w600 : FontWeight.bold,
                          color: isNight ? Colors.white : const Color(0xFF0F172A),
                          fontFamilyFallback: AppTypography.hindiFontFallback,
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 11,
                      color: isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B),
                    ),
                  ),
                ],
              ),
            ),
            trailing ??
                Icon(
                  Icons.chevron_right,
                  size: 18,
                  color: isNight ? const Color(0xFF475569) : const Color(0xFFCBD5E1),
                ),
          ],
        ),
      ),
    );
  }

  Widget _buildSocialRow(bool isNight, IconData icon, String label, String handle, Color accent) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      decoration: BoxDecoration(
        color: isNight ? const Color(0xFF0F1626) : const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Icon(icon, size: 18, color: accent),
              const SizedBox(width: 10),
              Text(
                label,
                style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.bold,
                  color: isNight ? Colors.white : const Color(0xFF0F172A),
                ),
              ),
            ],
          ),
          Row(
            children: [
              Text(
                handle,
                style: TextStyle(
                  fontSize: 12,
                  fontFamily: 'monospace',
                  fontWeight: FontWeight.bold,
                  color: accent,
                ),
              ),
              const SizedBox(width: 4),
              Icon(Icons.open_in_new_rounded, size: 14, color: accent),
            ],
          ),
        ],
      ),
    );
  }
}
