import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/preference_service.dart';
import '../localization/app_localizations.dart';
import 'ohm_calculator_screen.dart';
import 'amplifier_calculator_screen.dart';
import 'cable_loss_screen.dart';
import 'dmx_screen.dart';

class GuideScreen extends StatefulWidget {
  const GuideScreen({super.key});

  @override
  State<GuideScreen> createState() => _GuideScreenState();
}

class _GuideScreenState extends State<GuideScreen> {
  String _activeCategory = 'all';

  bool get isHindi {
    try {
      return Provider.of<PreferenceService>(context, listen: false).locale.languageCode == 'hi';
    } catch (_) {
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final prefService = Provider.of<PreferenceService>(context);
    final isHindi = prefService.locale.languageCode == 'hi';
    final isNight = prefService.isNightMode;

    final bgColor = isNight ? const Color(0xFF070B14) : const Color(0xFFE5EBF3);
    final cardBg = isNight ? const Color(0xFF101726) : Colors.white;
    final borderColor = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final textColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final subtitleColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    final categories = [
      {'id': 'all', 'label': isHindi ? 'सभी' : 'All'},
      {'id': 'speaker', 'label': isHindi ? 'स्पीकर' : 'Speaker'},
      {'id': 'amp', 'label': isHindi ? 'एम्पलीफायर' : 'Amplifier'},
      {'id': 'cable', 'label': isHindi ? 'केबल' : 'Cable'},
      {'id': 'lighting', 'label': isHindi ? 'लाइटिंग' : 'Lighting'},
    ];

    return Scaffold(
      backgroundColor: bgColor,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          children: [
            // Top Screen Banner Card
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: cardBg,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: borderColor),
                boxShadow: [
                  BoxShadow(
                    color: isNight ? Colors.black.withOpacity(0.4) : const Color(0x0A0F172A),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: isNight ? const Color(0xFF1E293B) : const Color(0xFFEFF6FF),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isNight ? const Color(0xFF334155) : const Color(0xFFBFDBFE),
                      ),
                    ),
                    child: Icon(
                      Icons.menu_book_rounded,
                      color: isNight ? const Color(0xFF38BDF8) : const Color(0xFF1D4ED8),
                      size: 22,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          isHindi ? 'अपने इक्विपमेंट की डिटेल्स कहाँ देखें' : 'Where to Find Your Equipment Details',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: isHindi ? FontWeight.w600 : FontWeight.w700,
                            color: textColor,
                            letterSpacing: isHindi ? 0.0 : -0.3,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          isHindi ? 'स्पीकर ओहम, वॉटेज व स्टेज लाइटिंग ट्रिक्स' : 'Ohm, RMS, and Stage wiring practical rules',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                            color: subtitleColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 12),

            // Category Filter Pills
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: categories.map((cat) {
                  final isSelected = _activeCategory == cat['id'];
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: InkWell(
                      onTap: () => setState(() => _activeCategory = cat['id']!),
                      borderRadius: BorderRadius.circular(16),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? (isNight ? const Color(0xFF2563EB) : const Color(0xFF1D4ED8))
                              : (isNight ? const Color(0xFF101726) : Colors.white),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: isSelected
                                ? (isNight ? const Color(0xFF38BDF8) : const Color(0xFF1D4ED8))
                                : borderColor,
                          ),
                          boxShadow: isSelected
                              ? [
                                  BoxShadow(
                                    color: const Color(0xFF1D4ED8).withOpacity(0.3),
                                    blurRadius: 6,
                                    offset: const Offset(0, 2),
                                  ),
                                ]
                              : null,
                        ),
                        child: Text(
                          cat['label']!,
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            color: isSelected
                                ? Colors.white
                                : (isNight ? const Color(0xFFCBD5E1) : const Color(0xFF475569)),
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),

            const SizedBox(height: 16),

            // Guide Card 1: Speaker Ohm
            if (_activeCategory == 'all' || _activeCategory == 'speaker')
              _buildGuideCard(
                id: 'speaker_ohm',
                title: isHindi ? 'Speaker Ohm (Impedance) कहाँ मिलेगा?' : 'Where to find Speaker Impedance (Ohm)',
                badge: 'SPEAKER OHM',
                summary: isHindi
                    ? 'स्पीकर कैबिनेट, रॉ ड्राइवर मैग्नेट और मल्टीमीटर से सही Ohm पता करने का तरीका।'
                    : 'How to check nominal impedance (4Ω, 8Ω, or 16Ω) on cabinets and raw drivers.',
                icon: Icons.layers_rounded,
                points: [
                  {
                    'title': isHindi ? '1. कैबिनेट के पीछे Speakon प्लेट पर' : '1. Back Speakon Plate',
                    'desc': isHindi
                        ? 'स्पीकर कैबिनेट के पीछे धातु या प्लास्टिक प्लेट पर "8Ω" या "4Ω" स्पष्ट लिखा होता है।'
                        : 'Check the metal or plastic connector plate on the back of the cabinet.',
                  },
                  {
                    'title': isHindi ? '2. वूफर मैग्नेट के पीछे का स्टिकर' : '2. Raw Woofer Magnet Sticker',
                    'desc': isHindi
                        ? 'स्पीकर जाली खोलकर वूफर के मैग्नेट पर देखें, वहां मॉडल नंबर के साथ 8 Ohm या 4 Ohm छपा रहता है।'
                        : 'A stamped foil sticker on the magnet will display "8 Ohm" or "4 Ohm".',
                  },
                  {
                    'title': isHindi ? '3. डिजिटल मल्टीमीटर से टेस्ट करें' : '3. Testing with a Digital Multimeter',
                    'desc': isHindi
                        ? 'मल्टीमीटर को DC Resistance मोड पर लगाएं। 8Ω का स्पीकर लगभग 5.6Ω से 6.8Ω दिखाएगा।'
                        : '8Ω speaker reads ~5.6Ω to 6.8Ω DC resistance (about 70-80% of nominal impedance).',
                  },
                ],
                calcButtonTitle: isHindi ? 'ओम कैलकुलेटर खोलें' : 'Open Ohm Calculator',
                onOpenCalc: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const OhmCalculatorScreen()));
                },
              ),

            const SizedBox(height: 12),

            // Guide Card 2: RMS Power
            if (_activeCategory == 'all' || _activeCategory == 'speaker' || _activeCategory == 'amp')
              _buildGuideCard(
                id: 'rms_power',
                title: isHindi ? 'RMS Power (वॉटेज) कहाँ मिलेगी?' : 'Where to find RMS Power (Wattage)',
                badge: 'RMS POWER',
                summary: isHindi
                    ? 'असली कंटीन्यूअस (RMS) पावर पहचानें और नकली PMPO या Peak नंबरों के धोखे से बचें।'
                    : 'Find continuous voice coil wattage and avoid misleading PMPO or peak numbers.',
                icon: Icons.bolt_rounded,
                points: [
                  {
                    'title': isHindi ? '1. "RMS" या "AES" पावर देखें' : '1. Look for "RMS" or "AES"',
                    'desc': isHindi
                        ? 'हमेशा RMS Power, Continuous या AES रेटिंग (जैसे 600W RMS) देखें।'
                        : 'Always check continuous power handling (e.g. 600W RMS), not peak marketing claims.',
                  },
                  {
                    'title': isHindi ? '2. PMPO या Max पावर से बचें' : '2. Ignore PMPO Claims',
                    'desc': isHindi
                        ? '5000W PMPO जैसे नकली नंबर सिर्फ मार्केटिंग के लिए होते हैं, इन पर भरोसा न करें।'
                        : 'PMPO numbers are instantaneous split-second spikes and not usable for system design.',
                  },
                ],
                calcButtonTitle: isHindi ? 'एम्पलीफायर कैलकुलेटर खोलें' : 'Open Amplifier Calculator',
                onOpenCalc: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const AmplifierCalculatorScreen()));
                },
              ),

            const SizedBox(height: 12),

            // Guide Card 3: DMX 512 Addressing & Footprint
            if (_activeCategory == 'all' || _activeCategory == 'lighting')
              _buildGuideCard(
                id: 'dmx_guide',
                title: isHindi ? 'DMX 512 एड्रेसिंग व पैच कैसे सेट करें?' : 'How to set DMX 512 Addressing & Patch',
                badge: 'DMX 512',
                summary: isHindi
                    ? 'कंट्रोलर और स्टेज फिक्स्चर के बीच सही बेस एड्रेस और चैनल फुटप्रिंट सेट करें।'
                    : 'Assign proper start addresses and footprint channels across all lighting fixtures.',
                icon: Icons.tune_rounded,
                points: [
                  {
                    'title': isHindi ? '1. चैनल फुटप्रिंट (Footprint) समझें' : '1. Know Fixture Footprint',
                    'desc': isHindi
                        ? 'हर फिक्स्चर कितने चैनल (जैसे 4CH, 7CH, 16CH) लेता है, अगला एड्रेस उसी के बाद शुरू होता है।'
                        : 'Each fixture consumes a specific channel block (e.g. 4CH, 7CH, 16CH). The next fixture starts right after.',
                  },
                  {
                    'title': isHindi ? '2. ओवरलैपिंग एड्रेस से बचें' : '2. Avoid Overlapping Addresses',
                    'desc': isHindi
                        ? 'दो अलग फिक्स्चर्स को एक ही चैनल रेंज न दें ताकि दोनों को स्वतंत्र रूप से कंट्रोल किया जा सके।'
                        : 'Ensure fixture addresses do not overlap so each light can be controlled independently.',
                  },
                ],
                calcButtonTitle: isHindi ? 'DMX कैलकुलेटर खोलें' : 'Open DMX Calculator',
                onOpenCalc: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const DmxScreen()));
                },
              ),

            const SizedBox(height: 12),

            // Guide Card 4: Speaker Cable Sizing & Loss Rules
            if (_activeCategory == 'all' || _activeCategory == 'cable')
              _buildGuideCard(
                id: 'cable_guide',
                title: isHindi ? 'स्पीकर केबल साइज व लॉस कैसे चुनें?' : 'Speaker Cable Sizing & Loss Rules',
                badge: 'CABLE LOSS',
                summary: isHindi
                    ? 'लंबे केबल रन पर वॉटेज लॉस से बचें और सही mm² गेज तार का चुनाव करें।'
                    : 'Prevent heavy wattage loss on long cable runs and pick the right mm² conductor gauge.',
                icon: Icons.cable_rounded,
                points: [
                  {
                    'title': isHindi ? '1. 4Ω और 2Ω सिस्टम के लिए मोटा तार' : '1. Heavy Gauge for 4Ω & 2Ω',
                    'desc': isHindi
                        ? 'कम ओहम पर केबल में ज्यादा करंट बहता है। 4Ω पर कम से कम 2.5 mm² या 4.0 mm² केबल इस्तेमाल करें।'
                        : 'Low impedance systems draw high current. Always use at least 2.5 mm² or 4.0 mm² for 4Ω loads.',
                  },
                  {
                    'title': isHindi ? '2. प्योर कॉपर (OFC) बनाम CCA' : '2. Pure Copper vs. CCA',
                    'desc': isHindi
                        ? 'CCA (Copper Clad Aluminium) में 60% ज्यादा रेजिस्टेंस होता है। 20 मीटर से लंबे रन पर हमेशा प्योर कॉपर चुनें।'
                        : 'CCA cable has ~1.6x higher resistance than pure copper. Always choose OFC pure copper for runs over 20m.',
                  },
                  {
                    'title': isHindi ? '3. डैम्पिंग फैक्टर और पंच (Bass Punch)' : '3. Damping Factor & Punch',
                    'desc': isHindi
                        ? 'पतले केबल से एम्पलीफायर का डैम्पिंग फैक्टर गिर जाता है जिससे सबवूफर का बेस ढीला और मद्धम पड़ता है।'
                        : 'High cable resistance degrades damping factor, causing muddy bass response in high-power subwoofers.',
                  },
                ],
                calcButtonTitle: isHindi ? 'केबल लॉस कैलकुलेटर खोलें' : 'Open Cable Loss Calculator',
                onOpenCalc: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const CableLossScreen()));
                },
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildGuideCard({
    required String id,
    required String title,
    required String badge,
    required String summary,
    required IconData icon,
    required List<Map<String, String>> points,
    required String calcButtonTitle,
    required VoidCallback onOpenCalc,
  }) {
    final prefService = Provider.of<PreferenceService>(context);
    final isNight = prefService.isNightMode;
    final isHindi = prefService.locale.languageCode == 'hi';

    final cardBg = isNight ? const Color(0xFF101726) : Colors.white;
    final borderColor = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final innerItemBg = isNight ? const Color(0xFF0B101B) : const Color(0xFFF8FAFC);
    final titleColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final subtitleColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    return Container(
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: borderColor),
        boxShadow: [
          BoxShadow(
            color: isNight ? Colors.black.withOpacity(0.3) : const Color(0x080F172A),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: isNight ? const Color(0xFF1E293B) : const Color(0xFFEFF6FF),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: isNight ? const Color(0xFF334155) : const Color(0xFFBFDBFE),
                    ),
                  ),
                  child: Icon(
                    icon,
                    color: isNight ? const Color(0xFF38BDF8) : const Color(0xFF1D4ED8),
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                        decoration: BoxDecoration(
                          color: isNight ? const Color(0xFF1E293B) : const Color(0xFFEFF6FF),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          badge,
                          style: TextStyle(
                            fontSize: 9.5,
                            fontWeight: FontWeight.w800,
                            color: isNight ? const Color(0xFF38BDF8) : const Color(0xFF1D4ED8),
                          ),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        title,
                        style: TextStyle(
                          fontSize: 14.5,
                          fontWeight: isHindi ? FontWeight.w700 : FontWeight.w800,
                          color: titleColor,
                          letterSpacing: isHindi ? 0.0 : -0.2,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        summary,
                        style: TextStyle(
                          fontSize: 11.5,
                          color: subtitleColor,
                          height: 1.3,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          Divider(height: 1, color: borderColor),

          // Content points directly shown (no extra expand step)
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ...points.map((pt) {
                  return Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: innerItemBg,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: borderColor),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          pt['title']!,
                          style: TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.w800,
                            color: titleColor,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          pt['desc']!,
                          style: TextStyle(
                            fontSize: 11.5,
                            color: subtitleColor,
                            height: 1.35,
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),

                const SizedBox(height: 4),

                // Open matching calculator button
                InkWell(
                  onTap: onOpenCalc,
                  borderRadius: BorderRadius.circular(16),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(
                      color: isNight ? const Color(0xFF1E293B) : const Color(0xFFEFF6FF),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: isNight ? const Color(0xFF334155) : const Color(0xFFBFDBFE),
                      ),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          calcButtonTitle,
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                            color: isNight ? const Color(0xFF38BDF8) : const Color(0xFF1D4ED8),
                          ),
                        ),
                        const SizedBox(width: 6),
                        Icon(
                          Icons.arrow_forward_rounded,
                          size: 16,
                          color: isNight ? const Color(0xFF38BDF8) : const Color(0xFF1D4ED8),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
