import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/preference_service.dart';
import '../calculators/cable_loss_calculator.dart';
import '../localization/app_localizations.dart';
import '../models/models.dart';
import '../widgets/calculator_hero_header.dart';
import '../widgets/share_result_button.dart';
import '../widgets/ad_banner_widget.dart';
import '../utils/app_typography.dart';

class CableLossResultScreen extends StatelessWidget {
  final CableLossResult result;

  const CableLossResultScreen({
    super.key,
    required this.result,
  });

  String _generateShareText(bool isHindi) {
    final awg = CableLossCalculator.sizeAwgMap[result.recommendedCableSize] ?? '';
    final mat = result.material.toLowerCase() == 'cca' ? 'CCA (Aluminium)' : 'Pure OFC Copper';
    final recStr = result.meetsTarget
        ? '${result.recommendedCableSize} mm² ($awg)'
        : 'None meets target (${result.recommendedCableSize} mm² lowest loss: ${result.allSizes.last.powerLossPercent}%)';
    final minStr = result.minimumAcceptableSize != null
        ? '${result.minimumAcceptableSize} mm²'
        : 'None (< ${result.maxAcceptableLoss.toInt()}%)';
    final proStr = result.professionalChoiceSize != null
        ? '${result.professionalChoiceSize} mm²'
        : 'None';

    return '''
==============================
AMP OHM - CABLE LOSS CALCULATION
==============================
System Parameters:
• One-Way Run: ${result.cableLength} Meters
• Total Power: ${result.power.toInt()}W RMS
• Speaker Load: ${result.load}Ω
• Conductor: $mat
• Resistance Target: Max ${result.maxAcceptableLoss.toInt()}% of load (R_loop / R_load)
• Actual Power Loss: ${result.powerLossWatts} W (${result.powerLossPercent}%)

Recommendations:
• RECOMMENDED GAUGE: $recStr
• Min Acceptable: $minStr
• Pro Touring Choice: $proStr

Standard Baseline Reference (${result.cableSize} mm²):
• Loop Resistance: ${result.loopResistance} Ω
• Voltage Drop: ${result.voltageDrop} V (${result.voltageDropPercent}%)
• Power Loss: ${result.powerLossWatts} W (${result.powerLossPercent}%)
• Delivery Efficiency: ${result.estimatedEfficiency}%

Calculated with AMP OHM - Developed by AudioXpert
━━━━━━━━━━━━━━━━━━
📱 AMP OHM App:
https://play.google.com/store/apps/details?id=com.ampohm.app

📸 Instagram:
https://instagram.com/audio_xpert

▶️ YouTube:
https://youtube.com/@audioxpertt
==============================''';
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final isHindi = Localizations.localeOf(context).languageCode == 'hi';
    final prefService = Provider.of<PreferenceService>(context);
    final isNight = prefService.isNightMode;

    final bgColor = isNight ? const Color(0xFF070B14) : const Color(0xFFF1F5F9);
    final sheetBg = isNight ? const Color(0xFF0E1526) : Colors.white;
    final cardBg = isNight ? const Color(0xFF141C30) : Colors.white;
    final borderColorCard = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final textColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final subtitleColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    final recAwg = CableLossCalculator.sizeAwgMap[result.recommendedCableSize] ?? '';
    final activeAwg = CableLossCalculator.sizeAwgMap[result.cableSize] ?? '';
    final isCca = result.material.toLowerCase() == 'cca';

    // Premium colored gradient hero banner matching Ohm and Amp calculators
    List<Color> bannerGradient;
    Color badgeBg;
    Color badgeColor;
    Color borderColor;
    IconData statusIcon;
    String statusTitle;
    String statusMessage;

    if (result.meetsTarget) {
      bannerGradient = const [Color(0xFF064E3B), Color(0xFF065F46), Color(0xFF022C22)];
      badgeBg = const Color(0xFF059669);
      badgeColor = Colors.white;
      borderColor = const Color(0xFF34D399);
      statusIcon = Icons.check_circle_rounded;
      statusTitle = isHindi ? 'बेस्ट केबल' : 'RECOMMENDED';
      statusMessage = isHindi
          ? '${result.cableLength.truncateToDouble() == result.cableLength ? result.cableLength.toInt() : result.cableLength} मीटर दूरी और ${result.load}Ω लोड पर यह केबल पावर लॉस को एकदम कम (${result.maxAcceptableLoss.toInt()}% के अंदर) रखेगी। आवाज एकदम साफ और पंचदार रहेगी।'
          : 'Keeps cable loop resistance within the ${result.maxAcceptableLoss.toInt()}% load target over ${result.cableLength.truncateToDouble() == result.cableLength ? result.cableLength.toInt() : result.cableLength}m @ ${result.load}Ω.';
    } else {
      bannerGradient = const [Color(0xFF550C16), Color(0xFF821422), Color(0xFF36080E)];
      badgeBg = const Color(0xFFDC2626);
      badgeColor = Colors.white;
      borderColor = const Color(0xFFEF4444);
      statusIcon = Icons.warning_amber_rounded;
      statusTitle = isHindi ? 'लॉस बहुत ज्यादा' : 'TARGET EXCEEDED';
      statusMessage = isHindi
          ? '${result.cableLength.truncateToDouble() == result.cableLength ? result.cableLength.toInt() : result.cableLength} मीटर दूरी और ${result.load}Ω पर तार बहुत लंबा होने से लॉस बढ़ रहा है। 10 mm² केबल लगाने से सबसे कम नुकसान (${result.allSizes.last.powerLossPercent}%) होगा।'
          : 'No available cable size meets the ${result.maxAcceptableLoss.toInt()}% resistance target over ${result.cableLength.truncateToDouble() == result.cableLength ? result.cableLength.toInt() : result.cableLength}m @ ${result.load}Ω. 10 mm² provides lowest loss (${result.allSizes.last.powerLossPercent}%).';
    }

    final wiringStr = result.wiring == 'series'
        ? (isHindi ? 'सीरीज' : 'Series')
        : (isHindi ? 'पैरेलल' : 'Parallel');

    return Scaffold(
      backgroundColor: bgColor,
      body: SafeArea(
        child: Column(
          children: [
            // 1. Curved Hero Header matching other calculators
            CalculatorHeroHeader(
              title: isHindi ? 'केबल साइज रिज़ल्ट' : t.cableResultTitle,
              subtitle: isHindi
                  ? 'पावर लॉस और केबल साइज तुलना'
                  : 'Power loss & 5-gauge comparison matrix',
              onBack: () => Navigator.pop(context),
            ),

            // 2. Curved Sheet for Results
            Expanded(
              child: Transform.translate(
                offset: const Offset(0, -20),
                child: Container(
                  decoration: BoxDecoration(
                    color: sheetBg,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: isNight ? Colors.black.withOpacity(0.5) : const Color(0x140F172A),
                        blurRadius: 20,
                        offset: const Offset(0, -6),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
                      children: [
                        // HERO CARD: RECOMMENDED CABLE GAUGE (Matching Ohm & Amp Hero Banners)
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: bannerGradient,
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(28),
                            border: Border.all(color: borderColor.withOpacity(0.8), width: 1.5),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.2),
                                blurRadius: 16,
                                offset: const Offset(0, 6),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Top Badges Row
                              Wrap(
                                alignment: WrapAlignment.spaceBetween,
                                crossAxisAlignment: WrapCrossAlignment.center,
                                spacing: 8,
                                runSpacing: 6,
                                children: [
                                  Wrap(
                                    crossAxisAlignment: WrapCrossAlignment.center,
                                    spacing: 6,
                                    runSpacing: 4,
                                    children: [
                                      Text(
                                        (isHindi ? 'बेस्ट केबल साइज़' : 'RECOMMENDED CABLE SIZE').toUpperCase(),
                                        style: TextStyle(
                                          fontSize: 11,
                                          fontWeight: isHindi ? FontWeight.w600 : FontWeight.bold,
                                          letterSpacing: isHindi ? 0.0 : 0.8,
                                          color: Colors.white.withOpacity(0.85),
                                          fontFamilyFallback: AppTypography.hindiFontFallback,
                                        ),
                                      ),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                        decoration: BoxDecoration(
                                          color: Colors.white.withOpacity(0.2),
                                          borderRadius: BorderRadius.circular(12),
                                          border: Border.all(color: Colors.white.withOpacity(0.25)),
                                        ),
                                        child: Text(
                                          isCca
                                              ? (isHindi ? 'CCA एल्युमिनियम' : 'CCA CONDUCTOR')
                                              : (isHindi ? 'असली तांबा (Copper)' : 'OFC PURE COPPER'),
                                          style: TextStyle(
                                            fontSize: 9.5,
                                            fontWeight: isHindi ? FontWeight.w600 : FontWeight.bold,
                                            color: Colors.white,
                                            fontFamilyFallback: AppTypography.hindiFontFallback,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),

                                  // Status Badge
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: badgeBg,
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                    child: Text(
                                      statusTitle.toUpperCase(),
                                      style: TextStyle(
                                        fontSize: 10.5,
                                        fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                                        color: badgeColor,
                                        letterSpacing: isHindi ? 0.0 : 0.5,
                                        fontFamilyFallback: AppTypography.hindiFontFallback,
                                      ),
                                    ),
                                  ),
                                ],
                              ),

                              const SizedBox(height: 10),

                              // Big Cable Size Number Display
                              FittedBox(
                                fit: BoxFit.scaleDown,
                                alignment: Alignment.centerLeft,
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.baseline,
                                  textBaseline: TextBaseline.alphabetic,
                                  children: [
                                    Text(
                                      '${result.recommendedCableSize} mm²',
                                      style: const TextStyle(
                                        fontSize: 44,
                                        fontWeight: FontWeight.w900,
                                        color: Colors.white,
                                        letterSpacing: -1.0,
                                        height: 1.0,
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Text(
                                      '($recAwg)',
                                      style: const TextStyle(
                                        fontSize: 22,
                                        fontWeight: FontWeight.bold,
                                        color: Color(0xFFFBBF24),
                                      ),
                                    ),
                                    if (!result.meetsTarget) ...[
                                      const SizedBox(width: 8),
                                      Text(
                                        isHindi ? '(सबसे कम लॉस वाला तार)' : '(Lowest Loss)',
                                        style: const TextStyle(
                                          fontSize: 13,
                                          fontWeight: FontWeight.bold,
                                          color: Color(0xFFFCA5A5),
                                        ),
                                      ),
                                    ],
                                  ],
                                ),
                              ),

                              const SizedBox(height: 14),

                              // Inner Explanatory Card
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.35),
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(color: Colors.white.withOpacity(0.12)),
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Icon(statusIcon, color: borderColor, size: 20),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            result.meetsTarget
                                                ? (isHindi ? 'केबल बिल्कुल सही है (Safe)' : 'Optimal Cable Compliance')
                                                : (isHindi ? 'पावर लॉस ज्यादा है (चेतावनी)' : 'Target Exceeded Advisory'),
                                            style: TextStyle(
                                              fontSize: 12.5,
                                              fontWeight: FontWeight.bold,
                                              color: borderColor,
                                            ),
                                          ),
                                          const SizedBox(height: 2),
                                          Text(
                                            statusMessage,
                                            style: TextStyle(
                                              fontSize: 11,
                                              color: Colors.white.withOpacity(0.9),
                                              height: 1.35,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 12),

                        // Info Scope Notice
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          decoration: BoxDecoration(
                            color: isNight ? const Color(0xFF0B172E) : const Color(0xFFEFF6FF),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: isNight ? const Color(0xFF1E3A8A) : const Color(0xFFBFDBFE),
                            ),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.info_outline_rounded,
                                size: 18,
                                color: isNight ? const Color(0xFF38BDF8) : const Color(0xFF2563EB),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  isHindi
                                      ? 'यह केबल ${result.cableLength.toInt()} मीटर दूरी पर पावर लॉस को एकदम कम रखती है ताकि बेस और आवाज साफ रहे।'
                                      : 'Optimized for ${result.cableLength.toInt()}m one-way run to keep loop resistance and actual power loss minimized.',
                                  style: TextStyle(
                                    fontSize: 11.5,
                                    fontWeight: FontWeight.w600,
                                    color: isNight ? const Color(0xFF93C5FD) : const Color(0xFF1E40AF),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 14),

                        // CARD 1: SYSTEM INPUT PARAMETERS
                        Container(
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(color: borderColorCard),
                            boxShadow: [
                              BoxShadow(
                                color: isNight ? Colors.black.withOpacity(0.3) : const Color(0x060F172A),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(
                                    Icons.tune_rounded,
                                    size: 16,
                                    color: isNight ? const Color(0xFF38BDF8) : const Color(0xFF2563EB),
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    (isHindi ? 'सिस्टम इनपुट' : 'SYSTEM PARAMETERS').toUpperCase(),
                                    style: TextStyle(
                                      fontSize: 11.5,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: 0.6,
                                      color: textColor,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),
                              Row(
                                children: [
                                  Expanded(
                                    child: _buildParamChip(
                                      icon: Icons.bolt_rounded,
                                      iconColor: const Color(0xFFF59E0B),
                                      label: isHindi ? 'एम्पलीफायर पावर' : 'Amp Power',
                                      value: '${result.power.toInt()} W RMS',
                                      isNight: isNight,
                                      textColor: textColor,
                                      subtextColor: subtitleColor,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: _buildParamChip(
                                      icon: Icons.straighten_rounded,
                                      iconColor: const Color(0xFF38BDF8),
                                      label: isHindi ? 'केबल की लंबाई' : 'Cable Run',
                                      value: '${result.cableLength.truncateToDouble() == result.cableLength ? result.cableLength.toInt() : result.cableLength} मीटर',
                                      isNight: isNight,
                                      textColor: textColor,
                                      subtextColor: subtitleColor,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 10),
                              Row(
                                children: [
                                  Expanded(
                                    child: _buildParamChip(
                                      icon: Icons.speaker_rounded,
                                      iconColor: const Color(0xFF8B5CF6),
                                      label: isHindi ? 'स्पीकर सेटअप' : 'Speakers',
                                      value: '${result.speakerQuantity} × ${result.perSpeakerImpedance.truncateToDouble() == result.perSpeakerImpedance ? result.perSpeakerImpedance.toInt() : result.perSpeakerImpedance}Ω ($wiringStr)',
                                      isNight: isNight,
                                      textColor: textColor,
                                      subtextColor: subtitleColor,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: _buildParamChip(
                                      icon: Icons.graphic_eq_rounded,
                                      iconColor: const Color(0xFF10B981),
                                      label: isHindi ? 'कुल लोड' : 'Total Load',
                                      value: '${result.load.truncateToDouble() == result.load ? result.load.toInt() : result.load.toStringAsFixed(2)} Ω',
                                      isNight: isNight,
                                      textColor: textColor,
                                      subtextColor: subtitleColor,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 14),

                        // CARD 2: CABLE SPECIFICATIONS & TOURING BENCHMARK
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(22),
                            border: Border.all(color: borderColorCard),
                            boxShadow: [
                              BoxShadow(
                                color: isNight ? Colors.black.withOpacity(0.3) : const Color(0x060F172A),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  const Icon(
                                    Icons.cable_rounded,
                                    size: 17,
                                    color: Color(0xFFF59E0B),
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      (isHindi ? 'केबल साइज और सुझाव' : 'CABLE SPECIFICATIONS & BENCHMARK').toUpperCase(),
                                      style: TextStyle(
                                        fontSize: 11.5,
                                        fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                                        letterSpacing: isHindi ? 0.0 : 0.6,
                                        color: textColor,
                                        fontFamilyFallback: AppTypography.hindiFontFallback,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),

                              _buildSummaryTile(
                                label: isHindi ? 'बेस्ट केबल साइज़' : 'Recommended Cable Gauge',
                                value: '${result.recommendedCableSize} mm² ($recAwg)',
                                isHighlight: true,
                                isNight: isNight,
                              ),
                              const SizedBox(height: 8),
                              _buildSummaryTile(
                                label: isHindi ? 'केबल मटेरियल (तार)' : 'Conductor Material',
                                value: isCca
                                    ? (isHindi ? 'CCA (एल्युमिनियम तार)' : 'CCA (Copper-Clad Aluminium)')
                                    : (isHindi ? 'असली तांबा (Pure Copper)' : 'OFC Pure Copper (Oxygen-Free)'),
                                isNight: isNight,
                              ),
                              const SizedBox(height: 8),
                              _buildSummaryTile(
                                label: isHindi ? 'कम से कम साइज़ (Min Size)' : 'Min Acceptable Size',
                                value: result.minimumAcceptableSize != null
                                    ? '${result.minimumAcceptableSize} mm²'
                                    : (isHindi ? 'कोई साइज नहीं' : 'None'),
                                isNight: isNight,
                              ),
                              const SizedBox(height: 8),
                              _buildSummaryTile(
                                label: isHindi ? 'प्रो चॉइस (Best Choice)' : 'Pro Touring Choice',
                                value: result.professionalChoiceSize != null
                                    ? '${result.professionalChoiceSize} mm²'
                                    : (isHindi ? 'कोई साइज नहीं' : 'None'),
                                isNight: isNight,
                              ),
                              const SizedBox(height: 10),

                              // Pro Choice explanation note
                              Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  color: isNight ? const Color(0xFF0F172A) : const Color(0xFFF8FAFC),
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(color: borderColorCard),
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Icon(
                                      Icons.info_outline_rounded,
                                      size: 14,
                                      color: isNight ? const Color(0xFF38BDF8) : const Color(0xFF0284C7),
                                    ),
                                    const SizedBox(width: 8),
                                    Expanded(
                                      child: Text(
                                        _getProChoiceExplanation(result, isHindi),
                                        style: TextStyle(
                                          fontSize: 10.5,
                                          height: 1.35,
                                          color: subtitleColor,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 14),

                        // Google AdMob Banner Centered directly below result cards
                        const Center(
                          child: AdBannerWidget(placement: 'cable_loss_result'),
                        ),

                        const SizedBox(height: 14),

                        // CARD 3: 5-GAUGE COMPARISON MATRIX
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(22),
                            border: Border.all(color: borderColorCard),
                            boxShadow: [
                              BoxShadow(
                                color: isNight ? Colors.black.withOpacity(0.3) : const Color(0x060F172A),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(
                                    Icons.table_chart_rounded,
                                    size: 17,
                                    color: isNight ? const Color(0xFF38BDF8) : const Color(0xFF2563EB),
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    (isHindi ? 'केबल साइज तुलना चार्ट' : '5-GAUGE COMPARISON MATRIX').toUpperCase(),
                                    style: TextStyle(
                                      fontSize: 11.5,
                                      fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                                      letterSpacing: isHindi ? 0.0 : 0.6,
                                      color: textColor,
                                      fontFamilyFallback: AppTypography.hindiFontFallback,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),

                              ClipRRect(
                                borderRadius: BorderRadius.circular(14),
                                child: Table(
                                  columnWidths: const {
                                    0: FlexColumnWidth(1.1),
                                    1: FlexColumnWidth(1.0),
                                    2: FlexColumnWidth(1.0),
                                    3: FlexColumnWidth(1.4),
                                    4: FlexColumnWidth(1.2),
                                  },
                                  children: [
                                    TableRow(
                                      decoration: BoxDecoration(
                                        color: isNight ? const Color(0xFF0F172A) : const Color(0xFFF8FAFC),
                                        border: Border(bottom: BorderSide(color: borderColorCard)),
                                      ),
                                      children: [
                                        _buildTableHeaderCell(isHindi ? 'साइज़' : 'Size', isNight: isNight),
                                        _buildTableHeaderCell(isHindi ? 'रेसिस्टेंस' : 'Loop R', isNight: isNight),
                                        _buildTableHeaderCell(isHindi ? 'V ड्रॉप' : 'V Drop', isNight: isNight),
                                        _buildTableHeaderCell(isHindi ? 'पावर लॉस %' : 'Actual Power Loss %', isNight: isNight),
                                        _buildTableHeaderCell(isHindi ? 'रिजल्ट' : 'Status', isNight: isNight),
                                      ],
                                    ),
                                    ...result.allSizes.map((sz) {
                                      final isRec = result.meetsTarget && sz.size == result.recommendedCableSize;
                                      return TableRow(
                                        decoration: BoxDecoration(
                                          color: isRec
                                              ? (isNight ? const Color(0xFF1E3A8A).withOpacity(0.35) : const Color(0xFFEFF6FF))
                                              : Colors.transparent,
                                          border: Border(bottom: BorderSide(color: borderColorCard.withOpacity(0.5))),
                                        ),
                                        children: [
                                          _buildTableCell('${sz.size} mm²', bold: true, isRec: isRec, isNight: isNight),
                                          _buildTableCell('${sz.loopResistance}Ω', isNight: isNight),
                                          _buildTableCell('${sz.voltageDrop}V', isNight: isNight),
                                          _buildTableCell('${sz.powerLossPercent}%', bold: true, isNight: isNight),
                                          _buildTableStatusBadge(sz.statusBadge, sz.badgeLabel, isHindi: isHindi),
                                        ],
                                      );
                                    }),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 16),

                        // CARD 4: STANDARD BASELINE REFERENCE (PERFORMANCE ANALYSIS)
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(22),
                            border: Border.all(color: borderColorCard),
                            boxShadow: [
                              BoxShadow(
                                color: isNight ? Colors.black.withOpacity(0.3) : const Color(0x060F172A),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Wrap(
                                alignment: WrapAlignment.spaceBetween,
                                crossAxisAlignment: WrapCrossAlignment.center,
                                spacing: 8,
                                runSpacing: 6,
                                children: [
                                  Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(
                                        Icons.analytics_rounded,
                                        size: 17,
                                        color: isNight ? const Color(0xFF38BDF8) : const Color(0xFF2563EB),
                                      ),
                                      const SizedBox(width: 8),
                                      Text(
                                        (isHindi
                                                ? 'चुनी गई केबल की परफॉर्मेंस (${result.cableSize} mm²)'
                                                : 'STANDARD BASELINE (${result.cableSize} mm² / $activeAwg)')
                                            .toUpperCase(),
                                        style: TextStyle(
                                          fontSize: 11.5,
                                          fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                                          letterSpacing: isHindi ? 0.0 : 0.5,
                                          color: textColor,
                                          fontFamilyFallback: AppTypography.hindiFontFallback,
                                        ),
                                      ),
                                    ],
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                    decoration: BoxDecoration(
                                      color: result.meetsTarget
                                          ? const Color(0xFFDCFCE7)
                                          : const Color(0xFFFEE2E2),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Text(
                                      '${result.estimatedEfficiency}% Efficiency',
                                      style: TextStyle(
                                        fontSize: 10,
                                        fontWeight: FontWeight.w900,
                                        color: result.meetsTarget
                                            ? const Color(0xFF15803D)
                                            : const Color(0xFFB91C1C),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),
                              Row(
                                children: [
                                  Expanded(
                                    child: _buildMetricTile(
                                      isHindi ? 'पावर लॉस' : 'Power Loss',
                                      '${result.powerLossWatts}W',
                                      isHindi ? 'कुल पावर का ${result.powerLossPercent}%' : '${result.powerLossPercent}% of total',
                                      isNight: isNight,
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: _buildMetricTile(
                                      isHindi ? 'वोल्टेज ड्रॉप' : 'Voltage Drop',
                                      '${result.voltageDrop}V',
                                      isHindi ? '${result.voltageDropPercent}% ड्रॉप' : '${result.voltageDropPercent}% drop',
                                      isNight: isNight,
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: _buildMetricTile(
                                      isHindi ? 'तार रेसिस्टेंस' : 'Loop R',
                                      '${result.loopResistance}Ω',
                                      isHindi ? 'लोड का ${result.resistanceRatioPercent}%' : '${result.resistanceRatioPercent}% of load',
                                      isNight: isNight,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),

                        if (result.cableLength > 40 || isCca) ...[
                          const SizedBox(height: 14),
                          Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: isNight ? const Color(0xFF271A0B) : const Color(0xFFFFFBEB),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: isNight ? const Color(0xFF78350F) : const Color(0xFFFDE68A),
                              ),
                            ),
                            child: Row(
                              children: [
                                const Icon(Icons.warning_amber_rounded, size: 20, color: Color(0xFFD97706)),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    isCca
                                        ? (isHindi
                                            ? 'नोट: एल्युमिनियम (CCA) केबल में कॉपर से ज्यादा पावर लॉस होता है। भारी बेस के लिए असली तांबे (Pure Copper) की केबल लगाएं।'
                                            : 'Notice: CCA has 1.6x higher resistance than OFC copper. Consider upgrading to Pure Copper for subwoofers.')
                                        : (isHindi
                                            ? 'सलाह: 40 मीटर से ज्यादा लंबी केबल लगाने पर बेस कमजोर पड़ जाता है। हमेशा भारी (मोटी) केबल इस्तेमाल करें।'
                                            : 'Long Cable Run Advisory: Cable runs over 40m noticeably degrade damping factor and low-end transient punch.'),
                                    style: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                      color: isNight ? const Color(0xFFFCD34D) : const Color(0xFF92400E),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],

                        const SizedBox(height: 16),

                        // Native Share Result Button
                        ShareResultButton(
                          title: isHindi ? 'रिजल्ट शेयर करें' : 'SHARE RESULT',
                          shareText: _generateShareText(isHindi),
                        ),

                        const SizedBox(height: 12),

                        // Action Button: Modify Inputs (Gold Button matching Ohm & Amp screens)
                        InkWell(
                          onTap: () => Navigator.pop(context),
                          borderRadius: BorderRadius.circular(22),
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFBBF24),
                              borderRadius: BorderRadius.circular(22),
                              border: Border.all(color: const Color(0xFFF59E0B)),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFFF59E0B).withOpacity(0.35),
                                  blurRadius: 10,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.tune_rounded, size: 20, color: Color(0xFF0F172A)),
                                const SizedBox(width: 8),
                                Text(
                                  isHindi ? 'वैल्यू बदलें' : 'MODIFY INPUTS',
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                                    letterSpacing: isHindi ? 0.2 : 0.5,
                                    color: const Color(0xFF0F172A),
                                    fontFamilyFallback: AppTypography.hindiFontFallback,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _getProChoiceExplanation(CableLossResult result, bool isHindi) {
    if (result.professionalChoiceSize == null) {
      if (result.meetsTarget) {
        return isHindi
            ? '${result.maxAcceptableLoss.toInt()}% टारगेट के लिए कम से कम ${result.minimumAcceptableSize} mm² केबल सही है, लेकिन कोई भी उपलब्ध केबल ≤2.5% प्रो टूरिंग बेंचमार्क पूरा नहीं करती। 10.0 mm² सबसे कम लॉस वाला उपलब्ध विकल्प है (${result.allSizes.last.resistanceRatioPercent}% रेसिस्टेंस)।'
            : 'Min Acceptable is ${result.minimumAcceptableSize} mm² for the ${result.maxAcceptableLoss.toInt()}% target, but no available cable meets the ≤2.5% professional touring benchmark. 10.0 mm² is the lowest-loss available option (${result.allSizes.last.resistanceRatioPercent}% resistance ratio).';
      } else {
        return isHindi
            ? 'कोई भी उपलब्ध केबल ${result.maxAcceptableLoss.toInt()}% टारगेट या ≤2.5% प्रो टूरिंग बेंचमार्क पूरा नहीं करती। 10.0 mm² सबसे कम लॉस वाला उपलब्ध विकल्प है (${result.allSizes.last.resistanceRatioPercent}% रेसिस्टेंस)।'
            : 'No available cable meets the selected ${result.maxAcceptableLoss.toInt()}% target or the ≤2.5% professional touring benchmark. 10.0 mm² is the lowest-loss available option (${result.allSizes.last.resistanceRatioPercent}% resistance ratio).';
      }
    }

    final isSame = result.minimumAcceptableSize == result.professionalChoiceSize;
    if (isSame) {
      return isHindi
          ? 'प्रो टूरिंग बेंचमार्क ≤2.5% रेसिस्टेंस रेशियो के लिए है। इस सेटअप में कम से कम ${result.minimumAcceptableSize} mm² केबल ही इस बेंचमार्क को पूरा करती है, इसलिए दोनों एक ही हैं।'
          : 'Pro Choice targets the professional touring benchmark (≤2.5% resistance ratio). In this configuration, Min Acceptable (${result.minimumAcceptableSize} mm²) already satisfies this benchmark, so both select the same cable.';
    } else {
      return isHindi
          ? 'प्रो चॉइस ≤2.5% टूरिंग बेंचमार्क (टाइट बेस और हाई डैम्पिंग) के लिए ${result.professionalChoiceSize} mm² चुनता है, जबकि ${result.maxAcceptableLoss.toInt()}% टारगेट के लिए कम से कम ${result.minimumAcceptableSize} mm² भी काम कर जाएगा।'
          : 'Pro Choice selects ${result.professionalChoiceSize} mm² to satisfy the professional touring benchmark (≤2.5% resistance ratio for superior damping factor), whereas Min Acceptable is ${result.minimumAcceptableSize} mm² for the ${result.maxAcceptableLoss.toInt()}% target.';
    }
  }

  Widget _buildSummaryTile({
    required String label,
    required String value,
    bool isHighlight = false,
    bool isNight = false,
  }) {
    final tileBg = isHighlight
        ? (isNight ? const Color(0xFF0F172A) : const Color(0xFFEFF6FF))
        : (isNight ? const Color(0xFF0A0F1D) : const Color(0xFFF8FAFC));
    final tileBorder = isHighlight
        ? (isNight ? const Color(0xFF1E3A8A) : const Color(0xFFBFDBFE))
        : (isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0));
    final labelColor = isHighlight
        ? (isNight ? const Color(0xFF93C5FD) : const Color(0xFF1E40AF))
        : (isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B));
    final valueColor = isHighlight
        ? (isNight ? const Color(0xFF38BDF8) : const Color(0xFF1D4ED8))
        : (isNight ? Colors.white : const Color(0xFF0F172A));

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      decoration: BoxDecoration(
        color: tileBg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: tileBorder),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w600,
                color: labelColor,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w800,
                color: valueColor,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildParamChip({
    required IconData icon,
    required Color iconColor,
    required String label,
    required String value,
    required bool isNight,
    required Color textColor,
    required Color subtextColor,
  }) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: iconColor.withOpacity(isNight ? 0.2 : 0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, size: 14, color: iconColor),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 9.5,
                  fontWeight: FontWeight.w600,
                  color: subtextColor,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 1),
              Text(
                value,
                style: TextStyle(
                  fontSize: 11.5,
                  fontWeight: FontWeight.w800,
                  color: textColor,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTableHeaderCell(String text, {bool isNight = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w900,
          color: isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B),
        ),
      ),
    );
  }

  Widget _buildTableCell(String text, {bool bold = false, bool isRec = false, bool isNight = false}) {
    Color textColor;
    if (isRec) {
      textColor = isNight ? const Color(0xFF38BDF8) : const Color(0xFF1D4ED8);
    } else {
      textColor = isNight ? Colors.white : const Color(0xFF1E293B);
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: TextStyle(
          fontSize: 11,
          fontWeight: bold ? FontWeight.w900 : FontWeight.w600,
          color: textColor,
        ),
      ),
    );
  }

  Widget _buildTableStatusBadge(String status, String label, {bool isHindi = false}) {
    Color bg;
    Color fg;
    switch (status) {
      case 'excellent':
      case 'recommended':
        bg = const Color(0xFFDCFCE7);
        fg = const Color(0xFF15803D);
        break;
      case 'acceptable':
        bg = const Color(0xFFFEF3C7);
        fg = const Color(0xFFB45309);
        break;
      case 'high_loss':
        bg = const Color(0xFFFFEDD5);
        fg = const Color(0xFFC2410C);
        break;
      default:
        bg = const Color(0xFFFEE2E2);
        fg = const Color(0xFFB91C1C);
        break;
    }

    String displayLabel = label;
    if (isHindi) {
      switch (status) {
        case 'excellent':
          displayLabel = 'बेस्ट';
          break;
        case 'recommended':
          displayLabel = 'सही';
          break;
        case 'acceptable':
          displayLabel = 'कामचलाऊ';
          break;
        case 'high_loss':
          displayLabel = 'लॉस ज्यादा';
          break;
        default:
          displayLabel = 'खराब';
          break;
      }
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            displayLabel,
            style: TextStyle(fontSize: 9, fontWeight: FontWeight.w900, color: fg),
          ),
        ),
      ),
    );
  }

  Widget _buildMetricTile(String label, String value, String sub, {bool isNight = false}) {
    final tileBg = isNight ? const Color(0xFF0F172A) : const Color(0xFFF8FAFC);
    final tileBorder = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final titleColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final labelColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: tileBg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: tileBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: TextStyle(fontSize: 9.5, color: labelColor)),
          const SizedBox(height: 3),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: Text(value, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: titleColor)),
          ),
          const SizedBox(height: 1),
          Text(sub, style: const TextStyle(fontSize: 8.5, color: Color(0xFF94A3B8))),
        ],
      ),
    );
  }
}
