import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/subscription_service.dart';
import '../services/preference_service.dart';
import '../widgets/calculator_hero_header.dart';
import '../utils/app_typography.dart';

class PaywallScreen extends StatelessWidget {
  const PaywallScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final subService = Provider.of<SubscriptionService>(context);
    final prefService = Provider.of<PreferenceService>(context);
    final isHindi = prefService.isHindi;
    final isNight = prefService.isNightMode;

    // Theme tokens for full Night Mode support
    final bgColor = isNight ? const Color(0xFF070B14) : const Color(0xFFF1F5F9);
    final sheetBg = isNight ? const Color(0xFF0E1526) : Colors.white;
    final cardBg = isNight ? const Color(0xFF141C30) : Colors.white;
    final cardBorder = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final textColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final subtextColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);
    final iconBg = isNight ? const Color(0xFF1E293B) : const Color(0xFFEFF6FF);

    return Scaffold(
      backgroundColor: bgColor,
      body: SafeArea(
        top: false,
        child: Column(
          children: [
            // 1. Hero Header
            CalculatorHeroHeader(
              title: isHindi ? 'AMP OHM Pro' : 'AMP OHM Pro',
              subtitle: isHindi 
                  ? 'सभी एडवांस्ड टूल्स और 100% ऐड-फ्री अनुभव' 
                  : 'Unlock unlimited tools & 100% ad-free experience',
              onBack: () => Navigator.pop(context),
            ),

            // 2. Curved Sheet with 100% Theme Awareness
            Expanded(
              child: Transform.translate(
                offset: const Offset(0, -20),
                child: Container(
                  decoration: BoxDecoration(
                    color: sheetBg,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: isNight ? Colors.black.withOpacity(0.5) : const Color(0x140F172A),
                        blurRadius: 20,
                        offset: const Offset(0, -6),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(16, 24, 16, 32),
                      children: [
                        // Pro Header Card
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: isNight 
                                  ? const [Color(0xFF1E3A8A), Color(0xFF172554)] 
                                  : const [Color(0xFF1D4ED8), Color(0xFF2563EB)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(24),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFF1D4ED8).withOpacity(isNight ? 0.25 : 0.35),
                                blurRadius: 16,
                                offset: const Offset(0, 6),
                              ),
                            ],
                          ),
                          child: Column(
                            children: [
                              Container(
                                width: 56,
                                height: 56,
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(16),
                                  border: Border.all(color: Colors.white.withOpacity(0.35), width: 1.5),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.25),
                                      blurRadius: 10,
                                      offset: const Offset(0, 4),
                                    ),
                                  ],
                                ),
                                clipBehavior: Clip.antiAlias,
                                child: Image.asset(
                                  'assets/images/app_logo.png',
                                  fit: BoxFit.cover,
                                ),
                              ),
                              const SizedBox(height: 12),
                              Text(
                                isHindi ? 'AMP OHM Pro मेंबरशिप' : 'AMP OHM Pro Membership',
                                style: AppTypography.title(
                                  isHindi: isHindi,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w800,
                                  color: Colors.white,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                isHindi 
                                    ? '100% ऐड-फ्री • सभी ऑडियो टूल्स अनलॉक' 
                                    : '100% Ad-Free • All Professional Audio Tools Unlocked',
                                style: AppTypography.style(
                                  isHindi: isHindi,
                                  fontSize: 11.5,
                                  color: const Color(0xFF93C5FD),
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              if (subService.isPremium) ...[
                                const SizedBox(height: 12),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF10B981),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Text(
                                    isHindi 
                                        ? 'सक्रिय प्लान: ${subService.activeTier.toUpperCase()}' 
                                        : 'Active Plan: ${subService.activeTier.toUpperCase()}',
                                    style: AppTypography.style(
                                      isHindi: isHindi,
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),

                        // Features List (Theme Aware)
                        _buildFeatureCard(
                          isHindi: isHindi,
                          icon: Icons.block_rounded,
                          title: isHindi ? '100% ऐड-फ्री अनुभव' : '100% Ad-Free Experience',
                          subtitle: isHindi 
                              ? 'बिना किसी बैनर या वीडियो ऐड के तुरंत गणना करें।' 
                              : 'Zero banner ads, video rewards, or popups during shows.',
                          cardBg: cardBg,
                          cardBorder: cardBorder,
                          iconBg: iconBg,
                          textColor: textColor,
                          subtextColor: subtextColor,
                        ),
                        const SizedBox(height: 10),
                        _buildFeatureCard(
                          isHindi: isHindi,
                          icon: Icons.all_inclusive_rounded,
                          title: isHindi ? 'सभी एडवांस्ड कैलकुलेटर्स अनलॉक' : 'Unlimited Calculators Access',
                          subtitle: isHindi 
                              ? 'Cable Loss, Ohm, Amp Match और DMX टूल्स का असीमित उपयोग।' 
                              : 'Full uninterrupted access to Cable Loss, Ohm, Amp Matching & DMX.',
                          cardBg: cardBg,
                          cardBorder: cardBorder,
                          iconBg: iconBg,
                          textColor: textColor,
                          subtextColor: subtextColor,
                        ),
                        const SizedBox(height: 10),
                        _buildFeatureCard(
                          isHindi: isHindi,
                          icon: Icons.offline_bolt_rounded,
                          title: isHindi ? 'ऑफलाइन साउंड कैलकुलेटर इंजन' : 'Offline Sound Calculator Engine',
                          subtitle: isHindi 
                              ? 'बिना इंटरनेट के सभी गणनाएं तुरंत ऑन-डिवाइस।' 
                              : 'Full offline calculation without internet connectivity.',
                          cardBg: cardBg,
                          cardBorder: cardBorder,
                          iconBg: iconBg,
                          textColor: textColor,
                          subtextColor: subtextColor,
                        ),
                        const SizedBox(height: 22),

                        if (subService.isPremium) ...[
                          // Active Subscriber VIP Card
                          Container(
                            padding: const EdgeInsets.all(18),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: isNight 
                                    ? [const Color(0xFF064E3B), const Color(0xFF022C22)]
                                    : [const Color(0xFFD1FAE5), const Color(0xFFA7F3D0)],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: const Color(0xFF10B981).withOpacity(0.5),
                                width: 1.5,
                              ),
                            ),
                            child: Column(
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(8),
                                      decoration: BoxDecoration(
                                        color: const Color(0xFF10B981).withOpacity(0.2),
                                        shape: BoxShape.circle,
                                      ),
                                      child: const Icon(
                                        Icons.verified_rounded,
                                        color: Color(0xFF10B981),
                                        size: 26,
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            isHindi ? 'आपकी प्रो मेंबरशिप सक्रिय है!' : 'Pro Membership Active!',
                                            style: AppTypography.title(
                                              isHindi: isHindi,
                                              fontSize: 15,
                                              fontWeight: FontWeight.bold,
                                              color: isNight ? Colors.white : const Color(0xFF064E3B),
                                            ),
                                          ),
                                          const SizedBox(height: 2),
                                          Text(
                                            isHindi 
                                                ? 'प्लान: ${subService.activeTier.toUpperCase()} • सभी टूल्स 100% ऐड-फ्री हैं'
                                                : 'Plan: ${subService.activeTier.toUpperCase()} • 100% ad-free & unlocked',
                                            style: AppTypography.style(
                                              isHindi: isHindi,
                                              fontSize: 11.5,
                                              color: isNight ? const Color(0xFF6EE7B7) : const Color(0xFF047857),
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 14),
                                SizedBox(
                                  width: double.infinity,
                                  child: ElevatedButton.icon(
                                    onPressed: () {
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(
                                          content: Text(
                                            isHindi
                                                ? 'सब्सक्रिप्शन Google Play Store > Payments & Subscriptions से प्रबंधित किया जा सकता है।'
                                                : 'Manage your subscription anytime in Google Play Store > Subscriptions.',
                                          ),
                                          backgroundColor: const Color(0xFF10B981),
                                        ),
                                      );
                                    },
                                    icon: const Icon(Icons.check_circle_outline_rounded, size: 18),
                                    label: Text(
                                      isHindi ? 'मेंबरशिप सक्रिय (Google Play)' : 'Active via Google Play',
                                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                                    ),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: const Color(0xFF10B981),
                                      foregroundColor: Colors.white,
                                      padding: const EdgeInsets.symmetric(vertical: 12),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(14),
                                      ),
                                      elevation: 0,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ] else ...[
                          // Pricing Section Header
                          Text(
                            isHindi ? 'प्लान चुनें' : 'SELECT YOUR PASS',
                            style: AppTypography.style(
                              isHindi: isHindi,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              color: subtextColor,
                              letterSpacing: isHindi ? 0.2 : 1.1,
                            ),
                          ),
                          const SizedBox(height: 12),

                          // Plan 1: Yearly Pass (₹399 / Year - MOST POPULAR)
                          _buildPlanButton(
                            context: context,
                            isHindi: isHindi,
                            title: isHindi ? 'वार्षिक पास (Yearly)' : 'Annual Pass',
                            price: subService.priceAnnual,
                            subtitle: isHindi ? 'प्रति माह मात्र ₹33 • सभी आगामी अपडेट्स शामिल' : 'Best Value • Includes all future updates',
                            badge: isHindi ? 'सर्वाधिक लोकप्रिय' : 'MOST POPULAR',
                            isPopular: true,
                            isNight: isNight,
                            cardBg: cardBg,
                            cardBorder: cardBorder,
                            textColor: textColor,
                            subtextColor: subtextColor,
                            onTap: () => _handlePurchase(context, 'yearly', isHindi),
                          ),
                          const SizedBox(height: 10),

                          // Plan 2: Monthly Pass (₹49 / Month)
                          _buildPlanButton(
                            context: context,
                            isHindi: isHindi,
                            title: isHindi ? 'मासिक पास (Monthly)' : 'Monthly Pass',
                            price: subService.priceMonthly,
                            subtitle: isHindi ? 'लचीला प्लान • कभी भी रद्द करें' : 'Flexible monthly access • Cancel anytime',
                            badge: null,
                            isPopular: false,
                            isNight: isNight,
                            cardBg: cardBg,
                            cardBorder: cardBorder,
                            textColor: textColor,
                            subtextColor: subtextColor,
                            onTap: () => _handlePurchase(context, 'monthly', isHindi),
                          ),
                        ],

                        const SizedBox(height: 20),

                        // Restore Purchases & Google Play Footer
                        Center(
                          child: TextButton.icon(
                            onPressed: () => _handleRestore(context, isHindi),
                            icon: Icon(Icons.restore_rounded, size: 16, color: subtextColor),
                            label: Text(
                              isHindi ? 'Google Play खरीदारी रीस्टोर करें' : 'Restore Google Play Purchases',
                              style: AppTypography.style(
                                isHindi: isHindi,
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: subtextColor,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 4),

                        Center(
                          child: Text(
                            isHindi 
                                ? 'सब्सक्रिप्शन Google Play के माध्यम से अपने आप नवीनीकृत होते हैं। कभी भी Google Play Store सेटिंग्स में रद्द करें।' 
                                : 'Subscriptions automatically renew through Google Play. Cancel anytime in Google Play Store settings.',
                            textAlign: TextAlign.center,
                            style: AppTypography.style(
                              isHindi: isHindi,
                              fontSize: 10,
                              color: subtextColor,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFeatureCard({
    required bool isHindi,
    required IconData icon,
    required String title,
    required String subtitle,
    required Color cardBg,
    required Color cardBorder,
    required Color iconBg,
    required Color textColor,
    required Color subtextColor,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: cardBorder),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: iconBg,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: const Color(0xFF2563EB), size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: AppTypography.style(
                    isHindi: isHindi,
                    fontSize: 12.5,
                    fontWeight: FontWeight.bold,
                    color: textColor,
                  ),
                ),
                Text(
                  subtitle,
                  style: AppTypography.style(
                    isHindi: isHindi,
                    fontSize: 11,
                    color: subtextColor,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlanButton({
    required BuildContext context,
    required bool isHindi,
    required String title,
    required String price,
    required String subtitle,
    required String? badge,
    required bool isPopular,
    required bool isNight,
    required Color cardBg,
    required Color cardBorder,
    required Color textColor,
    required Color subtextColor,
    required VoidCallback onTap,
  }) {
    final activeBg = isPopular 
        ? (isNight ? const Color(0xFF1E3A8A).withOpacity(0.25) : const Color(0xFFEFF6FF))
        : cardBg;
    final activeBorder = isPopular 
        ? const Color(0xFF2563EB) 
        : cardBorder;

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: activeBg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: activeBorder,
            width: isPopular ? 1.6 : 1.0,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        title,
                        style: AppTypography.style(
                          isHindi: isHindi,
                          fontSize: 13.5,
                          fontWeight: FontWeight.bold,
                          color: textColor,
                        ),
                      ),
                      if (badge != null) ...[
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFBBF24),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            badge,
                            style: AppTypography.style(
                              isHindi: isHindi,
                              fontSize: 9,
                              fontWeight: FontWeight.w800,
                              color: const Color(0xFF0F172A),
                              letterSpacing: isHindi ? 0.0 : 0.3,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: AppTypography.style(
                      isHindi: isHindi,
                      fontSize: 11,
                      color: subtextColor,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  price,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    color: isPopular ? const Color(0xFF2563EB) : textColor,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _handlePurchase(BuildContext context, String tier, bool isHindi) async {
    final subService = Provider.of<SubscriptionService>(context, listen: false);

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Dialog(
        backgroundColor: const Color(0xFF141C30),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 18),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(
                  strokeWidth: 2.5,
                  valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF38BDF8)),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Text(
                  isHindi
                      ? 'सब्सक्रिप्शन सत्यापित किया जा रहा है...\nVerifying subscription...'
                      : 'Verifying subscription with Google Play...',
                  style: const TextStyle(fontSize: 12, color: Colors.white, fontWeight: FontWeight.w600, height: 1.3),
                ),
              ),
            ],
          ),
        ),
      ),
    );

    final outcome = await subService.purchaseTier(tier);

    if (context.mounted && Navigator.canPop(context)) {
      Navigator.pop(context); // close loading dialog
    }

    if (!context.mounted) return;

    if (outcome.status == PurchaseStatus.success) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            isHindi
                ? 'सब्सक्रिप्शन सफलतापूर्वक सक्रिय हो गया! सभी ऐड्स हटा दिए गए हैं।'
                : 'Subscription successfully activated! All ads removed.',
          ),
          backgroundColor: const Color(0xFF10B981),
        ),
      );
      Navigator.pop(context); // close paywall
    } else if (outcome.status == PurchaseStatus.verifying) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            isHindi
                ? 'आपका भुगतान प्राप्त हो गया है। सब्सक्रिप्शन Google Play से सत्यापित किया जा रहा है। यदि तुरंत सक्रिय न हो, तो कृपया "रीस्टोर करें" पर टैप करें।'
                : 'Your payment was received. We are verifying your subscription with Google Play. Please tap Restore Purchases if not updated shortly.',
          ),
          backgroundColor: const Color(0xFFF59E0B),
          duration: const Duration(seconds: 6),
        ),
      );
    } else if (outcome.status == PurchaseStatus.error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(outcome.message),
          backgroundColor: const Color(0xFFEF4444),
          duration: const Duration(seconds: 4),
        ),
      );
    }
  }

  Future<void> _handleRestore(BuildContext context, bool isHindi) async {
    final subService = Provider.of<SubscriptionService>(context, listen: false);

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => Dialog(
        backgroundColor: const Color(0xFF141C30),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 18),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(
                  strokeWidth: 2.5,
                  valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF38BDF8)),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Text(
                  isHindi
                      ? 'Google Play से रीस्टोर हो रहा है...\nRestoring purchases...'
                      : 'Restoring purchases from Google Play...',
                  style: const TextStyle(fontSize: 12, color: Colors.white, fontWeight: FontWeight.w600, height: 1.3),
                ),
              ),
            ],
          ),
        ),
      ),
    );

    final outcome = await subService.restorePurchases();

    if (context.mounted && Navigator.canPop(context)) {
      Navigator.pop(context); // close loading dialog
    }

    if (!context.mounted) return;

    if (outcome.status == PurchaseStatus.success) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            isHindi
                ? 'खरीदारी सफलतापूर्वक रीस्टोर हो गई! सभी ऐड्स हटा दिए गए हैं।'
                : 'Purchases restored successfully! All ads removed.',
          ),
          backgroundColor: const Color(0xFF10B981),
        ),
      );
      Navigator.pop(context); // close paywall
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            isHindi
                ? 'कोई सक्रिय Google Play सब्सक्रिप्शन नहीं मिला।'
                : outcome.message,
          ),
          backgroundColor: const Color(0xFF1E293B),
        ),
      );
    }
  }

}
