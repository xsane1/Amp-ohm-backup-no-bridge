import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../calculators/cable_loss_calculator.dart';
import '../localization/app_localizations.dart';
import '../services/preference_service.dart';
import '../services/subscription_service.dart';
import '../services/admob_service.dart';
import '../services/history_service.dart';
import '../widgets/calculator_unlock_dialog.dart';
import '../utils/app_typography.dart';
import '../widgets/calculator_hero_header.dart';
import 'cable_loss_result_screen.dart';

class CableLossScreen extends StatefulWidget {
  const CableLossScreen({super.key});

  @override
  State<CableLossScreen> createState() => _CableLossScreenState();
}

class _CableLossScreenState extends State<CableLossScreen> {
  // Controllers
  final TextEditingController _powerController = TextEditingController(text: '500');
  final TextEditingController _lengthController = TextEditingController(text: '20');

  // Input states matching Web exactly
  int _power = 500; // Amplifier Power per channel (Watts)
  double _perSpeakerImpedance = 8.0; // 2, 4, 8, 16 Ω
  String _wiring = 'parallel'; // 'parallel' | 'series'
  int _speakerQuantity = 4; // Number of speakers
  double _cableLength = 20.0; // One-way distance in meters
  String _material = 'copper'; // 'copper' | 'cca'
  double? _maxAcceptableLoss; // null = None Selected (Default 5%), or 3.0, 5.0, 10.0
  bool _showAdvanced = false; // Accordion toggle state

  final List<double> _perSpeakerOptions = [2.0, 4.0, 8.0, 16.0];

  @override
  void dispose() {
    _powerController.dispose();
    _lengthController.dispose();
    super.dispose();
  }

  // Calculate Total System Load
  double get _calculatedImpedanceRaw {
    if (_speakerQuantity <= 0) return _perSpeakerImpedance;
    if (_wiring == 'parallel') {
      return _perSpeakerImpedance / _speakerQuantity;
    } else {
      return _perSpeakerImpedance * _speakerQuantity;
    }
  }

  double get _calculatedImpedance =>
      (double.parse((_calculatedImpedanceRaw * 100).toStringAsFixed(0)) / 100);

  String get _formattedImpedance {
    final val = _calculatedImpedance;
    return val.truncateToDouble() == val ? val.toInt().toString() : val.toStringAsFixed(2);
  }

  // Safe Standard Range: 2Ω to 16Ω inclusive
  bool get _isImpedanceSupported => _calculatedImpedance >= 2.0 && _calculatedImpedance <= 16.0;
  bool get _isImpedanceTooLow => _calculatedImpedance < 2.0;
  bool get _isImpedanceTooHigh => _calculatedImpedance > 16.0;

  bool get _isPowerValid => _power > 0;
  bool get _isLengthValid => _cableLength > 0;
  bool get _isValid => _isPowerValid && _isLengthValid && _isImpedanceSupported;

  void _handleReset() {
    setState(() {
      _power = 500;
      _perSpeakerImpedance = 8.0;
      _wiring = 'parallel';
      _speakerQuantity = 4;
      _cableLength = 20.0;
      _material = 'copper';
      _maxAcceptableLoss = null;
      _showAdvanced = false;
      _powerController.text = '500';
      _lengthController.text = '20';
    });
  }

  void _calculateAndNavigate() {
    if (!_isValid) return;

    // 1. Active subscribers bypass ad checks
    final subService = Provider.of<SubscriptionService>(context, listen: false);
    if (subService.isPremium) {
      _executeCalculation();
      return;
    }

    // 2. If 60-minute unlock is still active across all calculators, show result immediately
    final adMobService = Provider.of<AdMobService>(context, listen: false);
    if (adMobService.hasActiveRewardPass) {
      _executeCalculation();
      return;
    }

    final prefService = Provider.of<PreferenceService>(context, listen: false);
    final isHindi = prefService.isHindi;

    CalculatorUnlockDialog.show(
      context,
      calculatorTitle: isHindi ? 'स्पीकर केबल लॉस' : 'Cable Loss Calculator',
      onUnlocked: () {
        _executeCalculation();
      },
    );
  }

  void _executeCalculation() {
    final effectiveLoss = _maxAcceptableLoss ?? 5.0;
    final enteredLength = double.tryParse(_lengthController.text) ?? _cableLength;
    final enteredPower = int.tryParse(_powerController.text) ?? _power;

    final result = CableLossCalculator.calculate(
      cableLength: enteredLength,
      load: _calculatedImpedance,
      power: enteredPower.toDouble(),
      material: _material,
      maxAcceptableLoss: effectiveLoss,
      speakerQuantity: _speakerQuantity,
      perSpeakerImpedance: _perSpeakerImpedance,
      wiring: _wiring,
    );

    // Save to calculation history
    final isHindi = Provider.of<PreferenceService>(context, listen: false).isHindi;
    HistoryService().addItem(
      HistoryItem(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        title: isHindi
            ? 'केबल लॉस (${result.recommendedCableSize} mm²)'
            : 'Cable Loss (${result.recommendedCableSize} mm²)',
        subtitle: '${enteredLength.toInt()}m ${result.material.toUpperCase()} • ${result.powerLossPercent.toStringAsFixed(1)}% Loss (${result.powerLossWatts.toStringAsFixed(1)}W)',
        calculatorId: 'calc_cable_loss',
        timestamp: DateTime.now(),
        payload: {
          'cableLength': enteredLength,
          'power': enteredPower,
          'material': _material,
          'maxAcceptableLoss': effectiveLoss,
          'speakerQuantity': _speakerQuantity,
          'perSpeakerImpedance': _perSpeakerImpedance,
          'wiring': _wiring,
        },
      ),
    );

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CableLossResultScreen(result: result),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final prefService = Provider.of<PreferenceService>(context);
    final isHindi = prefService.isHindi;
    final isNight = prefService.isNightMode;

    // Theme Tokens matching Web design exactly
    final bgColor = isNight ? const Color(0xFF070B14) : const Color(0xFFF8FAFC);
    final sheetBg = isNight ? const Color(0xFF0E1526) : Colors.white;
    final cardBg = isNight ? const Color(0xFF131B2A) : Colors.white;
    final cardBorder = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final innerInputBg = isNight ? const Color(0xFF141C30) : const Color(0xFFF8FAFC);
    final stepperBtnBg = isNight ? const Color(0xFF1E293B) : const Color(0xFFEEF2F8);
    final stepperIconColor = isNight ? Colors.white : const Color(0xFF334155);
    final textColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final subtextColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);
    final tagBg = isNight ? const Color(0xFF1E293B) : const Color(0xFFF1F5F9);
    final tagTextColor = isNight ? const Color(0xFFCBD5E1) : const Color(0xFF475569);

    return Scaffold(
      backgroundColor: bgColor,
      body: SafeArea(
        child: Column(
          children: [
            // 1. Curved Hero Header matching Web
            CalculatorHeroHeader(
              title: isHindi ? 'स्पीकर केबल सुझाव' : 'SPEAKER CABLE RECOMMENDATION',
              subtitle: isHindi
                  ? 'सही केबल साइज चुनें और पावर लॉस रोकें'
                  : 'Professional cable gauge recommendation & efficiency analysis.',
              onBack: () => Navigator.pop(context),
              actions: Container(
                padding: const EdgeInsets.all(3),
                decoration: BoxDecoration(
                  color: isNight ? const Color(0xFF0F182B) : Colors.black.withOpacity(0.20),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: isNight ? const Color(0xFF1E2B48) : Colors.white.withOpacity(0.25),
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    InkWell(
                      onTap: () => prefService.setLocale(const Locale('en', '')),
                      borderRadius: BorderRadius.circular(16),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color: !isHindi ? Colors.white : Colors.transparent,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Text(
                          'English',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            color: !isHindi ? const Color(0xFF0F172A) : Colors.white70,
                          ),
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () => prefService.setLocale(const Locale('hi', '')),
                      borderRadius: BorderRadius.circular(16),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color: isHindi ? Colors.white : Colors.transparent,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Text(
                          'हिंदी',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            color: isHindi ? const Color(0xFF0F172A) : Colors.white70,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // 2. Curved White / Dark Sheet for Inputs
            Expanded(
              child: Transform.translate(
                offset: const Offset(0, -20),
                child: Container(
                  decoration: BoxDecoration(
                    color: sheetBg,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: isNight ? Colors.black.withOpacity(0.5) : const Color(0x140F172A),
                        blurRadius: 20,
                        offset: const Offset(0, -6),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(16, 24, 16, 36),
                      children: [
                        // ==========================================
                        // 1. AMPLIFIER POWER (PER CHANNEL)
                        // ==========================================
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: cardBorder),
                            boxShadow: [
                              BoxShadow(
                                color: isNight ? Colors.black.withOpacity(0.2) : const Color(0x060F172A),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    isHindi
                                        ? '1. एम्पलीफायर पावर (प्रति चैनल)'
                                        : '1. AMPLIFIER POWER (PER CHANNEL)',
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 0.5,
                                      color: textColor,
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                    decoration: BoxDecoration(
                                      color: tagBg,
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Text(
                                      'Watts (W)',
                                      style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w600,
                                        color: tagTextColor,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),

                              // Stepper Container
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                                decoration: BoxDecoration(
                                  color: innerInputBg,
                                  borderRadius: BorderRadius.circular(18),
                                  border: Border.all(color: cardBorder),
                                ),
                                child: Row(
                                  children: [
                                    // Minus Button
                                    InkWell(
                                      onTap: () {
                                        setState(() {
                                          _power = (_power - 50).clamp(50, 20000);
                                          _powerController.text = _power.toString();
                                        });
                                      },
                                      borderRadius: BorderRadius.circular(14),
                                      child: Container(
                                        width: 44,
                                        height: 44,
                                        decoration: BoxDecoration(
                                          color: stepperBtnBg,
                                          borderRadius: BorderRadius.circular(14),
                                        ),
                                        child: Icon(Icons.remove, size: 20, color: stepperIconColor),
                                      ),
                                    ),

                                    // Direct Input & Watts Label
                                    Expanded(
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment: CrossAxisAlignment.baseline,
                                        textBaseline: TextBaseline.alphabetic,
                                        children: [
                                          IntrinsicWidth(
                                            child: TextField(
                                              controller: _powerController,
                                              keyboardType: TextInputType.number,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                fontSize: 26,
                                                fontWeight: FontWeight.w900,
                                                color: textColor,
                                              ),
                                              decoration: const InputDecoration(
                                                border: InputBorder.none,
                                                isDense: true,
                                                contentPadding: EdgeInsets.zero,
                                              ),
                                              onChanged: (val) {
                                                final parsed = int.tryParse(val);
                                                setState(() {
                                                  _power = parsed ?? 0;
                                                });
                                              },
                                            ),
                                          ),
                                          const SizedBox(width: 6),
                                          Text(
                                            'Watts',
                                            style: TextStyle(
                                              fontSize: 13,
                                              fontWeight: FontWeight.w600,
                                              color: subtextColor,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),

                                    // Plus Button
                                    InkWell(
                                      onTap: () {
                                        setState(() {
                                          _power = (_power + 50).clamp(50, 20000);
                                          _powerController.text = _power.toString();
                                        });
                                      },
                                      borderRadius: BorderRadius.circular(14),
                                      child: Container(
                                        width: 44,
                                        height: 44,
                                        decoration: BoxDecoration(
                                          color: stepperBtnBg,
                                          borderRadius: BorderRadius.circular(14),
                                        ),
                                        child: Icon(Icons.add, size: 20, color: stepperIconColor),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 14),

                        // ==========================================
                        // 2, 3, 4. SPEAKER LOAD, WIRING & QUANTITY
                        // ==========================================
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: cardBorder),
                            boxShadow: [
                              BoxShadow(
                                color: isNight ? Colors.black.withOpacity(0.2) : const Color(0x060F172A),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // 2. PER-SPEAKER IMPEDANCE
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    isHindi
                                        ? '2. प्रति-स्पीकर इम्पीडेंस'
                                        : '2. PER-SPEAKER IMPEDANCE',
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 0.5,
                                      color: textColor,
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                    decoration: BoxDecoration(
                                      color: tagBg,
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Text(
                                      '${_perSpeakerImpedance.toInt()}Ω',
                                      style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                        color: tagTextColor,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 10),

                              // 4-Grid buttons: 2Ω, 4Ω, 8Ω, 16Ω
                              Row(
                                children: _perSpeakerOptions.map((imp) {
                                  final isSelected = _perSpeakerImpedance == imp;
                                  return Expanded(
                                    child: Padding(
                                      padding: const EdgeInsets.symmetric(horizontal: 3),
                                      child: InkWell(
                                        onTap: () {
                                          setState(() => _perSpeakerImpedance = imp);
                                        },
                                        borderRadius: BorderRadius.circular(12),
                                        child: AnimatedContainer(
                                          duration: const Duration(milliseconds: 150),
                                          padding: const EdgeInsets.symmetric(vertical: 10),
                                          decoration: BoxDecoration(
                                            color: isSelected
                                                ? const Color(0xFF1D4ED8)
                                                : (isNight ? const Color(0xFF182440) : const Color(0xFFF8FAFC)),
                                            borderRadius: BorderRadius.circular(12),
                                            border: Border.all(
                                              color: isSelected
                                                  ? const Color(0xFF1D4ED8)
                                                  : cardBorder,
                                              width: 1.2,
                                            ),
                                          ),
                                          child: Center(
                                            child: Text(
                                              '${imp.toInt()}Ω',
                                              style: TextStyle(
                                                fontSize: 13,
                                                fontWeight: FontWeight.bold,
                                                color: isSelected ? Colors.white : textColor,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  );
                                }).toList(),
                              ),
                              const SizedBox(height: 18),
                              Divider(height: 1, color: cardBorder),
                              const SizedBox(height: 14),

                              // 3. WIRING METHOD (Parallel / Series)
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    isHindi ? '3. वायरिंग प्रकार' : '3. WIRING METHOD',
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 0.5,
                                      color: textColor,
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                    decoration: BoxDecoration(
                                      color: tagBg,
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Text(
                                      _wiring == 'parallel' ? 'Parallel' : 'Series',
                                      style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                        color: const Color(0xFF2563EB),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 10),

                              // 2-Option Buttons: Parallel vs Series
                              Row(
                                children: [
                                  Expanded(
                                    child: InkWell(
                                      onTap: () {
                                        setState(() => _wiring = 'parallel');
                                      },
                                      borderRadius: BorderRadius.circular(12),
                                      child: AnimatedContainer(
                                        duration: const Duration(milliseconds: 150),
                                        padding: const EdgeInsets.symmetric(vertical: 10),
                                        decoration: BoxDecoration(
                                          color: _wiring == 'parallel'
                                              ? const Color(0xFF1D4ED8)
                                              : (isNight ? const Color(0xFF182440) : const Color(0xFFF8FAFC)),
                                          borderRadius: BorderRadius.circular(12),
                                          border: Border.all(
                                            color: _wiring == 'parallel'
                                                ? const Color(0xFF1D4ED8)
                                                : cardBorder,
                                            width: 1.2,
                                          ),
                                        ),
                                        child: Center(
                                          child: Text(
                                            isHindi ? 'पैरलल (Parallel)' : 'Parallel',
                                            style: TextStyle(
                                              fontSize: 13,
                                              fontWeight: FontWeight.bold,
                                              color: _wiring == 'parallel' ? Colors.white : textColor,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: InkWell(
                                      onTap: () {
                                        setState(() => _wiring = 'series');
                                      },
                                      borderRadius: BorderRadius.circular(12),
                                      child: AnimatedContainer(
                                        duration: const Duration(milliseconds: 150),
                                        padding: const EdgeInsets.symmetric(vertical: 10),
                                        decoration: BoxDecoration(
                                          color: _wiring == 'series'
                                              ? const Color(0xFF1D4ED8)
                                              : (isNight ? const Color(0xFF182440) : const Color(0xFFF8FAFC)),
                                          borderRadius: BorderRadius.circular(12),
                                          border: Border.all(
                                            color: _wiring == 'series'
                                                ? const Color(0xFF1D4ED8)
                                                : cardBorder,
                                            width: 1.2,
                                          ),
                                        ),
                                        child: Center(
                                          child: Text(
                                            isHindi ? 'सीरीज (Series)' : 'Series',
                                            style: TextStyle(
                                              fontSize: 13,
                                              fontWeight: FontWeight.bold,
                                              color: _wiring == 'series' ? Colors.white : textColor,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 18),
                              Divider(height: 1, color: cardBorder),
                              const SizedBox(height: 14),

                              // 4. SPEAKER QUANTITY
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    isHindi ? '4. स्पीकर संख्या' : '4. SPEAKER QUANTITY',
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 0.5,
                                      color: textColor,
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                    decoration: BoxDecoration(
                                      color: tagBg,
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Text(
                                      isHindi ? 'प्रति चैनल' : 'Per Channel',
                                      style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w600,
                                        color: tagTextColor,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 10),

                              // Stepper Container
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                                decoration: BoxDecoration(
                                  color: innerInputBg,
                                  borderRadius: BorderRadius.circular(18),
                                  border: Border.all(color: cardBorder),
                                ),
                                child: Row(
                                  children: [
                                    // Minus
                                    InkWell(
                                      onTap: () {
                                        if (_speakerQuantity > 1) {
                                          setState(() => _speakerQuantity--);
                                        }
                                      },
                                      borderRadius: BorderRadius.circular(14),
                                      child: Container(
                                        width: 44,
                                        height: 44,
                                        decoration: BoxDecoration(
                                          color: stepperBtnBg,
                                          borderRadius: BorderRadius.circular(14),
                                        ),
                                        child: Icon(Icons.remove, size: 20, color: stepperIconColor),
                                      ),
                                    ),

                                    // Center Count + 'speakers'
                                    Expanded(
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment: CrossAxisAlignment.baseline,
                                        textBaseline: TextBaseline.alphabetic,
                                        children: [
                                          Text(
                                            '$_speakerQuantity',
                                            style: TextStyle(
                                              fontSize: 26,
                                              fontWeight: FontWeight.w900,
                                              color: textColor,
                                            ),
                                          ),
                                          const SizedBox(width: 6),
                                          Text(
                                            _speakerQuantity == 1
                                                ? (isHindi ? 'स्पीकर' : 'speaker')
                                                : (isHindi ? 'स्पीकर्स' : 'speakers'),
                                            style: TextStyle(
                                              fontSize: 13,
                                              fontWeight: FontWeight.w600,
                                              color: subtextColor,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),

                                    // Plus
                                    InkWell(
                                      onTap: () {
                                        if (_speakerQuantity < 32) {
                                          setState(() => _speakerQuantity++);
                                        }
                                      },
                                      borderRadius: BorderRadius.circular(14),
                                      child: Container(
                                        width: 44,
                                        height: 44,
                                        decoration: BoxDecoration(
                                          color: stepperBtnBg,
                                          borderRadius: BorderRadius.circular(14),
                                        ),
                                        child: Icon(Icons.add, size: 20, color: stepperIconColor),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 16),

                              // TOTAL SYSTEM LOAD DISPLAY CARD
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                                decoration: BoxDecoration(
                                  color: isNight ? const Color(0xFF0F182B) : const Color(0xFFF8FAFC),
                                  borderRadius: BorderRadius.circular(16),
                                  border: Border.all(
                                    color: _isImpedanceSupported
                                        ? (isNight ? const Color(0xFF1E2B48) : const Color(0xFFE2E8F0))
                                        : const Color(0xFFEF4444).withOpacity(0.5),
                                  ),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          isHindi ? 'टोटल सिस्टम लोड' : 'TOTAL SYSTEM LOAD',
                                          style: TextStyle(
                                            fontSize: 11,
                                            fontWeight: isHindi ? FontWeight.w600 : FontWeight.w800,
                                            letterSpacing: isHindi ? 0.0 : 0.5,
                                            color: subtextColor,
                                            fontFamilyFallback: AppTypography.hindiFontFallback,
                                          ),
                                        ),
                                        const SizedBox(height: 2),
                                        Text(
                                          '$_speakerQuantity × ${_perSpeakerImpedance.toInt()}Ω (${_wiring == 'parallel' ? 'Parallel' : 'Series'})',
                                          style: TextStyle(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w600,
                                            color: textColor,
                                          ),
                                        ),
                                      ],
                                    ),
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.end,
                                      children: [
                                        Text(
                                          '$_formattedImpedanceΩ',
                                          style: const TextStyle(
                                            fontSize: 22,
                                            fontWeight: FontWeight.w900,
                                            color: Color(0xFF2563EB),
                                          ),
                                        ),
                                        Text(
                                          _isImpedanceSupported
                                              ? (isHindi ? 'सेफ स्टैंडर्ड (2Ω–16Ω)' : 'Safe Standard (2Ω–16Ω)')
                                              : (isHindi ? 'अमान्य सीमा' : 'Invalid Range (2Ω–16Ω)'),
                                          style: TextStyle(
                                            fontSize: 11,
                                            fontWeight: isHindi ? FontWeight.w600 : FontWeight.bold,
                                            color: _isImpedanceSupported
                                                ? const Color(0xFF10B981)
                                                : const Color(0xFFEF4444),
                                            fontFamilyFallback: AppTypography.hindiFontFallback,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),

                              if (!_isImpedanceSupported) ...[
                                const SizedBox(height: 8),
                                Padding(
                                  padding: const EdgeInsets.only(left: 4),
                                  child: Text(
                                    _isImpedanceTooLow
                                        ? (isHindi
                                            ? '⚠️ लोड 2Ω से कम है। स्पीकर कम करें या सीरीज वायरिंग करें।'
                                            : '⚠️ Load is below 2Ω. Reduce speaker quantity or select Series.')
                                        : (isHindi
                                            ? '⚠️ लोड 16Ω से ज्यादा है। स्पीकर कम करें या पैरलल वायरिंग करें।'
                                            : '⚠️ Load is above 16Ω. Reduce speaker quantity or select Parallel.'),
                                    style: const TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xFFEF4444),
                                    ),
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                        const SizedBox(height: 14),

                        // ==========================================
                        // 5. CABLE RUN LENGTH
                        // ==========================================
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: cardBorder),
                            boxShadow: [
                              BoxShadow(
                                color: isNight ? Colors.black.withOpacity(0.2) : const Color(0x060F172A),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    isHindi ? '5. केबल रन की लंबाई' : '5. CABLE RUN LENGTH',
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 0.5,
                                      color: textColor,
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                    decoration: BoxDecoration(
                                      color: tagBg,
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Text(
                                      'Meters (m)',
                                      style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w600,
                                        color: tagTextColor,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),

                              // Text field with 'm (One Way)' trailing
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                                decoration: BoxDecoration(
                                  color: innerInputBg,
                                  borderRadius: BorderRadius.circular(16),
                                  border: Border.all(
                                    color: _isLengthValid ? cardBorder : const Color(0xFFEF4444),
                                    width: 1.2,
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: TextField(
                                        controller: _lengthController,
                                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.w900,
                                          color: textColor,
                                        ),
                                        decoration: const InputDecoration(
                                          border: InputBorder.none,
                                          isDense: true,
                                          contentPadding: EdgeInsets.symmetric(vertical: 8),
                                        ),
                                        onChanged: (val) {
                                          final parsed = double.tryParse(val);
                                          setState(() => _cableLength = parsed ?? 0.0);
                                        },
                                      ),
                                    ),
                                    Text(
                                      'm (One Way)',
                                      style: TextStyle(
                                        fontSize: 13,
                                        fontWeight: FontWeight.w600,
                                        color: subtextColor,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 14),

                        // ==========================================
                        // 6. CABLE MATERIAL
                        // ==========================================
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: cardBorder),
                            boxShadow: [
                              BoxShadow(
                                color: isNight ? Colors.black.withOpacity(0.2) : const Color(0x060F172A),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    isHindi ? '6. केबल मटेरियल' : '6. CABLE MATERIAL',
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 0.5,
                                      color: textColor,
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                    decoration: BoxDecoration(
                                      color: _material == 'copper'
                                          ? const Color(0xFF10B981).withOpacity(0.12)
                                          : const Color(0xFFF59E0B).withOpacity(0.12),
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Text(
                                      _material == 'copper' ? 'OFC Pure' : 'CCA (~1.6x R)',
                                      style: TextStyle(
                                        fontSize: 11,
                                        fontWeight: FontWeight.bold,
                                        color: _material == 'copper'
                                            ? const Color(0xFF10B981)
                                            : const Color(0xFFF59E0B),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),

                              // 2 Big Side-by-Side Cards
                              Row(
                                children: [
                                  // Card 1: Pure Copper
                                  Expanded(
                                    child: InkWell(
                                      onTap: () {
                                        setState(() => _material = 'copper');
                                      },
                                      borderRadius: BorderRadius.circular(16),
                                      child: AnimatedContainer(
                                        duration: const Duration(milliseconds: 150),
                                        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 10),
                                        decoration: BoxDecoration(
                                          color: _material == 'copper'
                                              ? (isNight
                                                  ? const Color(0xFF1D4ED8).withOpacity(0.18)
                                                  : const Color(0xFFEFF6FF))
                                              : (isNight ? const Color(0xFF141C30) : const Color(0xFFF8FAFC)),
                                          borderRadius: BorderRadius.circular(16),
                                          border: Border.all(
                                            color: _material == 'copper'
                                                ? const Color(0xFF2563EB)
                                                : cardBorder,
                                            width: 1.5,
                                          ),
                                        ),
                                        child: Column(
                                          children: [
                                            Text(
                                              isHindi ? 'कॉपर (असली तांबा)' : 'Copper (Pure Copper)',
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                fontSize: 13,
                                                fontWeight: FontWeight.bold,
                                                color: _material == 'copper'
                                                    ? const Color(0xFF2563EB)
                                                    : textColor,
                                              ),
                                            ),
                                            const SizedBox(height: 3),
                                            Text(
                                              isHindi ? 'सबसे बेस्ट (कम लॉस)' : 'Pure Copper',
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                fontSize: 11,
                                                color: subtextColor,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 10),

                                  // Card 2: CCA
                                  Expanded(
                                    child: InkWell(
                                      onTap: () {
                                        setState(() => _material = 'cca');
                                      },
                                      borderRadius: BorderRadius.circular(16),
                                      child: AnimatedContainer(
                                        duration: const Duration(milliseconds: 150),
                                        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 10),
                                        decoration: BoxDecoration(
                                          color: _material == 'cca'
                                              ? (isNight
                                                  ? const Color(0xFFF59E0B).withOpacity(0.18)
                                                  : const Color(0xFFFFFBEB))
                                              : (isNight ? const Color(0xFF141C30) : const Color(0xFFF8FAFC)),
                                          borderRadius: BorderRadius.circular(16),
                                          border: Border.all(
                                            color: _material == 'cca'
                                                ? const Color(0xFFF59E0B)
                                                : cardBorder,
                                            width: 1.5,
                                          ),
                                        ),
                                        child: Column(
                                          children: [
                                            Text(
                                              isHindi ? 'सीसीए (एल्युमिनियम)' : 'CCA (Copper Clad Aluminium)',
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                fontSize: 12.5,
                                                fontWeight: FontWeight.bold,
                                                color: _material == 'cca'
                                                    ? const Color(0xFFD97706)
                                                    : textColor,
                                              ),
                                            ),
                                            const SizedBox(height: 3),
                                            Text(
                                              isHindi ? 'सस्ता (ज्यादा लॉस)' : 'High Resistance',
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                fontSize: 11,
                                                color: subtextColor,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 14),

                        // ==========================================
                        // ADVANCED OPTIONS (COLLAPSIBLE / ACCORDION)
                        // ==========================================
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: cardBorder),
                            boxShadow: [
                              BoxShadow(
                                color: isNight ? Colors.black.withOpacity(0.2) : const Color(0x060F172A),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Accordion Header Row
                              InkWell(
                                onTap: () {
                                  setState(() => _showAdvanced = !_showAdvanced);
                                },
                                borderRadius: BorderRadius.circular(20),
                                child: Padding(
                                  padding: const EdgeInsets.all(16),
                                  child: Row(
                                    children: [
                                      // Sliders/tune icon in squircle
                                      Container(
                                        width: 36,
                                        height: 36,
                                        decoration: BoxDecoration(
                                          color: const Color(0xFF2563EB).withOpacity(0.12),
                                          borderRadius: BorderRadius.circular(10),
                                        ),
                                        child: const Icon(
                                          Icons.tune_rounded,
                                          size: 18,
                                          color: Color(0xFF2563EB),
                                        ),
                                      ),
                                      const SizedBox(width: 12),

                                      // Title + Subtitle
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              isHindi ? 'एडवांस्ड ऑप्शंस' : 'ADVANCED OPTIONS',
                                              style: TextStyle(
                                                fontSize: 12.5,
                                                fontWeight: FontWeight.bold,
                                                letterSpacing: 0.5,
                                                color: textColor,
                                              ),
                                            ),
                                            const SizedBox(height: 2),
                                            Text(
                                              _maxAcceptableLoss == null
                                                  ? (isHindi
                                                      ? 'केबल रेसिस्टेंस टारगेट: डिफ़ॉल्ट 5%'
                                                      : 'Cable Resistance Target: Default 5%')
                                                  : (isHindi
                                                      ? 'केबल रेसिस्टेंस टारगेट: ${_maxAcceptableLoss!.toInt()}%'
                                                      : 'Cable Resistance Target: ${_maxAcceptableLoss!.toInt()}%'),
                                              style: TextStyle(
                                                fontSize: 11,
                                                color: subtextColor,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),

                                      // Chevron indicator
                                      Icon(
                                        _showAdvanced
                                            ? Icons.keyboard_arrow_up_rounded
                                            : Icons.keyboard_arrow_down_rounded,
                                        size: 24,
                                        color: subtextColor,
                                      ),
                                    ],
                                  ),
                                ),
                              ),

                              // Expanded Content (Screenshot 2)
                              if (_showAdvanced) ...[
                                Divider(height: 1, color: cardBorder),
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        isHindi
                                            ? 'केबल रेसिस्टेंस टारगेट'
                                            : 'CABLE RESISTANCE TARGET',
                                        style: TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.bold,
                                          letterSpacing: 0.5,
                                          color: textColor,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        isHindi
                                            ? 'यह टारगेट केबल रेसिस्टेंस को सीधे स्पीकर लोड से नापता है (R_loop / R_load × 100)। कम रेसिस्टेंस रहने से बेस टाइट बजता है और आवाज साफ रहती है।'
                                            : 'Compares cable loop resistance directly with speaker load impedance (R_loop / R_load × 100). Lower resistance ratio ensures superior damping factor and tight speaker control.',
                                        style: TextStyle(
                                          fontSize: 11.5,
                                          color: subtextColor,
                                        ),
                                      ),
                                      const SizedBox(height: 14),

                                      // 3-Option Buttons Grid
                                      Row(
                                        children: [
                                          _buildLossTargetCard(
                                            value: 3.0,
                                            label: '3%',
                                            title: isHindi ? 'हाई क्वालिटी' : 'Strict',
                                            subtitle: isHindi ? '3% से कम लॉस' : 'R_loop ≤ 3% load',
                                            isNight: isNight,
                                            textColor: textColor,
                                            subtextColor: subtextColor,
                                            cardBorder: cardBorder,
                                          ),
                                          const SizedBox(width: 8),
                                          _buildLossTargetCard(
                                            value: 5.0,
                                            label: '5%',
                                            title: isHindi ? 'नॉर्मल (बेस्ट)' : 'Balanced',
                                            subtitle: isHindi ? '5% से कम लॉस' : 'R_loop ≤ 5% load',
                                            isNight: isNight,
                                            textColor: textColor,
                                            subtextColor: subtextColor,
                                            cardBorder: cardBorder,
                                          ),
                                          const SizedBox(width: 8),
                                          _buildLossTargetCard(
                                            value: 10.0,
                                            label: '10%',
                                            title: isHindi ? 'बजट' : 'Budget',
                                            subtitle: isHindi ? '10% तक लॉस' : 'R_loop ≤ 10% load',
                                            isNight: isNight,
                                            textColor: textColor,
                                            subtextColor: subtextColor,
                                            cardBorder: cardBorder,
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 10),
                                      Text(
                                        _maxAcceptableLoss == 3.0
                                            ? (isHindi
                                                ? 'हाई क्वालिटी (3%): आवाज में बिल्कुल लॉस नहीं होगा, भारी और मोटी केबल लगेगी।'
                                                : 'Strict resistance target: limits loop resistance to ≤3% of speaker load (may require thicker cable).')
                                            : (_maxAcceptableLoss == 10.0
                                                ? (isHindi
                                                    ? 'बजट (10%): पतली केबल भी चल जाएगी, पर थोड़ा पावर लॉस होगा।'
                                                    : 'Budget resistance target: allows loop resistance up to 10% of speaker load; actual power loss is reported separately.')
                                                : (isHindi
                                                    ? 'नॉर्मल (5%): लाइव साउंड और डीजे सेटअप के लिए सबसे बेस्ट सेटिंग है।'
                                                    : 'Standard live audio benchmark: keeps cable resistance within ≤5% of speaker load for balanced performance.')),
                                        style: TextStyle(
                                          fontSize: 11,
                                          fontStyle: FontStyle.italic,
                                          color: subtextColor,
                                          fontFamilyFallback: AppTypography.hindiFontFallback,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                        const SizedBox(height: 22),

                        // ==========================================
                        // CALCULATE CTA BUTTON (Golden/Yellow)
                        // ==========================================
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: _isValid ? _calculateAndNavigate : null,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFFFBBF24),
                              foregroundColor: const Color(0xFF0F172A),
                              disabledBackgroundColor: isNight
                                  ? const Color(0xFF1E293B)
                                  : const Color(0xFFE2E8F0),
                              disabledForegroundColor: isNight
                                  ? const Color(0xFF64748B)
                                  : const Color(0xFF94A3B8),
                              elevation: _isValid ? 3 : 0,
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  isHindi
                                      ? 'सही केबल साइज़ देखें'
                                      : 'Calculate Cable Recommendation',
                                  style: TextStyle(
                                    fontSize: 14.5,
                                    fontWeight: isHindi ? FontWeight.w600 : FontWeight.w800,
                                    letterSpacing: isHindi ? 0.0 : 0.3,
                                    fontFamilyFallback: AppTypography.hindiFontFallback,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                const Icon(Icons.arrow_forward_rounded, size: 18),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLossTargetCard({
    required double value,
    required String label,
    required String title,
    required String subtitle,
    required bool isNight,
    required Color textColor,
    required Color subtextColor,
    required Color cardBorder,
  }) {
    final isSelected = (_maxAcceptableLoss == null && value == 5.0) || _maxAcceptableLoss == value;

    return Expanded(
      child: InkWell(
        onTap: () {
          setState(() {
            _maxAcceptableLoss = isSelected ? null : value;
          });
        },
        borderRadius: BorderRadius.circular(14),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
          decoration: BoxDecoration(
            color: isSelected
                ? const Color(0xFF1D4ED8)
                : (isNight ? const Color(0xFF141C30) : const Color(0xFFF8FAFC)),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: isSelected ? const Color(0xFF1D4ED8) : cardBorder,
              width: 1.2,
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                  color: isSelected ? Colors.white : textColor,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                title,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: AppTypography.isDevanagari(title) ? FontWeight.w600 : FontWeight.bold,
                  color: isSelected ? Colors.white : textColor,
                  fontFamilyFallback: AppTypography.hindiFontFallback,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 9.5,
                  fontWeight: FontWeight.w500,
                  color: isSelected ? const Color(0xFFDBEAFE) : subtextColor,
                  fontFamilyFallback: AppTypography.hindiFontFallback,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
