import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/preference_service.dart';
import '../services/history_service.dart';
import '../localization/app_localizations.dart';
import 'ohm_calculator_screen.dart';
import 'ohm_result_screen.dart';
import 'amplifier_calculator_screen.dart';
import 'amp_result_screen.dart';
import 'top_speaker_screen.dart';
import 'top_speaker_result_screen.dart';
import 'cable_loss_screen.dart';
import 'cable_loss_result_screen.dart';
import 'dmx_screen.dart';
import 'dmx_result_screen.dart';
import '../models/models.dart';
import '../calculators/ohm_calculator.dart';
import '../calculators/amplifier_calculator.dart';
import '../calculators/cable_loss_calculator.dart';
import '../calculators/top_speaker_calculator.dart';
import '../calculators/dmx_calculator.dart';
import '../utils/app_typography.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  void _openHistoryRecord(BuildContext context, HistoryItem item) {
    final payload = item.payload;

    switch (item.calculatorId) {
      case 'calc_ohm':
        if (payload != null) {
          final speakerRms = (payload['speakerRms'] as num?)?.toDouble() ?? 300.0;
          final speakerCount = (payload['speakerCount'] as num?)?.toInt() ?? 2;
          final speakerImpedance = (payload['speakerImpedance'] as num?)?.toDouble() ?? 8.0;
          final wiringStr = payload['wiring'] as String? ?? 'parallel';
          final wiring = wiringStr == 'series'
              ? WiringConfiguration.series
              : WiringConfiguration.parallel;

          final result = OhmCalculator.calculate(
            speakerRms: speakerRms,
            speakerCount: speakerCount,
            speakerImpedance: speakerImpedance,
            wiring: wiring,
          );

          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => OhmResultScreen(result: result),
            ),
          );
          return;
        }
        Navigator.push(context, MaterialPageRoute(builder: (_) => const OhmCalculatorScreen()));
        break;

      case 'calc_cable_loss':
        if (payload != null) {
          final cableLength = (payload['cableLength'] as num?)?.toDouble() ?? 20.0;
          final power = (payload['power'] as num?)?.toDouble() ?? 500.0;
          final material = payload['material'] as String? ?? 'copper';
          final maxAcceptableLoss = (payload['maxAcceptableLoss'] as num?)?.toDouble() ?? 5.0;
          final speakerQuantity = (payload['speakerQuantity'] as num?)?.toInt() ?? 4;
          final perSpeakerImpedance = (payload['perSpeakerImpedance'] as num?)?.toDouble() ?? 8.0;
          final wiring = payload['wiring'] as String? ?? 'parallel';

          final double rawImpedance = speakerQuantity <= 0
              ? perSpeakerImpedance
              : (wiring == 'parallel'
                  ? perSpeakerImpedance / speakerQuantity
                  : perSpeakerImpedance * speakerQuantity);
          final double load = double.parse((rawImpedance * 100).toStringAsFixed(0)) / 100;

          final result = CableLossCalculator.calculate(
            cableLength: cableLength,
            load: load,
            power: power,
            material: material,
            maxAcceptableLoss: maxAcceptableLoss,
            speakerQuantity: speakerQuantity,
            perSpeakerImpedance: perSpeakerImpedance,
            wiring: wiring,
          );

          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => CableLossResultScreen(result: result),
            ),
          );
          return;
        }
        Navigator.push(context, MaterialPageRoute(builder: (_) => const CableLossScreen()));
        break;

      case 'calc_amp':
        if (payload != null) {
          final speakerRms = (payload['speakerRms'] as num?)?.toDouble() ?? 500.0;
          final speakerCount = (payload['speakerCount'] as num?)?.toInt() ?? 2;
          final speakerImpedance = (payload['speakerImpedance'] as num?)?.toDouble() ?? 8.0;
          final wiringStr = payload['wiring'] as String? ?? 'parallel';
          final wiring = wiringStr == 'series'
              ? WiringConfiguration.series
              : WiringConfiguration.parallel;
          final headroom = (payload['headroom'] as num?)?.toDouble() ?? 1.5;

          final result = AmplifierCalculator.calculate(
            speakerRms: speakerRms,
            speakerCount: speakerCount,
            speakerImpedance: speakerImpedance,
            wiring: wiring,
            headroom: headroom,
          );

          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => AmpResultScreen(result: result),
            ),
          );
          return;
        }
        Navigator.push(context, MaterialPageRoute(builder: (_) => const AmplifierCalculatorScreen()));
        break;

      case 'calc_dmx':
        if (payload != null) {
          final startAddress = (payload['startAddress'] as num?)?.toInt() ?? 1;
          final channelCount = (payload['channelCount'] as num?)?.toInt() ?? 16;
          final fixtureCount = (payload['fixtureCount'] as num?)?.toInt() ?? 4;

          final result = DmxCalculator.calculate(
            startAddress: startAddress,
            channelCount: channelCount,
            fixtureCount: fixtureCount,
          );

          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => DmxResultScreen(result: result),
            ),
          );
          return;
        }
        Navigator.push(context, MaterialPageRoute(builder: (_) => const DmxScreen()));
        break;

      case 'calc_top_speaker':
        if (payload != null) {
          final speakerRms = (payload['speakerRms'] as num?)?.toDouble() ?? 500.0;
          final speakerCount = (payload['speakerCount'] as num?)?.toInt() ?? 2;

          final result = TopSpeakerCalculator.calculate(
            speakerRms: speakerRms,
            speakerCount: speakerCount,
          );

          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => TopSpeakerResultScreen(result: result),
            ),
          );
          return;
        }
        Navigator.push(context, MaterialPageRoute(builder: (_) => const TopSpeakerScreen()));
        break;

      default:
        break;
    }
  }

  IconData _getCalcIcon(String calcId) {
    switch (calcId) {
      case 'calc_ohm':
        return Icons.layers_rounded;
      case 'calc_amp':
        return Icons.bolt_rounded;
      case 'calc_top_speaker':
        return Icons.speaker_group_rounded;
      case 'calc_cable_loss':
        return Icons.cable_rounded;
      case 'calc_dmx':
        return Icons.tune_rounded;
      default:
        return Icons.history_rounded;
    }
  }

  String _formatTimestamp(DateTime dt, bool isHindi) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inSeconds < 60) return isHindi ? 'अभी' : 'Just now';
    if (diff.inMinutes < 60) return isHindi ? '${diff.inMinutes} मिनट पहले' : '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return isHindi ? '${diff.inHours} घंटे पहले' : '${diff.inHours}h ago';
    final minuteStr = dt.minute.toString().padLeft(2, '0');
    final hourStr = dt.hour.toString().padLeft(2, '0');
    return '${dt.day}/${dt.month}/${dt.year} $hourStr:$minuteStr';
  }

  @override
  Widget build(BuildContext context) {
    final prefService = Provider.of<PreferenceService>(context);
    final historyService = Provider.of<HistoryService>(context);
    final isHindi = prefService.locale.languageCode == 'hi';
    final isNight = prefService.isNightMode;
    final items = historyService.items;

    final bgColor = isNight ? const Color(0xFF070B14) : const Color(0xFFE5EBF3);
    final cardBg = isNight ? const Color(0xFF101726) : Colors.white;
    final borderColor = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final textColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final subtitleColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    return Scaffold(
      backgroundColor: bgColor,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          children: [
            // Top Screen Banner Card
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: cardBg,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: borderColor),
                boxShadow: [
                  BoxShadow(
                    color: isNight ? Colors.black.withOpacity(0.4) : const Color(0x0A0F172A),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: isNight ? const Color(0xFF1E293B) : const Color(0xFFEFF6FF),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isNight ? const Color(0xFF334155) : const Color(0xFFBFDBFE),
                      ),
                    ),
                    child: Icon(
                      Icons.history_rounded,
                      color: isNight ? const Color(0xFF38BDF8) : const Color(0xFF1D4ED8),
                      size: 22,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          isHindi ? 'कैलकुलेशन हिस्ट्री' : 'Calculation History',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                            color: textColor,
                            letterSpacing: isHindi ? 0.0 : -0.3,
                            fontFamilyFallback: AppTypography.hindiFontFallback,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          isHindi
                              ? 'आपकी पिछली सभी कैलकुलेशन का सुरक्षित रिकॉर्ड'
                              : 'Offline saved records for your past rig setups',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                            color: subtitleColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (items.isNotEmpty)
                    InkWell(
                      onTap: () {
                        showDialog(
                          context: context,
                          builder: (ctx) => AlertDialog(
                            backgroundColor: cardBg,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                            title: Text(
                              isHindi ? 'हिस्ट्री मिटाएं?' : 'Clear History?',
                              style: TextStyle(
                                color: textColor,
                                fontWeight: isHindi ? FontWeight.w600 : FontWeight.bold,
                                fontFamilyFallback: AppTypography.hindiFontFallback,
                              ),
                            ),
                            content: Text(
                              isHindi
                                  ? 'क्या आप सभी पुरानी कैलकुलेशन मिटाना चाहते हैं?'
                                  : 'Are you sure you want to clear all saved calculation records?',
                              style: TextStyle(color: subtitleColor),
                            ),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.pop(ctx),
                                child: Text(isHindi ? 'रद्द करें' : 'Cancel'),
                              ),
                              TextButton(
                                onPressed: () {
                                  historyService.clearHistory();
                                  Navigator.pop(ctx);
                                },
                                child: Text(
                                  isHindi ? 'हाँ, मिटाएं' : 'Clear All',
                                  style: const TextStyle(color: Colors.redAccent),
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: isNight ? const Color(0xFF450A0A) : const Color(0xFFFEF2F2),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: isNight ? const Color(0xFF7F1D1D) : const Color(0xFFFECACA),
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.delete_outline_rounded, color: Colors.redAccent, size: 16),
                            const SizedBox(width: 4),
                            Text(
                              isHindi ? 'साफ़ करें' : 'Clear',
                              style: TextStyle(
                                fontSize: 11.5,
                                fontWeight: isHindi ? FontWeight.w600 : FontWeight.bold,
                                color: Colors.redAccent,
                                fontFamilyFallback: AppTypography.hindiFontFallback,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // History List or Empty State (100% Free For All Users)
            if (items.isEmpty)
              Container(
                padding: const EdgeInsets.all(32),
                decoration: BoxDecoration(
                  color: cardBg,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: borderColor),
                  boxShadow: [
                    BoxShadow(
                      color: isNight ? Colors.black.withOpacity(0.3) : const Color(0x0A0F172A),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Icon(
                      Icons.history_toggle_off_rounded,
                      size: 48,
                      color: isNight ? const Color(0xFF475569) : const Color(0xFF94A3B8),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      isHindi ? 'कोई पुराना रिकॉर्ड नहीं मिला' : 'No Calculation History Yet',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: isHindi ? FontWeight.w600 : FontWeight.bold,
                        color: textColor,
                        fontFamilyFallback: AppTypography.hindiFontFallback,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      isHindi
                          ? 'जब आप Ohm, Amp, Cable या DMX टूल्स का उपयोग करेंगे, तो उनके परिणाम अपने आप यहाँ सुरक्षित रहेंगे।'
                          : 'Your calculated speaker setups, amplifier configs, and DMX patch charts will automatically appear here.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 12,
                        color: subtitleColor,
                        height: 1.35,
                      ),
                    ),
                  ],
                ),
              )
            else
              ...items.map((item) {
                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: cardBg,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: borderColor),
                    boxShadow: [
                      BoxShadow(
                        color: isNight ? Colors.black.withOpacity(0.3) : const Color(0x080F172A),
                        blurRadius: 8,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: InkWell(
                    onTap: () => _openHistoryRecord(context, item),
                    borderRadius: BorderRadius.circular(16),
                    child: Row(
                      children: [
                        Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            color: isNight ? const Color(0xFF1E293B) : const Color(0xFFF1F5F9),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: isNight ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
                            ),
                          ),
                          child: Icon(
                            _getCalcIcon(item.calculatorId),
                            color: isNight ? const Color(0xFF38BDF8) : const Color(0xFF2563EB),
                            size: 20,
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                item.title,
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  color: textColor,
                                ),
                              ),
                              const SizedBox(height: 3),
                              Text(
                                item.subtitle,
                                style: TextStyle(
                                  fontSize: 12,
                                  color: subtitleColor,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Row(
                                children: [
                                  Icon(
                                    Icons.access_time_rounded,
                                    size: 11,
                                    color: subtitleColor.withOpacity(0.8),
                                  ),
                                  const SizedBox(width: 4),
                                  Text(
                                    _formatTimestamp(item.timestamp, isHindi),
                                    style: TextStyle(
                                      fontSize: 10.5,
                                      fontWeight: FontWeight.w500,
                                      color: subtitleColor.withOpacity(0.8),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        Icon(
                          Icons.arrow_forward_ios_rounded,
                          size: 14,
                          color: subtitleColor,
                        ),
                      ],
                    ),
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }
}
