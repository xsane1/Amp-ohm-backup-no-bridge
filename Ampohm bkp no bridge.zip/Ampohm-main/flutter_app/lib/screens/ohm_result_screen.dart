import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/preference_service.dart';
import '../localization/app_localizations.dart';
import '../models/models.dart';
import '../widgets/calculator_hero_header.dart';
import '../widgets/wiring_diagram.dart';
import '../widgets/share_result_button.dart';
import '../widgets/ad_banner_widget.dart';
import 'amplifier_calculator_screen.dart';
import '../utils/app_typography.dart';

class OhmResultScreen extends StatelessWidget {
  final OhmCalculationResult result;

  const OhmResultScreen({
    super.key,
    required this.result,
  });

  String _generateShareText() {
    final wiringStr = result.wiring == WiringConfiguration.parallel ? 'Parallel' : 'Series';
    return '''
==============================
AMP OHM - OHM & LOAD CALCULATION
==============================
System Parameters:
• Cabinet Drivers: ${result.speakerCount} ${result.speakerCount == 1 ? "Speaker" : "Speakers"}
• Cabinet Impedance: ${result.speakerImpedance.toInt()}Ω each
• Wiring Configuration: $wiringStr
• Per Driver RMS: ${result.speakerRms.toInt()}W RMS
• Total System Power: ${result.totalSystemRms.toInt()}W RMS

Results & Classification:
• Total Net Load: ${result.formattedImpedance}Ω (Per Channel)
• Safety Classification: ${result.loadCategory.displayName}
• Amplifier Recommendation: ${result.canRecommendAmp ? "Compatible with 2Ω-8Ω stable amplifiers" : "Requires specialized power amp"}

Calculated with AMP OHM - Developed by AudioXpert
━━━━━━━━━━━━━━━━━━
📱 AMP OHM App:
https://play.google.com/store/apps/details?id=com.ampohm.app

📸 Instagram:
https://instagram.com/audio_xpert

▶️ YouTube:
https://youtube.com/@audioxpertt
==============================''';
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final isHindi = Localizations.localeOf(context).languageCode == 'hi';

    // Color and visual determination matching web visuals exactly
    List<Color> bannerGradient;
    Color badgeBg;
    Color badgeColor;
    Color borderColor;
    IconData statusIcon;
    String statusTitle;
    String statusMessage;

    final is16Ohm = (result.totalImpedance - 16.0).abs() < 0.005;

    switch (result.loadCategory) {
      case OhmLoadCategory.extreme:
        bannerGradient = const [Color(0xFF550C16), Color(0xFF821422), Color(0xFF36080E)];
        badgeBg = const Color(0xFFDC2626);
        badgeColor = Colors.white;
        borderColor = const Color(0xFFEF4444);
        statusIcon = Icons.warning_amber_rounded;
        statusTitle = t.ohmClassExtreme;
        statusMessage = t.ohmClassExtremeMsg;
        break;
      case OhmLoadCategory.requires2Ohm:
      case OhmLoadCategory.highCurrent:
      case OhmLoadCategory.uncommon:
        bannerGradient = const [Color(0xFF522004), Color(0xFF85360A), Color(0xFF331302)];
        badgeBg = const Color(0xFFF59E0B);
        badgeColor = const Color(0xFF0F172A);
        borderColor = const Color(0xFFFBBF24);
        statusIcon = Icons.warning_amber_rounded;
        if (result.loadCategory == OhmLoadCategory.uncommon) {
          statusTitle = t.ohmClassUncommon;
          statusMessage = t.ohmClassUncommonMsg;
        } else if (result.loadCategory == OhmLoadCategory.highCurrent) {
          statusTitle = t.ohmClassHighCurrent;
          statusMessage = t.ohmClassHighCurrentMsg;
        } else {
          statusTitle = t.ohmClassRequires2Ohm;
          statusMessage = t.ohmClassRequires2OhmMsg;
        }
        break;
      case OhmLoadCategory.safe:
      case OhmLoadCategory.proLoad:
      default:
        if (is16Ohm) {
          // 16Ω Load: orange banner and badge matching extreme/amber load style
          bannerGradient = const [Color(0xFF522004), Color(0xFF85360A), Color(0xFF331302)];
          badgeBg = const Color(0xFFF59E0B);
          badgeColor = const Color(0xFF0F172A);
          borderColor = const Color(0xFFFBBF24);
          statusIcon = Icons.warning_amber_rounded;
          statusTitle = t.ohmClassProLoad;
          statusMessage = t.ohmClass16OhmMsg;
        } else {
          bannerGradient = const [Color(0xFF064E3B), Color(0xFF065F46), Color(0xFF022C22)];
          badgeBg = const Color(0xFF059669);
          badgeColor = Colors.white;
          borderColor = const Color(0xFF34D399);
          statusIcon = Icons.check_circle_rounded;
          if (result.loadCategory == OhmLoadCategory.proLoad) {
            statusTitle = t.ohmClassProLoad;
            statusMessage = t.ohmClassProLoadMsg;
          } else {
            statusTitle = t.ohmClassSafe;
            statusMessage = t.ohmClassSafeMsg;
          }
        }
        break;
    }

    statusMessage = AppLocalizations.interpolateLoad(statusMessage, result.totalImpedance);

    final prefService = Provider.of<PreferenceService>(context);
    final isNight = prefService.isNightMode;

    final bgColor = isNight ? const Color(0xFF070B14) : const Color(0xFFF1F5F9);
    final sheetBg = isNight ? const Color(0xFF0E1526) : Colors.white;
    final cardBg = isNight ? const Color(0xFF141C30) : Colors.white;
    final borderColorCard = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final textColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final subtitleColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    return Scaffold(
      backgroundColor: bgColor,
      body: SafeArea(
        child: Column(
          children: [
            // 1. Curved Hero Header exactly like Web
            CalculatorHeroHeader(
              title: t.ohmResultTitle,
              subtitle: isHindi
                  ? 'स्पीकर लोड और एम्पलीफायर मैचिंग'
                  : 'System load analysis & amplifier matching',
              onBack: () => Navigator.pop(context),
            ),

            // 2. Curved Sheet for Results
            Expanded(
              child: Transform.translate(
                offset: const Offset(0, -20),
                child: Container(
                  decoration: BoxDecoration(
                    color: sheetBg,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: isNight ? Colors.black.withOpacity(0.5) : const Color(0x140F172A),
                        blurRadius: 20,
                        offset: const Offset(0, -6),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
                      children: [
                        // Main Load Result Banner matching web
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: bannerGradient,
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(28),
                            border: Border.all(color: borderColor.withOpacity(0.8), width: 1.5),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.2),
                                blurRadius: 16,
                                offset: const Offset(0, 6),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Top badge row - Wrap prevents text clipping on small Android screens
                              Wrap(
                                alignment: WrapAlignment.spaceBetween,
                                crossAxisAlignment: WrapCrossAlignment.center,
                                spacing: 8,
                                runSpacing: 6,
                                children: [
                                  Wrap(
                                    crossAxisAlignment: WrapCrossAlignment.center,
                                    spacing: 6,
                                    runSpacing: 4,
                                    children: [
                                      Text(
                                        t.ohmResultTotalLoad.toUpperCase(),
                                        style: TextStyle(
                                          fontSize: 11,
                                          fontWeight: FontWeight.bold,
                                          letterSpacing: 0.8,
                                          color: Colors.white.withOpacity(0.8),
                                        ),
                                      ),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                        decoration: BoxDecoration(
                                          color: Colors.white.withOpacity(0.2),
                                          borderRadius: BorderRadius.circular(12),
                                          border: Border.all(color: Colors.white.withOpacity(0.2)),
                                        ),
                                        child: Text(
                                          t.perChannelBadge.toUpperCase(),
                                          style: const TextStyle(
                                            fontSize: 9.5,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),

                                  // Status Badge - Fully visible without ellipsis truncation
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: badgeBg,
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                    child: Text(
                                      statusTitle.toUpperCase(),
                                      style: TextStyle(
                                        fontSize: 10.5,
                                        fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                                        color: badgeColor,
                                        letterSpacing: isHindi ? 0.0 : 0.5,
                                        fontFamilyFallback: AppTypography.hindiFontFallback,
                                      ),
                                    ),
                                  ),
                                ],
                              ),

                              const SizedBox(height: 10),

                              // Big Impedance Numbers
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.baseline,
                                textBaseline: TextBaseline.alphabetic,
                                children: [
                                  Text(
                                    result.totalImpedance.toStringAsFixed(2),
                                    style: const TextStyle(
                                      fontSize: 48,
                                      fontWeight: FontWeight.w900,
                                      color: Colors.white,
                                      letterSpacing: -1.0,
                                      height: 1.0,
                                    ),
                                  ),
                                  const SizedBox(width: 4),
                                  const Text(
                                    'Ω',
                                    style: TextStyle(
                                      fontSize: 26,
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xFFFBBF24),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Flexible(
                                    child: Text(
                                      t.perChannelSuffix,
                                      style: TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w600,
                                        color: Colors.white.withOpacity(0.7),
                                      ),
                                    ),
                                  ),
                                ],
                              ),

                              const SizedBox(height: 14),

                              // Inner Explanatory Card
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.35),
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(color: Colors.white.withOpacity(0.12)),
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Icon(statusIcon, color: borderColor, size: 20),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            statusTitle,
                                            style: TextStyle(
                                              fontSize: 12.5,
                                              fontWeight: FontWeight.bold,
                                              color: borderColor,
                                            ),
                                          ),
                                          const SizedBox(height: 2),
                                          Text(
                                            statusMessage,
                                            style: TextStyle(
                                              fontSize: 11,
                                              color: Colors.white.withOpacity(0.9),
                                              height: 1.35,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 12),

                        // Per-Channel Scope Notice
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          decoration: BoxDecoration(
                            color: isNight ? const Color(0xFF0B172E) : const Color(0xFFEFF6FF),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: isNight ? const Color(0xFF1E3A8A) : const Color(0xFFBFDBFE),
                            ),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                Icons.info_outline_rounded,
                                size: 18,
                                color: isNight ? const Color(0xFF38BDF8) : const Color(0xFF2563EB),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  t.perChannelNotice,
                                  style: TextStyle(
                                    fontSize: 11.5,
                                    fontWeight: FontWeight.w600,
                                    color: isNight ? const Color(0xFF93C5FD) : const Color(0xFF1E40AF),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 14),

                        // Google AdMob Banner Centered directly below colored result box
                        const Center(
                          child: AdBannerWidget(placement: 'ohm_result'),
                        ),

                        const SizedBox(height: 14),

                        // System Summary Card
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(color: borderColorCard),
                            boxShadow: [
                              BoxShadow(
                                color: isNight ? Colors.black.withOpacity(0.3) : const Color(0x080F172A),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(
                                    Icons.layers_rounded,
                                    size: 16,
                                    color: isNight ? const Color(0xFF38BDF8) : const Color(0xFF2563EB),
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    t.ohmSummaryTitle.toUpperCase(),
                                    style: TextStyle(
                                      fontSize: 11.5,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: 0.6,
                                      color: textColor,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),

                              // Grid summary rows
                              _buildSummaryTile(
                                label: t.ohmSummaryTotalSpeakers,
                                value: '${result.speakerCount} ${result.speakerCount == 1 ? "Speaker" : "Speakers"}',
                                isNight: isNight,
                              ),
                              const SizedBox(height: 8),
                              _buildSummaryTile(
                                label: t.ohmSummarySpeakerRms,
                                value: '${result.speakerRms.toInt()} Watts',
                                isNight: isNight,
                              ),
                              const SizedBox(height: 8),
                              _buildSummaryTile(
                                label: t.ohmSummaryTotalRms,
                                value: '${result.totalSystemRms.toInt()} Watts Total',
                                isHighlight: true,
                                isNight: isNight,
                              ),
                              const SizedBox(height: 8),
                              _buildSummaryTile(
                                label: t.ohmSummaryWiring,
                                value: result.wiring == WiringConfiguration.parallel ? 'Parallel' : 'Series',
                                isNight: isNight,
                              ),
                              const SizedBox(height: 8),
                              _buildSummaryTile(
                                label: t.ohmSummaryCabinetImp,
                                value: '${result.speakerImpedance.toInt()} Ω each',
                                isNight: isNight,
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 16),

                        // Interactive Wiring Diagram
                        WiringDiagramWidget(
                          wiring: result.wiring,
                          speakerCount: result.speakerCount,
                          speakerImpedance: result.speakerImpedance,
                        ),

                        const SizedBox(height: 16),

                        // Share / Clipboard Action Button
                        ShareResultButton(
                          title: isHindi ? 'रिजल्ट शेयर करें' : 'SHARE SYSTEM SPECIFICATION',
                          shareText: _generateShareText(),
                        ),

                        const SizedBox(height: 16),

                        // Action 1: Find Recommended Amplifier (Gold Button) or Restricted Notice
                        if (result.canRecommendAmp)
                          InkWell(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => AmplifierCalculatorScreen(
                                    initialSpeakerRms: result.speakerRms,
                                    initialSpeakerCount: result.speakerCount,
                                    initialSpeakerImpedance: result.speakerImpedance,
                                    initialWiring: result.wiring,
                                    initialFinalLoad: result.totalImpedance,
                                    initialTotalRms: result.totalSystemRms,
                                    autoCalculateAndShowResult: true,
                                  ),
                                ),
                              );
                            },
                            borderRadius: BorderRadius.circular(22),
                            child: Container(
                              width: double.infinity,
                              padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
                              decoration: BoxDecoration(
                                color: const Color(0xFFFBBF24),
                                borderRadius: BorderRadius.circular(22),
                                border: Border.all(color: const Color(0xFFF59E0B)),
                                boxShadow: [
                                  BoxShadow(
                                    color: const Color(0xFFF59E0B).withOpacity(0.35),
                                    blurRadius: 10,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                              ),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Icon(Icons.bolt_rounded, size: 20, color: Color(0xFF0F172A)),
                                  const SizedBox(width: 8),
                                  Flexible(
                                    child: Text(
                                      t.ohmFindAmp,
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                                        color: const Color(0xFF0F172A),
                                        fontFamilyFallback: AppTypography.hindiFontFallback,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  const Icon(Icons.arrow_forward_rounded, size: 18, color: Color(0xFF0F172A)),
                                ],
                              ),
                            ),
                          )
                        else
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFEF2F2),
                              borderRadius: BorderRadius.circular(18),
                              border: Border.all(color: const Color(0xFFFECACA)),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Icon(Icons.warning_amber_rounded, size: 20, color: Color(0xFFDC2626)),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        isHindi ? 'एम्पलीफायर सुझाव उपलब्ध नहीं' : 'Amplifier Recommendation Restricted',
                                        style: TextStyle(
                                          fontSize: 12.5,
                                          fontWeight: isHindi ? FontWeight.w600 : FontWeight.bold,
                                          color: const Color(0xFF991B1B),
                                          fontFamilyFallback: AppTypography.hindiFontFallback,
                                        ),
                                      ),
                                      const SizedBox(height: 2),
                                      Text(
                                        t.ohmRecRestrictedReason,
                                        style: const TextStyle(
                                          fontSize: 11,
                                          color: Color(0xFFB91C1C),
                                          height: 1.35,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        const SizedBox(height: 10),

                        // Action 2: Modify Inputs Button
                        InkWell(
                          onTap: () => Navigator.pop(context),
                          borderRadius: BorderRadius.circular(22),
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            decoration: BoxDecoration(
                              color: cardBg,
                              borderRadius: BorderRadius.circular(22),
                              border: Border.all(color: borderColorCard),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.tune_rounded,
                                  size: 18,
                                  color: isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B),
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  t.ohmModifyInputs,
                                  style: TextStyle(
                                    fontSize: 13.5,
                                    fontWeight: FontWeight.w800,
                                    color: textColor,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryTile({
    required String label,
    required String value,
    bool isHighlight = false,
    bool isNight = false,
  }) {
    final tileBg = isNight
        ? (isHighlight ? const Color(0xFF0F172A) : const Color(0xFF0A0F1D))
        : (isHighlight ? const Color(0xFFEFF6FF) : const Color(0xFFF8FAFC));
    final tileBorder = isNight
        ? (isHighlight ? const Color(0xFF1E3A8A) : const Color(0xFF1E293B))
        : (isHighlight ? const Color(0xFFBFDBFE) : const Color(0xFFE2E8F0));
    final labelColor = isNight
        ? (isHighlight ? const Color(0xFF93C5FD) : const Color(0xFF94A3B8))
        : (isHighlight ? const Color(0xFF1E40AF) : const Color(0xFF64748B));
    final valueColor = isNight
        ? (isHighlight ? const Color(0xFF38BDF8) : Colors.white)
        : (isHighlight ? const Color(0xFF1D4ED8) : const Color(0xFF0F172A));

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      decoration: BoxDecoration(
        color: tileBg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: tileBorder),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w600,
                color: labelColor,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w800,
                color: valueColor,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
