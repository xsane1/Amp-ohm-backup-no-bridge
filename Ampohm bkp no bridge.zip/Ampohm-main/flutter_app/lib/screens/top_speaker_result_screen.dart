import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/preference_service.dart';
import '../models/models.dart';
import '../utils/app_typography.dart';
import '../widgets/calculator_hero_header.dart';
import '../widgets/share_result_button.dart';
import '../widgets/ad_banner_widget.dart';

class TopSpeakerResultScreen extends StatelessWidget {
  final TopSpeakerResult result;

  const TopSpeakerResultScreen({
    super.key,
    required this.result,
  });

  String _getRecommendedCableGauge() {
    return result.totalRms <= 600 ? '2.5 mm² (13 AWG)' : '4.0 mm² (11 AWG)';
  }

  String _generateShareText(bool isHindi) {
    final cableSize = _getRecommendedCableGauge();
    return '''
==============================
AMP OHM - TOP SPEAKER POWER CALCULATION
==============================
System Parameters:
• Cabinet Drivers: ${result.speakerCount}x Speaker${result.speakerCount > 1 ? 's' : ''}
• Per Driver RMS: ${result.speakerRms.toInt()}W RMS

Results & Power Capacity:
• Continuous System RMS: ${result.totalRms.toInt()}W RMS
• Program Power Rating: ${result.programPower.toInt()}W Program (RMS × 2)
• Peak Power Capacity: ${result.peakPower.toInt()}W Peak (RMS × 4)

Recommended Amplifier Matching:
• Suggested Amp Power: ${result.recommendedAmpPower.toInt()}W RMS / Channel
• Headroom Factor: 1.5x Program Dynamic Headroom
• Recommended HPF / Low Cut: 80Hz - 100Hz (24dB/oct)

Recommended Speaker Cable:
• Gauge: $cableSize
• Material: OFC Pure Copper (2-Core / 4-Core)
• Connector: Neutrik Speakon NL4 (1+ / 1-)
• Max Run: 25 - 30 Meters

Calculated with AMP OHM - Developed by AudioXpert
━━━━━━━━━━━━━━━━━━
📱 AMP OHM App:
https://play.google.com/store/apps/details?id=com.ampohm.app

📸 Instagram:
https://instagram.com/audio_xpert

▶️ YouTube:
https://youtube.com/@audioxpertt
==============================''';
  }

  @override
  Widget build(BuildContext context) {
    final prefService = Provider.of<PreferenceService>(context);
    final isNight = prefService.isNightMode;
    final isHindi = prefService.isHindi;

    final bgColor = isNight ? const Color(0xFF070B14) : const Color(0xFFF1F5F9);
    final sheetBg = isNight ? const Color(0xFF0E1526) : Colors.white;
    final cardBg = isNight ? const Color(0xFF141C30) : Colors.white;
    final borderColorCard = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final textColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final subtitleColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    final heroGradient = isNight
        ? const [Color(0xFF0B1933), Color(0xFF132B5C), Color(0xFF0F172A)]
        : const [Color(0xFF1D4ED8), Color(0xFF2563EB), Color(0xFF1E40AF)];

    final cableGauge = _getRecommendedCableGauge();

    return Scaffold(
      backgroundColor: bgColor,
      body: SafeArea(
        child: Column(
          children: [
            // 1. Curved Hero Header matching other calculators
            CalculatorHeroHeader(
              title: isHindi ? 'टॉप स्पीकर रिज़ल्ट' : 'TOP SPEAKER RESULT',
              subtitle: isHindi
                  ? 'RMS, प्रोग्राम, पीक पावर और सही एम्पलीफायर'
                  : 'Power capacity, amplifier matching & cable specifications',
              onBack: () => Navigator.pop(context),
            ),

            // 2. Curved Sheet for Results
            Expanded(
              child: Transform.translate(
                offset: const Offset(0, -20),
                child: Container(
                  decoration: BoxDecoration(
                    color: sheetBg,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: isNight ? Colors.black.withOpacity(0.5) : const Color(0x140F172A),
                        blurRadius: 20,
                        offset: const Offset(0, -6),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
                      children: [
                        // HERO CARD: RECOMMENDED AMPLIFIER POWER (Matching Ohm & Amp Hero Cards)
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: heroGradient,
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(28),
                            border: Border.all(
                              color: isNight
                                  ? const Color(0xFF38BDF8).withOpacity(0.4)
                                  : const Color(0xFF93C5FD).withOpacity(0.6),
                              width: 1.5,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: isNight ? Colors.black.withOpacity(0.4) : const Color(0x1A1D4ED8),
                                blurRadius: 18,
                                offset: const Offset(0, 8),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Top Badges Row
                              Wrap(
                                alignment: WrapAlignment.spaceBetween,
                                crossAxisAlignment: WrapCrossAlignment.center,
                                spacing: 8,
                                runSpacing: 6,
                                children: [
                                  Wrap(
                                    crossAxisAlignment: WrapCrossAlignment.center,
                                    spacing: 6,
                                    runSpacing: 4,
                                    children: [
                                      Text(
                                        isHindi ? 'बेस्ट एम्पलीफायर' : 'RECOMMENDED AMPLIFIER',
                                        style: TextStyle(
                                          fontSize: 11,
                                          fontWeight: isHindi ? FontWeight.w600 : FontWeight.bold,
                                          letterSpacing: isHindi ? 0.0 : 0.8,
                                          color: Colors.white.withOpacity(0.85),
                                          fontFamilyFallback: AppTypography.hindiFontFallback,
                                        ),
                                      ),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                        decoration: BoxDecoration(
                                          color: Colors.white.withOpacity(0.2),
                                          borderRadius: BorderRadius.circular(12),
                                        ),
                                        child: Text(
                                          isHindi ? 'प्रति चैनल' : 'PER CHANNEL',
                                          style: TextStyle(
                                            fontSize: 9.5,
                                            fontWeight: isHindi ? FontWeight.w600 : FontWeight.bold,
                                            color: Colors.white,
                                            fontFamilyFallback: AppTypography.hindiFontFallback,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFF10B981),
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                    child: const Text(
                                      '1.5X HEADROOM',
                                      style: TextStyle(
                                        fontSize: 10.5,
                                        fontWeight: FontWeight.w900,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                ],
                              ),

                              const SizedBox(height: 12),

                              // Big Wattage Display
                              FittedBox(
                                fit: BoxFit.scaleDown,
                                alignment: Alignment.centerLeft,
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.baseline,
                                  textBaseline: TextBaseline.alphabetic,
                                  children: [
                                    Text(
                                      result.recommendedAmpPower.toInt().toString(),
                                      style: const TextStyle(
                                        fontSize: 48,
                                        fontWeight: FontWeight.w900,
                                        color: Colors.white,
                                        letterSpacing: -1.0,
                                        height: 1.0,
                                      ),
                                    ),
                                    const SizedBox(width: 6),
                                    const Text(
                                      'WATTS',
                                      style: TextStyle(
                                        fontSize: 22,
                                        fontWeight: FontWeight.w900,
                                        color: Color(0xFFFBBF24),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Text(
                                      isHindi ? 'RMS / चैनल' : 'RMS / Ch',
                                      style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white.withOpacity(0.85),
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              const SizedBox(height: 14),

                              // Explanatory Note Inside Hero Box
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.32),
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(color: Colors.white.withOpacity(0.12)),
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Icon(Icons.check_circle_rounded, color: Color(0xFF34D399), size: 20),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            isHindi ? 'बेस्ट एम्पलीफायर मैचिंग' : 'Optimal Top Cabinet Matching',
                                            style: TextStyle(
                                              fontSize: 12.5,
                                              fontWeight: isHindi ? FontWeight.w600 : FontWeight.bold,
                                              color: const Color(0xFF34D399),
                                              fontFamilyFallback: AppTypography.hindiFontFallback,
                                            ),
                                          ),
                                          const SizedBox(height: 2),
                                          Text(
                                            isHindi
                                                ? '${result.speakerCount}x ${result.speakerRms.toInt()}W टॉप्स (${result.totalRms.toInt()}W कुल RMS) के लिए ${result.recommendedAmpPower.toInt()}W एम्पलीफायर बेस्ट है। आवाज फटेगी नहीं और बेस व वोकल्स साफ रहेंगे।'
                                                : 'For ${result.speakerCount}x ${result.speakerRms.toInt()}W tops (${result.totalRms.toInt()}W Total RMS), a ${result.recommendedAmpPower.toInt()}W amplifier provides 1.5x dynamic headroom to avoid clipping and thermal distortion.',
                                            style: TextStyle(
                                              fontSize: 11,
                                              color: Colors.white.withOpacity(0.9),
                                              height: 1.35,
                                              fontFamilyFallback: AppTypography.hindiFontFallback,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 14),

                        // PARAMETER CHIPS MATRIX (Matching Cable Loss Screenshot 1)
                        Container(
                          padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(color: borderColorCard),
                          ),
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: _buildParamChip(
                                      icon: Icons.speaker_rounded,
                                      iconColor: const Color(0xFF2563EB),
                                      label: isHindi ? 'कैबिनेट स्पीकर्स' : 'Cabinet Drivers',
                                      value: '${result.speakerCount} × ${result.speakerRms.toInt()}W',
                                      isNight: isNight,
                                      textColor: textColor,
                                      subtextColor: subtitleColor,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: _buildParamChip(
                                      icon: Icons.bolt_rounded,
                                      iconColor: const Color(0xFFD97706),
                                      label: isHindi ? 'कुल सिस्टम RMS' : 'Total System RMS',
                                      value: '${result.totalRms.toInt()} Watts',
                                      isNight: isNight,
                                      textColor: textColor,
                                      subtextColor: subtitleColor,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 10),
                              Row(
                                children: [
                                  Expanded(
                                    child: _buildParamChip(
                                      icon: Icons.graphic_eq_rounded,
                                      iconColor: const Color(0xFF059669),
                                      label: isHindi ? 'प्रोग्राम पावर' : 'Program Power',
                                      value: '${result.totalProgram.toInt()} Watts',
                                      isNight: isNight,
                                      textColor: textColor,
                                      subtextColor: subtitleColor,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: _buildParamChip(
                                      icon: Icons.speed_rounded,
                                      iconColor: const Color(0xFFDC2626),
                                      label: isHindi ? 'पीक हैंडलिंग' : 'Peak Handling',
                                      value: '${result.totalPeak.toInt()} Watts',
                                      isNight: isNight,
                                      textColor: textColor,
                                      subtextColor: subtitleColor,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 16),

                        // CARD 1: POWER RATINGS BREAKDOWN (RMS, Program, Peak)
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(22),
                            border: Border.all(color: borderColorCard),
                            boxShadow: [
                              BoxShadow(
                                color: isNight ? Colors.black.withOpacity(0.3) : const Color(0x060F172A),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(
                                    Icons.equalizer_rounded,
                                    size: 17,
                                    color: isNight ? const Color(0xFF38BDF8) : const Color(0xFF2563EB),
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    (isHindi ? 'पावर रेटिंग्स विश्लेषण' : 'POWER RATINGS BREAKDOWN').toUpperCase(),
                                    style: TextStyle(
                                      fontSize: 11.5,
                                      fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                                      letterSpacing: isHindi ? 0.0 : 0.6,
                                      color: textColor,
                                      fontFamilyFallback: AppTypography.hindiFontFallback,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 14),

                              Row(
                                children: [
                                  Expanded(
                                    child: _buildPowerRatingTile(
                                      title: isHindi ? 'कंटीन्यूअस RMS' : 'Continuous RMS',
                                      value: '${result.totalRms.toInt()}W',
                                      formula: '1.0x RMS',
                                      badgeColor: const Color(0xFF2563EB),
                                      isNight: isNight,
                                      textColor: textColor,
                                      subtextColor: subtitleColor,
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: _buildPowerRatingTile(
                                      title: isHindi ? 'प्रोग्राम पावर' : 'Program Power',
                                      value: '${result.totalProgram.toInt()}W',
                                      formula: 'RMS × 2',
                                      badgeColor: const Color(0xFFD97706),
                                      isNight: isNight,
                                      textColor: textColor,
                                      subtextColor: subtitleColor,
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: _buildPowerRatingTile(
                                      title: isHindi ? 'पीक SPL पावर' : 'Peak Power',
                                      value: '${result.totalPeak.toInt()}W',
                                      formula: 'RMS × 4',
                                      badgeColor: const Color(0xFFDC2626),
                                      isNight: isNight,
                                      textColor: textColor,
                                      subtextColor: subtitleColor,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 16),

                        // CARD 2: AMPLIFIER SPECIFICATION & MATCHING CARD
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(22),
                            border: Border.all(color: borderColorCard),
                            boxShadow: [
                              BoxShadow(
                                color: isNight ? Colors.black.withOpacity(0.3) : const Color(0x060F172A),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(
                                    Icons.tune_rounded,
                                    size: 17,
                                    color: const Color(0xFF10B981),
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    (isHindi ? 'एम्पलीफायर मैचिंग और सेटअप' : 'AMPLIFIER MATCHING & SETUP').toUpperCase(),
                                    style: TextStyle(
                                      fontSize: 11.5,
                                      fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                                      letterSpacing: isHindi ? 0.0 : 0.6,
                                      color: textColor,
                                      fontFamilyFallback: AppTypography.hindiFontFallback,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),

                              _buildSummaryTile(
                                label: isHindi ? 'बेस्ट एम्पलीफायर पावर' : 'Recommended Amp Output',
                                value: '${result.recommendedAmpPower.toInt()} Watts RMS / Ch',
                                isHighlight: true,
                                isNight: isNight,
                              ),
                              const SizedBox(height: 8),
                              _buildSummaryTile(
                                label: isHindi ? 'हेडरूम मल्टीप्लायर' : 'Headroom Multiplier',
                                value: '1.5x (Safe Dynamic Peaks)',
                                isNight: isNight,
                              ),
                              const SizedBox(height: 8),
                              _buildSummaryTile(
                                label: isHindi ? 'एम्पलीफायर क्लास (टाइप)' : 'Recommended Amp Topology',
                                value: 'Class D / Class H Pro Power Amp',
                                isNight: isNight,
                              ),
                              const SizedBox(height: 8),
                              _buildSummaryTile(
                                label: isHindi ? 'क्रॉसओवर कट (HPF)' : 'Recommended HPF (Low Cut)',
                                value: '80 Hz – 100 Hz (24dB/oct)',
                                isNight: isNight,
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 16),

                        // CARD 3: RECOMMENDED SPEAKER CABLE SPECIFICATION CARD
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(22),
                            border: Border.all(color: borderColorCard),
                            boxShadow: [
                              BoxShadow(
                                color: isNight ? Colors.black.withOpacity(0.3) : const Color(0x060F172A),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(
                                    Icons.cable_rounded,
                                    size: 17,
                                    color: const Color(0xFFF59E0B),
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    (isHindi ? 'बेस्ट स्पीकर केबल' : 'RECOMMENDED SPEAKER CABLE').toUpperCase(),
                                    style: TextStyle(
                                      fontSize: 11.5,
                                      fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                                      letterSpacing: isHindi ? 0.0 : 0.6,
                                      color: textColor,
                                      fontFamilyFallback: AppTypography.hindiFontFallback,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),

                              _buildSummaryTile(
                                label: isHindi ? 'बेस्ट केबल साइज़' : 'Recommended Cable Gauge',
                                value: cableGauge,
                                isHighlight: true,
                                isNight: isNight,
                              ),
                              const SizedBox(height: 8),
                              _buildSummaryTile(
                                label: isHindi ? 'तार मटीरियल' : 'Conductor Material',
                                value: 'OFC Pure Copper (Oxygen-Free)',
                                isNight: isNight,
                              ),
                              const SizedBox(height: 8),
                              _buildSummaryTile(
                                label: isHindi ? 'कनेक्टर टाइप' : 'Connector Type',
                                value: 'Neutrik NL4 Speakon (Pin 1+/1-)',
                                isNight: isNight,
                              ),
                              const SizedBox(height: 8),
                              _buildSummaryTile(
                                label: isHindi ? 'अधिकतम सेफ दूरी' : 'Max Recommended Run',
                                value: '25 – 30 Meters (Damping Factor > 100)',
                                isNight: isNight,
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 16),

                        // CARD 4: SYSTEM SPECIFICATION SUMMARY (Matching Screenshot 2)
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(22),
                            border: Border.all(color: borderColorCard),
                            boxShadow: [
                              BoxShadow(
                                color: isNight ? Colors.black.withOpacity(0.3) : const Color(0x060F172A),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Icon(
                                    Icons.analytics_rounded,
                                    size: 17,
                                    color: isNight ? const Color(0xFF38BDF8) : const Color(0xFF2563EB),
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    (isHindi ? 'सिस्टम डिटेल्स' : 'SYSTEM SUMMARY').toUpperCase(),
                                    style: TextStyle(
                                      fontSize: 11.5,
                                      fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                                      letterSpacing: isHindi ? 0.0 : 0.6,
                                      color: textColor,
                                      fontFamilyFallback: AppTypography.hindiFontFallback,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),

                              _buildSummaryTile(
                                label: isHindi ? 'कुल स्पीकर्स' : 'Total Speakers',
                                value: '${result.speakerCount} Speaker${result.speakerCount > 1 ? 's' : ''}',
                                isNight: isNight,
                              ),
                              const SizedBox(height: 8),
                              _buildSummaryTile(
                                label: isHindi ? 'हर स्पीकर का RMS' : 'Individual Speaker RMS',
                                value: '${result.speakerRms.toInt()} Watts',
                                isNight: isNight,
                              ),
                              const SizedBox(height: 8),
                              _buildSummaryTile(
                                label: isHindi ? 'कुल सिस्टम RMS' : 'Total System RMS',
                                value: '${result.totalRms.toInt()} Watts Total',
                                isHighlight: true,
                                isNight: isNight,
                              ),
                              const SizedBox(height: 8),
                              _buildSummaryTile(
                                label: isHindi ? 'प्रोग्राम (म्यूज़िक) पावर' : 'Program (Music) Power',
                                value: '${result.totalProgram.toInt()} Watts',
                                isNight: isNight,
                              ),
                              const SizedBox(height: 8),
                              _buildSummaryTile(
                                label: isHindi ? 'पीक पावर (Peak)' : 'Peak Power Capacity',
                                value: '${result.totalPeak.toInt()} Watts',
                                isNight: isNight,
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 16),

                        // Google AdMob Banner Centered directly below result cards
                        const Center(
                          child: AdBannerWidget(placement: 'top_speaker_result'),
                        ),

                        const SizedBox(height: 16),

                        // Share Action Button
                        ShareResultButton(
                          title: isHindi ? 'डिटेल्स शेयर करें' : 'SHARE SPEAKER SPECIFICATION',
                          shareText: _generateShareText(isHindi),
                        ),
                        const SizedBox(height: 14),

                        // Modify Inputs (Gold Button matching Ohm & Amp screens)
                        InkWell(
                          onTap: () => Navigator.pop(context),
                          borderRadius: BorderRadius.circular(22),
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFBBF24),
                              borderRadius: BorderRadius.circular(22),
                              border: Border.all(color: const Color(0xFFF59E0B)),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFFF59E0B).withOpacity(0.35),
                                  blurRadius: 10,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.tune_rounded, size: 20, color: Color(0xFF0F172A)),
                                const SizedBox(width: 8),
                                Text(
                                  isHindi ? 'इनपुट बदलें' : 'MODIFY INPUTS',
                                  style: TextStyle(
                                    fontSize: 13,
                                    fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                                    color: const Color(0xFF0F172A),
                                    letterSpacing: isHindi ? 0.2 : 0.5,
                                    fontFamilyFallback: AppTypography.hindiFontFallback,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildParamChip({
    required IconData icon,
    required Color iconColor,
    required String label,
    required String value,
    required bool isNight,
    required Color textColor,
    required Color subtextColor,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: isNight ? const Color(0xFF0F172A).withOpacity(0.6) : const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0),
          width: 0.8,
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(5),
            decoration: BoxDecoration(
              color: iconColor.withOpacity(isNight ? 0.2 : 0.12),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, size: 14, color: iconColor),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 9.5,
                    fontWeight: FontWeight.w600,
                    color: subtextColor,
                    fontFamilyFallback: AppTypography.hindiFontFallback,
                  ),
                ),
                const SizedBox(height: 1),
                Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w800,
                    color: textColor,
                    letterSpacing: -0.2,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPowerRatingTile({
    required String title,
    required String value,
    required String formula,
    required Color badgeColor,
    required bool isNight,
    required Color textColor,
    required Color subtextColor,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
      decoration: BoxDecoration(
        color: isNight ? const Color(0xFF0F172A).withOpacity(0.5) : const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: badgeColor.withOpacity(0.12),
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              formula,
              style: TextStyle(
                fontSize: 9,
                fontWeight: FontWeight.w800,
                color: badgeColor,
              ),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w900,
              color: textColor,
              letterSpacing: -0.3,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            title,
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 9.5,
              fontWeight: FontWeight.w600,
              color: subtextColor,
              fontFamilyFallback: AppTypography.hindiFontFallback,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryTile({
    required String label,
    required String value,
    required bool isNight,
    bool isHighlight = false,
  }) {
    final textColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final subtextColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);
    final tileBg = isHighlight
        ? (isNight ? const Color(0xFF1E3A8A).withOpacity(0.25) : const Color(0xFFEFF6FF))
        : (isNight ? const Color(0xFF0F172A).withOpacity(0.5) : const Color(0xFFF8FAFC));
    final borderColor = isHighlight
        ? (isNight ? const Color(0xFF38BDF8).withOpacity(0.3) : const Color(0xFFBFDBFE))
        : (isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0));
    final valueColor = isHighlight
        ? (isNight ? const Color(0xFF38BDF8) : const Color(0xFF1D4ED8))
        : textColor;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: tileBg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: borderColor, width: 0.8),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: subtextColor,
                fontFamilyFallback: AppTypography.hindiFontFallback,
              ),
            ),
          ),
          const SizedBox(width: 8),
          Text(
            value,
            style: TextStyle(
              fontSize: 12.5,
              fontWeight: FontWeight.w800,
              color: valueColor,
            ),
          ),
        ],
      ),
    );
  }
}
