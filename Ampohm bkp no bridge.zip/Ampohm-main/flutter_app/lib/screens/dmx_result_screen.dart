import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/preference_service.dart';
import '../localization/app_localizations.dart';
import '../models/models.dart';
import '../widgets/calculator_hero_header.dart';
import '../widgets/share_result_button.dart';
import '../widgets/ad_banner_widget.dart';
import '../utils/app_typography.dart';

class DmxResultScreen extends StatefulWidget {
  final DmxResult result;

  const DmxResultScreen({
    super.key,
    required this.result,
  });

  @override
  State<DmxResultScreen> createState() => _DmxResultScreenState();
}

class _DmxResultScreenState extends State<DmxResultScreen> {
  final Set<int> _addressedFixtures = {};
  String _filterMode = 'all'; // 'all', 'pending', 'done'
  bool _isFixturesExpanded = false;
  final ScrollController _mainScrollController = ScrollController();
  final ScrollController _fixturesScrollController = ScrollController();

  @override
  void dispose() {
    _mainScrollController.dispose();
    _fixturesScrollController.dispose();
    super.dispose();
  }

  void _scrollToTop() {
    if (_mainScrollController.hasClients) {
      _mainScrollController.animateTo(
        0,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  String _generateShareText() {
    final result = widget.result;
    final patchList = result.subsequentFixtures.map((f) {
      final isDone = _addressedFixtures.contains(f.fixtureNumber);
      return '• Fixture #${f.fixtureNumber}: Channels ${f.rangeString}${isDone ? " [DONE]" : ""}';
    }).join('\n');
    return '''
==============================
AMP OHM - DMX 512 ADDRESS PATCH
==============================
Primary Fixture #1:
• Start Address: ${result.startAddress}
• Footprint: ${result.channelCount} Channels (Span: ${result.startAddress} - ${result.endAddress})

Subsequent Fixture Patch Plan (${_addressedFixtures.length}/${result.subsequentFixtures.length} Set):
$patchList

Calculated with AMP OHM - Developed by AudioXpert
━━━━━━━━━━━━━━━━━━
📱 AMP OHM App:
https://play.google.com/store/apps/details?id=com.ampohm.app

📸 Instagram:
https://instagram.com/audio_xpert

▶️ YouTube:
https://youtube.com/@audioxpertt
==============================''';
  }

  @override
  Widget build(BuildContext context) {
    final result = widget.result;
    final t = AppLocalizations.of(context);
    final isHindi = Localizations.localeOf(context).languageCode == 'hi';

    final prefService = Provider.of<PreferenceService>(context);
    final isNight = prefService.isNightMode;

    final bgColor = isNight ? const Color(0xFF070B14) : const Color(0xFFF1F5F9);
    final sheetBg = isNight ? const Color(0xFF0E1526) : Colors.white;
    final cardBg = isNight ? const Color(0xFF141C30) : Colors.white;
    final headerCardBg = isNight ? const Color(0xFF0F172A) : const Color(0xFFF8FAFC);
    final itemCardBg = isNight ? const Color(0xFF0A0F1D) : const Color(0xFFF8FAFC);
    final itemDoneBg = isNight ? const Color(0xFF064E3B).withOpacity(0.4) : const Color(0xFFF0FDF4);
    final itemDoneBorder = isNight ? const Color(0xFF059669) : const Color(0xFF86EFAC);
    final borderColorCard = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final textColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final subtitleColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    return Scaffold(
      backgroundColor: bgColor,
      body: SafeArea(
        child: Column(
          children: [
            // 1. Curved Hero Header matching Web
            CalculatorHeroHeader(
              title: t.dmxResultTitle,
              subtitle: isHindi
                  ? 'DMX एड्रेस, चैनल फुटप्रिंट व फिक्सचर पैच'
                  : 'DMX 512 start address & sequential fixture patch',
              onBack: () => Navigator.pop(context),
            ),

            // 2. Curved Sheet for Results
            Expanded(
              child: Transform.translate(
                offset: const Offset(0, -20),
                child: Container(
                  decoration: BoxDecoration(
                    color: sheetBg,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: isNight ? Colors.black.withOpacity(0.5) : const Color(0x140F172A),
                        blurRadius: 20,
                        offset: const Offset(0, -6),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    child: ListView(
                      controller: _mainScrollController,
                      padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
                      children: [
                        // Card 1: DMX Start Address Hero Card (Dark Navy & Royal Blue Gradient)
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [Color(0xFF0F172A), Color(0xFF1E3A8A), Color(0xFF172554)],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(28),
                            border: Border.all(color: const Color(0xFF3B82F6).withOpacity(0.5), width: 1.5),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.25),
                                blurRadius: 16,
                                offset: const Offset(0, 6),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Wrap(
                                alignment: WrapAlignment.spaceBetween,
                                crossAxisAlignment: WrapCrossAlignment.center,
                                spacing: 8,
                                runSpacing: 6,
                                children: [
                                  Text(
                                    t.dmxCardCurrentAddress.toUpperCase(),
                                    style: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 0.8,
                                      color: Colors.white.withOpacity(0.8),
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFFBBF24),
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                    child: Text(
                                      '${result.channelCount} CHANNELS',
                                      style: const TextStyle(
                                        fontSize: 10.5,
                                        fontWeight: FontWeight.w900,
                                        color: Color(0xFF0F172A),
                                      ),
                                    ),
                                  ),
                                ],
                              ),

                              const SizedBox(height: 12),

                              // Big DMX Address Display
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.baseline,
                                textBaseline: TextBaseline.alphabetic,
                                children: [
                                  Text(
                                    '${result.currentAddress}',
                                    style: const TextStyle(
                                      fontSize: 48,
                                      fontWeight: FontWeight.w900,
                                      color: Colors.white,
                                      letterSpacing: -1.0,
                                      height: 1.0,
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  const Text(
                                    'DMX',
                                    style: TextStyle(
                                      fontSize: 22,
                                      fontWeight: FontWeight.w900,
                                      color: Color(0xFFFBBF24),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Flexible(
                                    child: Text(
                                      '(${result.addressRange})',
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white.withOpacity(0.85),
                                      ),
                                    ),
                                  ),
                                ],
                              ),

                              const SizedBox(height: 12),

                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                decoration: BoxDecoration(
                                  color: Colors.black.withOpacity(0.3),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      isHindi ? 'अगला फिक्स्चर एड्रेस:' : 'Next Fixture Starts At:',
                                      style: TextStyle(fontSize: 11.5, color: Colors.white.withOpacity(0.8)),
                                    ),
                                    Text(
                                      result.nextFixtureAddress > 512
                                          ? (isHindi ? 'यूनिवर्स समाप्त (>512)' : 'Universe Full (>512)')
                                          : 'DMX ${result.nextFixtureAddress}',
                                      style: TextStyle(
                                        fontSize: 12.5,
                                        fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                                        color: const Color(0xFF67E8F9),
                                        fontFamilyFallback: AppTypography.hindiFontFallback,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 14),

                        // Google AdMob Banner Centered directly below colored DMX result box
                        const Center(
                          child: AdBannerWidget(placement: 'dmx_result'),
                        ),

                        const SizedBox(height: 16),

                        // Card 2: Sequential DMX Fixtures Patch List & Field Checklist
                        Builder(
                          builder: (context) {
                            final totalFixtures = result.subsequentFixtures.length;
                            final addressedCount = _addressedFixtures.length;
                            final pendingCount = (totalFixtures - addressedCount).clamp(0, totalFixtures);
                            final isAllDone = addressedCount == totalFixtures && totalFixtures > 0;

                            final filteredFixtures = result.subsequentFixtures.where((f) {
                              if (_filterMode == 'pending') {
                                return !_addressedFixtures.contains(f.fixtureNumber);
                              }
                              if (_filterMode == 'done') {
                                return _addressedFixtures.contains(f.fixtureNumber);
                              }
                              return true;
                            }).toList();

                            return Container(
                              decoration: BoxDecoration(
                                color: cardBg,
                                borderRadius: BorderRadius.circular(24),
                                border: Border.all(color: borderColorCard),
                                boxShadow: [
                                  BoxShadow(
                                    color: isNight ? Colors.black.withOpacity(0.3) : const Color(0x080F172A),
                                    blurRadius: 10,
                                    offset: const Offset(0, 2),
                                  ),
                                ],
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // 1. Header with Title, Progress Badge and Actions (Select All, Reset)
                                  Container(
                                    padding: const EdgeInsets.all(14),
                                    decoration: BoxDecoration(
                                      color: headerCardBg,
                                      borderRadius: const BorderRadius.only(
                                        topLeft: Radius.circular(24),
                                        topRight: Radius.circular(24),
                                      ),
                                      border: Border(
                                        bottom: BorderSide(color: borderColorCard),
                                      ),
                                    ),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          children: [
                                            Container(
                                              width: 32,
                                              height: 32,
                                              decoration: BoxDecoration(
                                                color: isNight ? const Color(0xFF1E293B) : const Color(0xFFEFF6FF),
                                                borderRadius: BorderRadius.circular(10),
                                              ),
                                              child: Center(
                                                child: Icon(
                                                  Icons.layers_rounded,
                                                  size: 18,
                                                  color: isNight ? const Color(0xFF38BDF8) : const Color(0xFF2563EB),
                                                ),
                                              ),
                                            ),
                                            const SizedBox(width: 10),
                                            Expanded(
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    isHindi ? 'सीक्वेंशियल DMX एड्रेस' : 'SEQUENTIAL DMX ADDRESSES',
                                                    style: TextStyle(
                                                      fontSize: 12.5,
                                                      fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                                                      letterSpacing: isHindi ? 0.0 : 0.5,
                                                      color: textColor,
                                                      fontFamilyFallback: AppTypography.hindiFontFallback,
                                                    ),
                                                  ),
                                                  Text(
                                                    '${result.channelCount} CH / ${isHindi ? "फिक्स्चर" : "Fixture"} • $totalFixtures ${isHindi ? "कुल" : "Total"}${_isFixturesExpanded ? "" : " • ↕ ${isHindi ? "स्क्रॉल" : "Scroll"}"}',
                                                    style: TextStyle(
                                                      fontSize: 11,
                                                      fontWeight: FontWeight.w600,
                                                      color: subtitleColor,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            const SizedBox(width: 8),

                                            // Progress Pill
                                            Container(
                                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                              decoration: BoxDecoration(
                                                color: isAllDone
                                                    ? const Color(0xFF059669)
                                                    : addressedCount > 0
                                                        ? const Color(0xFFD1FAE5)
                                                        : const Color(0xFFF1F5F9),
                                                borderRadius: BorderRadius.circular(12),
                                              ),
                                              child: Row(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  Icon(
                                                    isAllDone ? Icons.check_circle_rounded : Icons.check_rounded,
                                                    size: 13,
                                                    color: isAllDone
                                                        ? Colors.white
                                                        : addressedCount > 0
                                                            ? const Color(0xFF065F46)
                                                            : const Color(0xFF64748B),
                                                  ),
                                                  const SizedBox(width: 4),
                                                  Text(
                                                    '$addressedCount/$totalFixtures ${isHindi ? "सेट" : "Done"}',
                                                    style: TextStyle(
                                                      fontSize: 10.5,
                                                      fontWeight: FontWeight.w800,
                                                      fontFamily: 'monospace',
                                                      color: isAllDone
                                                          ? Colors.white
                                                          : addressedCount > 0
                                                              ? const Color(0xFF065F46)
                                                              : const Color(0xFF475569),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),

                                        const SizedBox(height: 10),

                                        // Progress Bar
                                        ClipRRect(
                                          borderRadius: BorderRadius.circular(4),
                                          child: LinearProgressIndicator(
                                            value: totalFixtures > 0 ? (addressedCount / totalFixtures) : 0,
                                            minHeight: 5,
                                            backgroundColor: const Color(0xFFE2E8F0),
                                            valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF10B981)),
                                          ),
                                        ),

                                        const SizedBox(height: 8),

                                        // Field helper text & Quick action buttons
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Expanded(
                                              child: Text(
                                                isAllDone
                                                    ? (isHindi ? '✓ सभी फिक्स्चर सेट हो चुके हैं!' : '✓ All fixtures configured!')
                                                    : (addressedCount == 0
                                                        ? (isHindi ? 'फिक्स्चर पर टैप करके पूरा (✓) मार्क करें' : 'Tap fixture to mark done (✓)')
                                                        : (isHindi ? '$addressedCount सेट • $pendingCount बाकी' : '$addressedCount Set • $pendingCount Remaining')),
                                                style: TextStyle(
                                                  fontSize: 11,
                                                  fontWeight: isAllDone ? FontWeight.bold : FontWeight.w600,
                                                  color: isAllDone ? const Color(0xFF059669) : const Color(0xFF64748B),
                                                ),
                                              ),
                                            ),
                                            Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                if (addressedCount < totalFixtures)
                                                  InkWell(
                                                    onTap: () {
                                                      setState(() {
                                                        _addressedFixtures.addAll(
                                                          result.subsequentFixtures.map((f) => f.fixtureNumber),
                                                        );
                                                      });
                                                    },
                                                    borderRadius: BorderRadius.circular(6),
                                                    child: Padding(
                                                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                                      child: Row(
                                                        children: [
                                                          const Icon(Icons.done_all_rounded, size: 13, color: Color(0xFF2563EB)),
                                                          const SizedBox(width: 3),
                                                          Text(
                                                            isHindi ? 'सब चुनें' : 'All',
                                                            style: const TextStyle(
                                                              fontSize: 10.5,
                                                              fontWeight: FontWeight.bold,
                                                              color: Color(0xFF2563EB),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                if (addressedCount > 0) ...[
                                                  const SizedBox(width: 6),
                                                  InkWell(
                                                    onTap: () {
                                                      setState(() {
                                                        _addressedFixtures.clear();
                                                      });
                                                    },
                                                    borderRadius: BorderRadius.circular(6),
                                                    child: Padding(
                                                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                                      child: Row(
                                                        children: [
                                                          const Icon(Icons.refresh_rounded, size: 13, color: Color(0xFF64748B)),
                                                          const SizedBox(width: 3),
                                                          Text(
                                                            isHindi ? 'रीसेट' : 'Reset',
                                                            style: const TextStyle(
                                                              fontSize: 10.5,
                                                              fontWeight: FontWeight.bold,
                                                              color: Color(0xFF64748B),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                                if (totalFixtures > 3) ...[
                                                  const SizedBox(width: 6),
                                                  InkWell(
                                                    onTap: () {
                                                      setState(() {
                                                        _isFixturesExpanded = !_isFixturesExpanded;
                                                      });
                                                    },
                                                    borderRadius: BorderRadius.circular(6),
                                                    child: Padding(
                                                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                                      child: Row(
                                                        children: [
                                                          Icon(
                                                            _isFixturesExpanded ? Icons.unfold_less_rounded : Icons.unfold_more_rounded,
                                                            size: 13,
                                                            color: const Color(0xFF7C3AED),
                                                          ),
                                                          const SizedBox(width: 3),
                                                          Text(
                                                            _isFixturesExpanded
                                                                ? (isHindi ? 'कम दिखाएं' : 'Collapse')
                                                                : (isHindi ? 'पूरा देखें' : 'Expand'),
                                                            style: const TextStyle(
                                                              fontSize: 10.5,
                                                              fontWeight: FontWeight.bold,
                                                              color: Color(0xFF7C3AED),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ],
                                            ),
                                          ],
                                        ),

                                        // Optional Filter tabs when fixtures > 4
                                        if (totalFixtures > 4) ...[
                                          const SizedBox(height: 8),
                                          Row(
                                            children: [
                                              _buildFilterChip(
                                                label: isHindi ? 'सब ($totalFixtures)' : 'All ($totalFixtures)',
                                                isSelected: _filterMode == 'all',
                                                selectedColor: const Color(0xFF2563EB),
                                                onTap: () {
                                                  setState(() => _filterMode = 'all');
                                                  if (_fixturesScrollController.hasClients) {
                                                    _fixturesScrollController.jumpTo(0);
                                                  }
                                                },
                                              ),
                                              const SizedBox(width: 6),
                                              _buildFilterChip(
                                                label: isHindi ? 'बाकी ($pendingCount)' : 'Pending ($pendingCount)',
                                                isSelected: _filterMode == 'pending',
                                                selectedColor: const Color(0xFFD97706),
                                                onTap: () {
                                                  setState(() => _filterMode = 'pending');
                                                  if (_fixturesScrollController.hasClients) {
                                                    _fixturesScrollController.jumpTo(0);
                                                  }
                                                },
                                              ),
                                              const SizedBox(width: 6),
                                              _buildFilterChip(
                                                label: isHindi ? 'हो गए ($addressedCount)' : 'Done ($addressedCount)',
                                                isSelected: _filterMode == 'done',
                                                selectedColor: const Color(0xFF059669),
                                                onTap: () {
                                                  setState(() => _filterMode = 'done');
                                                  if (_fixturesScrollController.hasClients) {
                                                    _fixturesScrollController.jumpTo(0);
                                                  }
                                                },
                                              ),
                                            ],
                                          ),
                                        ],
                                      ],
                                    ),
                                  ),

                                  // 2. SCROLLABLE FIXTURE LIST WITH BOUNDARY OVERSCROLL DELEGATION TO HOME/PARENT
                                  Container(
                                    constraints: _isFixturesExpanded
                                        ? const BoxConstraints()
                                        : const BoxConstraints(maxHeight: 330),
                                    child: filteredFixtures.isEmpty
                                        ? Padding(
                                            padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
                                            child: Center(
                                              child: Text(
                                                _filterMode == 'pending'
                                                    ? (isHindi ? 'कोई फिक्स्चर बाकी नहीं है! सभी सेट हो चुके हैं।' : 'No pending fixtures! All configured.')
                                                    : (isHindi ? 'अभी कोई फिक्स्चर सेट नहीं हुआ है।' : 'No completed fixtures yet.'),
                                                textAlign: TextAlign.center,
                                                style: const TextStyle(fontSize: 12, color: Color(0xFF94A3B8)),
                                              ),
                                            ),
                                          )
                                        : NotificationListener<ScrollNotification>(
                                            onNotification: (ScrollNotification notification) {
                                              // Only forward scroll when inner list reaches top/bottom boundaries
                                              if (notification.depth == 0) {
                                                if (notification is OverscrollNotification) {
                                                  if (_mainScrollController.hasClients) {
                                                    final double delta = notification.overscroll;
                                                    final double current = _mainScrollController.offset;
                                                    final double target = (current + delta).clamp(
                                                      0.0,
                                                      _mainScrollController.position.maxScrollExtent,
                                                    );
                                                    if (target != current) {
                                                      _mainScrollController.jumpTo(target);
                                                    }
                                                  }
                                                }
                                              }
                                              return false;
                                            },
                                            child: RawScrollbar(
                                              controller: _fixturesScrollController,
                                              thumbVisibility: !_isFixturesExpanded && filteredFixtures.length > 3,
                                              radius: const Radius.circular(8),
                                              thickness: 4,
                                              thumbColor: isNight ? const Color(0xFF475569) : const Color(0xFF94A3B8),
                                              child: ListView.builder(
                                                controller: _fixturesScrollController,
                                                shrinkWrap: _isFixturesExpanded,
                                                physics: _isFixturesExpanded
                                                    ? const NeverScrollableScrollPhysics()
                                                    : const AlwaysScrollableScrollPhysics(
                                                        parent: ClampingScrollPhysics(),
                                                      ),
                                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                                                itemCount: filteredFixtures.length,
                                                itemBuilder: (context, index) {
                                                final fixture = filteredFixtures[index];
                                                final isDone = _addressedFixtures.contains(fixture.fixtureNumber);

                                                return InkWell(
                                                  key: ValueKey('fixture-${fixture.fixtureNumber}'),
                                                  onTap: () {
                                                    setState(() {
                                                      if (isDone) {
                                                        _addressedFixtures.remove(fixture.fixtureNumber);
                                                      } else {
                                                        _addressedFixtures.add(fixture.fixtureNumber);
                                                      }
                                                    });
                                                  },
                                                  borderRadius: BorderRadius.circular(14),
                                                  child: AnimatedContainer(
                                                    duration: const Duration(milliseconds: 180),
                                                    padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 10),
                                                    margin: const EdgeInsets.only(bottom: 6),
                                                    decoration: BoxDecoration(
                                                      color: isDone ? itemDoneBg : itemCardBg,
                                                      borderRadius: BorderRadius.circular(14),
                                                      border: Border.all(
                                                        color: isDone ? itemDoneBorder : borderColorCard,
                                                        width: isDone ? 1.5 : 1.0,
                                                      ),
                                                    ),
                                                    child: Row(
                                                      children: [
                                                        // Tactile Checkbox Box
                                                        Container(
                                                          width: 24,
                                                          height: 24,
                                                          decoration: BoxDecoration(
                                                            color: isDone ? const Color(0xFF059669) : (isNight ? const Color(0xFF1E293B) : Colors.white),
                                                            borderRadius: BorderRadius.circular(7),
                                                            border: Border.all(
                                                              color: isDone ? const Color(0xFF059669) : (isNight ? const Color(0xFF475569) : const Color(0xFFCBD5E1)),
                                                              width: 1.5,
                                                            ),
                                                          ),
                                                          child: isDone
                                                              ? const Center(
                                                                  child: Icon(Icons.check_rounded, size: 16, color: Colors.white),
                                                                )
                                                              : null,
                                                        ),
                                                        const SizedBox(width: 8),

                                                        // Fixture Number Badge
                                                        Container(
                                                          width: 26,
                                                          height: 26,
                                                          decoration: BoxDecoration(
                                                            color: isDone 
                                                                ? (isNight ? const Color(0xFF065F46) : const Color(0xFFDCFCE7))
                                                                : (isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0)),
                                                            borderRadius: BorderRadius.circular(8),
                                                          ),
                                                          child: Center(
                                                            child: Text(
                                                              '#${fixture.fixtureNumber}',
                                                              style: TextStyle(
                                                                fontSize: 10,
                                                                fontWeight: FontWeight.w900,
                                                                color: isDone 
                                                                    ? (isNight ? const Color(0xFF6EE7B7) : const Color(0xFF166534))
                                                                    : (isNight ? const Color(0xFF94A3B8) : const Color(0xFF475569)),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        const SizedBox(width: 10),

                                                        // Fixture Label and Channels
                                                        Expanded(
                                                          child: Column(
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              Row(
                                                                children: [
                                                                  Expanded(
                                                                    child: Text(
                                                                      'Fixture #${fixture.fixtureNumber}',
                                                                      overflow: TextOverflow.ellipsis,
                                                                      style: TextStyle(
                                                                        fontSize: 12.5,
                                                                        fontWeight: isDone ? FontWeight.w800 : FontWeight.w700,
                                                                        color: isDone 
                                                                            ? (isNight ? const Color(0xFF6EE7B7) : const Color(0xFF166534))
                                                                            : textColor,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  if (isDone)
                                                                    Container(
                                                                      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5),
                                                                      decoration: BoxDecoration(
                                                                        color: const Color(0xFF059669),
                                                                        borderRadius: BorderRadius.circular(6),
                                                                      ),
                                                                      child: Text(
                                                                        '✓ ${isHindi ? "सेट" : "Done"}',
                                                                        style: const TextStyle(
                                                                          fontSize: 9,
                                                                          fontWeight: FontWeight.w900,
                                                                          color: Colors.white,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                ],
                                                              ),
                                                              const SizedBox(height: 2),
                                                              Text(
                                                                'CH ${fixture.rangeString} (${result.channelCount} CH)',
                                                                style: TextStyle(
                                                                  fontSize: 11,
                                                                  fontFamily: 'monospace',
                                                                  color: isDone 
                                                                      ? (isNight ? const Color(0xFF34D399) : const Color(0xFF15803D))
                                                                      : subtitleColor,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        const SizedBox(width: 8),

                                                        const Text('→', style: TextStyle(fontSize: 12, color: Color(0xFF94A3B8))),
                                                        const SizedBox(width: 6),

                                                        // Start Address Chip
                                                        Container(
                                                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                                          decoration: BoxDecoration(
                                                            color: isDone ? const Color(0xFFDCFCE7) : Colors.white,
                                                            borderRadius: BorderRadius.circular(10),
                                                            border: Border.all(
                                                              color: isDone ? const Color(0xFF86EFAC) : const Color(0xFFCBD5E1),
                                                            ),
                                                          ),
                                                          child: Text(
                                                            fixture.startAddress.toString().padLeft(3, '0'),
                                                            style: TextStyle(
                                                              fontSize: 13,
                                                              fontWeight: FontWeight.w900,
                                                              fontFamily: 'monospace',
                                                              color: isDone ? const Color(0xFF166534) : const Color(0xFF0F172A),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                );
                                              },
                                            ),
                                          ),
                                        ),
                                  ),

                                  // 3. Card Footer: Next Available Slot
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                                    decoration: const BoxDecoration(
                                      color: Color(0xFFF8FAFC),
                                      borderRadius: BorderRadius.only(
                                        bottomLeft: Radius.circular(24),
                                        bottomRight: Radius.circular(24),
                                      ),
                                      border: Border(
                                        top: BorderSide(color: Color(0xFFE2E8F0)),
                                      ),
                                    ),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Expanded(
                                          child: Row(
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              Text(
                                                isHindi ? 'अगला खाली एड्रेस:' : 'Next Slot:',
                                                style: const TextStyle(
                                                  fontSize: 11,
                                                  fontWeight: FontWeight.w700,
                                                  color: Color(0xFF64748B),
                                                ),
                                              ),
                                              const SizedBox(width: 5),
                                              Flexible(
                                                child: Text(
                                                  'DMX ${result.nextFixtureAddress.toString().padLeft(3, '0')}',
                                                  overflow: TextOverflow.ellipsis,
                                                  style: const TextStyle(
                                                    fontSize: 12,
                                                    fontWeight: FontWeight.w900,
                                                    fontFamily: 'monospace',
                                                    color: Color(0xFFD97706),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        const SizedBox(width: 8),
                                        // Scroll to Top Button
                                        InkWell(
                                          onTap: _scrollToTop,
                                          borderRadius: BorderRadius.circular(8),
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                            decoration: BoxDecoration(
                                              color: const Color(0xFFF59E0B),
                                              borderRadius: BorderRadius.circular(8),
                                              boxShadow: const [
                                                BoxShadow(
                                                  color: Color(0x22F59E0B),
                                                  blurRadius: 4,
                                                  offset: Offset(0, 1),
                                                ),
                                              ],
                                            ),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Text(
                                                  isHindi ? 'ऊपर' : 'Top',
                                                  style: TextStyle(
                                                    fontSize: 10.5,
                                                    fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                                                    color: const Color(0xFF0F172A),
                                                    fontFamilyFallback: AppTypography.hindiFontFallback,
                                                  ),
                                                ),
                                                const SizedBox(width: 4),
                                                const Icon(Icons.arrow_upward_rounded, size: 13, color: Color(0xFF0F172A)),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),

                        const SizedBox(height: 16),

                        // Share / Clipboard Action Button
                        ShareResultButton(
                          title: isHindi ? 'DMX पैच कॉपी करें' : 'SHARE DMX PATCH SHEET',
                          shareText: _generateShareText(),
                        ),

                        const SizedBox(height: 16),

                        // Modify Inputs Button (Gold button)
                        InkWell(
                          onTap: () => Navigator.pop(context),
                          borderRadius: BorderRadius.circular(22),
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFBBF24),
                              borderRadius: BorderRadius.circular(22),
                              border: Border.all(color: const Color(0xFFF59E0B)),
                              boxShadow: [
                                BoxShadow(
                                  color: const Color(0xFFF59E0B).withOpacity(0.35),
                                  blurRadius: 10,
                                  offset: const Offset(0, 4),
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.tune_rounded, size: 20, color: Color(0xFF0F172A)),
                                const SizedBox(width: 8),
                                Text(
                                  isHindi ? 'इनपुट बदलें' : 'MODIFY INPUTS',
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                                    letterSpacing: isHindi ? 0.2 : 0.5,
                                    color: const Color(0xFF0F172A),
                                    fontFamilyFallback: AppTypography.hindiFontFallback,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChip({
    required String label,
    required bool isSelected,
    required Color selectedColor,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3.5),
        decoration: BoxDecoration(
          color: isSelected ? selectedColor : const Color(0xFFF1F5F9),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 10.5,
            fontWeight: FontWeight.w700,
            color: isSelected ? Colors.white : const Color(0xFF475569),
          ),
        ),
      ),
    );
  }
}
