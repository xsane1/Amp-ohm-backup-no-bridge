import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../services/preference_service.dart';
import '../services/mail_service.dart';
import '../widgets/calculator_hero_header.dart';

class ContactScreen extends StatelessWidget {
  const ContactScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final prefService = Provider.of<PreferenceService>(context);
    final isNight = prefService.isNightMode;
    final scaffoldBg = isNight ? const Color(0xFF0B111C) : const Color(0xFFF1F5F9);
    final sheetBg = isNight ? const Color(0xFF0F172A) : Colors.white;
    final sectionTitleColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    return Scaffold(
      backgroundColor: scaffoldBg,
      body: SafeArea(
        child: Column(
          children: [
            // Hero Header
            CalculatorHeroHeader(
              title: 'Contact & Tech Feedback',
              subtitle: 'Email, support & sound community',
              onBack: () => Navigator.pop(context),
            ),

            // Curved Sheet
            Expanded(
              child: Transform.translate(
                offset: const Offset(0, -20),
                child: Container(
                  decoration: BoxDecoration(
                    color: sheetBg,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: isNight ? Colors.black.withOpacity(0.4) : const Color(0x140F172A),
                        blurRadius: 20,
                        offset: const Offset(0, -6),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(16, 24, 16, 32),
                      children: [
                        // Direct Support Items
                        _buildContactCard(
                          context: context,
                          isNight: isNight,
                          icon: Icons.mail_outline_rounded,
                          title: 'Official Email & Feedback',
                          subtitle: 'audioxpert123@gmail.com',
                        ),
                        const SizedBox(height: 12),

                        _buildContactCard(
                          context: context,
                          isNight: isNight,
                          icon: Icons.shop_two_outlined,
                          title: 'Google Play Store',
                          subtitle: 'https://play.google.com/store/apps/details?id=com.ampohm.app',
                        ),
                        const SizedBox(height: 24),

                        // Community & Social
                        Text(
                          'OFFICIAL COMMUNITY & CHANNELS',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                            color: sectionTitleColor,
                            letterSpacing: 1.1,
                          ),
                        ),
                        const SizedBox(height: 12),

                        _buildSocialCard(isNight, 'Instagram', '@audio_xpert', Icons.camera_alt_outlined),
                        const SizedBox(height: 8),
                        _buildSocialCard(isNight, 'YouTube (Sound Tutorials)', '@audioxpertt', Icons.video_library_rounded),
                        const SizedBox(height: 8),
                        _buildSocialCard(isNight, 'Developed by', 'AudioXpert', Icons.verified_user_rounded),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContactCard({
    required BuildContext context,
    required bool isNight,
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    final cardBg = isNight ? const Color(0xFF141C30) : Colors.white;
    final cardBorder = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final titleColor = isNight ? Colors.white : const Color(0xFF0F172A);

    return Container(
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: cardBorder),
        boxShadow: [
          BoxShadow(
            color: isNight ? Colors.black.withOpacity(0.2) : const Color(0x060F172A),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        leading: Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            color: isNight ? const Color(0xFF1E293B) : const Color(0xFFEFF6FF),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: const Color(0xFF1D4ED8), size: 20),
        ),
        title: Text(
          title,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.bold,
            color: titleColor,
          ),
        ),
        subtitle: Text(
          subtitle,
          style: const TextStyle(
            fontSize: 11.5,
            color: Color(0xFF2563EB),
            fontWeight: FontWeight.w600,
          ),
        ),
        trailing: Icon(Icons.copy_rounded, size: 18, color: isNight ? const Color(0xFF475569) : const Color(0xFF94A3B8)),
        onTap: () {
          if (subtitle.contains('@')) {
            MailService.contactSupport();
          } else {
            Clipboard.setData(ClipboardData(text: subtitle));
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Copied: $subtitle'),
                behavior: SnackBarBehavior.floating,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
            );
          }
        },
      ),
    );
  }

  Widget _buildSocialCard(bool isNight, String platform, String handle, IconData icon) {
    final cardBg = isNight ? const Color(0xFF141C30) : Colors.white;
    final cardBorder = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final titleColor = isNight ? Colors.white : const Color(0xFF0F172A);

    return Container(
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: cardBorder),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
        leading: Icon(icon, size: 20, color: isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B)),
        title: Text(
          platform,
          style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.bold, color: titleColor),
        ),
        subtitle: Text(
          handle,
          style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFF2563EB)),
        ),
        trailing: Icon(Icons.open_in_new_rounded, size: 16, color: isNight ? const Color(0xFF475569) : const Color(0xFF94A3B8)),
      ),
    );
  }
}
