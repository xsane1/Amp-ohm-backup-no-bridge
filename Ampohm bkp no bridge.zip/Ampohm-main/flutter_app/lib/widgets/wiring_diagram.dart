import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/preference_service.dart';
import '../models/models.dart';

class WiringDiagramWidget extends StatelessWidget {
  final WiringConfiguration wiring;
  final int speakerCount;
  final double speakerImpedance;

  const WiringDiagramWidget({
    super.key,
    required this.wiring,
    required this.speakerCount,
    required this.speakerImpedance,
  });

  @override
  Widget build(BuildContext context) {
    final isParallel = wiring == WiringConfiguration.parallel;
    final count = speakerCount.clamp(1, 8);
    final isSingle = count == 1;

    final prefService = Provider.of<PreferenceService>(context);
    final isNight = prefService.isNightMode;

    final cardBg = isNight ? const Color(0xFF131B2A) : Colors.white;
    final borderColor = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final titleColor = isNight ? const Color(0xFFE2E8F0) : const Color(0xFF1E293B);

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor),
        boxShadow: [
          BoxShadow(
            color: isNight ? Colors.black.withOpacity(0.3) : const Color(0x060F172A),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.alt_route_rounded, size: 16, color: isNight ? const Color(0xFF38BDF8) : const Color(0xFF2563EB)),
                  const SizedBox(width: 6),
                  Text(
                    'WIRING DIAGRAM',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 0.5,
                      color: titleColor,
                    ),
                  ),
                ],
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: isParallel
                      ? (isNight ? const Color(0xFF1E3A8A).withOpacity(0.5) : const Color(0xFFEFF6FF))
                      : (isNight ? const Color(0xFF78350F).withOpacity(0.5) : const Color(0xFFFFFBEB)),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: isParallel
                        ? (isNight ? const Color(0xFF2563EB) : const Color(0xFFBFDBFE))
                        : (isNight ? const Color(0xFFD97706) : const Color(0xFFFDE68A)),
                  ),
                ),
                child: Text(
                  isSingle
                      ? '1 SPEAKER DIRECT'
                      : (isParallel ? 'PARALLEL WIRING' : 'SERIES WIRING'),
                  style: TextStyle(
                    fontSize: 9.5,
                    fontWeight: FontWeight.w900,
                    color: isParallel
                        ? (isNight ? const Color(0xFF60A5FA) : const Color(0xFF1D4ED8))
                        : (isNight ? const Color(0xFFFBBF24) : const Color(0xFFB45309)),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 104,
            width: double.infinity,
            child: CustomPaint(
              painter: _WiringPainter(
                wiring: wiring,
                speakerCount: count,
                impedance: speakerImpedance,
                isNight: isNight,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _WiringPainter extends CustomPainter {
  final WiringConfiguration wiring;
  final int speakerCount;
  final double impedance;
  final bool isNight;

  _WiringPainter({
    required this.wiring,
    required this.speakerCount,
    required this.impedance,
    this.isNight = false,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final isParallel = wiring == WiringConfiguration.parallel;
    final redPaint = Paint()
      ..color = isNight ? const Color(0xFFF87171) : const Color(0xFFEF4444)
      ..strokeWidth = 2.2
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final blackPaint = Paint()
      ..color = isNight ? const Color(0xFF94A3B8) : const Color(0xFF1E293B)
      ..strokeWidth = 2.2
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final ampPaint = Paint()
      ..color = isNight ? const Color(0xFF1D4ED8) : const Color(0xFF1E3A8A)
      ..style = PaintingStyle.fill;

    // Draw Amplifier Box on left
    const ampX = 6.0;
    const ampY = 16.0;
    const ampW = 48.0;
    const ampH = 56.0;

    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(ampX, ampY, ampW, ampH),
        const Radius.circular(8),
      ),
      ampPaint,
    );

    // AMP Label
    final tpAmp = TextPainter(
      text: const TextSpan(
        text: 'AMP',
        style: TextStyle(
          color: Colors.white,
          fontSize: 12,
          fontStyle: FontStyle.italic,
          fontWeight: FontWeight.w900,
        ),
      ),
      textAlign: TextAlign.center,
      textDirection: TextDirection.ltr,
    );
    tpAmp.layout();
    tpAmp.paint(canvas, Offset(ampX + (ampW - tpAmp.width) / 2, ampY + (ampH - tpAmp.height) / 2));

    // Terminal dots on AMP
    final termRed = Paint()..color = isNight ? const Color(0xFFF87171) : const Color(0xFFEF4444);
    final termBlack = Paint()..color = isNight ? const Color(0xFF94A3B8) : const Color(0xFF0F172A);
    canvas.drawCircle(const Offset(ampX + ampW, 28), 4.0, termRed);
    canvas.drawCircle(const Offset(ampX + ampW, 58), 4.0, termBlack);

    final displayCount = speakerCount.clamp(1, 4);
    const spkW = 44.0;
    const spkH = 56.0;
    const spkY = 16.0;

    // Amp takes up ampX + ampW = 54.0. First speaker starts at startX = 68.0.
    const startX = 68.0;
    // Generous right margin so the speaker and wires never cut off on the right
    final rightMargin = wiring == WiringConfiguration.series ? 26.0 : 18.0;
    final maxAllowedRight = size.width - rightMargin;
    final availableSpan = (maxAllowedRight - spkW - startX).clamp(0.0, double.infinity);
    final spacing = displayCount > 1 
        ? (availableSpan / (displayCount - 1)).clamp(46.0, 96.0) 
        : 72.0;

    for (int i = 0; i < displayCount; i++) {
      final spkX = startX + i * spacing;
      final cx = spkX + spkW / 2;
      final cy = spkY + 28.0;

      // 1. Speaker Baffle Cabinet
      final spkRect = Rect.fromLTWH(spkX, spkY, spkW, spkH);
      final spkBoxPaint = Paint()
        ..color = isNight ? const Color(0xFF0B0F19) : const Color(0xFFF8FAFC)
        ..style = PaintingStyle.fill;
      final spkBorderPaint = Paint()
        ..color = isNight ? const Color(0xFF3B82F6) : const Color(0xFF2563EB)
        ..strokeWidth = 1.8
        ..style = PaintingStyle.stroke;

      canvas.drawRRect(RRect.fromRectAndRadius(spkRect, const Radius.circular(8)), spkBoxPaint);
      canvas.drawRRect(RRect.fromRectAndRadius(spkRect, const Radius.circular(8)), spkBorderPaint);

      // 4 Corner Screws
      final screwPaint = Paint()..color = isNight ? const Color(0xFF475569) : const Color(0xFF94A3B8);
      canvas.drawCircle(Offset(spkX + 4.5, spkY + 4.5), 1.1, screwPaint);
      canvas.drawCircle(Offset(spkX + spkW - 4.5, spkY + 4.5), 1.1, screwPaint);
      canvas.drawCircle(Offset(spkX + 4.5, spkY + spkH - 4.5), 1.1, screwPaint);
      canvas.drawCircle(Offset(spkX + spkW - 4.5, spkY + spkH - 4.5), 1.1, screwPaint);

      // 2. Outer Speaker Basket Rim
      final basketRimPaint = Paint()
        ..color = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0)
        ..style = PaintingStyle.fill;
      final basketBorder = Paint()
        ..color = isNight ? const Color(0xFF38BDF8) : const Color(0xFF2563EB)
        ..strokeWidth = 1.0
        ..style = PaintingStyle.stroke;
      canvas.drawCircle(Offset(cx, cy), 16.5, basketRimPaint);
      canvas.drawCircle(Offset(cx, cy), 16.5, basketBorder);

      // 3. Rubber Surround Roll Ring
      final surroundPaint = Paint()
        ..color = isNight ? const Color(0xFF334155) : const Color(0xFF64748B)
        ..strokeWidth = 1.8
        ..style = PaintingStyle.stroke;
      canvas.drawCircle(Offset(cx, cy), 14.2, surroundPaint);

      // 4. Acoustic Woofer Cone
      final conePaint = Paint()
        ..color = isNight ? const Color(0xFF0F172A) : const Color(0xFF1E293B)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(Offset(cx, cy), 12.6, conePaint);

      // 5. Concentric Acoustic Ribs (Grooves)
      final ribPaint = Paint()
        ..color = (isNight ? const Color(0xFF38BDF8) : const Color(0xFF94A3B8)).withOpacity(0.4)
        ..strokeWidth = 0.8
        ..style = PaintingStyle.stroke;
      canvas.drawCircle(Offset(cx, cy), 9.5, ribPaint);
      canvas.drawCircle(Offset(cx, cy), 6.8, ribPaint);

      // 6. Center Dust Cap Dome
      final dustCapPaint = Paint()
        ..color = isNight ? const Color(0xFF1D4ED8) : const Color(0xFF3B82F6)
        ..style = PaintingStyle.fill;
      final dustCapBorder = Paint()
        ..color = isNight ? const Color(0xFF60A5FA) : const Color(0xFF1E40AF)
        ..strokeWidth = 0.8
        ..style = PaintingStyle.stroke;
      canvas.drawCircle(Offset(cx, cy), 4.2, dustCapPaint);
      canvas.drawCircle(Offset(cx, cy), 4.2, dustCapBorder);

      // Specular highlight on dust cap
      final specPaint = Paint()..color = Colors.white.withOpacity(0.9);
      canvas.drawCircle(Offset(cx - 1.2, cy - 1.2), 1.0, specPaint);

      // 7. Impedance Label below Driver
      final tpSpk = TextPainter(
        text: TextSpan(
          text: '${impedance.toInt()}Ω',
          style: TextStyle(
            color: isNight ? const Color(0xFF93C5FD) : const Color(0xFF1D4ED8),
            fontSize: 8.5,
            fontWeight: FontWeight.w900,
          ),
        ),
        textDirection: TextDirection.ltr,
      );
      tpSpk.layout();
      tpSpk.paint(canvas, Offset(cx - tpSpk.width / 2, spkY + spkH - 12));

      // 8. Positive (+) and Negative (-) Speaker Terminals
      // (+) Terminal Top-Left
      canvas.drawCircle(Offset(spkX + 7, 28), 3.8, termRed);
      final tpPlus = TextPainter(
        text: const TextSpan(
          text: '+',
          style: TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w900),
        ),
        textDirection: TextDirection.ltr,
      );
      tpPlus.layout();
      tpPlus.paint(canvas, Offset(spkX + 7 - tpPlus.width / 2, 28 - tpPlus.height / 2));

      // (-) Terminal Bottom-Right
      canvas.drawCircle(Offset(spkX + spkW - 7, 58), 3.8, termBlack);
      final tpMinus = TextPainter(
        text: const TextSpan(
          text: '-',
          style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w900),
        ),
        textDirection: TextDirection.ltr,
      );
      tpMinus.layout();
      tpMinus.paint(canvas, Offset(spkX + spkW - 7 - tpMinus.width / 2, 58 - tpMinus.height / 2));

      // Parallel Wiring Rails
      if (isParallel || displayCount == 1) {
        // Red Rail Wire (Positive) straight across top to all (+)
        final pStart = i == 0 ? const Offset(ampX + ampW, 28) : Offset(spkX - spacing + 7, 28);
        canvas.drawLine(pStart, Offset(spkX + 7, 28), redPaint);

        // Black Rail Wire (Negative) straight across bottom to all (-)
        final nStart = i == 0 ? const Offset(ampX + ampW, 58) : Offset(spkX - spacing + spkW - 7, 58);
        canvas.drawLine(nStart, Offset(spkX + spkW - 7, 58), blackPaint);
      }
    }

    // Series Wiring: Daisy-Chain Loop from Negative to Positive
    if (!isParallel && displayCount > 1) {
      // 1. Amp Red (+) straight to Speaker 1 (+)
      canvas.drawLine(const Offset(ampX + ampW, 28), const Offset(startX + 7, 28), redPaint);

      // 2. Loop Speaker i (-) to Speaker i+1 (+)
      for (int i = 0; i < displayCount - 1; i++) {
        final curX = startX + i * spacing;
        final nextX = startX + (i + 1) * spacing;
        final fromX = curX + spkW - 7;
        final toX = nextX + 7;
        final midX = (fromX + toX) / 2;

        final path = Path()
          ..moveTo(fromX, 58)
          ..lineTo(midX, 58)
          ..lineTo(midX, 28)
          ..lineTo(toX, 28);

        canvas.drawPath(path, redPaint);
      }

      // 3. Return last Speaker (-) to Amp Black (-) underneath
      final lastX = startX + (displayCount - 1) * spacing;
      final returnPath = Path()
        ..moveTo(lastX + spkW - 7, 58)
        ..lineTo(lastX + spkW + 6, 58)
        ..lineTo(lastX + spkW + 6, 82)
        ..lineTo(ampX + ampW, 82)
        ..lineTo(ampX + ampW, 58);

      canvas.drawPath(returnPath, blackPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _WiringPainter oldDelegate) {
    return oldDelegate.wiring != wiring ||
        oldDelegate.speakerCount != speakerCount ||
        oldDelegate.impedance != impedance ||
        oldDelegate.isNight != isNight;
  }
}
