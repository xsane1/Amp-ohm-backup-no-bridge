import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/preference_service.dart';
import '../screens/settings_screen.dart';

class HomeTopHeader extends StatelessWidget {
  const HomeTopHeader({super.key});

  @override
  Widget build(BuildContext context) {
    final prefService = Provider.of<PreferenceService>(context);
    final isHindi = prefService.locale.languageCode == 'hi';
    final isNight = prefService.isNightMode;

    return Container(
      decoration: BoxDecoration(
        color: isNight ? const Color(0xFF0E1524) : Colors.white,
        border: Border(
          bottom: BorderSide(
            color: isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0),
          ),
        ),
      ),
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Left: App Logo + Title
          Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(9),
                child: Image.asset(
                  'assets/images/app_logo.png',
                  width: 38,
                  height: 38,
                  fit: BoxFit.contain,
                ),
              ),
              const SizedBox(width: 8),
              Flexible(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    RichText(
                      text: TextSpan(
                        style: const TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.w900,
                          letterSpacing: -0.4,
                          height: 1.0,
                        ),
                        children: [
                          TextSpan(
                            text: 'AMP ',
                            style: TextStyle(
                              color: isNight ? Colors.white : const Color(0xFF0F172A),
                            ),
                          ),
                          TextSpan(
                            text: 'OHM',
                            style: TextStyle(
                              color: isNight ? const Color(0xFF38BDF8) : const Color(0xFF2563EB),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Audio & Lighting Tools',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 9.5,
                        fontWeight: FontWeight.w600,
                        color: isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B),
                        letterSpacing: -0.2,
                        height: 1.0,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          // Right: Theme Toggle + Language Toggle + Settings
          Row(
            children: [
              // Theme Toggle (Sun / Moon)
              InkWell(
                onTap: () => prefService.toggleTheme(),
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: isNight ? const Color(0xFF1E293B) : const Color(0xFFF8FAFC),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: isNight ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
                    ),
                  ),
                  child: Center(
                    child: Icon(
                      isNight ? Icons.light_mode_rounded : Icons.dark_mode_outlined,
                      size: 16,
                      color: isNight ? const Color(0xFFFBBF24) : const Color(0xFF475569),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 6),

              // Language Toggle Pill
              InkWell(
                onTap: () {
                  final nextLang = isHindi ? 'en' : 'hi';
                  prefService.setLocale(Locale(nextLang, ''));
                },
                borderRadius: BorderRadius.circular(16),
                child: Container(
                  height: 32,
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: BoxDecoration(
                    color: isNight ? const Color(0xFF1E293B) : const Color(0xFFF8FAFC),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: isNight ? const Color(0xFF334155) : const Color(0xFFE2E8F0),
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.g_translate_rounded,
                        size: 14,
                        color: isNight ? const Color(0xFF38BDF8) : const Color(0xFF2563EB),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        isHindi ? 'हिन्दी' : 'ENG',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: isHindi ? FontWeight.w700 : FontWeight.w800,
                          color: isNight ? Colors.white : const Color(0xFF0F172A),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 6),

              // Settings
              InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const SettingsScreen()),
                  );
                },
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: isNight ? const Color(0xFF1E293B) : const Color(0xFFF8FAFC),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: isNight ? const Color(0xFF334155) : const Color(0xFFCBD5E1),
                    ),
                  ),
                  child: Icon(
                    Icons.settings_outlined,
                    size: 16,
                    color: isNight ? const Color(0xFF94A3B8) : const Color(0xFF475569),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
