import 'package:flutter/material.dart';
import '../utils/app_typography.dart';

/// Modern 2-Column Grid Card matching the AI Studio Web UI
/// - Deep rounded corners (20px)
/// - Top accent line
/// - Top-right circular gold action arrow
/// - Real vector equipment artwork in bottom-right corner
/// - Multi-line title & clean subtitle

class ModernToolCard extends StatelessWidget {
  final String title;
  final String description;
  final Widget artwork;
  final VoidCallback onTap;

  const ModernToolCard({
    super.key,
    required this.title,
    required this.description,
    required this.artwork,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      elevation: 2,
      shadowColor: const Color(0x140F172A),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        splashColor: const Color(0x1A2563EB),
        highlightColor: const Color(0x0A2563EB),
        child: Container(
          height: 164,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: const Color(0xFFE2E8F0), width: 1),
          ),
          clipBehavior: Clip.antiAlias,
          child: Stack(
            children: [
              // Bottom Right Artwork (Positioned precisely like web)
              Positioned(
                right: 2,
                bottom: 2,
                child: Opacity(
                  opacity: 0.95,
                  child: artwork,
                ),
              ),

              // Top Right Circular Amber Action Button
              Positioned(
                top: 10,
                right: 10,
                child: Container(
                  width: 26,
                  height: 26,
                  decoration: BoxDecoration(
                    color: const Color(0xFFFBBF24),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.08),
                        blurRadius: 4,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: const Center(
                    child: Icon(
                      Icons.chevron_right,
                      size: 18,
                      color: Color(0xFF0F172A),
                    ),
                  ),
                ),
              ),

              // Content Area (Top Left)
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 12, 40, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Mini Blue Accent Bar
                    Container(
                      width: 20,
                      height: 3.5,
                      decoration: BoxDecoration(
                        color: const Color(0xFF2563EB),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    const SizedBox(height: 8),

                    // Title
                    Builder(
                      builder: (context) {
                        final isHindi = title.contains(RegExp(r'[\u0900-\u097F]'));
                        return Text(
                          isHindi ? title : title.toUpperCase(),
                          style: TextStyle(
                            fontSize: isHindi ? 13.5 : 14,
                            fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                            color: const Color(0xFF0F172A),
                            letterSpacing: isHindi ? 0.0 : -0.3,
                            height: 1.18,
                            fontFamilyFallback: AppTypography.hindiFontFallback,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        );
                      },
                    ),
                    const SizedBox(height: 5),

                    // Subtitle / Description
                    Text(
                      description,
                      style: const TextStyle(
                        fontSize: 10.5,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF64748B),
                        height: 1.25,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
