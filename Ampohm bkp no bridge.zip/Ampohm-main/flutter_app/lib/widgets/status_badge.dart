import 'package:flutter/material.dart';
import '../models/models.dart';
import '../localization/app_localizations.dart';

class StatusBadge extends StatelessWidget {
  final StatusLevel status;
  final String? customText;

  const StatusBadge({
    super.key,
    required this.status,
    this.customText,
  });

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);

    Color bg;
    Color border;
    Color text;
    IconData icon;
    String defaultLabel;

    switch (status) {
      case StatusLevel.safe:
        bg = const Color(0xFFECFDF5);
        border = const Color(0xFFA7F3D0);
        text = const Color(0xFF065F46);
        icon = Icons.check_circle_outline;
        defaultLabel = t.statusSafe;
        break;
      case StatusLevel.warning:
        bg = const Color(0xFFFFFBEB);
        border = const Color(0xFFFDE68A);
        text = const Color(0xFF92400E);
        icon = Icons.warning_amber_rounded;
        defaultLabel = t.statusWarning;
        break;
      case StatusLevel.danger:
        bg = const Color(0xFFFEF2F2);
        border = const Color(0xFFFECACA);
        text = const Color(0xFF991B1B);
        icon = Icons.error_outline;
        defaultLabel = t.statusDanger;
        break;
      case StatusLevel.info:
        bg = const Color(0xFFEFF6FF);
        border = const Color(0xFFBFDBFE);
        text = const Color(0xFF1E40AF);
        icon = Icons.info_outline;
        defaultLabel = t.statusInfo;
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: text),
          const SizedBox(width: 6),
          Text(
            customText ?? defaultLabel,
            style: TextStyle(
              color: text,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}
