import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/admob_service.dart';
import '../services/preference_service.dart';
import '../services/subscription_service.dart';
import '../screens/paywall_screen.dart';
import 'reward_success_dialog.dart';
import '../utils/app_typography.dart';

class CalculatorUnlockDialog {
  /// Shows the choice dialog when non-subscribers press Calculate
  static void show(
    BuildContext context, {
    required String calculatorTitle,
    required VoidCallback onUnlocked,
  }) {
    final subService = Provider.of<SubscriptionService>(context, listen: false);
    final adMobService = Provider.of<AdMobService>(context, listen: false);

    // 1. Priority 1: Active Subscription -> Immediately unlocked, no ads!
    if (subService.isPremium) {
      onUnlocked();
      return;
    }

    // 2. Priority 2: Active 60-Minute Rewarded Pass -> Immediately unlocked, no ads!
    if (adMobService.hasActiveRewardPass) {
      onUnlocked();
      return;
    }

    // 3. Remote ads disabled -> Immediately unlocked!
    if (!adMobService.adsMasterEnabled || !adMobService.rewardAdsEnabled) {
      onUnlocked();
      return;
    }

    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (dialogCtx) => _UnlockDialogContent(
        calculatorTitle: calculatorTitle,
        onUnlocked: onUnlocked,
      ),
    );
  }
}

class _UnlockDialogContent extends StatefulWidget {
  final String calculatorTitle;
  final VoidCallback onUnlocked;

  const _UnlockDialogContent({
    required this.calculatorTitle,
    required this.onUnlocked,
  });

  @override
  State<_UnlockDialogContent> createState() => _UnlockDialogContentState();
}

class _UnlockDialogContentState extends State<_UnlockDialogContent> {
  String? _errorMessage;
  bool _isError = false;

  void _startWatchAd(BuildContext context, bool isHindi) {
    setState(() {
      _errorMessage = null;
      _isError = false;
    });

    final adMobService = Provider.of<AdMobService>(context, listen: false);

    if (adMobService.hasActiveRewardPass) {
      Navigator.of(context, rootNavigator: true).pop();
      widget.onUnlocked();
      return;
    }

    adMobService.showRewardedAdWithLoadingDialog(
      context,
      onResult: (success, message) {
        if (!mounted) return;

        if (success) {
          // Reward earned successfully! Close choice dialog
          Navigator.of(context, rootNavigator: true).pop();
          // Unlock and show the calculation result screen
          widget.onUnlocked();
          // Show the small, premium success dialog over the result screen
          WidgetsBinding.instance.addPostFrameCallback((_) {
            RewardSuccessDialog.show(context);
          });
        } else {
          // Ad was not completed or failed
          setState(() {
            _isError = true;
            _errorMessage = isHindi
                ? 'ऐड पूरा होने से पहले बंद हो गया या लोड नहीं हो सका। परिणाम देखने के लिए कृपया ऐड पूरा देखें।'
                : 'The ad was closed before finishing or could not load. The calculation remains locked until the ad is completed.';
          });
        }
      },
    );
  }

  void _openSubscription(BuildContext context) {
    Navigator.of(context, rootNavigator: true).pop();
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const PaywallScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final prefService = Provider.of<PreferenceService>(context);
    final isHindi = prefService.isHindi;
    final isNight = prefService.isNightMode;

    final dialogBg = isNight ? const Color(0xFF0F172A) : Colors.white;
    final borderColor = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final titleColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final subtitleColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    return Dialog(
      backgroundColor: dialogBg,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(28),
        side: BorderSide(color: borderColor, width: 1.2),
      ),
      insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 20),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Header Row: Icon + Title + Close Button
              Row(
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: const Color(0xFF2563EB).withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(
                      Icons.layers_rounded,
                      color: Color(0xFF38BDF8),
                      size: 20,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          isHindi ? 'कैलकुलेशन परिणाम' : 'Calculation Result',
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                            color: titleColor,
                            letterSpacing: isHindi ? 0.0 : -0.3,
                            fontFamilyFallback: AppTypography.hindiFontFallback,
                          ),
                        ),
                        Text(
                          widget.calculatorTitle,
                          style: const TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF2563EB),
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.of(context, rootNavigator: true).pop(),
                    icon: Icon(
                      Icons.close_rounded,
                      size: 20,
                      color: isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B),
                    ),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Divider(height: 1, color: borderColor),
              const SizedBox(height: 14),

              // Subtitle
              Text(
                isHindi
                    ? 'कैलकुलेशन परिणाम देखने के लिए नीचे दिए गए विकल्पों में से एक चुनें:'
                    : 'Choose how you would like to view this calculation result:',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  color: subtitleColor,
                  height: 1.35,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),

              // Error banner if user dismissed ad early or ad failed
              if (_isError && _errorMessage != null) ...[
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEF4444).withOpacity(0.12),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: const Color(0xFFEF4444).withOpacity(0.35),
                      width: 1,
                    ),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(
                        Icons.warning_amber_rounded,
                        color: Color(0xFFEF4444),
                        size: 20,
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          _errorMessage!,
                          style: TextStyle(
                            fontSize: 11,
                            color: isNight ? const Color(0xFFFCA5A5) : const Color(0xFFB91C1C),
                            fontWeight: FontWeight.w600,
                            height: 1.3,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
              ],

              // OPTION 1: WATCH AD (Gold / Amber Card)
              InkWell(
                onTap: () => _startWatchAd(context, isHindi),
                borderRadius: BorderRadius.circular(18),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFF59E0B), Color(0xFFD97706)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFF59E0B).withOpacity(0.3),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: const Color(0xFF0F172A),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(
                          Icons.play_arrow_rounded,
                          color: Color(0xFFFBBF24),
                          size: 22,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              isHindi ? 'ऐड देखें' : 'Watch Ad',
                              style: TextStyle(
                                fontSize: 13.5,
                                fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                                color: const Color(0xFF0F172A),
                                fontFamilyFallback: AppTypography.hindiFontFallback,
                              ),
                            ),
                            const SizedBox(height: 1.5),
                            Text(
                              isHindi
                                  ? 'परिणाम देखने के लिए एक छोटा वीडियो ऐड देखें।'
                                  : 'Watch a rewarded video to continue to the result.',
                              style: const TextStyle(
                                fontSize: 10.5,
                                fontWeight: FontWeight.w600,
                                color: Color(0xD90F172A),
                                height: 1.25,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: const Color(0xFF0F172A).withOpacity(0.2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          isHindi ? 'फ्री' : 'Free',
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                            color: const Color(0xFF0F172A),
                            fontFamilyFallback: AppTypography.hindiFontFallback,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 12),

              // OR Divider
              Row(
                children: [
                  Expanded(child: Divider(color: borderColor, height: 1)),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Text(
                      isHindi ? 'या' : 'OR',
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                        color: subtitleColor,
                      ),
                    ),
                  ),
                  Expanded(child: Divider(color: borderColor, height: 1)),
                ],
              ),

              const SizedBox(height: 12),

              // OPTION 2: GET SUBSCRIPTION (Royal Blue / Indigo Card)
              InkWell(
                onTap: () => _openSubscription(context),
                borderRadius: BorderRadius.circular(18),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFF1D4ED8), Color(0xFF4338CA)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF1D4ED8).withOpacity(0.25),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: const Color(0xFFFBBF24),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(
                          Icons.workspace_premium_rounded,
                          color: Color(0xFF0F172A),
                          size: 22,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              isHindi ? 'सब्सक्रिप्शन लें' : 'Get Subscription',
                              style: TextStyle(
                                fontSize: 13.5,
                                fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                                color: Colors.white,
                                fontFamilyFallback: AppTypography.hindiFontFallback,
                              ),
                            ),
                            const SizedBox(height: 1.5),
                            Text(
                              isHindi
                                  ? 'ऐड-फ्री अनुभव के लिए प्रो सब्सक्रिप्शन लें।'
                                  : 'Subscribe for an ad-free experience.',
                              style: const TextStyle(
                                fontSize: 10.5,
                                fontWeight: FontWeight.w500,
                                color: Color(0xFFDBEAFE),
                                height: 1.25,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 6),
                      const Icon(
                        Icons.arrow_forward_ios_rounded,
                        color: Color(0xFFFBBF24),
                        size: 14,
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 14),

              // CANCEL BUTTON
              TextButton(
                onPressed: () => Navigator.of(context, rootNavigator: true).pop(),
                style: TextButton.styleFrom(
                  backgroundColor: isNight ? const Color(0xFF1E293B) : const Color(0xFFF1F5F9),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                    side: BorderSide(color: borderColor, width: 1),
                  ),
                ),
                child: Text(
                  isHindi ? 'रद्द करें' : 'Cancel',
                  style: TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w700,
                    color: isNight ? const Color(0xFFE2E8F0) : const Color(0xFF475569),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
