import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

class ShareResultButton extends StatefulWidget {
  final String title;
  final String shareText;

  const ShareResultButton({
    super.key,
    required this.title,
    required this.shareText,
  });

  @override
  State<ShareResultButton> createState() => _ShareResultButtonState();
}

class _ShareResultButtonState extends State<ShareResultButton> {
  bool _shared = false;

  void _handleShare() async {
    try {
      final box = context.findRenderObject() as RenderBox?;
      final origin = box != null ? box.localToGlobal(Offset.zero) & box.size : null;

      await Share.share(
        widget.shareText,
        subject: widget.title,
        sharePositionOrigin: origin,
      );

      if (mounted) {
        setState(() => _shared = true);
        Future.delayed(const Duration(seconds: 3), () {
          if (mounted) setState(() => _shared = false);
        });
      }
    } catch (_) {
      // Fallback: Copy to Android clipboard
      _handleCopyFallback();
    }
  }

  void _handleCopyFallback() async {
    await Clipboard.setData(ClipboardData(text: widget.shareText));
    if (mounted) {
      setState(() => _shared = true);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: const [
              Icon(Icons.check_circle, color: Color(0xFF22C55E), size: 18),
              SizedBox(width: 8),
              Text(
                'Result copied to clipboard! Ready to share.',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
              ),
            ],
          ),
          backgroundColor: const Color(0xFF0F172A),
          behavior: SnackBarBehavior.floating,
          duration: const Duration(seconds: 2),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      );
      Future.delayed(const Duration(seconds: 2), () {
        if (mounted) setState(() => _shared = false);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: _handleShare,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 16),
        decoration: BoxDecoration(
          color: _shared ? const Color(0xFFDCFCE7) : const Color(0xFFF1F5F9),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: _shared ? const Color(0xFF86EFAC) : const Color(0xFFCBD5E1),
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              _shared ? Icons.check_rounded : Icons.share_rounded,
              size: 18,
              color: _shared ? const Color(0xFF16A34A) : const Color(0xFF334155),
            ),
            const SizedBox(width: 8),
            Text(
              _shared ? 'SHARED / COPIED' : widget.title,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.3,
                color: _shared ? const Color(0xFF15803D) : const Color(0xFF1E293B),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
