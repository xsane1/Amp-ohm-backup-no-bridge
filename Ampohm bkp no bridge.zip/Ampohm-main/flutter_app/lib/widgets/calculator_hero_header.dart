import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/preference_service.dart';
import '../utils/app_typography.dart';

/// Reusable Curved Hero Header matching the Web AI Studio design exactly:
/// - Royal Blue to Deep Blue gradient (or Obsidian in dark mode)
/// - Back navigation circular blur button
/// - Reset circular button (optional)
/// - Right-side actions (e.g. Language toggle or custom badges)
/// - Theme toggle button (Sun/Moon)
/// - Subtitle and bold display title
class CalculatorHeroHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  final VoidCallback onBack;
  final VoidCallback? onReset;
  final Widget? actions;
  final Widget? badge;
  final bool showThemeToggle;

  const CalculatorHeroHeader({
    super.key,
    required this.title,
    required this.subtitle,
    required this.onBack,
    this.onReset,
    this.actions,
    this.badge,
    this.showThemeToggle = false,
  });

  @override
  Widget build(BuildContext context) {
    final prefService = Provider.of<PreferenceService>(context);
    final isNight = prefService.isNightMode;

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: isNight
              ? const [
                  Color(0xFF070B14),
                  Color(0xFF0E1526),
                  Color(0xFF141E34),
                ]
              : const [
                  Color(0xFF1D4ED8), // Royal Blue
                  Color(0xFF2563EB),
                  Color(0xFF3B82F6),
                ],
        ),
      ),
      child: Stack(
        children: [
          // Ambient soft curved overlay glow
          Positioned(
            top: -40,
            right: -40,
            child: Container(
              width: 180,
              height: 180,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isNight
                    ? const Color(0xFF2563EB).withOpacity(0.08)
                    : Colors.white.withOpacity(0.12),
              ),
            ),
          ),
          Positioned(
            bottom: -30,
            left: -30,
            child: Container(
              width: 140,
              height: 140,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isNight
                    ? const Color(0xFF38BDF8).withOpacity(0.10)
                    : const Color(0xFF93C5FD).withOpacity(0.18),
              ),
            ),
          ),

          // Content safely inset below device notification / status bar
          SafeArea(
            bottom: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Top Bar Row: Back Button + Actions + Reset Button
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // Back circular button
                      InkWell(
                        onTap: onBack,
                        borderRadius: BorderRadius.circular(24),
                        child: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white.withOpacity(0.20),
                            border: Border.all(color: Colors.white.withOpacity(0.35)),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.08),
                                blurRadius: 6,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: const Icon(
                            Icons.arrow_back_ios_new_rounded,
                            size: 18,
                            color: Colors.white,
                          ),
                        ),
                      ),

                      // Right Actions (Custom Actions + Theme Toggle + Reset)
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          if (actions != null) actions!,

                          // Theme Toggle Button (Only when enabled, hidden by default in calculators)
                          if (showThemeToggle) ...[
                            const SizedBox(width: 8),
                            InkWell(
                              onTap: () => prefService.toggleTheme(),
                              borderRadius: BorderRadius.circular(24),
                              child: Container(
                                width: 40,
                                height: 40,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: isNight
                                      ? const Color(0xFF1E293B)
                                      : Colors.white.withOpacity(0.20),
                                  border: Border.all(
                                    color: isNight
                                        ? const Color(0xFFFBBF24).withOpacity(0.5)
                                        : Colors.white.withOpacity(0.35),
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.08),
                                      blurRadius: 6,
                                      offset: const Offset(0, 2),
                                    ),
                                  ],
                                ),
                                child: Icon(
                                  isNight ? Icons.light_mode_rounded : Icons.nightlight_round,
                                  size: 18,
                                  color: isNight ? const Color(0xFFFBBF24) : Colors.white,
                                ),
                              ),
                            ),
                          ],

                          if (onReset != null) ...[
                            const SizedBox(width: 8),
                            InkWell(
                              onTap: onReset,
                              borderRadius: BorderRadius.circular(24),
                              child: Container(
                                width: 40,
                                height: 40,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white.withOpacity(0.20),
                                  border: Border.all(color: Colors.white.withOpacity(0.35)),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.08),
                                      blurRadius: 6,
                                      offset: const Offset(0, 2),
                                    ),
                                  ],
                                ),
                                child: const Icon(
                                  Icons.refresh_rounded,
                                  size: 20,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ],
                  ),

                  if (badge != null) ...[
                    const SizedBox(height: 10),
                    badge!,
                  ],

                  const SizedBox(height: 14),

                  // Title
                  Builder(
                    builder: (context) {
                      final isHindiTitle = title.contains(RegExp(r'[\u0900-\u097F]'));
                      return Text(
                        title,
                        style: TextStyle(
                          fontSize: isHindiTitle ? 21 : 24,
                          fontWeight: isHindiTitle ? FontWeight.w600 : FontWeight.w800,
                          color: Colors.white,
                          letterSpacing: isHindiTitle ? 0.0 : -0.4,
                          height: isHindiTitle ? 1.25 : 1.15,
                          fontFamilyFallback: AppTypography.hindiFontFallback,
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 4),

                  // Subtitle
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w500,
                      color: isNight ? const Color(0xFF94A3B8) : const Color(0xFFDBEAFE),
                      height: 1.3,
                      fontFamilyFallback: AppTypography.hindiFontFallback,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
