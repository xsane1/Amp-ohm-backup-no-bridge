import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../main.dart';
import '../services/admob_service.dart';
import '../services/preference_service.dart';
import '../utils/app_typography.dart';

class RewardSuccessDialog extends StatefulWidget {
  const RewardSuccessDialog({super.key});

  /// Displays the small, premium success dialog and automatically dismisses after 4 seconds
  static void show(BuildContext context) {
    final navContext = AmpOhmApp.navigatorKey.currentContext ?? context;
    showDialog(
      context: navContext,
      barrierDismissible: true,
      builder: (ctx) => const RewardSuccessDialog(),
    );
  }

  @override
  State<RewardSuccessDialog> createState() => _RewardSuccessDialogState();
}

class _RewardSuccessDialogState extends State<RewardSuccessDialog> {
  Timer? _autoDismissTimer;
  Timer? _tickerTimer;

  @override
  void initState() {
    super.initState();

    // Auto-dismiss dialog after 4.5 seconds
    _autoDismissTimer = Timer(const Duration(milliseconds: 4500), () {
      if (mounted && Navigator.canPop(context)) {
        Navigator.pop(context);
      }
    });

    // Tick every 1 second to update the displayed remaining time from existing shared expiry
    _tickerTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) {
        setState(() {});
      }
    });
  }

  @override
  void dispose() {
    _autoDismissTimer?.cancel();
    _tickerTimer?.cancel();
    super.dispose();
  }

  void _handleDismiss() {
    _autoDismissTimer?.cancel();
    if (Navigator.canPop(context)) {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final prefService = Provider.of<PreferenceService>(context);
    final adMobService = Provider.of<AdMobService>(context);
    final isHindi = prefService.isHindi;
    final isNight = prefService.isNightMode;

    final dialogBg = isNight ? const Color(0xFF0F172A) : Colors.white;
    final borderColor = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final titleColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final subtextColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF475569);

    final timerBg = isNight
        ? const Color(0xFF064E3B).withOpacity(0.35)
        : const Color(0xFFECFDF5);
    final timerBorder = isNight
        ? const Color(0xFF10B981).withOpacity(0.4)
        : const Color(0xFFA7F3D0);
    final timerTextColor = isNight
        ? const Color(0xFF34D399)
        : const Color(0xFF047857);

    // Get live formatted remaining time directly from existing shared expiration timestamp
    final remainingTime = adMobService.formattedRemainingTime;

    return Dialog(
      backgroundColor: dialogBg,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(24),
        side: BorderSide(color: borderColor, width: 1.2),
      ),
      insetPadding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(22, 20, 22, 18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Glowing Success Check Icon
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: const Color(0xFF10B981).withOpacity(0.15),
                shape: BoxShape.circle,
                border: Border.all(
                  color: const Color(0xFF10B981).withOpacity(0.35),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF10B981).withOpacity(0.25),
                    blurRadius: 12,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: const Icon(
                Icons.check_circle_rounded,
                color: Color(0xFF10B981),
                size: 28,
              ),
            ),
            const SizedBox(height: 14),

            // Title
            Text(
              isHindi ? 'सभी कैलकुलेटर अनलॉक!' : 'All Calculators Unlocked!',
              style: TextStyle(
                fontSize: 16,
                fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                color: titleColor,
                letterSpacing: isHindi ? 0.0 : -0.2,
                fontFamilyFallback: AppTypography.hindiFontFallback,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),

            // Message
            Text(
              isHindi
                  ? 'अब आप अगले 60 मिनट तक बिना कोई ऐड देखे सभी कैलकुलेटर का उपयोग कर सकते हैं।'
                  : 'You can now use all calculators without watching another ad for the next 60 minutes.',
              style: TextStyle(
                fontSize: 12,
                fontWeight: isHindi ? FontWeight.w400 : FontWeight.w500,
                color: subtextColor,
                height: 1.35,
                fontFamilyFallback: AppTypography.hindiFontFallback,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),

            // Timer Pill showing actual remaining unlock time (starts at 60:00)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                color: timerBg,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: timerBorder, width: 1),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.timer_outlined,
                    size: 16,
                    color: timerTextColor,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    isHindi ? 'शेष समय: ' : 'Time Remaining: ',
                    style: TextStyle(
                      fontSize: 11.5,
                      fontWeight: isHindi ? FontWeight.w500 : FontWeight.w600,
                      color: timerTextColor,
                      fontFamilyFallback: AppTypography.hindiFontFallback,
                    ),
                  ),
                  Text(
                    remainingTime,
                    style: TextStyle(
                      fontSize: 12.5,
                      fontWeight: FontWeight.w900,
                      color: timerTextColor,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Quick Dismiss CTA Button
            SizedBox(
              width: double.infinity,
              child: TextButton(
                onPressed: _handleDismiss,
                style: TextButton.styleFrom(
                  backgroundColor: const Color(0xFF10B981),
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                child: Text(
                  isHindi ? 'जारी रखें' : 'Continue',
                  style: TextStyle(
                    fontSize: 12.5,
                    fontWeight: isHindi ? FontWeight.w600 : FontWeight.w900,
                    color: const Color(0xFF0F172A),
                    fontFamilyFallback: AppTypography.hindiFontFallback,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
