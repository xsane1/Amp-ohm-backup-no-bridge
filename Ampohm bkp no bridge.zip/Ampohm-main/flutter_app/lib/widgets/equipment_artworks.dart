import 'dart:math' as math;
import 'package:flutter/material.dart';

/// Ultra-Realistic Professional Audio & Lighting Equipment Artworks
/// Faithfully converted from the approved web vector graphics:
/// 1. Woofer Driver (Cast basket, 8 perimeter screws, ribbed rubber surround, concave cone, dust cap with gloss sheen)
/// 2. 3-Tier Rack Power Amplifier Stack (3x 2U chassis, chrome handles, rotary volume knobs, dual 5-segment LED VU meters, cyan power pilot)
///    - With Night Mode smooth rising/falling VU meter animation & pulsing power pilot
/// 3. Coiled Stage Cable (Triple concentric loops, heavy rubber sheen, two Neutrik-style Speakon/XLR plugs with blue anodized collars)
/// 4. DMX Moving Head Fixture (Matte body, rubber feet, digital DMX address LCD, yoke arms, multi-element optical lens, and glowing cyan stage light beam)
///    - With Night Mode smooth 3.6s beam sweep rotation & intensity pulse

// ==========================================
// 1. WOOFER SPEAKER ARTWORK
// ==========================================
class WooferArt extends StatelessWidget {
  final double size;
  final bool isNightMode;

  const WooferArt({
    super.key,
    this.size = 94,
    this.isNightMode = false,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _WooferPainter(isNightMode: isNightMode),
      ),
    );
  }
}

class _WooferPainter extends CustomPainter {
  final bool isNightMode;
  _WooferPainter({this.isNightMode = false});

  @override
  void paint(Canvas canvas, Size size) {
    final scale = size.width / 160.0;
    canvas.save();
    canvas.scale(scale);

    final center = const Offset(80, 80);

    // 1. Soft Drop Shadow
    final shadowPaint = Paint()
      ..color = Colors.black.withOpacity(isNightMode ? 0.45 : 0.25)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5.0);
    canvas.drawCircle(const Offset(82, 84), 72, shadowPaint);

    // 2. Cast Basket Outer Rim (Metallic Gradient)
    final basketShader = RadialGradient(
      center: Alignment.center,
      radius: 0.9,
      colors: const [
        Color(0xFF1E242B),
        Color(0xFF374151),
        Color(0xFF111827),
        Color(0xFF4B5563),
      ],
      stops: const [0.70, 0.85, 0.92, 1.0],
    ).createShader(Rect.fromCircle(center: center, radius: 72));

    canvas.drawCircle(center, 72, Paint()..shader = basketShader);
    canvas.drawCircle(
      center,
      72,
      Paint()
        ..color = const Color(0xFF111827)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.0,
    );
    canvas.drawCircle(
      center,
      70,
      Paint()
        ..color = const Color(0xFF4B5563).withOpacity(0.6)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.75,
    );

    // 3. Thick Rubber Surround
    final surroundShader = RadialGradient(
      center: const Alignment(-0.12, -0.2),
      radius: 0.9,
      colors: const [
        Color(0xFF0B0F14),
        Color(0xFF252C36),
        Color(0xFF12171F),
        Color(0xFF080C10),
      ],
      stops: const [0.0, 0.50, 0.80, 1.0],
    ).createShader(Rect.fromCircle(center: center, radius: 64));

    canvas.drawCircle(center, 64, Paint()..shader = surroundShader);
    canvas.drawCircle(
      center,
      64,
      Paint()
        ..color = const Color(0xFF090D12)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5,
    );

    // Surround Specular Glaze (Linear shine)
    final surroundGlaze = const LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [Color(0x66FFFFFF), Color(0x0DFFFFFF), Color(0x99000000)],
      stops: [0.0, 0.35, 1.0],
    ).createShader(Rect.fromCircle(center: center, radius: 64));
    canvas.drawCircle(center, 64, Paint()..shader = surroundGlaze);

    // Surround Inner Valley
    canvas.drawCircle(
      center,
      54,
      Paint()
        ..color = const Color(0xFF05070A)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.5,
    );
    canvas.drawCircle(
      center,
      53,
      Paint()
        ..color = const Color(0xFF2A333E).withOpacity(0.8)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.7,
    );

    // 4. Matte Black Concave Speaker Cone
    final coneShader = RadialGradient(
      center: const Alignment(-0.04, -0.08),
      radius: 0.9,
      colors: const [
        Color(0xFF1F2730),
        Color(0xFF141920),
        Color(0xFF0B0E13),
        Color(0xFF05070A),
      ],
      stops: const [0.0, 0.45, 0.80, 1.0],
    ).createShader(Rect.fromCircle(center: center, radius: 52));
    canvas.drawCircle(center, 52, Paint()..shader = coneShader);

    // Concentric Acoustic Damping Ribs
    canvas.drawCircle(
      center,
      44,
      Paint()
        ..color = const Color(0xFF222B35).withOpacity(0.7)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.8,
    );
    canvas.drawCircle(
      center,
      38,
      Paint()
        ..color = const Color(0xFF1C242E).withOpacity(0.8)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.8,
    );
    canvas.drawCircle(
      center,
      32,
      Paint()
        ..color = const Color(0xFF151B22).withOpacity(0.9)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.8,
    );

    // Voice Coil Neck Transition
    canvas.drawCircle(
      center,
      26,
      Paint()
        ..color = const Color(0xFF0C1015)
        ..style = PaintingStyle.fill,
    );
    canvas.drawCircle(
      center,
      26,
      Paint()
        ..color = const Color(0xFF05070A)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.0,
    );

    // 5. Inverted Dust Cap Dome
    final dustCapShader = RadialGradient(
      center: const Alignment(-0.16, -0.24),
      radius: 0.9,
      colors: const [
        Color(0xFF3D4957),
        Color(0xFF1A222C),
        Color(0xFF0A0E13),
        Color(0xFF030507),
      ],
      stops: const [0.0, 0.40, 0.90, 1.0],
    ).createShader(Rect.fromCircle(center: center, radius: 23));
    canvas.drawCircle(center, 23, Paint()..shader = dustCapShader);
    canvas.drawCircle(
      center,
      23,
      Paint()
        ..color = const Color(0xFF0F141A)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.0,
    );

    // Specular Sheen Arc on Dust Cap
    final sheenPath = Path()
      ..moveTo(68, 70)
      ..quadraticBezierTo(78, 62, 90, 67)
      ..quadraticBezierTo(78, 68, 68, 70)
      ..close();
    canvas.drawPath(sheenPath, Paint()..color = Colors.white.withOpacity(0.35));
    canvas.drawCircle(const Offset(75, 72), 2.5, Paint()..color = Colors.white.withOpacity(0.4));

    // 6. Eight Perimeter Mounting Screws with Hex Sockets
    final screwGradient = const LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [Color(0xFFCBD5E1), Color(0xFF64748B), Color(0xFF334155)],
    );

    for (int i = 0; i < 8; i++) {
      final rad = (i * 45.0) * math.pi / 180.0;
      final cx = 80.0 + 68.0 * math.cos(rad);
      final cy = 80.0 + 68.0 * math.sin(rad);
      final screwCenter = Offset(cx, cy);

      final screwShader = screwGradient.createShader(
        Rect.fromCircle(center: screwCenter, radius: 2.8),
      );

      canvas.drawCircle(screwCenter, 2.8, Paint()..shader = screwShader);
      canvas.drawCircle(
        screwCenter,
        2.8,
        Paint()
          ..color = const Color(0xFF1E293B)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 0.5,
      );
      // Screw center dark socket
      canvas.drawCircle(screwCenter, 1.2, Paint()..color = const Color(0xFF0F172A));
    }

    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _WooferPainter oldDelegate) =>
      oldDelegate.isNightMode != isNightMode;
}

// ==========================================
// 2. RACK AMPLIFIER STACK ARTWORK (ANIMATED)
// ==========================================
class RackAmplifierArt extends StatefulWidget {
  final double width;
  final double height;
  final bool isNightMode;

  const RackAmplifierArt({
    super.key,
    this.width = 98,
    this.height = 80,
    this.isNightMode = false,
  });

  @override
  State<RackAmplifierArt> createState() => _RackAmplifierArtState();
}

class _RackAmplifierArtState extends State<RackAmplifierArt>
    with SingleTickerProviderStateMixin {
  late AnimationController _animCtrl;

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 920),
    );
    if (widget.isNightMode) {
      _animCtrl.repeat(reverse: true);
    } else {
      _animCtrl.value = 0.0;
    }
  }

  @override
  void didUpdateWidget(covariant RackAmplifierArt oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isNightMode != oldWidget.isNightMode) {
      if (widget.isNightMode) {
        _animCtrl.repeat(reverse: true);
      } else {
        _animCtrl.stop();
        _animCtrl.value = 0.0;
      }
    }
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _animCtrl,
      builder: (context, child) {
        return SizedBox(
          width: widget.width,
          height: widget.height,
          child: CustomPaint(
            painter: _RackAmplifierPainter(
              isNightMode: widget.isNightMode,
              animProgress: _animCtrl.value,
            ),
          ),
        );
      },
    );
  }
}

class _RackAmplifierPainter extends CustomPainter {
  final bool isNightMode;
  final double animProgress;

  _RackAmplifierPainter({
    this.isNightMode = false,
    this.animProgress = 0.5,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final scale = size.width / 160.0;
    canvas.save();
    canvas.scale(scale);

    // 1. Soft Ambient Drop Shadow
    final shadowPaint = Paint()
      ..color = Colors.black.withOpacity(isNightMode ? 0.5 : 0.3)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6.0);
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(22, 24, 124, 116), const Radius.circular(6)),
      shadowPaint,
    );

    // 2. Three 2U Rack Amplifier Units Stacked
    for (int idx = 0; idx < 3; idx++) {
      final y = 22.0 + idx * 38.0;

      // Chassis Faceplate
      final chassisRect = Rect.fromLTWH(20, y, 120, 34);
      final chassisRRect = RRect.fromRectAndRadius(chassisRect, const Radius.circular(3));

      final chassisShader = const LinearGradient(
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
        colors: [Color(0xFF11161D), Color(0xFF1E2631), Color(0xFF171E27), Color(0xFF0C1015)],
        stops: [0.0, 0.10, 0.85, 1.0],
      ).createShader(chassisRect);

      canvas.drawRRect(chassisRRect, Paint()..shader = chassisShader);
      canvas.drawRRect(
        chassisRRect,
        Paint()
          ..color = const Color(0xFF2A3647)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 0.75,
      );

      // Left Rack Mounting Ear & Screws
      canvas.drawRRect(
        RRect.fromRectAndRadius(Rect.fromLTWH(20, y, 9, 34), const Radius.circular(2)),
        Paint()..color = const Color(0xFF12171F),
      );
      canvas.drawLine(
        Offset(29, y + 2),
        Offset(29, y + 32),
        Paint()
          ..color = const Color(0xFF0A0D12)
          ..strokeWidth = 0.8,
      );
      canvas.drawCircle(Offset(24.5, y + 8), 1.6, Paint()..color = const Color(0xFF64748B));
      canvas.drawCircle(Offset(24.5, y + 8), 0.8, Paint()..color = const Color(0xFF0F172A));
      canvas.drawCircle(Offset(24.5, y + 26), 1.6, Paint()..color = const Color(0xFF64748B));
      canvas.drawCircle(Offset(24.5, y + 26), 0.8, Paint()..color = const Color(0xFF0F172A));

      // Right Rack Mounting Ear & Screws
      canvas.drawRRect(
        RRect.fromRectAndRadius(Rect.fromLTWH(131, y, 9, 34), const Radius.circular(2)),
        Paint()..color = const Color(0xFF12171F),
      );
      canvas.drawLine(
        Offset(131, y + 2),
        Offset(131, y + 32),
        Paint()
          ..color = const Color(0xFF0A0D12)
          ..strokeWidth = 0.8,
      );
      canvas.drawCircle(Offset(135.5, y + 8), 1.6, Paint()..color = const Color(0xFF64748B));
      canvas.drawCircle(Offset(135.5, y + 8), 0.8, Paint()..color = const Color(0xFF0F172A));
      canvas.drawCircle(Offset(135.5, y + 26), 1.6, Paint()..color = const Color(0xFF64748B));
      canvas.drawCircle(Offset(135.5, y + 26), 0.8, Paint()..color = const Color(0xFF0F172A));

      // Chrome Heavy Handles
      final handleShader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color(0xFF4B5563), Color(0xFF9CA3AF), Color(0xFF374151)],
      ).createShader(Rect.fromLTWH(29.5, y + 5, 4.5, 25));

      canvas.drawRRect(
        RRect.fromRectAndRadius(Rect.fromLTWH(29.5, y + 5, 4.5, 25), const Radius.circular(2)),
        Paint()..shader = handleShader,
      );
      canvas.drawRRect(
        RRect.fromRectAndRadius(Rect.fromLTWH(126, y + 5, 4.5, 25), const Radius.circular(2)),
        Paint()..shader = handleShader,
      );

      // Recessed Center Console
      final centerRect = Rect.fromLTWH(38, y + 4, 84, 26);
      canvas.drawRRect(
        RRect.fromRectAndRadius(centerRect, const Radius.circular(2)),
        Paint()..color = const Color(0xFF090D12),
      );

      // Horizontal Air Intake Vents
      final ventPaint = Paint()
        ..color = const Color(0xFF18202A)
        ..strokeWidth = 0.8;
      for (double vy = y + 7.5; vy <= y + 27.5; vy += 2.8) {
        canvas.drawLine(Offset(42, vy), Offset(55, vy), ventPaint);
      }

      // Dual Volume Knobs (Channel A and B)
      _drawKnob(canvas, Offset(64, y + 17), 5.5);
      _drawKnob(canvas, Offset(78, y + 17), 5.5);

      // Power Pilot Cyan LED in Center (Lit in Night Mode, Completely Down / Off in Day Mode)
      final pilotCenter = Offset(94, y + 17);
      if (isNightMode) {
        final pilotOpacity = (0.55 + animProgress * 0.45).clamp(0.4, 1.0);
        canvas.drawCircle(
          pilotCenter,
          5.0,
          Paint()
            ..color = const Color(0xFF38BDF8).withOpacity(pilotOpacity * 0.6)
            ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.5),
        );
        canvas.drawCircle(
          pilotCenter,
          2.2,
          Paint()..color = const Color(0xFF38BDF8).withOpacity(pilotOpacity),
        );
      } else {
        // Fully down / unlit in Day Mode
        canvas.drawCircle(
          pilotCenter,
          2.0,
          Paint()..color = const Color(0xFF1E293B),
        );
      }

      // Dynamic Animated 5-Segment VU Meter Ladders (Smooth rising and falling only in Night Mode, Completely Down in Day Mode)
      int litCountA = 0;
      int litCountB = 0;

      if (isNightMode) {
        final bouncePhase = (idx * 0.3);
        final effectiveAnimA = ((animProgress + bouncePhase) % 1.0);
        final effectiveAnimB = ((1.0 - animProgress + bouncePhase) % 1.0);
        litCountA = (1 + (effectiveAnimA * 4.0).round()).clamp(1, 5);
        litCountB = (1 + (effectiveAnimB * 4.0).round()).clamp(1, 5);
      }

      _drawVuLadder(canvas, 111.0, y + 8.5, litCountA);
      _drawVuLadder(canvas, 115.5, y + 8.5, litCountB);
    }

    canvas.restore();
  }

  void _drawKnob(Canvas canvas, Offset center, double radius) {
    final knobShader = const LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [Color(0xFF374151), Color(0xFF111827), Color(0xFF030712)],
    ).createShader(Rect.fromCircle(center: center, radius: radius));

    canvas.drawCircle(center, radius, Paint()..shader = knobShader);
    canvas.drawCircle(
      center,
      radius,
      Paint()
        ..color = const Color(0xFF4B5563)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.6,
    );
    // Indicator notch
    canvas.drawLine(
      Offset(center.dx, center.dy - radius + 1),
      Offset(center.dx, center.dy - 1),
      Paint()
        ..color = const Color(0xFFE2E8F0)
        ..strokeWidth = 1.0,
    );
  }

  void _drawVuLadder(Canvas canvas, double x, double topY, int litCount) {
    // 5 segments: Red (Clip), Amber (Limit), Yellow (-6dB), Lime (-12dB), Green (Signal)
    final colors = const [
      Color(0xFFEF4444), // Red
      Color(0xFFF59E0B), // Amber
      Color(0xFFFACC15), // Yellow
      Color(0xFF22C55E), // Lime
      Color(0xFF10B981), // Green
    ];

    for (int i = 0; i < 5; i++) {
      final segY = topY + i * 3.5;
      final isLit = (4 - i) < litCount;
      final col = colors[i];

      if (isNightMode && isLit) {
        canvas.drawRRect(
          RRect.fromRectAndRadius(Rect.fromLTWH(x - 0.5, segY - 0.5, 3.8, 3.2), const Radius.circular(1)),
          Paint()
            ..color = col.withOpacity(0.65)
            ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.0),
        );
      }

      canvas.drawRRect(
        RRect.fromRectAndRadius(Rect.fromLTWH(x, segY, 2.8, 2.3), const Radius.circular(0.5)),
        Paint()..color = (isNightMode && isLit) ? col : const Color(0xFF0F172A),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _RackAmplifierPainter oldDelegate) =>
      oldDelegate.isNightMode != isNightMode || oldDelegate.animProgress != animProgress;
}

// ==========================================
// 3. SPEAKER CABLE LOSS ARTWORK
// ==========================================
class CableLossArt extends StatelessWidget {
  final double size;
  final bool isNightMode;

  const CableLossArt({
    super.key,
    this.size = 96,
    this.isNightMode = false,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _CableLossPainter(isNightMode: isNightMode),
      ),
    );
  }
}

class _CableLossPainter extends CustomPainter {
  final bool isNightMode;
  _CableLossPainter({this.isNightMode = false});

  @override
  void paint(Canvas canvas, Size size) {
    final scale = size.width / 160.0;
    canvas.save();
    canvas.scale(scale);

    // 1. Drop shadow ellipse
    final shadowPaint = Paint()
      ..color = Colors.black.withOpacity(isNightMode ? 0.45 : 0.25)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6.0);
    canvas.drawOval(
      Rect.fromCenter(center: const Offset(80, 115), width: 130, height: 56),
      shadowPaint,
    );

    // Cable sheen shader
    final cableShader = const LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [Color(0xFF2E3846), Color(0xFF151B22), Color(0xFF080B0F)],
      stops: [0.0, 0.50, 1.0],
    );

    // 2. Coiled Heavy Cable Loops
    // Outer loop
    final outerRect = Rect.fromCircle(center: const Offset(92, 70), radius: 48);
    canvas.drawCircle(
      const Offset(92, 70),
      48,
      Paint()
        ..shader = cableShader.createShader(outerRect)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 11.0,
    );
    // Outer loop white highlight arc
    canvas.drawArc(
      outerRect,
      math.pi * 0.8,
      math.pi * 0.8,
      false,
      Paint()
        ..color = Colors.white.withOpacity(0.2)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.0,
    );

    // Mid loop
    final midRect = Rect.fromCircle(center: const Offset(94, 72), radius: 38);
    canvas.drawCircle(
      const Offset(94, 72),
      38,
      Paint()
        ..shader = cableShader.createShader(midRect)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 10.0,
    );

    // Inner loop
    final innerRect = Rect.fromCircle(center: const Offset(95, 74), radius: 28);
    canvas.drawCircle(
      const Offset(95, 74),
      28,
      Paint()
        ..shader = cableShader.createShader(innerRect)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 9.0,
    );

    // 3. Cable Leads Extending Forward to Plugs
    final lead1 = Path()
      ..moveTo(60, 85)
      ..quadraticBezierTo(48, 105, 40, 120);
    canvas.drawPath(
      lead1,
      Paint()
        ..color = const Color(0xFF11161D)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 9.0
        ..strokeCap = StrokeCap.round,
    );

    final lead2 = Path()
      ..moveTo(75, 88)
      ..quadraticBezierTo(66, 108, 58, 126);
    canvas.drawPath(
      lead2,
      Paint()
        ..color = const Color(0xFF18202A)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 9.0
        ..strokeCap = StrokeCap.round,
    );

    // 4. Two Professional Speakon / XLR Connectors with Cobalt Blue Rings
    // Connector 1 (Left)
    canvas.save();
    canvas.translate(40, 120);
    canvas.rotate(-30.0 * math.pi / 180.0);
    _drawConnector(canvas, isNightMode);
    canvas.restore();

    // Connector 2 (Right)
    canvas.save();
    canvas.translate(68, 128);
    canvas.rotate(-25.0 * math.pi / 180.0);
    _drawConnector(canvas, isNightMode);
    canvas.restore();

    canvas.restore();
  }

  void _drawConnector(Canvas canvas, bool isNight) {
    // Rubber strain relief boot
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(-4, -24, 8, 15), const Radius.circular(1.5)),
      Paint()..color = const Color(0xFF0B0E12),
    );

    // Anodized Cobalt Blue Locking Collar
    final blueShader = const LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [Color(0xFF38BDF8), Color(0xFF0284C7), Color(0xFF0369A1)],
    ).createShader(const Rect.fromLTWH(-5, -34, 10, 10));

    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(-5, -34, 10, 10), const Radius.circular(1)),
      Paint()..shader = blueShader,
    );

    // Chrome Metallic Barrel
    final chromeShader = const LinearGradient(
      begin: Alignment.centerLeft,
      end: Alignment.centerRight,
      colors: [Color(0xFF475569), Color(0xFF94A3B8), Color(0xFFCBD5E1), Color(0xFF334155)],
    ).createShader(const Rect.fromLTWH(-5.5, -52, 11, 18));

    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(-5.5, -52, 11, 18), const Radius.circular(1.5)),
      Paint()..shader = chromeShader,
    );

    // Connector Face with Contacts
    canvas.drawCircle(const Offset(0, -55), 5.0, Paint()..color = const Color(0xFF0F172A));
    canvas.drawCircle(
      const Offset(0, -55),
      5.0,
      Paint()
        ..color = const Color(0xFF475569)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.8,
    );

    // 3 Gold/Silver pin contacts
    final pinPaint = Paint()..color = const Color(0xFFF8FAFC);
    canvas.drawCircle(const Offset(-2, -56), 0.9, pinPaint);
    canvas.drawCircle(const Offset(2, -56), 0.9, pinPaint);
    canvas.drawCircle(const Offset(0, -53), 0.9, pinPaint);
  }

  @override
  bool shouldRepaint(covariant _CableLossPainter oldDelegate) =>
      oldDelegate.isNightMode != isNightMode;
}

// ==========================================
// 4. DMX MOVING HEAD STAGE FIXTURE (ANIMATED)
// ==========================================
class DmxStageArt extends StatefulWidget {
  final double size;
  final bool isNightMode;

  const DmxStageArt({
    super.key,
    this.size = 94,
    this.isNightMode = false,
  });

  @override
  State<DmxStageArt> createState() => _DmxStageArtState();
}

class _DmxStageArtState extends State<DmxStageArt>
    with SingleTickerProviderStateMixin {
  late AnimationController _sweepCtrl;

  @override
  void initState() {
    super.initState();
    _sweepCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3600),
    );
    if (widget.isNightMode) {
      _sweepCtrl.repeat(reverse: true);
    } else {
      _sweepCtrl.value = 0.5;
    }
  }

  @override
  void didUpdateWidget(covariant DmxStageArt oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isNightMode != oldWidget.isNightMode) {
      if (widget.isNightMode) {
        _sweepCtrl.repeat(reverse: true);
      } else {
        _sweepCtrl.stop();
        _sweepCtrl.value = 0.5;
      }
    }
  }

  @override
  void dispose() {
    _sweepCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _sweepCtrl,
      builder: (context, child) {
        return SizedBox(
          width: widget.size,
          height: widget.size,
          child: CustomPaint(
            painter: _DmxStagePainter(
              isNightMode: widget.isNightMode,
              sweepProgress: _sweepCtrl.value,
            ),
          ),
        );
      },
    );
  }
}

class _DmxStagePainter extends CustomPainter {
  final bool isNightMode;
  final double sweepProgress;

  _DmxStagePainter({
    this.isNightMode = false,
    this.sweepProgress = 0.5,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final scale = size.width / 130.0;
    canvas.save();
    canvas.scale(scale);
    canvas.translate(-65, -10);

    // 1. Soft Drop Shadow under Base
    final shadowPaint = Paint()
      ..color = Colors.black.withOpacity(isNightMode ? 0.45 : 0.25)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4.0);
    canvas.drawOval(
      Rect.fromCenter(center: const Offset(130, 142), width: 92, height: 12),
      shadowPaint,
    );

    // 2. Animated Stage Light Beam Cone (Active strictly in Night Mode)
    if (isNightMode) {
      final sweepAngle = (-12.0 + sweepProgress * 24.0) * math.pi / 180.0;
      final pulseOpacity = (0.88 + sweepProgress * 0.12).clamp(0.75, 1.0);

      canvas.save();
      canvas.translate(130, 54);
      canvas.rotate(sweepAngle);
      canvas.translate(-130, -54);

      // Broad Volumetric Stage Light Cone (Extends far across card to y = -220)
      final beamPath = Path()
        ..moveTo(120, 54)
        ..lineTo(10, -220)
        ..lineTo(250, -220)
        ..lineTo(140, 54)
        ..close();

      final beamShader = LinearGradient(
        begin: Alignment.bottomCenter,
        end: Alignment.topCenter,
        colors: [
          Colors.white.withOpacity(0.95 * pulseOpacity),
          const Color(0xFF67E8F9).withOpacity(0.92 * pulseOpacity),
          const Color(0xFF38BDF8).withOpacity(0.80 * pulseOpacity),
          const Color(0xFF0EA5E9).withOpacity(0.58 * pulseOpacity),
          const Color(0xFF2563EB).withOpacity(0.35 * pulseOpacity),
          const Color(0xFF1D4ED8).withOpacity(0.0),
        ],
        stops: const [0.0, 0.08, 0.28, 0.58, 0.82, 1.0],
      ).createShader(const Rect.fromLTWH(10, -220, 240, 274));

      canvas.drawPath(beamPath, Paint()..shader = beamShader);

      // Bright Core Ray in Center of Beam
      final coreRay = Path()
        ..moveTo(126, 54)
        ..lineTo(75, -220)
        ..lineTo(185, -220)
        ..lineTo(134, 54)
        ..close();

      final coreShader = LinearGradient(
        begin: Alignment.bottomCenter,
        end: Alignment.topCenter,
        colors: [
          Colors.white.withOpacity(1.0 * pulseOpacity),
          Colors.white.withOpacity(0.95 * pulseOpacity),
          const Color(0xFFCFFAFE).withOpacity(0.88 * pulseOpacity),
          const Color(0xFF38BDF8).withOpacity(0.70 * pulseOpacity),
          const Color(0xFF0284C7).withOpacity(0.0),
        ],
        stops: const [0.0, 0.20, 0.50, 0.80, 1.0],
      ).createShader(const Rect.fromLTWH(75, -220, 110, 274));

      canvas.drawPath(coreRay, Paint()..shader = coreShader);

      // Ultra-Bright White Laser Needle
      final laserNeedle = Path()
        ..moveTo(129, 54)
        ..lineTo(118, -220)
        ..lineTo(142, -220)
        ..lineTo(131, 54)
        ..close();

      final needleShader = LinearGradient(
        begin: Alignment.bottomCenter,
        end: Alignment.topCenter,
        colors: [
          Colors.white.withOpacity(1.0 * pulseOpacity),
          Colors.white.withOpacity(0.98 * pulseOpacity),
          const Color(0xFFBAE6FD).withOpacity(0.75 * pulseOpacity),
          const Color(0xFF38BDF8).withOpacity(0.0),
        ],
        stops: const [0.0, 0.35, 0.70, 1.0],
      ).createShader(const Rect.fromLTWH(118, -220, 24, 274));

      canvas.drawPath(laserNeedle, Paint()..shader = needleShader);

      // Aperture Bloom and Lens Flare
      canvas.drawCircle(
        const Offset(130, 54),
        18,
        Paint()
          ..color = const Color(0xFF38BDF8).withOpacity(0.88 * pulseOpacity)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
      );
      canvas.drawCircle(
        const Offset(130, 54),
        8,
        Paint()..color = Colors.white.withOpacity(0.98 * pulseOpacity),
      );

      canvas.restore();
    }

    // 3. Moving Head Fixture Base (Stable)
    final bodyShader = const LinearGradient(
      begin: Alignment.centerLeft,
      end: Alignment.centerRight,
      colors: [Color(0xFF1E2530), Color(0xFF131922), Color(0xFF0A0D12)],
    );

    final baseRect = Rect.fromLTWH(88, 122, 84, 16);
    canvas.drawRRect(
      RRect.fromRectAndRadius(baseRect, const Radius.circular(4)),
      Paint()..shader = bodyShader.createShader(baseRect),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(baseRect, const Radius.circular(4)),
      Paint()
        ..color = const Color(0xFF2B3747)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.0,
    );

    // Top Chamfer Edge Highlight
    canvas.drawLine(
      const Offset(90, 123),
      const Offset(170, 123),
      Paint()
        ..color = const Color(0xFF475569)
        ..strokeWidth = 0.8,
    );

    // Base Rubber Feet
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(94, 137, 13, 4), const Radius.circular(1.5)),
      Paint()..color = const Color(0xFF06090D),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(153, 137, 13, 4), const Radius.circular(1.5)),
      Paint()..color = const Color(0xFF06090D),
    );

    // DMX Control Console Inset & Blue DMX Digital Address LCD Screen
    final consoleRect = Rect.fromLTWH(108, 125, 44, 11);
    canvas.drawRRect(
      RRect.fromRectAndRadius(consoleRect, const Radius.circular(2)),
      Paint()..color = const Color(0xFF070B13),
    );

    final lcdRect = Rect.fromLTWH(110, 126.5, 22, 8);
    canvas.drawRRect(
      RRect.fromRectAndRadius(lcdRect, const Radius.circular(1)),
      Paint()..color = const Color(0xFF040D1E),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(lcdRect, const Radius.circular(1)),
      Paint()
        ..color = const Color(0xFF2563EB)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.6,
    );

    // Status LEDs & 4 tactile buttons
    canvas.drawCircle(const Offset(134.5, 128.5), 1.1, Paint()..color = const Color(0xFF10B981));
    canvas.drawCircle(const Offset(134.5, 132.5), 0.9, Paint()..color = const Color(0xFFEF4444));
    canvas.drawCircle(const Offset(138.8, 128.5), 1.1, Paint()..color = const Color(0xFF94A3B8));
    canvas.drawCircle(const Offset(142.5, 128.5), 1.1, Paint()..color = const Color(0xFFCBD5E1));
    canvas.drawCircle(const Offset(146.2, 128.5), 1.1, Paint()..color = const Color(0xFFCBD5E1));
    canvas.drawCircle(const Offset(150.0, 128.5), 1.1, Paint()..color = const Color(0xFF38BDF8));

    // Rotating Yoke Pivot & Pan Ring
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(96, 117, 68, 6), const Radius.circular(2)),
      Paint()..color = const Color(0xFF131924),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(118, 112, 24, 6), const Radius.circular(1.5)),
      Paint()..color = const Color(0xFF1C2432),
    );

    // 4. Dual Yoke Heavy Arms
    final yokePaint = Paint()
      ..shader = bodyShader.createShader(const Rect.fromLTWH(95, 78, 70, 48))
      ..style = PaintingStyle.stroke
      ..strokeWidth = 13.0
      ..strokeCap = StrokeCap.round;

    final leftArm = Path()
      ..moveTo(102, 118)
      ..lineTo(102, 80)
      ..quadraticBezierTo(102, 72, 112, 72)
      ..lineTo(116, 72);
    canvas.drawPath(leftArm, yokePaint);

    final rightArm = Path()
      ..moveTo(158, 118)
      ..lineTo(158, 80)
      ..quadraticBezierTo(158, 72, 148, 72)
      ..lineTo(144, 72);
    canvas.drawPath(rightArm, yokePaint);

    // Yoke Arm Joint Pivot Caps
    canvas.drawCircle(const Offset(110, 78), 5.5, Paint()..color = const Color(0xFF0A0D12));
    canvas.drawCircle(const Offset(150, 78), 5.5, Paint()..color = const Color(0xFF0A0D12));

    // 5. Spherical Moving Head Light Body
    final headCenter = const Offset(130, 68);
    final headRect = Rect.fromCircle(center: headCenter, radius: 24);
    canvas.drawCircle(
      headCenter,
      24,
      Paint()..shader = bodyShader.createShader(headRect),
    );
    canvas.drawCircle(
      headCenter,
      24,
      Paint()
        ..color = const Color(0xFF263242)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.0,
    );

    // 6. Large Concentric Multi-Element Stage Projection Lens
    final lensCenter = const Offset(130, 54);
    canvas.drawCircle(lensCenter, 18, Paint()..color = const Color(0xFF0F172A));
    canvas.drawCircle(
      lensCenter,
      18,
      Paint()
        ..color = const Color(0xFF38BDF8)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.8,
    );

    // Vibrant Electric Blue / Cyan Stage Glow Inside Lens
    final lensShader = RadialGradient(
      center: Alignment.center,
      radius: 0.9,
      colors: const [
        Color(0xFFBFDBFE),
        Color(0xFF60A5FA),
        Color(0xFF2563EB),
        Color(0xFF1E3A8A),
      ],
      stops: const [0.0, 0.30, 0.70, 1.0],
    ).createShader(Rect.fromCircle(center: lensCenter, radius: 15));
    canvas.drawCircle(lensCenter, 15, Paint()..shader = lensShader);

    // Glass Reflection Arc on Lens
    final glassShader = const LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [Color(0xB3FFFFFF), Color(0x4093C5FD), Color(0xCC172554)],
    ).createShader(Rect.fromCircle(center: lensCenter, radius: 15));
    canvas.drawCircle(lensCenter, 15, Paint()..shader = glassShader);

    // Center Lens Bulb Filament Dot
    canvas.drawCircle(lensCenter, 4.0, Paint()..color = Colors.white);

    // Aperture Flare Ring in Night Mode
    if (isNightMode) {
      final pulseOpacity = (0.88 + sweepProgress * 0.12).clamp(0.75, 1.0);
      canvas.drawCircle(
        lensCenter,
        22.0,
        Paint()
          ..color = const Color(0xFF38BDF8).withOpacity(0.4 * pulseOpacity)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4.0),
      );
    }

    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _DmxStagePainter oldDelegate) =>
      oldDelegate.isNightMode != isNightMode ||
      oldDelegate.sweepProgress != sweepProgress;
}
