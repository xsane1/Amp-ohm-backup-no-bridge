import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../services/subscription_service.dart';
import '../services/mail_service.dart';

class SettingsModals {
  // 1. CONTACT US MODAL (Matching preview ContactModal.tsx)
  static void showContact(BuildContext context, {required bool isNight, required bool isHindi}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _ContactSheet(isNight: isNight, isHindi: isHindi),
    );
  }

  // 2. ABOUT MODAL (Matching preview AboutModal.tsx)
  static void showAbout(BuildContext context, {required bool isNight, required bool isHindi}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _AboutSheet(isNight: isNight, isHindi: isHindi),
    );
  }

  // 3. PRIVACY POLICY MODAL (Matching preview PrivacyPolicyModal.tsx)
  static void showPrivacy(BuildContext context, {required bool isNight, required bool isHindi}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _PrivacySheet(isNight: isNight, isHindi: isHindi),
    );
  }

  // 4. TERMS & CONDITIONS MODAL (Matching preview TermsConditionsModal.tsx)
  static void showTerms(BuildContext context, {required bool isNight, required bool isHindi}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _TermsSheet(isNight: isNight, isHindi: isHindi),
    );
  }

  // 5. DISCLAIMER MODAL (Matching preview DisclaimerModal.tsx)
  static void showDisclaimer(BuildContext context, {required bool isNight, required bool isHindi}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _DisclaimerSheet(isNight: isNight, isHindi: isHindi),
    );
  }

  // 6. FEEDBACK / REPORT ISSUE MODAL
  static void showFeedbackOrReport(
    BuildContext context, {
    required bool isNight,
    required bool isHindi,
    required bool isBugReport,
  }) {
    if (isBugReport) {
      MailService.reportIssue();
    } else {
      MailService.sendFeedback();
    }
  }
}

// ==========================================
// 1. CONTACT SHEET
// ==========================================
class _ContactSheet extends StatefulWidget {
  final bool isNight;
  final bool isHindi;

  const _ContactSheet({required this.isNight, required this.isHindi});

  @override
  State<_ContactSheet> createState() => _ContactSheetState();
}

class _ContactSheetState extends State<_ContactSheet> {
  final _emailController = TextEditingController();
  final _msgController = TextEditingController();
  bool _copied = false;
  String? _statusFeedback;
  bool _isSubmitting = false;
  bool _isVipSuccess = false;

  @override
  void dispose() {
    _emailController.dispose();
    _msgController.dispose();
    super.dispose();
  }

  void _copyEmail() {
    Clipboard.setData(const ClipboardData(text: 'audioxpert123@gmail.com'));
    setState(() => _copied = true);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(widget.isHindi ? 'ईमेल कॉपी हो गया: audioxpert123@gmail.com' : 'Email copied to clipboard: audioxpert123@gmail.com'),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _copied = false);
    });
  }

  void _submitInquiry() async {
    final email = _emailController.text.trim();
    final msg = _msgController.text.trim();
    if (email.isEmpty) return;

    setState(() {
      _isSubmitting = true;
      _statusFeedback = null;
    });

    final subService = Provider.of<SubscriptionService>(context, listen: false);
    final isVip = await subService.verifyFriendVip(email);

    if (mounted) {
      setState(() {
        _isSubmitting = false;
        _isVipSuccess = isVip;
        if (isVip) {
          _statusFeedback = widget.isHindi
              ? '✨ VIP सर्वर ऐक्सेस एक्टिवेट हो गया! (VIP Pro)'
              : '✨ Server VIP Entitlement Verified & Activated! (VIP Pro)';
        } else {
          _statusFeedback = widget.isHindi
              ? 'धन्यवाद! आपकी सहायता रिक्वेस्ट दर्ज कर ली गई है।'
              : 'Thank you! Your inquiry has been registered.';
          if (msg.isNotEmpty) {
            MailService.openMail(subject: 'AMP OHM Feedback', body: 'From: $email\n\n$msg');
          }
        }
      });
      _msgController.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    final isNight = widget.isNight;
    final isHindi = widget.isHindi;
    final bgColor = isNight ? const Color(0xFF141C30) : Colors.white;
    final cardBg = isNight ? const Color(0xFF0F1626) : const Color(0xFFF8FAFC);
    final borderColor = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final textColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final subColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.88),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(28),
            topRight: Radius.circular(28),
          ),
          border: Border.all(color: borderColor),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Drag Handle
            Center(
              child: Container(
                margin: const EdgeInsets.only(top: 10, bottom: 6),
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                  color: isNight ? Colors.white24 : Colors.black12,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),

            // Header
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 16, 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: const Color(0xFF2563EB).withOpacity(0.12),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.chat_bubble_outline_rounded, color: Color(0xFF2563EB), size: 18),
                      ),
                      const SizedBox(width: 10),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            isHindi ? 'संपर्क एवं सहायता' : 'Contact Us & Connect',
                            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: textColor),
                          ),
                          Text(
                            'AudioXpert Engineering Support',
                            style: TextStyle(fontSize: 11, color: subColor),
                          ),
                        ],
                      ),
                    ],
                  ),
                  IconButton(
                    icon: Icon(Icons.close_rounded, color: subColor, size: 20),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
            ),
            const Divider(height: 1),

            // Content
            Flexible(
              child: ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  // Direct Email Card
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: cardBg,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: borderColor),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: const Color(0xFF2563EB).withOpacity(0.12),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Icon(Icons.mail_rounded, color: Color(0xFF2563EB), size: 18),
                            ),
                            const SizedBox(width: 12),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  isHindi ? 'ऑफिशियल ईमेल' : 'OFFICIAL EMAIL',
                                  style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.bold, color: subColor, letterSpacing: 0.8),
                                ),
                                const SizedBox(height: 2),
                                const Text(
                                  'audioxpert123@gmail.com',
                                  style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.bold, color: Color(0xFF2563EB)),
                                ),
                              ],
                            ),
                          ],
                        ),
                        InkWell(
                          onTap: _copyEmail,
                          borderRadius: BorderRadius.circular(10),
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: isNight ? const Color(0xFF1E293B) : Colors.white,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: borderColor),
                            ),
                            child: Icon(
                              _copied ? Icons.check_rounded : Icons.copy_rounded,
                              size: 16,
                              color: _copied ? const Color(0xFF10B981) : subColor,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 14),

                  // Connect Section
                  Text(
                    isHindi ? 'सोशल मीडिया व कम्युनिटी' : 'CONNECT',
                    style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: subColor, letterSpacing: 1.1),
                  ),
                  const SizedBox(height: 8),

                  Row(
                    children: [
                      // Instagram
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: borderColor),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              Row(
                                children: [
                                  Icon(Icons.camera_alt_outlined, size: 16, color: Color(0xFFE1306C)),
                                  SizedBox(width: 6),
                                  Text('Instagram', style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold)),
                                ],
                              ),
                              SizedBox(height: 4),
                              Text('@audio_xpert', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFFE1306C))),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      // YouTube
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: borderColor),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: const [
                              Row(
                                children: [
                                  Icon(Icons.video_library_rounded, size: 16, color: Color(0xFFEF4444)),
                                  SizedBox(width: 6),
                                  Text('YouTube', style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold)),
                                ],
                              ),
                              SizedBox(height: 4),
                              Text('@audioxpertt', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Color(0xFFEF4444))),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // Quick Support & Inquiry Form
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: cardBg,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: borderColor),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          isHindi ? 'त्वरित सहायता व सुझाव' : 'Quick Support & Suggestions',
                          style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: textColor),
                        ),
                        const SizedBox(height: 10),

                        TextField(
                          controller: _emailController,
                          keyboardType: TextInputType.emailAddress,
                          style: TextStyle(fontSize: 12, color: textColor),
                          decoration: InputDecoration(
                            isDense: true,
                            hintText: isHindi ? 'आपका ईमेल (Email ID)' : 'Your email address',
                            hintStyle: TextStyle(fontSize: 11.5, color: subColor),
                            filled: true,
                            fillColor: isNight ? const Color(0xFF0A0F1D) : Colors.white,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(color: borderColor),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(color: borderColor),
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),

                        TextField(
                          controller: _msgController,
                          style: TextStyle(fontSize: 12, color: textColor),
                          decoration: InputDecoration(
                            isDense: true,
                            hintText: isHindi ? 'कोई सवाल या सुझाव लिखें...' : 'Type feedback or query...',
                            hintStyle: TextStyle(fontSize: 11.5, color: subColor),
                            filled: true,
                            fillColor: isNight ? const Color(0xFF0A0F1D) : Colors.white,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(color: borderColor),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(color: borderColor),
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),

                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            onPressed: _isSubmitting ? null : _submitInquiry,
                            icon: _isSubmitting
                                ? const SizedBox(
                                    width: 14,
                                    height: 14,
                                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                                  )
                                : const Icon(Icons.send_rounded, size: 14),
                            label: Text(
                              _isSubmitting
                                  ? (isHindi ? 'सत्यापित हो रहा है...' : 'Verifying...')
                                  : (isHindi ? 'सबमिट करें' : 'Submit'),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF2563EB),
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              textStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),

                        if (_statusFeedback != null) ...[
                          const SizedBox(height: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(
                              color: _isVipSuccess
                                  ? const Color(0xFF10B981).withOpacity(0.12)
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              _statusFeedback!,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                color: _isVipSuccess ? const Color(0xFF10B981) : const Color(0xFF10B981),
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),

                  const SizedBox(height: 14),

                  // Action Buttons: Send Feedback & Report Issue
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => MailService.sendFeedback(),
                          icon: const Icon(Icons.send_rounded, size: 14),
                          label: Text(isHindi ? 'फीडबैक भेजें' : 'Send Feedback'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF2563EB),
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            textStyle: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => MailService.reportIssue(),
                          icon: const Icon(Icons.error_outline_rounded, size: 14, color: Color(0xFFF59E0B)),
                          label: Text(
                            isHindi ? 'समस्या रिपोर्ट करें' : 'Report Issue',
                            style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold, color: textColor),
                          ),
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(color: borderColor),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                            padding: const EdgeInsets.symmetric(vertical: 10),
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 14),
                  Center(
                    child: Text(
                      'Developed by AudioXpert',
                      style: TextStyle(fontSize: 11, color: subColor, fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// 2. ABOUT SHEET
// ==========================================
class _AboutSheet extends StatelessWidget {
  final bool isNight;
  final bool isHindi;

  const _AboutSheet({required this.isNight, required this.isHindi});

  @override
  Widget build(BuildContext context) {
    final bgColor = isNight ? const Color(0xFF141C30) : Colors.white;
    final cardBg = isNight ? const Color(0xFF0F1626) : const Color(0xFFF8FAFC);
    final borderColor = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final textColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final subColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    return Container(
      constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.85),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(28),
          topRight: Radius.circular(28),
        ),
        border: Border.all(color: borderColor),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Center(
            child: Container(
              margin: const EdgeInsets.only(top: 10, bottom: 6),
              width: 36,
              height: 4,
              decoration: BoxDecoration(
                color: isNight ? Colors.white24 : Colors.black12,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 16, 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: const Color(0xFF2563EB).withOpacity(0.12),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(Icons.info_outline_rounded, color: Color(0xFF2563EB), size: 18),
                    ),
                    const SizedBox(width: 10),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          isHindi ? 'AMP OHM के बारे में' : 'About AMP OHM',
                          style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: textColor),
                        ),
                        Text(
                          'Audio & Lighting Tools',
                          style: TextStyle(fontSize: 11, color: subColor),
                        ),
                      ],
                    ),
                  ],
                ),
                IconButton(
                  icon: Icon(Icons.close_rounded, color: subColor, size: 20),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
          ),
          const Divider(height: 1),

          Flexible(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                // App Name & Version
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: cardBg,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: borderColor),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'AMP OHM',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Color(0xFF2563EB)),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: const Color(0xFF2563EB),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: const Text(
                              'App Version 1.0.4',
                              style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.white),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            isHindi ? 'ऑडियो एवं लाइटिंग टूल्स' : 'Audio & Lighting Tools',
                            style: TextStyle(fontSize: 11, color: subColor),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 12),

                // Developer Information
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: cardBg,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: borderColor),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        isHindi ? 'डेवलपर जानकारी' : 'DEVELOPER INFORMATION',
                        style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: subColor, letterSpacing: 0.8),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Developed by AudioXpert',
                        style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: textColor),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        isHindi
                            ? 'लाइव साउंड इंजीनियर्स, डीजे, स्टेज ऑपरेटर्स और लाइटिंग तकनीशियनों के लिए समर्पित टूलकिट।'
                            : 'Dedicated professional suite crafted for live sound engineers, DJs, festival crews, and stage technicians.',
                        style: TextStyle(fontSize: 12, height: 1.4, color: subColor),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 12),

                // Connect
                Text(
                  isHindi ? 'कनेक्ट करें' : 'CONNECT',
                  style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: subColor, letterSpacing: 1.1),
                ),
                const SizedBox(height: 8),

                _buildAboutConnectRow(Icons.camera_alt_outlined, 'Instagram', '@audio_xpert', const Color(0xFFE1306C), cardBg, borderColor),
                const SizedBox(height: 6),
                _buildAboutConnectRow(Icons.video_library_rounded, 'YouTube', '@audioxpertt', const Color(0xFFEF4444), cardBg, borderColor),
                const SizedBox(height: 6),
                _buildAboutConnectRow(Icons.mail_outline_rounded, 'Email', 'audioxpert123@gmail.com', const Color(0xFF2563EB), cardBg, borderColor),
              ],
            ),
          ),
        ],
      ),
    );
  }

  static Widget _buildAboutConnectRow(IconData icon, String label, String handle, Color accent, Color bg, Color border) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: border),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Icon(icon, size: 16, color: accent),
              const SizedBox(width: 8),
              Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
            ],
          ),
          Text(handle, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.bold, color: accent)),
        ],
      ),
    );
  }
}

// ==========================================
// 3. PRIVACY POLICY SHEET
// ==========================================
// ==========================================
// 3. PRIVACY POLICY SHEET
// ==========================================
class _PrivacySheet extends StatelessWidget {
  final bool isNight;
  final bool isHindi;

  const _PrivacySheet({required this.isNight, required this.isHindi});

  @override
  Widget build(BuildContext context) {
    final bgColor = isNight ? const Color(0xFF141C30) : Colors.white;
    final cardBg = isNight ? const Color(0xFF0F1626) : const Color(0xFFF8FAFC);
    final borderColor = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final textColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final subColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    return Container(
      constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.88),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(28),
          topRight: Radius.circular(28),
        ),
        border: Border.all(color: borderColor),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Center(
            child: Container(
              margin: const EdgeInsets.only(top: 10, bottom: 6),
              width: 36,
              height: 4,
              decoration: BoxDecoration(
                color: isNight ? Colors.white24 : Colors.black12,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 16, 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: const Color(0xFF10B981).withOpacity(0.12),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(Icons.shield_outlined, color: Color(0xFF10B981), size: 18),
                    ),
                    const SizedBox(width: 10),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Privacy Policy',
                          style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: textColor),
                        ),
                        Text(
                          'Amp Ohm Data & Privacy Standards',
                          style: TextStyle(fontSize: 11, color: subColor),
                        ),
                      ],
                    ),
                  ],
                ),
                IconButton(
                  icon: Icon(Icons.close_rounded, color: subColor, size: 20),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
          ),
          const Divider(height: 1),

          Flexible(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
              children: [
                // Highlight Box: On-Device Processing
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF10B981).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFF10B981).withOpacity(0.3)),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(Icons.lock_outline_rounded, color: Color(0xFF10B981), size: 18),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'Privacy by Design: All audio and lighting calculation formulas execute strictly locally in volatile device memory (RAM). Zero calculation inputs or project specifications are transmitted to external servers.',
                          style: const TextStyle(fontSize: 11.5, color: Color(0xFF10B981), fontWeight: FontWeight.w600, height: 1.35),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // 1. Introduction
                _buildPolicyBlock(
                  '1. Introduction',
                  'Amp Ohm is developed by AudioXpert to provide audio engineers, sound operators, DJs, and stage lighting technicians with reliable, fast mathematical calculators and utility tools. These include loudspeaker impedance (Series, Parallel, and Series-Parallel), amplifier power and headroom matching, top speaker array loading, speaker cable resistance and voltage drop, and DMX 512 fixture addressing. We respect your privacy and are committed to complete transparency regarding how data is handled when you use the application.',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 14),

                // 2. Information and Data Handling
                _buildPolicyBlock(
                  '2. Information and Data Handling',
                  'To provide full clarity, we distinguish how different categories of data are processed:\n\n'
                  '• Calculator Inputs & Outputs: Any numerical parameters entered into calculators (such as wattage ratings, speaker impedances, driver quantities, cable run distances, wire gauges, or DMX channels) are processed transiently in device RAM. They are not recorded in remote databases, uploaded to servers, or linked to your identity.\n\n'
                  '• Locally Stored On-Device Preferences: Amp Ohm utilizes secure on-device sandboxed storage (SharedPreferences) solely for basic operational preferences. This includes your theme choice (Night Mode / Light Mode), language preference, a temporary 60-minute rewarded ad pass expiration timestamp (ampohm_reward_pass_expiry_ms), cached subscription entitlement status (rc_is_premium, rc_active_tier, rc_expiration_date) to allow seamless offline launches, and optional VIP verification email (vip_verified_email) if you enter an authorized VIP pass.\n\n'
                  '• Information Collected by Third-Party SDKs: Third-party SDKs integrated into the app (Google AdMob, Google Play Billing, RevenueCat, and Firebase) collect standardized telemetry and anonymous device identifiers necessary to deliver advertising, process in-app purchases, verify entitlements, and retrieve remote configuration flags.\n\n'
                  '• Data Amp Ohm Itself Collects: Amp Ohm does not require account creation, user registration, social login, passwords, telephone numbers, or profile creation. We do not maintain user accounts or personal profiles on our servers.',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 14),

                // 3. Calculator Data
                _buildPolicyBlock(
                  '3. Calculator Data',
                  'All mathematical calculations and formulas run entirely on your local device. Your audio rig configurations, stage setups, speaker wiring combinations, and calculation results remain strictly on your phone. No project files, calculation histories, or technical schematics are transmitted to AudioXpert or any third party.',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 14),

                // 4. Advertising (Google AdMob)
                _buildPolicyBlock(
                  '4. Advertising (Google AdMob)',
                  'The free version of Amp Ohm is supported by advertising delivered via Google AdMob (Google LLC). The implemented ad formats are:\n\n'
                  '• Banner Ads: Non-intrusive banner advertisements displayed at the bottom of calculation result screens for free-tier users.\n\n'
                  '• Rewarded Video Ads: User-initiated, opt-in rewarded video ads. When you use a calculator, you can voluntarily choose to watch a short video ad to unlock a full 60-minute ad-free pass across all calculators in the app.\n\n'
                  '• Ad-Free Experience for Subscribers: Active Amp Ohm Pro subscribers receive a completely ad-free experience; all banner ads and rewarded video prompts are disabled throughout the entire app.\n\n'
                  '• Data Processing by Google AdMob: Google Mobile Ads SDK may automatically collect and process anonymous device identifiers (such as Google Advertising ID / AAID on Android), IP addresses for approximate geographic location and fraud prevention, device hardware specifications, and ad interaction metrics.\n\n'
                  'To learn how Google collects and uses advertising data, please review Google’s Privacy & Terms: https://policies.google.com/technologies/ads',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 14),

                // 5. In-App Purchases & Subscriptions
                _buildPolicyBlock(
                  '5. In-App Purchases & Subscriptions (Google Play & RevenueCat)',
                  'Amp Ohm offers an optional "Amp Ohm Pro" upgrade providing 100% ad-free usage and unrestricted access to all calculators and export tools.\n\n'
                  '• Payment Processing by Google Play: All subscription purchases and billing transactions are processed exclusively through Google Play Billing (Google LLC). AudioXpert and Amp Ohm never collect, view, process, or store your payment cards, bank account details, UPI credentials, or financial information.\n\n'
                  '• Subscription Verification via RevenueCat: We integrate the RevenueCat SDK (RevenueCat, Inc.) to validate store receipts, manage subscription states, verify the active "ampohm Pro" entitlement, and support purchase restorations. RevenueCat processes an anonymous app user identifier and receipt tokens generated by Google Play.\n\n'
                  '• Available Subscription Plans: Options include Pro Monthly (ampohm_pro_monthly, fallback ₹49 / Month) and Pro Yearly (ampohm_pro_annual, fallback ₹399 / Year) auto-renewing subscriptions.\n\n'
                  '• Automatic Renewal: Recurring monthly and yearly subscriptions automatically renew through Google Play unless cancelled by the user at least 24 hours prior to the end of the current billing cycle.\n\n'
                  '• Cancellation: Subscriptions may be cancelled at any time directly through Google Play Store (Account > Payments & subscriptions > Subscriptions).\n\n'
                  '• Access Following Cancellation: Cancelling auto-renewal stops future billing; your Pro entitlement remains active and completely ad-free until the verified expiration date of the currently paid billing period.\n\n'
                  '• Purchase Restoration: You can restore an active subscription on any device using the same Google Play account by tapping "Restore Purchases" in the app.',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 14),

                // 6. Data Security
                _buildPolicyBlock(
                  '6. Data Security',
                  'We take reasonable and appropriate technical measures to safeguard application operations. All external network communications (Google Play Billing, RevenueCat entitlement checks, Google AdMob ad requests, and Firebase remote config lookups) occur exclusively over encrypted HTTPS/TLS connections. Device preferences are stored within sandboxed operating system storage. While we implement industry-standard practices, no electronic transmission or local mobile storage can be guaranteed to be 100% secure.',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 14),

                // 7. Children’s Privacy
                _buildPolicyBlock(
                  '7. Children’s Privacy',
                  'Amp Ohm is a professional calculation and engineering utility designed specifically for audio engineers, sound technicians, DJs, and stage electricians. The application is not directed to or intended for children under 13 years of age. We do not knowingly collect or solicit personal information from children under 13.',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 14),

                // 8. Third-Party Services
                _buildPolicyBlock(
                  '8. Third-Party Services',
                  'The application utilizes strictly the following verified third-party services:\n\n'
                  '• Google AdMob (Google LLC) – Advertising delivery and monetization for free-tier users.\n'
                  '• Google Play Billing (Google LLC) – In-app purchase and subscription payment processing.\n'
                  '• RevenueCat (RevenueCat, Inc.) – Subscription entitlement management and receipt verification.\n'
                  '• Google Firebase / Cloud Firestore (Google LLC) – Anonymous read-only remote configuration checks (app_config/ads_settings and app_config/version_control) and optional VIP pass verification.',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 14),

                // 9. Changes to This Privacy Policy
                _buildPolicyBlock(
                  '9. Changes to This Privacy Policy',
                  'AudioXpert may update this Privacy Policy from time to time to reflect operational, legal, or regulatory updates. The most current version will always be accessible directly through the application’s Settings & Information section. Continued use of Amp Ohm following any revisions indicates your acknowledgment and acceptance of the updated policy.',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 14),

                // 10. Contact Information
                _buildPolicyBlock(
                  '10. Contact Information',
                  'If you have any questions, concerns, or inquiries regarding this Privacy Policy or data handling in Amp Ohm, please contact AudioXpert directly at:\n\nEmail: audioxpert123@gmail.com',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 10),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPolicyBlock(String title, String body, Color titleColor, Color bodyColor) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: titleColor),
        ),
        const SizedBox(height: 5),
        Text(
          body,
          style: TextStyle(fontSize: 12, height: 1.48, color: bodyColor),
        ),
      ],
    );
  }
}

// ==========================================
// 4. TERMS & CONDITIONS SHEET
// ==========================================
class _TermsSheet extends StatelessWidget {
  final bool isNight;
  final bool isHindi;

  const _TermsSheet({required this.isNight, required this.isHindi});

  @override
  Widget build(BuildContext context) {
    final bgColor = isNight ? const Color(0xFF141C30) : Colors.white;
    final borderColor = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final textColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final subColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    return Container(
      constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.88),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(28),
          topRight: Radius.circular(28),
        ),
        border: Border.all(color: borderColor),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Center(
            child: Container(
              margin: const EdgeInsets.only(top: 10, bottom: 6),
              width: 36,
              height: 4,
              decoration: BoxDecoration(
                color: isNight ? Colors.white24 : Colors.black12,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 16, 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: const Color(0xFF2563EB).withOpacity(0.12),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(Icons.gavel_rounded, color: Color(0xFF2563EB), size: 18),
                    ),
                    const SizedBox(width: 10),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Terms & Conditions',
                          style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: textColor),
                        ),
                        Text(
                          'Amp Ohm Application Terms & Agreement',
                          style: TextStyle(fontSize: 11, color: subColor),
                        ),
                      ],
                    ),
                  ],
                ),
                IconButton(
                  icon: Icon(Icons.close_rounded, color: subColor, size: 20),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
          ),
          const Divider(height: 1),

          Flexible(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
              children: [
                // Highlight Warning Box
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF2563EB).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFF2563EB).withOpacity(0.3)),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(Icons.shield_outlined, color: Color(0xFF2563EB), size: 18),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'Important Operational Notice: Amp Ohm provides mathematical reference calculations for sound and lighting systems. Always independently verify physical equipment ratings, minimum impedance loads, and manufacturer limits prior to live audio operation.',
                          style: const TextStyle(fontSize: 11.5, color: Color(0xFF2563EB), fontWeight: FontWeight.w600, height: 1.35),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // 1. Acceptance of Terms
                _buildTermBlock(
                  '1. Acceptance of Terms',
                  'By downloading, installing, accessing, or using the Amp Ohm mobile application, you agree to be bound by these Terms & Conditions. If you do not agree to these terms, please do not use and immediately uninstall the application.',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 14),

                // 2. About Amp Ohm
                _buildTermBlock(
                  '2. About Amp Ohm',
                  'Amp Ohm is an audio and lighting engineering calculation utility application developed by AudioXpert. It is designed to assist sound engineers, audio operators, stage technicians, DJs, and lighting professionals with system design, loudspeaker impedance matching, amplifier power recommendations, cable voltage drop estimations, and DMX 512 fixture addressing.',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 14),

                // 3. Permitted Use & License
                _buildTermBlock(
                  '3. Permitted Use & License',
                  'AudioXpert grants you a personal, non-exclusive, non-transferable, revocable, limited license to use Amp Ohm for lawful commercial, professional, and educational reference purposes in accordance with these Terms.\n\n'
                  'You agree not to: (a) reverse engineer, decompile, disassemble, or attempt to derive the source code of the application; (b) modify, copy, adapt, or create derivative works; (c) rent, lease, sublicense, resell, or redistribute the application; or (d) use the application in violation of any applicable local, national, or international regulations.',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 14),

                // 4. Calculator Accuracy and Limitations
                _buildTermBlock(
                  '4. Calculator Accuracy and Limitations',
                  '• Theoretical Estimates: All calculations provided by Amp Ohm (including speaker impedance, power matching, cable losses, and DMX dip-switch addressing) are mathematical estimates based on ideal engineering formulas and the specific numerical inputs provided by the user.\n\n'
                  '• Real-World Variance: Actual performance in live event environments may vary significantly due to physical equipment manufacturing tolerances, dynamic speaker impedance fluctuations with frequency, voice coil heating and power compression, AC mains voltage variations, cable strand resistance, and environmental factors (such as ambient temperature and humidity).\n\n'
                  '• Independent Verification Required: Calculation outputs do not constitute certified engineering blueprints or manufacturer-approved system designs. Users must independently verify critical calculations with manufacturer specification sheets, calibrated multimeters, and impedance meters.\n\n'
                  '• Professional Advice: Amp Ohm is a reference tool and does not substitute for certified acoustic consulting, licensed electrical engineering, or professional sound system commissioning.',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 14),

                // 5. Audio Equipment Safety & Warnings
                _buildTermBlock(
                  '5. Audio Equipment Safety & Warnings',
                  'Live sound reinforcement involves substantial electrical voltages and acoustic energy. You must observe the following precautions:\n\n'
                  '• Amplifier Impedance Limits: Parallel speaker wiring reduces total electrical impedance. Operating an amplifier into a load below its manufacturer-rated minimum impedance (e.g., running below 2Ω or 4Ω ratings) can trigger thermal protection shutdown, blown fuses, or permanent output transistor failure.\n\n'
                  '• Power Ratings & Clipping: Always respect the continuous RMS power ratings of speakers and amplifiers. Driving amplifiers into sustained clipping generates severe harmonic distortion and square waves that rapidly overheat and destroy loudspeaker voice coils and high-frequency compression drivers.\n\n'
                  '• Speaker Wiring & Polarity: Ensure all Series, Parallel, or combined wiring harnesses are terminated with correct phase and polarity. Reversed polarity causes acoustic cancellation, while wiring short circuits can instantly damage power amplifiers.\n\n'
                  '• Speaker Cable Selection: Select speaker cables with sufficient cross-sectional conductor area (AWG / mm²) for the cable run length and current load. Undersized cables cause high resistance, excessive voltage drop, cable heating, and degradation of amplifier damping factor.\n\n'
                  '• Electrical Mains & Grounding: Stage power distribution must comply with electrical safety standards, proper circuit breaker ratings, and solid earth grounding. Never defeat equipment ground pins.\n\n'
                  '• Acoustic Safety & Hearing Protection: High Sound Pressure Levels (SPL) produced by sound systems can cause permanent, irreversible hearing damage. Users are responsible for adhering to safe acoustic exposure limits.\n\n'
                  '• No Safety Guarantee: Amp Ohm does NOT guarantee the physical safety, electrical compliance, or damage-free operation of your sound reinforcement or lighting hardware.',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 14),

                // 6. User Responsibility
                _buildTermBlock(
                  '6. User Responsibility',
                  'You bear full and sole responsibility for: (a) verifying the accuracy and appropriateness of all values entered into the calculators; (b) inspecting and verifying the physical capabilities of all connected hardware; (c) ensuring compliance with manufacturer operational guidelines and safety codes; and (d) all outcomes, equipment configurations, and sound setups resulting from reliance on the application.',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 14),

                // 7. Ads and Rewarded Video
                _buildTermBlock(
                  '7. Ads and Rewarded Video Pass',
                  '• Free Version Advertisements: The free edition of Amp Ohm displays non-intrusive banner advertisements on calculation result screens.\n\n'
                  '• Rewarded Video Pass: Free-tier users can voluntarily choose to watch an opt-in Google AdMob rewarded video ad via the calculator unlock prompt. Successfully finishing the video ad grants a temporary 60-minute pass that unlocks all calculators and disables advertisements across the entire app for that period.\n\n'
                  '• Ad Availability: Ad delivery depends on network connectivity and third-party ad inventory.\n\n'
                  '• Remote Control: Ad frequency, formats, and killswitch toggles may be adjusted remotely by the developer via remote configuration.',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 14),

                // 8. Amp Ohm Pro Subscriptions
                _buildTermBlock(
                  '8. Amp Ohm Pro Subscriptions & In-App Purchases',
                  '• Pro Benefits: Amp Ohm Pro membership grants 100% ad-free usage and unrestricted, immediate access to all calculators and export tools.\n\n'
                  '• Available Subscription Plans: Pro access is available through Monthly recurring (ampohm_pro_monthly) and Yearly recurring (ampohm_pro_annual) subscriptions as shown in the in-app paywall.\n\n'
                  '• Billing & Payment: Subscription payments are billed to your Google Play account upon purchase confirmation.\n\n'
                  '• Automatic Renewal: Monthly and Yearly subscriptions renew automatically through Google Play unless cancelled at least 24 hours prior to the end of the current billing cycle.\n\n'
                  '• Cancellation: You may cancel your subscription at any time through Google Play Store (Account > Payments & subscriptions > Subscriptions).\n\n'
                  '• Access Following Cancellation: Cancelling auto-renewal prevents future charges; your Pro entitlement remains active and completely ad-free until the verified expiration date of the currently paid billing period.\n\n'
                  '• Expiration: When the paid entitlement period expires, the application automatically returns to standard free-user rules.\n\n'
                  '• Restore Purchases: You can restore valid purchases made with the same Google Play account across reinstalls or device changes using the "Restore Purchases" feature.',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 14),

                // 9. Refunds
                _buildTermBlock(
                  '9. Refunds',
                  'All subscription payments and billing transactions are processed by Google Play and are governed by applicable Google Play refund policies. AudioXpert does not directly handle, process, or guarantee refunds. To request a refund, please submit your request directly to Google Play Support according to their terms.',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 14),

                // 10. Intellectual Property
                _buildTermBlock(
                  '10. Intellectual Property',
                  'All software code, visual interface designs, graphics, branding, logos, calculation formulas, and content within Amp Ohm are the proprietary intellectual property of AudioXpert and are protected by applicable copyright, trademark, and intellectual property laws. All rights not expressly granted herein are reserved.',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 14),

                // 11. Limitation of Liability
                _buildTermBlock(
                  '11. Limitation of Liability',
                  'To the maximum extent permitted by applicable law, AudioXpert, its developers, affiliates, and licensors shall not be held liable for any direct, indirect, incidental, special, punitive, or consequential damages whatsoever (including, without limitation, burned voice coils, damaged loudspeakers, amplifier thermal failure, destroyed cables, stage electrical accidents, bodily injury, lost profits, event cancellation, or business interruption) arising out of or related to the use of, or inability to use, the application or reliance on its calculation results.',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 14),

                // 12. Changes to the Application or Terms
                _buildTermBlock(
                  '12. Changes to the Application or Terms',
                  'AudioXpert reserves the right to modify, enhance, or temporarily suspend features of the application or update these Terms & Conditions at any time. Updated terms will be made accessible within the application. Your continued use of Amp Ohm following any update constitutes your agreement to the modified terms.',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 14),

                // 13. Contact Information
                _buildTermBlock(
                  '13. Contact Information',
                  'For any questions or legal inquiries regarding these Terms & Conditions, please contact AudioXpert at:\n\nEmail: audioxpert123@gmail.com',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 10),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTermBlock(String title, String body, Color titleColor, Color bodyColor) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: titleColor),
        ),
        const SizedBox(height: 5),
        Text(
          body,
          style: TextStyle(fontSize: 12, height: 1.48, color: bodyColor),
        ),
      ],
    );
  }
}

// ==========================================
// 5. DISCLAIMER SHEET
// ==========================================
class _DisclaimerSheet extends StatelessWidget {
  final bool isNight;
  final bool isHindi;

  const _DisclaimerSheet({required this.isNight, required this.isHindi});

  @override
  Widget build(BuildContext context) {
    final bgColor = isNight ? const Color(0xFF141C30) : Colors.white;
    final borderColor = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final textColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final subColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);

    return Container(
      constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.85),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(28),
          topRight: Radius.circular(28),
        ),
        border: Border.all(color: borderColor),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Center(
            child: Container(
              margin: const EdgeInsets.only(top: 10, bottom: 6),
              width: 36,
              height: 4,
              decoration: BoxDecoration(
                color: isNight ? Colors.white24 : Colors.black12,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 16, 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF59E0B).withOpacity(0.12),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(Icons.warning_amber_rounded, color: Color(0xFFF59E0B), size: 18),
                    ),
                    const SizedBox(width: 10),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          isHindi ? 'डिस्क्लेमर (सावधानी)' : 'Technical Disclaimer',
                          style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: textColor),
                        ),
                        Text(
                          'Equipment Safety & Operational Notice',
                          style: TextStyle(fontSize: 11, color: subColor),
                        ),
                      ],
                    ),
                  ],
                ),
                IconButton(
                  icon: Icon(Icons.close_rounded, color: subColor, size: 20),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
          ),
          const Divider(height: 1),

          Flexible(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF59E0B).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFFF59E0B).withOpacity(0.3)),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.shield_outlined, color: Color(0xFFF59E0B), size: 18),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          isHindi
                              ? 'यह ऐप एक गाइड और कैलकुलेटर है। लाइव सेटअप चालू करने से पहले हमेशा एम्पलीफायर के लोड रेटिंग और स्पीकर के असली RMS व ओह्म की पुष्टि करें।'
                              : 'This app is an engineering calculation tool. Always verify physical amplifier specs, 2-ohm stability ratings, and genuine RMS limits before powering up.',
                          style: const TextStyle(fontSize: 11.5, color: Color(0xFFB45309), fontWeight: FontWeight.w600),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),

                _buildDisclaimerItem(
                  isHindi ? 'एम्पलीफायर क्लिपिंग व कॉइल बर्निंग' : 'Amplifier Clipping & Voice Coil Burning',
                  isHindi
                      ? 'कम पावर का एम्पलीफायर भी अगर रेड क्लिप (Distortion) में चलाया जाए तो स्क्वायर वेव बनने से स्पीकर की कॉइल जल सकती है। हमेशा साफ सिग्नल और उचित हेडरुम रखें।'
                      : 'Underpowered amplifiers driven into sustained square-wave clipping will destroy speaker voice coils just as easily as overpowering. Maintain clean headroom.',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 12),
                _buildDisclaimerItem(
                  isHindi ? '2Ω से कम लोड की चेतावनी' : 'Sub-2 Ohm Extreme Loads',
                  isHindi
                      ? '2Ω से नीचे लोड डालने पर अधिकांश एम्पलीफायर ओवरहीट होकर प्रोटेक्ट मोड में चले जाते हैं या उनके ट्रांजिस्टर शॉर्ट हो सकते हैं। इसे पूरी तरह टालें।'
                      : 'Loads below 2.0 ohms draw extreme current and can force amplifiers into thermal shutdown or permanent short-circuit failure. Strictly avoid sub-2Ω loading.',
                  textColor,
                  subColor,
                ),
                const SizedBox(height: 12),
                _buildDisclaimerItem(
                  isHindi ? 'सीमित देयता (Liability)' : 'Limitation of Liability',
                  isHindi
                      ? 'AudioXpert या डेवलपर उपकरण की किसी भी भौतिक क्षति, थर्मल डैमेज या इवेंट में रुकावट के लिए उत्तरदायी नहीं होंगे।'
                      : 'AudioXpert shall not be held liable for any hardware damage, burned coils, blown amplifier channels, or gig disruptions.',
                  textColor,
                  subColor,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDisclaimerItem(String title, String body, Color titleColor, Color bodyColor) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: titleColor)),
        const SizedBox(height: 4),
        Text(body, style: TextStyle(fontSize: 12, height: 1.45, color: bodyColor)),
      ],
    );
  }
}

// ==========================================
// 6. FEEDBACK / REPORT ISSUE SHEET
// ==========================================
class _FeedbackOrReportSheet extends StatefulWidget {
  final bool isNight;
  final bool isHindi;
  final bool isBugReport;

  const _FeedbackOrReportSheet({
    required this.isNight,
    required this.isHindi,
    required this.isBugReport,
  });

  @override
  State<_FeedbackOrReportSheet> createState() => _FeedbackOrReportSheetState();
}

class _FeedbackOrReportSheetState extends State<_FeedbackOrReportSheet> {
  final _textController = TextEditingController();
  bool _submitted = false;

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  void _sendDirectEmail() {
    final subject = widget.isBugReport ? 'AMP OHM Bug Report' : 'AMP OHM Feedback';
    final body = _textController.text.trim();
    MailService.openMail(subject: subject, body: body);
    setState(() => _submitted = true);
    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) Navigator.pop(context);
    });
  }

  @override
  Widget build(BuildContext context) {
    final isNight = widget.isNight;
    final isHindi = widget.isHindi;
    final isBug = widget.isBugReport;
    final bgColor = isNight ? const Color(0xFF141C30) : Colors.white;
    final cardBg = isNight ? const Color(0xFF0F1626) : const Color(0xFFF8FAFC);
    final borderColor = isNight ? const Color(0xFF1E293B) : const Color(0xFFE2E8F0);
    final textColor = isNight ? Colors.white : const Color(0xFF0F172A);
    final subColor = isNight ? const Color(0xFF94A3B8) : const Color(0xFF64748B);
    final accentColor = isBug ? const Color(0xFFF59E0B) : const Color(0xFF10B981);

    final title = isBug
        ? (isHindi ? 'समस्या रिपोर्ट करें (Bug Report)' : 'Report Issue / Bug')
        : (isHindi ? 'फीडबैक भेजें (Send Feedback)' : 'Send Feedback & Suggestions');
    final subtitle = isBug
        ? (isHindi ? 'कोई बग या गणना में कमी बताएं' : 'Report bugs or formula issues')
        : (isHindi ? 'अपने सुझाव और अनुभव साझा करें' : 'Share your ideas & suggestions');

    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.85),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(28),
            topRight: Radius.circular(28),
          ),
          border: Border.all(color: borderColor),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Center(
              child: Container(
                margin: const EdgeInsets.only(top: 10, bottom: 6),
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                  color: isNight ? Colors.white24 : Colors.black12,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 16, 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: accentColor.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(isBug ? Icons.bug_report_rounded : Icons.send_rounded, color: accentColor, size: 18),
                      ),
                      const SizedBox(width: 10),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(title, style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: textColor)),
                          Text(subtitle, style: TextStyle(fontSize: 11, color: subColor)),
                        ],
                      ),
                    ],
                  ),
                  IconButton(
                    icon: Icon(Icons.close_rounded, color: subColor, size: 20),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
            ),
            const Divider(height: 1),

            Flexible(
              child: ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: cardBg,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: borderColor),
                    ),
                    child: Row(
                      children: const [
                        Icon(Icons.mail_outline_rounded, color: Color(0xFF2563EB), size: 18),
                        SizedBox(width: 8),
                        Text(
                          'Direct to: audioxpert123@gmail.com',
                          style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Color(0xFF2563EB)),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),

                  TextField(
                    controller: _textController,
                    maxLines: 5,
                    style: TextStyle(fontSize: 12, color: textColor),
                    decoration: InputDecoration(
                      hintText: isBug
                          ? (isHindi ? 'कैलकुलेटर का नाम और क्या समस्या आई यहाँ लिखें...' : 'Describe the bug, screen or wrong calculation...')
                          : (isHindi ? 'अपनी राय, नया फीचर या सुझाव यहाँ लिखें...' : 'Share what you like or new features you want...'),
                      hintStyle: TextStyle(fontSize: 11.5, color: subColor),
                      filled: true,
                      fillColor: isNight ? const Color(0xFF0A0F1D) : Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: BorderSide(color: borderColor),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: BorderSide(color: borderColor),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),

                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _sendDirectEmail,
                      icon: Icon(_submitted ? Icons.check_circle_rounded : Icons.send_rounded, size: 16),
                      label: Text(_submitted
                          ? (isHindi ? 'ईमेल खुल रहा है...' : 'Opening Email...')
                          : (isHindi ? 'सीधे ईमेल में भेजें' : 'Send Directly to Email')),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: accentColor,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        textStyle: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
