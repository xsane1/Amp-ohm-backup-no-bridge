import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PreferenceService extends ChangeNotifier {
  static const String _localeKey = 'proaudio_app_locale';
  static const String _nightModeKey = 'app_is_night_mode';

  Locale _locale = const Locale('en', '');
  bool _isNightMode = false;

  Locale get locale => _locale;
  bool get isNightMode => _isNightMode;
  bool get isHindi => _locale.languageCode == 'hi';

  Future<void> init() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final languageCode = prefs.getString(_localeKey);
      if (languageCode == 'hi' || languageCode == 'en') {
        _locale = Locale(languageCode!, '');
      }
      _isNightMode = prefs.getBool(_nightModeKey) ?? false;
      notifyListeners();
    } catch (_) {
      // Default to English & light mode on error
    }
  }

  Future<void> setLocale(Locale newLocale) async {
    if (_locale == newLocale) return;
    _locale = newLocale;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_localeKey, newLocale.languageCode);
    } catch (_) {}
  }

  Future<void> toggleTheme() async {
    _isNightMode = !_isNightMode;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_nightModeKey, _isNightMode);
    } catch (_) {}
  }

  Future<void> setNightMode(bool value) async {
    if (_isNightMode == value) return;
    _isNightMode = value;
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_nightModeKey, _isNightMode);
    } catch (_) {}
  }
}
