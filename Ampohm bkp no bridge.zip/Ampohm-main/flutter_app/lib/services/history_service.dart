import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HistoryItem {
  final String id;
  final String title;
  final String subtitle;
  final String calculatorId;
  final DateTime timestamp;
  final Map<String, dynamic>? payload;

  HistoryItem({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.calculatorId,
    required this.timestamp,
    this.payload,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'subtitle': subtitle,
    'calculatorId': calculatorId,
    'timestamp': timestamp.toIso8601String(),
    if (payload != null) 'payload': payload,
  };

  factory HistoryItem.fromJson(Map<String, dynamic> json) => HistoryItem(
    id: json['id'] as String? ?? '',
    title: json['title'] as String? ?? '',
    subtitle: json['subtitle'] as String? ?? '',
    calculatorId: json['calculatorId'] as String? ?? 'calc_ohm',
    timestamp: json['timestamp'] != null
        ? DateTime.tryParse(json['timestamp'] as String) ?? DateTime.now()
        : DateTime.now(),
    payload: json['payload'] != null ? Map<String, dynamic>.from(json['payload'] as Map) : null,
  );
}

class HistoryService extends ChangeNotifier {
  static final HistoryService _instance = HistoryService._internal();
  factory HistoryService() => _instance;
  HistoryService._internal();

  static const String _storageKey = 'ampohm_calculation_history_v1';
  final List<HistoryItem> _items = [];

  List<HistoryItem> get items => List.unmodifiable(_items);

  /// Load persisted calculation history on app startup
  Future<void> init() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_storageKey);
      if (raw != null && raw.isNotEmpty) {
        final decoded = jsonDecode(raw) as List<dynamic>;
        _items.clear();
        for (final item in decoded) {
          if (item is Map<String, dynamic>) {
            _items.add(HistoryItem.fromJson(item));
          }
        }
        notifyListeners();
      }
    } catch (e) {
      debugPrint('HistoryService init error: $e');
    }
  }

  /// Adds a new calculation record to history and persists to storage
  void addItem(HistoryItem item) {
    _items.insert(0, item);
    if (_items.length > 50) {
      _items.removeLast();
    }
    _saveToPrefs();
    notifyListeners();
  }

  /// Clears all history records and updates storage
  void clearHistory() {
    _items.clear();
    _saveToPrefs();
    notifyListeners();
  }

  Future<void> _saveToPrefs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final list = _items.map((e) => e.toJson()).toList();
      await prefs.setString(_storageKey, jsonEncode(list));
    } catch (e) {
      debugPrint('HistoryService save error: $e');
    }
  }
}
