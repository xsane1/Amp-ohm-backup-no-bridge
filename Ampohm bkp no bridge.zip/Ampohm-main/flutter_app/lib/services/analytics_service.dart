import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Firebase Analytics Preparation Service (Flutter)
/// 
/// Tracks:
/// - App Opens
/// - Home Screen Visits
/// - Calculator Opens (Ohm, Amp, Top Speaker, Cable Loss, DMX)
/// - Completed Calculations
/// - Language Changes
/// - Settings Visits
/// 
/// Also provides usage telemetry reports:
/// - Most Used Calculator
/// - Least Used Calculator
/// - Daily & Monthly usage
class AnalyticsService extends ChangeNotifier {
  static final AnalyticsService _instance = AnalyticsService._internal();
  factory AnalyticsService() => _instance;
  AnalyticsService._internal() {
    _init();
  }

  final Map<String, int> _counts = {};
  final List<int> _calculationTimestamps = [];

  Future<void> _init() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final keys = [
        'app_open',
        'home_visit',
        'settings_visit',
        'calc_ohm',
        'calc_amp',
        'calc_top_speaker',
        'calc_cable_loss',
        'calc_dmx',
      ];
      for (final k in keys) {
        _counts[k] = prefs.getInt('analytics_$k') ?? 0;
      }
    } catch (_) {}
  }

  Future<void> _increment(String key) async {
    _counts[key] = (_counts[key] ?? 0) + 1;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('analytics_$key', _counts[key]!);
    } catch (_) {}
  }

  // ==========================================
  // Core Tracked Events
  // ==========================================

  void logAppOpen() {
    _increment('app_open');
    // Future Firebase hook:
    // FirebaseAnalytics.instance.logAppOpen();
  }

  void logHomeScreenVisit() {
    _increment('home_visit');
    // Future Firebase hook:
    // FirebaseAnalytics.instance.logScreenView(screenName: 'HomeScreen');
  }

  void logSettingsVisit() {
    _increment('settings_visit');
    // Future Firebase hook:
    // FirebaseAnalytics.instance.logScreenView(screenName: 'SettingsScreen');
  }

  void logCalculatorOpen(String calculatorId) {
    _increment('open_$calculatorId');
    // Future Firebase hook:
    // FirebaseAnalytics.instance.logEvent(name: 'calculator_open', parameters: {'id': calculatorId});
  }

  void logCalculationCompleted(String calculatorId, [Map<String, Object>? params]) {
    _increment('calc_$calculatorId');
    _calculationTimestamps.add(DateTime.now().millisecondsSinceEpoch);
    // Future Firebase hook:
    // FirebaseAnalytics.instance.logEvent(name: 'calculation_completed', parameters: {'id': calculatorId, ...?params});
  }

  void logLanguageChange(String prevLang, String newLang) {
    // Future Firebase hook:
    // FirebaseAnalytics.instance.logEvent(name: 'language_change', parameters: {'from': prevLang, 'to': newLang});
  }

  // ==========================================
  // Usage Telemetry Reports
  // ==========================================

  String getMostUsedCalculator() {
    final calcs = {
      'Ohm Calculator': _counts['calc_ohm'] ?? 0,
      'Amplifier Calculator': _counts['calc_amp'] ?? 0,
      'Top Speaker Calculator': _counts['calc_top_speaker'] ?? 0,
      'Cable Loss Calculator': _counts['calc_cable_loss'] ?? 0,
      'DMX Address Calculator': _counts['calc_dmx'] ?? 0,
    };
    var highestName = 'Ohm Calculator';
    var highestVal = -1;
    calcs.forEach((name, count) {
      if (count > highestVal) {
        highestVal = count;
        highestName = name;
      }
    });
    return highestName;
  }

  int getUsageCount(String calculatorId) {
    return _counts['calc_$calculatorId'] ?? 0;
  }
}
