import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:purchases_flutter/purchases_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum PurchaseStatus {
  success,
  verifying, // Payment processed, entitlement pending Google Play sync
  cancelled, // User dismissed store bottom sheet
  error,     // Payment failed
}

class PurchaseOutcome {
  final PurchaseStatus status;
  final String message;
  const PurchaseOutcome(this.status, [this.message = '']);
}

/// Central Entitlement System for RevenueCat Integration (Flutter)
///
/// Controls entitlements:
/// - remove_ads
/// - advanced_calculators
/// - speaker_database
/// - amplifier_database
/// - wiring_library
/// - pdf_export
class SubscriptionService extends ChangeNotifier {
  static final SubscriptionService _instance = SubscriptionService._internal();
  factory SubscriptionService() => _instance;
  SubscriptionService._internal() {
    _init();
  }

  // RevenueCat Approved Entitlement & Product IDs
  static const String apiKeyAndroid = 'test_QiAZRaEuqdieuLEgUlnkQffEFvn';
  static const String entitlementId = 'ampohm Pro';
  static const String productIdMonthly = 'ampohm_pro_monthly';
  static const String productIdAnnual = 'ampohm_pro_annual';

  // Fallback Display Pricing
  String _priceMonthly = '₹49 / Month';
  String _priceAnnual = '₹399 / Year';

  String get priceMonthly => _priceMonthly;
  String get priceAnnual => _priceAnnual;

  bool _isPremium = false;
  String _activeTier = 'free';
  DateTime? _expirationDate;
  String? _verifiedVipEmail;
  Offering? _currentOffering;

  bool get isPremium => _isPremium;
  bool get isProUser => _isPremium;
  String get activeTier => _activeTier;
  DateTime? get expirationDate => _expirationDate;
  String? get verifiedVipEmail => _verifiedVipEmail;
  Offering? get currentOffering => _currentOffering;

  Future<void> _init() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _isPremium = prefs.getBool('rc_is_premium') ?? false;
      _activeTier = prefs.getString('rc_active_tier') ?? 'free';
      _verifiedVipEmail = prefs.getString('vip_verified_email');

      final expStr = prefs.getString('rc_expiration_date');
      if (expStr != null) {
        try {
          _expirationDate = DateTime.parse(expStr);
          // If cached subscription period has already expired, invalidate cache immediately
          if (_expirationDate != null && DateTime.now().isAfter(_expirationDate!)) {
            _isPremium = false;
            _activeTier = 'free';
          }
        } catch (_) {}
      }
      notifyListeners();

      // If user had a previously verified VIP email, verify in background
      if (_verifiedVipEmail != null && _verifiedVipEmail!.isNotEmpty) {
        verifyFriendVip(_verifiedVipEmail!);
      }

      if (!kIsWeb && (Platform.isAndroid || Platform.isIOS)) {
        await Purchases.setLogLevel(LogLevel.debug);
        PurchasesConfiguration configuration = PurchasesConfiguration(apiKeyAndroid);
        await Purchases.configure(configuration);

        Purchases.addCustomerInfoUpdateListener((customerInfo) {
          _updateCustomerInfo(customerInfo);
        });

        await loadOfferings();
        await refreshSubscriptionStatus();
      }
    } catch (e) {
      debugPrint('RevenueCat init error: $e');
    }
  }

  /// Safe refresh of CustomerInfo handling network resilience and grace periods
  Future<void> refreshSubscriptionStatus() async {
    if (kIsWeb || (!Platform.isAndroid && !Platform.isIOS)) return;
    try {
      final customerInfo = await Purchases.getCustomerInfo();
      _updateCustomerInfo(customerInfo);
    } catch (e) {
      debugPrint('CustomerInfo network fetch warning: $e');
      // Temporary network failure!
      // Do NOT treat a temporary network failure as proof that subscription expired.
      // If cached expiration date is still in the future, retain active subscription.
      if (_expirationDate != null && DateTime.now().isBefore(_expirationDate!)) {
        debugPrint('Retaining active subscription through temporary network outage until: $_expirationDate');
      } else if (_expirationDate != null && DateTime.now().isAfter(_expirationDate!)) {
        _isPremium = false;
        _activeTier = 'free';
        _persistCache();
        notifyListeners();
      }
    }
  }

  Future<void> loadOfferings() async {
    try {
      if (!kIsWeb && (Platform.isAndroid || Platform.isIOS)) {
        Offerings offerings = await Purchases.getOfferings();
        if (offerings.current != null) {
          _currentOffering = offerings.current;

          // Enforce Indian Rupee (INR) pricing:
          if (_currentOffering?.monthly != null) {
            final rawPrice = _currentOffering!.monthly!.storeProduct.priceString;
            if (rawPrice.contains('₹') || rawPrice.contains('INR') || rawPrice.contains('Rs')) {
              _priceMonthly = '$rawPrice / Month';
            } else {
              _priceMonthly = '₹49 / Month';
            }
          }
          if (_currentOffering?.annual != null) {
            final rawPrice = _currentOffering!.annual!.storeProduct.priceString;
            if (rawPrice.contains('₹') || rawPrice.contains('INR') || rawPrice.contains('Rs')) {
              _priceAnnual = '$rawPrice / Year';
            } else {
              _priceAnnual = '₹399 / Year';
            }
          }
          notifyListeners();
        }
      }
    } catch (e) {
      debugPrint('RevenueCat loadOfferings error: $e');
    }
  }

  bool _updateCustomerInfo(CustomerInfo customerInfo) {
    // 1. Check exact configured entitlement 'ampohm Pro' and common identifiers
    final entitlement = customerInfo.entitlements.all[entitlementId] ??
        customerInfo.entitlements.all['pro'] ??
        customerInfo.entitlements.all['ampohm_pro'] ??
        customerInfo.entitlements.all['premium'];

    bool hasActiveEntitlement = entitlement?.isActive ?? false;

    // Parse expiration date
    DateTime? expDate;
    if (entitlement?.expirationDate != null) {
      try {
        expDate = DateTime.parse(entitlement!.expirationDate!);
      } catch (_) {}
    }

    // 2. Check active entitlement map
    if (!hasActiveEntitlement && customerInfo.entitlements.active.isNotEmpty) {
      hasActiveEntitlement = true;
    }

    // 3. Fallback: Check Google Play active subscriptions directly
    if (!hasActiveEntitlement && customerInfo.activeSubscriptions.isNotEmpty) {
      hasActiveEntitlement = true;
    }

    // 4. Cancellation & Expiration enforcement:
    // If user cancelled subscription before expiry, willRenew is false, but isActive remains true until expirationDate.
    // When expirationDate passes, access strictly ends.
    if (expDate != null && DateTime.now().isAfter(expDate)) {
      hasActiveEntitlement = false;
    }

    // Retain verified VIP access if active
    if (!hasActiveEntitlement && _verifiedVipEmail != null && _verifiedVipEmail!.isNotEmpty) {
      hasActiveEntitlement = true;
    }

    _isPremium = hasActiveEntitlement;
    _expirationDate = expDate;

    if (_isPremium) {
      if (customerInfo.activeSubscriptions.contains(productIdAnnual) ||
          customerInfo.activeSubscriptions.any((s) => s.contains('annual') || s.contains('year'))) {
        _activeTier = 'yearly';
      } else if (customerInfo.activeSubscriptions.contains(productIdMonthly) ||
          customerInfo.activeSubscriptions.any((s) => s.contains('month'))) {
        _activeTier = 'monthly';
      } else {
        _activeTier = 'yearly';
      }
    } else {
      _activeTier = 'free';
    }

    _persistCache();
    notifyListeners();
    return _isPremium;
  }

  void _persistCache() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('rc_is_premium', _isPremium);
      await prefs.setString('rc_active_tier', _activeTier);
      if (_expirationDate != null) {
        await prefs.setString('rc_expiration_date', _expirationDate!.toIso8601String());
      } else {
        await prefs.remove('rc_expiration_date');
      }
    } catch (_) {}
  }

  bool hasEntitlement(String entitlement) {
    if (!_isPremium) return false;
    switch (entitlement) {
      case 'remove_ads':
      case 'advanced_calculators':
      case 'speaker_database':
      case 'amplifier_database':
      case 'wiring_library':
      case 'pdf_export':
        return true;
      default:
        return false;
    }
  }

  bool isAdsEnabled() {
    return !hasEntitlement('remove_ads');
  }

  Future<bool> upgradeToTier(String tier) async {
    final outcome = await purchaseTier(tier);
    return outcome.status == PurchaseStatus.success;
  }

  /// Purchase subscription tier with delayed entitlement handling and retry verification
  Future<PurchaseOutcome> purchaseTier(String tier) async {
    try {
      if (!kIsWeb && (Platform.isAndroid || Platform.isIOS)) {
        Package? packageToBuy;
        if (_currentOffering != null) {
          if (tier == 'monthly') packageToBuy = _currentOffering?.monthly;
          if (tier == 'yearly') packageToBuy = _currentOffering?.annual;
        }

        CustomerInfo customerInfo;
        if (packageToBuy != null) {
          customerInfo = await Purchases.purchasePackage(packageToBuy);
        } else {
          final pid = tier == 'monthly' ? productIdMonthly : productIdAnnual;
          customerInfo = await Purchases.purchaseProduct(pid);
        }

        // 1. Immediate check: Was entitlement active right after purchase?
        bool isActive = _updateCustomerInfo(customerInfo);
        if (isActive) {
          return const PurchaseOutcome(
            PurchaseStatus.success,
            'Subscription successfully activated! All ads removed.',
          );
        }

        // 2. Delayed Entitlement Activation Handling:
        // Google Play deducted payment, but RevenueCat webhook / token sync is still in transit.
        // We retry up to 3 times safely before concluding.
        debugPrint('Payment received. Verifying entitlement with Google Play...');
        for (int retry = 1; retry <= 3; retry++) {
          await Future.delayed(Duration(milliseconds: 1500 * retry));
          try {
            final refreshedInfo = await Purchases.getCustomerInfo();
            if (_updateCustomerInfo(refreshedInfo)) {
              return const PurchaseOutcome(
                PurchaseStatus.success,
                'Subscription successfully verified! All ads removed.',
              );
            }
          } catch (e) {
            debugPrint('Verification retry $retry exception: $e');
          }
        }

        // 3. Payment was received by Google Play, but entitlement sync is still pending
        return const PurchaseOutcome(
          PurchaseStatus.verifying,
          'Your payment was received. We are verifying your subscription. Please tap Restore Purchases in a moment if not active immediately.',
        );
      }
    } on PlatformException catch (e) {
      final errorCode = PurchasesErrorHelper.getErrorCode(e);
      if (errorCode == PurchasesErrorCode.purchaseCancelledError) {
        return const PurchaseOutcome(PurchaseStatus.cancelled, 'Purchase was cancelled.');
      }
      debugPrint('Purchases PlatformException: ${e.message} (code: ${e.code})');
      return PurchaseOutcome(PurchaseStatus.error, e.message ?? 'Purchase could not be completed.');
    } catch (e) {
      debugPrint('Purchase error: $e');
      return PurchaseOutcome(PurchaseStatus.error, 'An unexpected error occurred during purchase.');
    }
    return const PurchaseOutcome(PurchaseStatus.error, 'In-app purchases are only available on Android & iOS devices.');
  }

  /// Restore Google Play purchases and refresh entitlements
  Future<PurchaseOutcome> restorePurchases() async {
    try {
      if (!kIsWeb && (Platform.isAndroid || Platform.isIOS)) {
        CustomerInfo customerInfo = await Purchases.restorePurchases();
        bool isActive = _updateCustomerInfo(customerInfo);
        if (isActive) {
          return const PurchaseOutcome(
            PurchaseStatus.success,
            'Purchases restored successfully! All ads removed.',
          );
        }

        // Additional refresh attempt
        final refreshedInfo = await Purchases.getCustomerInfo();
        if (_updateCustomerInfo(refreshedInfo)) {
          return const PurchaseOutcome(
            PurchaseStatus.success,
            'Purchases restored successfully! All ads removed.',
          );
        }

        return const PurchaseOutcome(
          PurchaseStatus.error,
          'No active Google Play subscription found on this account.',
        );
      }
    } catch (e) {
      debugPrint('Restore error: $e');
      return PurchaseOutcome(PurchaseStatus.error, 'Unable to restore purchases: $e');
    }
    return const PurchaseOutcome(PurchaseStatus.error, 'Restore purchases is only available on Android & iOS devices.');
  }

  /// Verifies a friend or developer VIP pass from Firestore backend database
  Future<bool> verifyFriendVip(String email) async {
    final cleanEmail = email.trim().toLowerCase();
    if (cleanEmail.isEmpty || !cleanEmail.contains('@') || !cleanEmail.contains('.')) {
      return false;
    }

    final docKey = cleanEmail.replaceAll(RegExp(r'[^a-zA-Z0-9]'), '_');
    const collections = ['vip_users', 'vip', 'vip_entitlements'];
    const projectId = 'mythic-ability-qgmzr';
    const databaseId = 'ai-studio-proaudiotoolkit-da3099cf-650a-448f-97c8-450d5be45b3c';
    const apiKey = 'AIzaSyDcwb008FXseYH5hkDt-MbT-m6d84Jz_Ns';

    final client = HttpClient();
    client.connectionTimeout = const Duration(seconds: 8);

    for (final coll in collections) {
      for (final key in [docKey, cleanEmail]) {
        try {
          final uri = Uri.parse(
            'https://firestore.googleapis.com/v1/projects/$projectId/databases/$databaseId/documents/$coll/$key?key=$apiKey',
          );
          final request = await client.getUrl(uri);
          final response = await request.close();
          if (response.statusCode == 200) {
            final body = await response.transform(utf8.decoder).join();
            final data = jsonDecode(body) as Map<String, dynamic>;
            final fields = data['fields'] as Map<String, dynamic>?;
            final status = fields?['status']?['stringValue'] ?? '';
            if (status == 'active') {
              final tier = fields?['tier']?['stringValue'] ?? 'yearly';
              _isPremium = true;
              _activeTier = tier;
              _verifiedVipEmail = cleanEmail;
              _persistCache();
              final prefs = await SharedPreferences.getInstance();
              await prefs.setString('vip_verified_email', cleanEmail);
              notifyListeners();
              client.close();
              return true;
            }
          }
        } catch (e) {
          debugPrint('Firestore VIP verification check: $e');
        }
      }
    }
    client.close();
    return false;
  }

  Future<void> resetToFree() async {
    _isPremium = false;
    _activeTier = 'free';
    _expirationDate = null;
    _persistCache();
    notifyListeners();
  }
}
