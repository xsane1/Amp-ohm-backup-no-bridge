import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

/// Service to directly open native email client (Gmail / default mail)
/// with prefilled 'To' and 'Subject' matching user specifications.
class MailService {
  static const String officialEmail = 'audioxpert123@gmail.com';

  /// Launches native email composer with prefilled To and Subject
  static Future<void> openMail({
    required String subject,
    String email = officialEmail,
    String body = '',
  }) async {
    final encodedSubject = Uri.encodeComponent(subject);
    final bodyPart = body.isNotEmpty ? '&body=${Uri.encodeComponent(body)}' : '';
    final Uri mailUri = Uri.parse('mailto:$email?subject=$encodedSubject$bodyPart');

    bool launched = false;
    // 1. Try url_launcher with externalApplication
    try {
      launched = await launchUrl(mailUri, mode: LaunchMode.externalApplication);
    } catch (_) {}

    // 2. Try url_launcher with platformDefault
    if (!launched) {
      try {
        launched = await launchUrl(mailUri, mode: LaunchMode.platformDefault);
      } catch (_) {}
    }

    // 3. Safety fallback: if no mail app available on device, copy email to clipboard
    if (!launched) {
      Clipboard.setData(ClipboardData(text: email));
    }
  }

  /// Direct 1-tap feedback: Opens Gmail with 'AMP OHM Feedback'
  static Future<void> sendFeedback() => openMail(subject: 'AMP OHM Feedback');

  /// Direct 1-tap bug report: Opens Gmail with 'AMP OHM Issue Report'
  static Future<void> reportIssue() => openMail(subject: 'AMP OHM Issue Report');

  /// Direct 1-tap support inquiry: Opens Gmail with 'AMP OHM Support'
  static Future<void> contactSupport() => openMail(subject: 'AMP OHM Support');
}
