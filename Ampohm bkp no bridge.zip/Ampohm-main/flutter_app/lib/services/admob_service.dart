import 'dart:async';
import 'dart:io';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'subscription_service.dart';

/// Central Google AdMob Service for Native Flutter APK
///
/// Features:
/// 1. Official Google Sample / Test Ad Unit IDs
/// 2. Rewarded Video Ads with auto-retry & active loading
/// 3. Standard Adaptive Banner Ad creation
/// 4. Robust state tracking for rewards and testing
class AdMobService extends ChangeNotifier {
  static final AdMobService _instance = AdMobService._internal();
  factory AdMobService() => _instance;
  AdMobService._internal() {
    _init();
  }

  // Official Google AdMob Test Ad Unit IDs (Android)
  static const String testBannerId = 'ca-app-pub-3940256099942544/6300978111';
  static const String testRewardedId = 'ca-app-pub-3940256099942544/5224354917';
  static const String storageKeyRewardPass = 'ampohm_reward_pass_expiry_ms';

  bool _isInitialized = false;
  int _rewardPassExpiryMs = 0;
  RewardedAd? _rewardedAd;
  bool _isLoadingRewarded = false;
  int _retryAttempt = 0;
  Timer? _retryTimer;

  // Firebase Remote Ads Control (Synced with Firestore 'app_config/ads_settings')
  bool _adsMasterEnabled = true;
  bool _bannerAdsEnabled = true;
  bool _rewardAdsEnabled = true;
  int _rewardDurationMinutes = 60;
  String _announcement = '';

  bool get isInitialized => _isInitialized;
  bool get isRewardedAdReady => _rewardedAd != null;
  bool get isLoadingRewarded => _isLoadingRewarded;
  bool get adsMasterEnabled => _adsMasterEnabled;
  bool get bannerAdsEnabled => _adsMasterEnabled && _bannerAdsEnabled;
  bool get rewardAdsEnabled => _adsMasterEnabled && _rewardAdsEnabled;
  int get rewardDurationMinutes => _rewardDurationMinutes;
  String get announcement => _announcement;

  /// Check if user has an active 60-minute reward pass
  bool get hasActiveRewardPass {
    final now = DateTime.now().millisecondsSinceEpoch;
    return now < _rewardPassExpiryMs;
  }

  /// Remaining minutes on the active reward pass
  int get remainingRewardPassMinutes {
    final diff = _rewardPassExpiryMs - DateTime.now().millisecondsSinceEpoch;
    if (diff <= 0) return 0;
    return (diff / (60 * 1000)).ceil();
  }

  /// Remaining seconds on the active reward pass
  int get remainingRewardPassSeconds {
    final diff = _rewardPassExpiryMs - DateTime.now().millisecondsSinceEpoch;
    if (diff <= 0) return 0;
    return (diff / 1000).ceil();
  }

  /// Formatted mm:ss string of remaining unlock time (e.g. 60:00, 59:59)
  String get formattedRemainingTime {
    final totalSecs = remainingRewardPassSeconds;
    if (totalSecs <= 0) return '00:00';
    final mins = (totalSecs ~/ 60).toString().padLeft(2, '0');
    final secs = (totalSecs % 60).toString().padLeft(2, '0');
    return '$mins:$secs';
  }

  Future<void> init() async {
    await _init();
  }

  Future<void> _init() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _rewardPassExpiryMs = prefs.getInt(storageKeyRewardPass) ?? 0;
      notifyListeners();

      // Synchronize with Firebase Remote Ad Config in background
      fetchRemoteAdsConfig();

      if (!kIsWeb && (Platform.isAndroid || Platform.isIOS)) {
        await MobileAds.instance.initialize();
        _isInitialized = true;
        notifyListeners();
        loadRewardedAd();
      }
    } catch (e) {
      debugPrint('AdMob initialization error: $e');
    }
  }

  /// Asynchronously fetch real-time Firebase Remote Ad Config from Firestore
  Future<void> fetchRemoteAdsConfig() async {
    try {
      final client = HttpClient();
      client.connectionTimeout = const Duration(seconds: 5);
      final uri = Uri.parse(
        'https://firestore.googleapis.com/v1/projects/mythic-ability-qgmzr/databases/ai-studio-proaudiotoolkit-da3099cf-650a-448f-97c8-450d5be45b3c/documents/app_config/ads_settings',
      );
      final request = await client.getUrl(uri);
      final response = await request.close();
      if (response.statusCode == 200) {
        final body = await response.transform(utf8.decoder).join();
        final jsonMap = jsonDecode(body) as Map<String, dynamic>;
        final fields = jsonMap['fields'] as Map<String, dynamic>?;
        if (fields != null) {
          if (fields['adsMasterEnabled']?['booleanValue'] != null) {
            _adsMasterEnabled = fields['adsMasterEnabled']['booleanValue'] as bool;
          }
          if (fields['bannerAdsEnabled']?['booleanValue'] != null) {
            _bannerAdsEnabled = fields['bannerAdsEnabled']['booleanValue'] as bool;
          }
          if (fields['rewardAdsEnabled']?['booleanValue'] != null) {
            _rewardAdsEnabled = fields['rewardAdsEnabled']['booleanValue'] as bool;
          }
          if (fields['rewardDurationMinutes']?['integerValue'] != null) {
            _rewardDurationMinutes = int.tryParse(fields['rewardDurationMinutes']['integerValue'].toString()) ?? 60;
          }
          if (fields['announcement']?['stringValue'] != null) {
            _announcement = fields['announcement']['stringValue'] as String;
          }
          notifyListeners();
          debugPrint('AdMobService: Remote Ads Config updated (master=$_adsMasterEnabled, rewardMins=$_rewardDurationMinutes)');
        }
      }
      client.close();
    } catch (e) {
      debugPrint('AdMobService: Using local fallback defaults: $e');
    }
  }

  /// Pre-load a rewarded ad so it displays instantly when requested
  void loadRewardedAd() {
    if (kIsWeb || (!Platform.isAndroid && !Platform.isIOS)) return;
    if (SubscriptionService().isPremium) return;
    if (!_adsMasterEnabled || !_rewardAdsEnabled) return;
    if (_rewardedAd != null || _isLoadingRewarded) return;

    _isLoadingRewarded = true;
    notifyListeners();

    RewardedAd.load(
      adUnitId: testRewardedId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _rewardedAd = ad;
          _isLoadingRewarded = false;
          _retryAttempt = 0;
          debugPrint('AdMob RewardedAd loaded and PRE-CACHED successfully in phone RAM');
          notifyListeners();
        },
        onAdFailedToLoad: (error) {
          _rewardedAd = null;
          _isLoadingRewarded = false;
          debugPrint('AdMob RewardedAd failed to load: ${error.message} (Code: ${error.code})');
          notifyListeners();

          // Auto-retry aggressively whenever network is available so ad is always pre-cached
          if (_retryAttempt < 10) {
            _retryAttempt++;
            final delay = Duration(seconds: (_retryAttempt <= 3 ? 3 : 8));
            _retryTimer?.cancel();
            _retryTimer = Timer(delay, () {
              loadRewardedAd();
            });
          }
        },
      ),
    );
  }

  /// Show Rewarded Ad to grant reward
  void showRewardedAd({
    required void Function(bool success, String message) onResult,
  }) {
    // 1. Active subscription has absolute priority: completely ad-free
    if (SubscriptionService().isPremium) {
      onResult(true, 'Active subscription verified. Ad-free access granted.');
      return;
    }

    // If user already has an active unlock pass, do not show another ad
    if (hasActiveRewardPass) {
      onResult(true, 'Active unlock pass already active.');
      return;
    }

    // If Firebase Remote Ads Control has turned off master ads or reward ads, grant unlock directly
    if (!_adsMasterEnabled || !_rewardAdsEnabled) {
      _grantRewardPass(_rewardDurationMinutes);
      onResult(true, 'Ads currently disabled by remote control. Pass granted!');
      return;
    }

    if (kIsWeb || (!Platform.isAndroid && !Platform.isIOS)) {
      onResult(false, 'Rewarded ads are only available on Android / iOS devices.');
      return;
    }

    if (_rewardedAd != null) {
      bool userEarnedReward = false;

      _rewardedAd!.fullScreenContentCallback = FullScreenContentCallback(
        onAdShowedFullScreenContent: (ad) {
          debugPrint('AdMob RewardedAd displayed full screen.');
        },
        onAdDismissedFullScreenContent: (ad) {
          debugPrint('AdMob RewardedAd dismissed full screen.');
          ad.dispose();
          _rewardedAd = null;
          notifyListeners();
          loadRewardedAd();
          if (userEarnedReward) {
            _grantRewardPass(_rewardDurationMinutes);
            onResult(true, 'Rewarded video completed! 60-minute unlock activated.');
          } else {
            onResult(false, 'Ad was closed before completion.');
          }
        },
        onAdFailedToShowFullScreenContent: (ad, error) {
          debugPrint('AdMob RewardedAd failed to show: ${error.message}');
          ad.dispose();
          _rewardedAd = null;
          notifyListeners();
          loadRewardedAd();
          onResult(false, 'Ad failed to show: ${error.message}');
        },
      );

      _rewardedAd!.show(
        onUserEarnedReward: (ad, reward) {
          userEarnedReward = true;
          debugPrint('User earned reward: ${reward.amount} ${reward.type}');
        },
      );
    } else {
      // Trigger load if not already loading
      loadRewardedAd();
      onResult(false, 'Ad is downloading from Google AdMob servers. Please try again in a few seconds.');
    }
  }

  /// Show Rewarded Ad with automatic loading spinner dialog if not yet cached
  void showRewardedAdWithLoadingDialog(
    BuildContext context, {
    required void Function(bool success, String message) onResult,
  }) {
    // 1. Active subscription has absolute priority: completely ad-free
    if (SubscriptionService().isPremium) {
      onResult(true, 'Active subscription verified. Ad-free access granted.');
      return;
    }

    // If user already has an active 60-minute unlock pass, do not show another ad
    if (hasActiveRewardPass) {
      onResult(true, 'Active unlock pass already active.');
      return;
    }

    if (kIsWeb || (!Platform.isAndroid && !Platform.isIOS)) {
      onResult(false, 'Rewarded ads are only available on Android / iOS devices.');
      return;
    }

    if (_rewardedAd != null) {
      showRewardedAd(onResult: onResult);
      return;
    }

    // Show loading modal while fetching from AdMob
    bool isDialogDismissed = false;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return WillPopScope(
          onWillPop: () async => false,
          child: Dialog(
            backgroundColor: const Color(0xFF141C30),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 20),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  SizedBox(
                    width: 26,
                    height: 26,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.8,
                      valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFFBBF24)),
                    ),
                  ),
                  SizedBox(width: 16),
                  Expanded(
                    child: Text(
                      'Loading Rewarded Video Ad...\nरिवॉर्ड वीडियो लोड हो रहा है...',
                      style: TextStyle(fontSize: 12, color: Colors.white, fontWeight: FontWeight.w600, height: 1.3),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    ).then((_) {
      isDialogDismissed = true;
    });

    // Actively load with custom callback and timeout
    bool didTimeout = false;
    final timeoutTimer = Timer(const Duration(seconds: 10), () {
      didTimeout = true;
      if (!isDialogDismissed && Navigator.canPop(context)) {
        Navigator.pop(context);
      }
      onResult(false, 'Ad loading timed out. Please check your internet connection and try again.');
    });

    _isLoadingRewarded = true;
    RewardedAd.load(
      adUnitId: testRewardedId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          timeoutTimer.cancel();
          _isLoadingRewarded = false;
          _rewardedAd = ad;
          if (!isDialogDismissed && !didTimeout && Navigator.canPop(context)) {
            Navigator.pop(context);
          }
          if (!didTimeout) {
            showRewardedAd(onResult: onResult);
          }
        },
        onAdFailedToLoad: (error) {
          timeoutTimer.cancel();
          _isLoadingRewarded = false;
          _rewardedAd = null;
          if (!isDialogDismissed && !didTimeout && Navigator.canPop(context)) {
            Navigator.pop(context);
          }
          if (!didTimeout) {
            onResult(false, 'AdMob failed to load: ${error.message}');
          }
        },
      ),
    );
  }

  /// Manually clear reward pass (useful for testing reward ads)
  Future<void> clearRewardPass() async {
    _rewardPassExpiryMs = 0;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(storageKeyRewardPass);
    } catch (_) {}
  }

  /// Grant a custom duration reward pass
  Future<void> grantRewardPass(int durationMinutes) async {
    _grantRewardPass(durationMinutes);
  }

  void _grantRewardPass(int durationMinutes) async {
    final now = DateTime.now().millisecondsSinceEpoch;
    _rewardPassExpiryMs = now + (durationMinutes * 60 * 1000);
    notifyListeners();

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(storageKeyRewardPass, _rewardPassExpiryMs);
    } catch (_) {}
  }

  /// Create a standard test BannerAd
  BannerAd createBannerAd({
    required Function(Ad) onAdLoaded,
    required Function(Ad, LoadAdError) onAdFailedToLoad,
  }) {
    return BannerAd(
      adUnitId: testBannerId,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: onAdLoaded,
        onAdFailedToLoad: onAdFailedToLoad,
      ),
    );
  }
}
