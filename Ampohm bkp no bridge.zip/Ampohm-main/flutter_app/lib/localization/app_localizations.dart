import 'package:flutter/material.dart';

class AppLocalizations {
  final Locale locale;
  AppLocalizations(this.locale);

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations) ??
        AppLocalizations(const Locale('en'));
  }

  bool get isHindi => locale.languageCode == 'hi';

  // Common & Header
  String get appName => 'AMP OHM';
  String get appSubtitle => 'Audio & Lighting Tools';
  String get targetUsers => isHindi
      ? 'डीजे ऑपरेटर्स, साउंड इंजीनियर्स और तकनीशियनों के लिए'
      : 'For Sound Engineers, DJ Operators, and PA Technicians';

  // Bottom Navigation
  String get navHome => isHindi ? 'होम' : 'Home';
  String get navMoreTools => isHindi ? 'और टूल्स' : 'More Tools';
  String get navSettings => isHindi ? 'सेटिंग्स' : 'Settings';

  // Categories
  String get catAll => isHindi ? 'सभी टूल्स' : 'All Tools';
  String get catAudio => isHindi ? 'ऑडियो टूल्स' : 'Audio Tools';
  String get catLighting => isHindi ? 'लाइटिंग टूल्स' : 'Lighting Tools';
  String get catFuture => isHindi ? 'आने वाले टूल्स' : 'Future Tools';

  // Statuses
  String get statusSafe => isHindi ? 'सेफ लोड' : 'Safe Operating Load';
  String get statusWarning => isHindi ? 'सावधानी' : 'Caution / Sub-optimal';
  String get statusDanger => isHindi ? 'खतरा' : 'Danger / High Risk';
  String get statusInfo => isHindi ? 'सुझाव' : 'Professional Info';

  // Actions
  String get calculate => isHindi ? 'कैलकुलेट करें' : 'Calculate';
  String get reset => isHindi ? 'रीसेट करें' : 'Reset Defaults';
  String get back => isHindi ? 'वापस' : 'Back';
  String get comingSoon => isHindi ? 'जल्द आ रहा है' : 'Coming Soon';

  // Tool 1: Ohm Calculator
  String get ohmTitle => isHindi ? 'ओम कैलकुलेटर' : 'OHM CALCULATOR';
  String get ohmDesc => isHindi 
      ? 'स्पीकर लोड और वायरिंग चेक करें।' 
      : 'Calculate speaker load impedance and wiring results.';
  String get ohmSpeakerRms => isHindi ? 'स्पीकर RMS पावर' : 'Speaker RMS Power';
  String get ohmSpeakerRmsMinWarning => isHindi 
      ? 'कम से कम 200W RMS डालें। 200W से कम काम नहीं करेगा।' 
      : 'Minimum RMS power is 200W. Values below 200W are invalid.';
  String get ohmCalculateButton => isHindi ? 'लोड कैलकुलेट करें' : 'Calculate Load Impedance';
  String get ohmResultTitle => isHindi ? 'ओम कैलकुलेशन रिज़ल्ट' : 'OHM CALCULATION RESULT';
  String get ohmResultSubtitle => isHindi ? 'स्पीकर लोड और सिस्टम जानकारी' : 'Impedance and amplifier load analysis';
  String get ohmModifyInputs => isHindi ? 'इनपुट बदलें' : 'Modify Inputs';
  String get ohmFindAmp => isHindi ? 'सही एम्पलीफायर देखें' : 'Find Recommended Amplifier';
  String get ohmSummaryTitle => isHindi ? 'सिस्टम डिटेल्स' : 'System Summary';
  String get ohmSummaryTotalSpeakers => isHindi ? 'कुल स्पीकर' : 'Total Speakers';
  String get ohmSummarySpeakerRms => isHindi ? 'हर स्पीकर का RMS' : 'Individual Speaker RMS';
  String get ohmSummaryTotalRms => isHindi ? 'कुल सिस्टम RMS पावर' : 'Total System RMS Power';
  String get ohmSummaryWiring => isHindi ? 'वायरिंग टाइप' : 'Wiring Configuration';
  String get ohmSummaryCabinetImp => isHindi ? 'स्पीकर लोड (Ω)' : 'Speaker Impedance';
  String get ohmWiringConfig => isHindi ? 'वायरिंग टाइप' : 'Wiring Configuration';
  String get ohmParallel => isHindi ? 'पैरलल (Parallel)' : 'Parallel (Standard)';
  String get ohmSeries => isHindi ? 'सीरीज (Series)' : 'Series (Chained)';
  String get ohmSpeakerCount => isHindi ? 'स्पीकर की संख्या' : 'Number of Speakers';
  String get ohmSpeakerImp => isHindi ? 'स्पीकर लोड (Ω)' : 'Speaker Impedance (Ω)';
  String get ohmTotalLoad => isHindi ? 'फाइनल सिस्टम लोड' : 'Final System Load';
  String get ohmResultTotalLoad => ohmTotalLoad;
  String get perChannelBadge => isHindi ? 'प्रति चैनल' : 'Per Channel';
  String get perChannelSuffix => isHindi ? 'प्रति चैनल' : 'Per Channel';
  String get perChannelNotice => isHindi 
      ? 'यह लोड एम्पलीफायर के सिर्फ एक चैनल का है।' 
      : 'This load is calculated per amplifier output channel in standard stereo/dual operation.';
  String get ohmPowerPerSpeaker => isHindi ? 'हर स्पीकर को पावर' : 'Power per Speaker';
  
  // Load formatting helper
  static String formatLoad(double val) {
    if (val == val.roundToDouble()) {
      return val.toInt().toString();
    }
    final rounded = double.parse(val.toStringAsFixed(2));
    if (rounded == rounded.roundToDouble()) {
      return rounded.toInt().toString();
    }
    return rounded.toString();
  }

  static String interpolateLoad(String message, double val) {
    if (message.isEmpty) return message;
    return message.replaceAll('{load}', formatLoad(val));
  }

  // Classifications & Status Messages
  String get ohmClassExtreme => isHindi ? 'बहुत ज्यादा लोड (खतरा)' : 'Extreme Load';
  String get ohmClassExtremeMsg => isHindi 
      ? 'खतरनाक कम लोड! कुल लोड {load}Ω (2Ω से कम) है। आम एम्पलीफायर 2Ω से नीचे जल सकते हैं या गर्म होकर बंद हो जाएंगे। इसलिए कोई एम्पलीफायर नहीं सजेस्ट किया गया।' 
      : 'Dangerous low impedance! This system load is {load}Ω (< 2Ω), which exceeds the safe operating capability of standard audio amplifiers. Risk of thermal shutdown or output transistor failure. Amplifier recommendation disabled.';
  String get ohmClassRequires2Ohm => isHindi ? '2Ω सपोर्ट वाला एम्पलीफायर चाहिए' : 'Requires 2Ω Stable Amp';
  String get ohmClassRequires2OhmMsg => isHindi 
      ? 'सिस्टम लोड {load}Ω (भारी लोड) है। सुनिश्चित करें कि आपका एम्पलीफायर प्रति चैनल 2Ω ऑपरेशन सपोर्ट करता है और उसमें पर्याप्त कूलिंग है। स्पीकर कनेक्ट करने से पहले हमेशा निर्माता के स्पेसिफिकेशन चेक करें।' 
      : 'This system load is {load}Ω (heavy load). Ensure your amplifier supports 2Ω operation per channel and has adequate cooling. Always check the manufacturer\'s specifications before connecting speakers.';
  String get ohmClassHighCurrent => isHindi ? 'हाई करंट लोड' : 'High Current Load';
  String get ohmClassHighCurrentMsg => isHindi 
      ? 'सिस्टम लोड {load}Ω है। चेक कर लें कि आपका एम्पलीफायर 2Ω या 2.67Ω लोड आराम से चला सकता है।' 
      : 'This system load is {load}Ω (high-current load). Ensure the amplifier is rated for 2Ω or 2.67Ω operation with robust power supply filtering.';
  String get ohmClassSafe => isHindi ? 'एकदम सेफ लोड' : 'Safe Load';
  String get ohmClassSafeMsg => isHindi 
      ? 'सिस्टम लोड {load}Ω (4Ω से 8Ω) सबसे बेस्ट है। सभी एम्पलीफायरों के लिए सेफ है, आवाज साफ रहेगी और मशीन गर्म नहीं होगी।' 
      : 'This system load is {load}Ω (ideal operating range 4Ω to 8Ω). Optimal damping factor, lowest harmonic distortion, and excellent thermal stability on standard pro amplifiers.';
  String get ohmClassProLoad => isHindi ? 'हल्का लोड (सुरक्षित)' : 'Professional Load';
  String get ohmClassProLoadMsg => isHindi 
      ? 'सिस्टम लोड {load}Ω (हल्का लोड) है। मशीन बिल्कुल ठंडी चलेगी और तार में पावर लॉस न के बराबर होगा।' 
      : 'This system load is {load}Ω (light amplifier load > 8Ω to 16Ω). Extremely safe thermal operation with minimal cable voltage drop.';
  String get ohmClass16OhmMsg => isHindi
      ? 'सिस्टम लोड {load}Ω है। 16Ω पर एम्पलीफायर कम वाट फेंकता है, इसलिए एम्पलीफायर की 16Ω वाली वाट चेक करके ही लगाएं।'
      : 'This system load is {load}Ω. The amplifier may deliver less power at this impedance. Check the amplifier manufacturer\'s rated output and supported load before selecting it.';
  String get ohmClassUncommon => isHindi ? 'कम वाट वाला लोड' : 'Uncommon Load';
  String get ohmClassUncommonMsg => isHindi 
      ? 'सिस्टम लोड {load}Ω है। 16Ω या ज्यादा पर एम्पलीफायर कम वाट आउटपुट देता है। इसलिए मशीन की वाट चेक करें।' 
      : 'This system load is {load}Ω. Most amplifiers deliver reduced power at 16Ω or higher. Verify amplifier output specifications and compatibility.';
  String get ohmRecRestrictedReason => isHindi
      ? 'एम्पलीफायर नहीं सजेस्ट कर सकते: लोड 2.0Ω से कम है। आम एम्पलीफायर 2Ω से नीचे खराब हो सकते हैं।'
      : 'Amplifier recommendation disabled: System load is below 2.0Ω (Extreme Load). Standard audio amplifiers cannot safely operate below 2.0Ω.';
  String get ohmMsgSafe => isHindi 
      ? 'एकदम सेफ लोड है। आवाज साफ रहेगी और मशीन सेफ रहेगी।' 
      : 'Safe amplifier load. Excellent damping factor and thermal stability.';
  String get ohmMsgWarning => isHindi 
      ? 'लोड लिमिट के करीब है। एम्पलीफायर का पंखा और कूलिंग चालू रखें।' 
      : 'Load is close to minimum limit. Ensure amplifier forced cooling is active.';
  String get ohmMsgDanger => isHindi 
      ? 'बड़ा खतरा: लोड बहुत ज्यादा कम है! एम्पलीफायर ट्रिप हो सकता है या जल सकता है।' 
      : 'CRITICAL: Total load below amplifier minimum safe rating! Overheating danger.';

  // Tool 2: Amp Calculator
  String get ampTitle => isHindi ? 'एम्पलीफायर कैलकुलेटर' : 'AMPLIFIER CALCULATOR';
  String get ampSubtitle => ampDesc;
  String get ampDesc => isHindi 
      ? 'अपने स्पीकर्स के लिए सही एम्पलीफायर चुनें।' 
      : 'Find recommended amplifier power for your system.';
  String get ampSpeakerRms => isHindi ? 'स्पीकर RMS पावर' : 'Speaker RMS Power';
  String get ampSpeakerRmsUnit => 'Watts RMS';
  String get ampSpeakerRmsMinWarning => isHindi 
      ? 'कम से कम 200W RMS डालें। 200W से कम मान्य नहीं है।' 
      : 'Minimum RMS power is 200W. Values below 200W are invalid.';
  String get ampSpeakerRmsMaxWarning => isHindi
      ? 'अधिकतम 1,00,000W (1 लाख वॉट) तक डाल सकते हैं।'
      : 'Maximum RMS power is 100,000W (1 Lakh Watt limit).';
  String get ampSpeakerCount => isHindi ? 'स्पीकर की संख्या' : 'Number of Speakers';
  String get ampSpeakerImpedance => isHindi ? 'स्पीकर लोड (Ω)' : 'Speaker Impedance';
  String get ampWiringType => isHindi ? 'वायरिंग टाइप' : 'Wiring Type';
  String get ampWiringParallel => isHindi ? 'पैरलल (Parallel)' : 'Parallel';
  String get ampWiringSeries => isHindi ? 'सीरीज (Series)' : 'Series';
  String get ampHeadroomTitle => isHindi ? 'हेडरूम सेलेक्टर' : 'Headroom Selector';
  String get ampHeadroom125Label => isHindi ? '1.25x स्पीच / वोकल' : '1.25x Speech / Voice';
  String get ampHeadroom125Desc => isHindi 
      ? 'आवाज फटने (क्लिपिंग) से बचाता है और सेफ रखता है।' 
      : 'Helps reduce clipping and provides additional clean headroom.';
  String get ampHeadroom150Label => isHindi ? '1.50x लाइव साउंड' : '1.50x Live Sound';
  String get ampHeadroom150Desc => isHindi 
      ? 'लाइव प्रोग्राम और स्टेज शो के लिए सबसे बेस्ट।' 
      : 'Recommended for most live sound applications.';
  String get ampHeadroom200Label => isHindi ? '2.00x हैवी बेस / डीजे' : '2.00x Bass Heavy / DJ';
  String get ampHeadroom200Desc => isHindi 
      ? 'डीजे और तगड़े बेस (Bass) के लिए सबसे बेस्ट।' 
      : 'Recommended for bass-heavy systems and high dynamic content.';
  String get ampCalculateButton => isHindi ? 'सही एम्पलीफायर देखें' : 'Find Recommended Amplifier';
  String get ampResultTitle => isHindi ? 'एम्पलीफायर कैलकुलेशन रिज़ल्ट' : 'AMPLIFIER CALCULATION RESULT';
  String get ampResultSubtitle => isHindi ? 'एम्पलीफायर पावर और लोड डिटेल्स' : 'Recommended amplifier power & load analysis';
  String get ampCard1Title => isHindi ? 'बेस्ट एम्पलीफायर' : 'Recommended Amplifier';
  String get ampCard1Unit => 'Watts RMS';
  String get ampCard1NotAvailable => isHindi ? 'एम्पलीफायर सुझाव उपलब्ध नहीं' : 'RECOMMENDATION NOT AVAILABLE';
  String get ampCard2Title => isHindi ? 'फाइनल लोड' : 'Final Load';
  String get ampCard2TotalRms => isHindi ? 'कुल सिस्टम RMS' : 'Total System RMS';
  String get ampCard2TotalLoad => isHindi ? 'फाइनल सिस्टम लोड' : 'Final Load Impedance';
  String get ampCard2HeadroomFactor => isHindi ? 'हेडरूम' : 'Headroom Multiplier';
  String get ampCard3Title => isHindi ? 'सिस्टम डिटेल्स' : 'System Summary';
  String get ampSummaryTotalSpeakers => isHindi ? 'कुल स्पीकर' : 'Speaker Count';
  String get ampSummarySpeakerRms => isHindi ? 'स्पीकर RMS' : 'Speaker RMS';
  String get ampSummaryTotalRms => isHindi ? 'कुल RMS' : 'Total RMS';
  String get ampSummaryHeadroom => isHindi ? 'हेडरूम' : 'Headroom';
  String get ampSummaryWiring => isHindi ? 'वायरिंग टाइप' : 'Connection Type';
  String get ampModifyInputs => isHindi ? 'इनपुट बदलें' : 'Modify Inputs';
  String get ampClassExtremeTitle => isHindi ? '2Ω से कम — अत्यधिक लोड' : 'EXTREME LOAD — BELOW 2Ω';
  String get ampClassExtremeMsg => isHindi 
      ? 'यह सिस्टम {load}Ω लोड पर काम करता है, जो 2Ω की रेफरेंस लिमिट से कम है।\n\nकई प्रोफेशनल एम्पलीफायर प्रति चैनल 2Ω से कम लोड के लिए रेटेड नहीं होते। ऐसे एम्पलीफायर का इस्तेमाल करने से ज़्यादा करंट, ओवरहीटिंग, प्रोटेक्शन शटडाउन या उपकरण खराब होने का खतरा हो सकता है।\n\nकेवल ऐसा एम्पलीफायर इस्तेमाल करें जो आपके कैलकुलेट किए गए लोड को सपोर्ट करता हो। स्पीकर कनेक्ट करने से पहले निर्माता की स्पेसिफिकेशन ज़रूर चेक करें।\n\nइस लोड के लिए एम्पलीफायर की सिफारिश उपलब्ध नहीं है।' 
      : 'This system operates at {load}Ω, below the 2Ω reference limit.\n\nMany professional amplifiers are not rated for operation below 2Ω per channel. Using an amplifier that does not support this load may cause excessive current demand, overheating, protection shutdown, or equipment damage.\n\nOnly use an amplifier specifically rated for your calculated load. Always verify the manufacturer\'s specifications before connecting speakers.\n\nAmplifier recommendation is unavailable for this load.';
  String get ampClass16OhmMsg => isHindi
      ? 'सिस्टम लोड {load}Ω है। 16Ω पर एम्पलीफायर कम वाट फेंकता है, इसलिए मशीन की 16Ω वाली वाट चेक करके ही लगाएं।'
      : 'This system load is {load}Ω. The amplifier may deliver less power at this impedance. Check the amplifier manufacturer\'s rated output and supported load before selecting it.';
  String get ampClassUncommonTitle => isHindi ? 'कम वाट वाला लोड' : 'Uncommon Load';
  String get ampClassUncommonMsg => isHindi 
      ? 'सिस्टम लोड {load}Ω है। 16Ω या ज्यादा पर एम्पलीफायर कम वाट फेंकता है, इसलिए एम्पलीफायर की वाट चेक करें।' 
      : 'This system load is {load}Ω. Most amplifiers deliver reduced power at 16Ω or higher. High impedance advisory: verify amplifier power delivery at this load.';
  String get ampTransferredNotice => isHindi 
      ? 'ओम कैलकुलेटर से लिया गया (आप बदल भी सकते हैं)' 
      : 'Transferred from Ohm Calculator (Inputs fully editable)';
  String get ampSpeakerRating => isHindi ? 'स्पीकर RMS पावर' : 'Speaker Rating (RMS)';
  String get ampImpedance => isHindi ? 'स्पीकर लोड (Ω)' : 'Cabinet Impedance';
  String get ampUsage => isHindi ? 'इस्तेमाल का तरीका' : 'System Usage';
  String get ampUsageLive => isHindi ? 'लाइव साउंड (2.0x हेडरूम)' : 'Live Sound (2.0x Headroom)';
  String get ampUsageDj => isHindi ? 'डीजे / इलेक्ट्रॉनिक (1.5x हेडरूम)' : 'DJ / Electronic (1.5x Headroom)';
  String get ampUsageSpeech => isHindi ? 'स्पीच / बैकग्राउंड (1.25x हेडरूम)' : 'Speech / Monitors (1.25x)';
  String get ampRecommendedRms => isHindi ? 'बेस्ट एम्पलीफायर RMS' : 'Recommended Amp RMS Power';

  // Tool 3: Top Speaker Calculator
  String get topSpeakerTitle => isHindi ? 'टॉप स्पीकर कैलकुलेटर' : 'TOP SPEAKER CALCULATOR';
  String get topSpeakerDesc => isHindi 
      ? 'RMS, प्रोग्राम और पीक रेटिंग कैलकुलेट करें।' 
      : 'Calculate RMS, Program and Peak ratings.';
  String get topSpeakerRms => isHindi ? 'स्पीकर RMS पावर' : 'Speaker RMS Power';
  String get topSpeakerRmsUnit => 'Watts RMS';
  String get topSpeakerRmsMinWarning => isHindi
      ? 'कम से कम 200W RMS डालें। 200W से कम मान्य नहीं है।'
      : 'Minimum RMS power is 200W. Values below 200W are invalid.';
  String get topSpeakerCount => isHindi ? 'टॉप स्पीकर की संख्या' : 'Number of Speakers';
  String get topSpeakerCalculateButton => isHindi ? 'कैलकुलेट करें' : 'Calculate Speaker Ratings';
  String get topSpeakerResultTitle => isHindi ? 'टॉप स्पीकर कैलकुलेशन रिज़ल्ट' : 'TOP SPEAKER CALCULATION RESULT';
  String get topSpeakerResultSubtitle => isHindi ? 'स्पीकर रेटिंग और सही एम्पलीफायर' : 'Professional PA ratings & amplifier sizing';
  String get topSpeakerCard1Title => isHindi ? 'स्पीकर RMS' : 'Speaker RMS';
  String get topSpeakerCard2Title => isHindi ? 'प्रोग्राम पावर' : 'Program Power';
  String get topSpeakerCard3Title => isHindi ? 'पीक पावर' : 'Peak Power';
  String get topSpeakerCard4Title => isHindi ? 'बेस्ट एम्पलीफायर' : 'Recommended Amplifier';
  String get topSpeakerRecommendedAmpDisplay => isHindi ? 'बेस्ट एम्पलीफायर पावर' : 'Recommended Amplifier Power';
  String get topSpeakerCard5Title => isHindi ? 'सिस्टम डिटेल्स' : 'System Summary';
  String get topSpeakerSummarySpeakers => isHindi ? 'कुल स्पीकर' : 'Speaker Count';
  String get topSpeakerSummaryPerRms => isHindi ? 'हर स्पीकर का RMS' : 'Individual Speaker RMS';
  String get topSpeakerSummaryTotalRms => isHindi ? 'कुल सिस्टम RMS' : 'Total System RMS';
  String get topSpeakerSummaryPerProgram => isHindi ? 'हर स्पीकर का प्रोग्राम' : 'Individual Program';
  String get topSpeakerSummaryTotalProgram => isHindi ? 'कुल सिस्टम प्रोग्राम' : 'Total System Program';
  String get topSpeakerSummaryPerPeak => isHindi ? 'हर स्पीकर का पीक' : 'Individual Peak';
  String get topSpeakerSummaryTotalPeak => isHindi ? 'कुल सिस्टम पीक' : 'Total System Peak';
  String get topSpeakerSummaryRecommendedAmp => isHindi ? 'बेस्ट एम्पलीफायर पावर' : 'Recommended Amplifier Power';
  String get topSpeakerModifyInputs => isHindi ? 'इनपुट बदलें' : 'Modify Inputs';
  String get topSpeakerProgramFormula => isHindi ? 'प्रोग्राम पावर = RMS × 2' : 'Program Power = RMS × 2';
  String get topSpeakerPeakFormula => isHindi ? 'पीक पावर = RMS × 4' : 'Peak Power = RMS × 4';
  String get topSpeakerAmpFormula => isHindi ? 'बेस्ट एम्पलीफायर = कुल RMS × 1.5' : 'Recommended Amplifier = Total RMS × 1.5';

  // Tool 4: Cable Loss
  String get cableTitle => isHindi ? 'स्पीकर केबल कैलकुलेटर' : 'SPEAKER CABLE LOSS CALCULATOR';
  String get cableDesc => isHindi ? 'सही केबल साइज चुनें और पावर लॉस रोकें।' : 'Analyze cable loss and efficiency.';
  String get cableLength => isHindi ? 'केबल की लंबाई (दूरी)' : 'Cable Length';
  String get cableLengthUnit => isHindi ? 'मीटर' : 'Meters';
  String get cableLengthMinWarning => isHindi ? 'केबल की लंबाई 0 से ज्यादा होनी चाहिए।' : 'Cable length must be greater than zero.';
  String get cablePower => isHindi ? 'पावर' : 'Power';
  String get cablePowerUnit => 'Watts';
  String get cablePowerMinWarning => isHindi ? 'कम से कम 200W पावर डालें।' : 'Minimum power is 200W. Values below 200W are invalid.';
  String get cableLoad => isHindi ? 'स्पीकर लोड' : 'Load';
  String get cableSize => isHindi ? 'केबल साइज' : 'Cable Size';
  String get cableCalculateButton => isHindi ? 'केबल साइज देखें' : 'Calculate Cable Loss';
  String get calculateButton => isHindi ? 'केबल साइज देखें' : 'Calculate Cable Loss';
  String get cableResultTitle => isHindi ? 'केबल कैलकुलेशन रिज़ल्ट' : 'CABLE LOSS CALCULATION RESULT';
  String get cableResultSubtitle => isHindi ? 'केबल साइज, पावर लॉस और एफिशिएंसी' : 'Voltage drop, power loss and efficiency analysis';
  String get cableCardPowerAtSpeaker => isHindi ? 'स्पीकर पर पावर' : 'Power Delivered at Speaker';
  String get cableCardVoltDrop => isHindi ? 'वोल्टेज ड्रॉप' : 'Voltage Drop';
  String get cableCardPowerLoss => isHindi ? 'पावर लॉस' : 'Power Loss';
  String get cableCardEfficiency => isHindi ? 'केबल एफिशिएंसी' : 'Estimated Efficiency';
  String get cableCardRecommendedSize => isHindi ? 'बेस्ट केबल साइज' : 'Recommended Cable Size';
  String get cableLossLowTitle => isHindi ? 'लो लॉस (सेफ)' : 'Low Loss';
  String get cableLossLowMsg => isHindi ? 'सेफ (3% से कम लॉस): स्पीकर को पूरी पावर और बढ़िया पंच/बेस मिलेगा।' : 'Green: Low Loss (< 3%). Maximum audio power delivery with tight transient control.';
  String get cableLossModerateTitle => isHindi ? 'मीडियम लॉस' : 'Moderate Loss';
  String get cableLossModerateMsg => isHindi ? 'मीडियम लॉस (3% से 10%): थोड़ी पावर तार गर्म होने में वेस्ट होगी।' : 'Yellow: Moderate Loss (3%–10%). Noticeable power dissipation and slight reduction in damping factor.';
  String get cableLossHighTitle => isHindi ? 'ज्यादा लॉस (खतरा)' : 'High Loss';
  String get cableLossHighMsg => isHindi ? 'ज्यादा लॉस (10% से ज्यादा): बेस कमजोर पड़ेगा और आवाज दबेगी। मोटा तार लगाएं।' : 'Red: High Loss (> 10%). Severe acoustic loss and poor bass control. Upgrade to a heavier cable gauge immediately.';
  String get cableModifyInputs => isHindi ? 'इनपुट बदलें' : 'Modify Inputs';

  // Tool 5: DMX Calculator
  String get dmxTitle => isHindi ? 'DMX एड्रेस कैलकुलेटर' : 'DMX ADDRESS CALCULATOR';
  String get dmxDesc => isHindi ? 'लाइट्स (Sharpy/LED) के लिए तुरंत DMX एड्रेस सेट करें।' : 'Quick DMX addressing for lighting fixtures.';
  String get dmxStartAddress => isHindi ? 'स्टार्ट एड्रेस' : 'Start Address';
  String get dmxStartAddressRange => isHindi ? 'रेंज: 1–512' : 'Range: 1–512';
  String get dmxStartAddressWarning => isHindi ? 'स्टार्ट एड्रेस 1 से 512 के बीच होना चाहिए।' : 'Start address must be between 1 and 512.';
  String get dmxStartWarning => dmxStartAddressWarning;
  String get dmxChannelCount => isHindi ? 'चैनल की संख्या' : 'Channel Count';
  String get dmxChannelCountRange => isHindi ? 'रेंज: 1–64' : 'Range: 1–64';
  String get dmxChannelCountWarning => isHindi ? 'चैनल 1 से 64 के बीच होने चाहिए।' : 'Channel count must be between 1 and 64.';
  String get dmxExceedWarning => isHindi ? '512 से ऊपर एड्रेस नहीं जा सकता! फिक्स्चर 512 की लिमिट पार कर रहा है।' : 'Never allow address values above: 512! Fixture exceeds universe capacity.';
  String get dmxCalculateButton => isHindi ? 'DMX एड्रेस निकालें' : 'Calculate DMX Address';
  String get dmxResultTitle => isHindi ? 'DMX एड्रेस रिज़ल्ट' : 'DMX ADDRESS RESULT';
  String get dmxResultSubtitle => isHindi ? 'फिक्स्चर एड्रेस और अगला खाली एड्रेस' : 'Fixture addressing, footprint and patch';
  String get dmxCardCurrentAddress => isHindi ? 'स्टार्ट एड्रेस' : 'Current Address';
  String get dmxCardChannelCount => isHindi ? 'चैनल / लाइट' : 'Channel Count';
  String get dmxCardNextAddress => isHindi ? 'अगला खाली एड्रेस' : 'Next Fixture Address';
  String get dmxCardAddressRange => isHindi ? 'एड्रेस रेंज' : 'Address Range';
  String get dmxUniverseInfoTitle => isHindi ? 'DMX यूनिवर्स जानकारी' : 'DMX Information';
  String get dmxUniverseInfoMessage => isHindi ? 'एक DMX यूनिवर्स में 512 चैनल होते हैं।' : 'DMX universe contains 512 channels.';
  String get dmxSubsequentTitle => isHindi ? 'सभी फिक्स्चर की एड्रेस लिस्ट' : 'Subsequent Fixture Sequence';
  String get dmxModifyInputs => isHindi ? 'इनपुट बदलें' : 'Modify Inputs';

  // Settings
  String get settingsTitle => isHindi ? 'सेटिंग्स' : 'Settings & Preferences';
  String get langSelect => isHindi ? 'भाषा' : 'Language Selection';
  String get langEnglish => 'English';
  String get langHindi => isHindi ? 'हिन्दी' : 'Hindi (हिन्दी)';
  String get removeAds => isHindi ? 'Ads हटाएं (Pro)' : 'Remove Ads (Pro)';
  String get rateApp => isHindi ? 'रेटिंग दें' : 'Rate App';
  String get privacy => isHindi ? 'प्राइवेसी पॉलिसी' : 'Privacy Policy';
  String get contact => isHindi ? 'हेल्प और फीडबैक' : 'Contact Support';
  String get about => isHindi ? 'AMP OHM के बारे में' : 'About AMP OHM Toolkit';
}

class AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => ['en', 'hi'].contains(locale.languageCode);

  @override
  Future<AppLocalizations> load(Locale locale) async => AppLocalizations(locale);

  @override
  bool shouldReload(AppLocalizationsDelegate old) => false;
}
