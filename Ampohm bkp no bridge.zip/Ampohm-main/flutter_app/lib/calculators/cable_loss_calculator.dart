import 'dart:math';
import '../models/models.dart';

/// Professional Cable Loss Calculator for Loudspeaker Lines
///
/// ============================================================================
/// ELECTRICAL FORMULAS & DERIVATION SPECIFICATION:
/// ============================================================================
/// 1. Material Resistivity (rho):
///    - Pure OFC Copper: 0.0175 Ω·mm²/m (IEC 60028 annealed copper baseline at operating temperature).
///    - CCA (Copper Clad Aluminium): 0.0280 Ω·mm²/m (~62.5% IACS conductivity, exactly 1.6x pure copper).
///
/// 2. Round-Trip Loop Resistance (R_loop):
///    - Input length (L) represents one-way distance in meters.
///    - The circuit contains both outgoing and return conductors, so conductor length = 2 * L.
///    - R_loop = (2.0 * rho * L) / A, where A is the cross-sectional area in mm².
///
/// 3. Amplifier Drive & Load Assumptions:
///    - Amplifier power (P) is treated as continuous RMS power delivered into nominal load (R_load).
///    - The amplifier is modeled as an ideal voltage source maintaining terminal voltage:
///        V_amp = sqrt(P * R_load)
///    - Speaker load is modeled as nominal resistive load (R_load). Note: physical loudspeakers
///      exhibit frequency-dependent complex impedance Z(f); nominal resistive load is the standard
///      engineering basis for audio transmission line sizing.
///
/// 4. Circuit Current & Voltage Drop:
///    - Total series loop impedance: Z_total = R_load + R_loop.
///    - Series loop current: I = V_amp / Z_total.
///    - Round-trip cable voltage drop: V_drop = I * R_loop = V_amp * (R_loop / Z_total).
///
/// 5. Power Loss, Loss Percentage & Efficiency:
///    - Cable power dissipation (Watts): P_loss = I² * R_loop.
///    - Delivered speaker power (Watts): P_speaker = I² * R_load.
///    - Total output power: P_total = P_loss + P_speaker = I² * Z_total.
///    - Technically consistent Loss Percentage:
///        Loss% = (P_loss / P_total) * 100% = (R_loop / Z_total) * 100% = (V_drop / V_amp) * 100%
///    - Delivery Efficiency Percentage:
///        Efficiency% = 100.0% - Loss% = (R_load / Z_total) * 100%
///
/// 6. Recommendation & Compliance Logic:
///    - Target compliance (3%, 5%, 10%) is evaluated using unrounded full-precision Loss%.
///    - Recommended size is the smallest available standard size where rawLossPct <= maxAcceptableLoss.
///    - If no size meets the target, meetsTarget is false and no compliant recommendation is claimed.
/// ============================================================================
class CableLossCalculator {
  static const double copperResistivity = 0.0175; // Ω·mm²/m (OFC Pure Copper)
  static const double ccaResistivity = 0.0280;    // Ω·mm²/m (CCA, 1.6x copper resistivity)

  static const List<double> standardSizes = [1.5, 2.5, 4.0, 6.0, 10.0];

  static final Map<double, String> sizeAwgMap = {
    1.5: '16 AWG',
    2.5: '13 AWG',
    4.0: '11 AWG',
    6.0: '9 AWG',
    10.0: '7 AWG',
  };

  static double getResistivity(String material) {
    return material.toLowerCase() == 'cca' ? ccaResistivity : copperResistivity;
  }

  static double calculateLoopResistance({
    required double lengthMeters,
    required double sizeMm2,
    required String material,
  }) {
    final rho = getResistivity(material);
    return (2.0 * rho * lengthMeters) / sizeMm2;
  }

  static CableLossResult calculate({
    required double cableLength,
    required double power,
    required double load,
    double cableSize = 2.5,
    String material = 'copper',
    double maxAcceptableLoss = 5.0,
    int speakerQuantity = 1,
    double? perSpeakerImpedance,
    String wiring = 'parallel',
  }) {
    final validLength = cableLength <= 0 ? 0.1 : cableLength;
    final validPower = power <= 0 ? 50.0 : power;
    final validLoad = load <= 0 ? 4.0 : load;
    final rho = getResistivity(material);

    // Compute metrics across all 5 standard cable sizes
    final List<CableSizeAnalysis> analyses = [];
    double? recommendedSize;
    double? proChoiceSize;

    for (final sz in standardSizes) {
      final loopR = (2.0 * rho * validLength) / sz;
      final rawResistanceRatio = (loopR / validLoad) * 100.0;
      final totalZ = validLoad + loopR;
      final ampVoltage = sqrt(validPower * validLoad);
      final current = ampVoltage / totalZ;
      final vDrop = current * loopR;
      final pLossWatts = pow(current, 2) * loopR;
      final pSpeakerWatts = pow(current, 2) * validLoad;
      final rawLossPct = (loopR / totalZ) * 100.0;
      final levelLossDb = 20.0 * (log(validLoad / totalZ) / ln10);
      final lossPct = double.parse(rawLossPct.toStringAsFixed(1));
      final resRatio = double.parse(rawResistanceRatio.toStringAsFixed(2));
      final effPct = double.parse(((validLoad / totalZ) * 100.0).toStringAsFixed(1));

      // Target compliance defined as Cable Resistance Ratio relative to speaker load
      final isCompliant = rawResistanceRatio <= maxAcceptableLoss;

      String badge;
      String label;
      if (isCompliant) {
        if (rawResistanceRatio <= 2.5) {
          badge = 'excellent';
          label = 'Excellent';
        } else if (maxAcceptableLoss > 5.0 && rawResistanceRatio > 5.0) {
          badge = 'acceptable';
          label = 'Acceptable';
        } else {
          badge = 'recommended';
          label = 'Recommended';
        }
      } else {
        if (rawResistanceRatio <= 12.0) {
          badge = 'high_loss';
          label = 'High Loss';
        } else {
          badge = 'not_recommended';
          label = 'Target Exceeded';
        }
      }

      // Smallest available cable size whose resistance ratio <= selected target
      if (isCompliant && recommendedSize == null) {
        recommendedSize = sz;
      }
      // Professional touring standard (<= 2.5% resistance ratio)
      if (rawResistanceRatio <= 2.5 && proChoiceSize == null) {
        proChoiceSize = sz;
      }

      analyses.add(CableSizeAnalysis(
        size: sz,
        awg: sizeAwgMap[sz] ?? '',
        loopResistance: double.parse(loopR.toStringAsFixed(3)),
        resistanceRatioPercent: resRatio,
        actualPowerLossPercent: lossPct,
        levelLossDb: double.parse(levelLossDb.toStringAsFixed(2)),
        voltageDrop: double.parse(vDrop.toStringAsFixed(1)),
        powerLossWatts: double.parse(pLossWatts.toStringAsFixed(1)),
        powerDeliveredWatts: double.parse(pSpeakerWatts.toStringAsFixed(1)),
        powerLossPercent: lossPct,
        estimatedEfficiency: effPct,
        isCompliant: isCompliant,
        statusBadge: badge,
        badgeLabel: label,
      ));
    }

    final bool hasCompliantSize = recommendedSize != null;
    // If no size meets target, show lowest-loss available option (10 mm²) as non-compliant alternative
    final double finalRecommended = hasCompliantSize ? recommendedSize! : standardSizes.last;
    // "Min Acceptable" must genuinely meet target; if none meets, null (displayed as None)
    final double? finalMinAcceptable = hasCompliantSize ? recommendedSize : null;
    // "Pro Choice" strictly evaluates the professional touring benchmark (resistance ratio <= 2.5%).
    // If any available size meets the <= 2.5% benchmark, the smallest qualifying size is selected.
    // If no available size meets <= 2.5%, it is null (displayed as "None").
    final double? finalProChoice = proChoiceSize;

    // Active reference is evaluated on the final recommended (or lowest-loss) gauge
    final activeAnalysis = analyses.firstWhere((a) => a.size == finalRecommended);

    // Warning level
    String warningLevel = 'green';
    String statusTitleKey = 'cableLossLowTitle';
    String statusMessageKey = 'cableLossLowMsg';

    if (!hasCompliantSize || activeAnalysis.resistanceRatioPercent >= 12.0) {
      warningLevel = 'red';
      statusTitleKey = 'cableLossHighTitle';
      statusMessageKey = 'cableLossHighMsg';
    } else if (activeAnalysis.resistanceRatioPercent >= 5.0) {
      warningLevel = 'yellow';
      statusTitleKey = 'cableLossModerateTitle';
      statusMessageKey = 'cableLossModerateMsg';
    }

    return CableLossResult(
      cableLength: validLength,
      power: validPower,
      load: validLoad,
      cableSize: finalRecommended,
      loopResistance: activeAnalysis.loopResistance,
      resistanceRatioPercent: activeAnalysis.resistanceRatioPercent,
      actualPowerLossPercent: activeAnalysis.actualPowerLossPercent,
      levelLossDb: activeAnalysis.levelLossDb,
      voltageDrop: activeAnalysis.voltageDrop,
      voltageDropPercent: activeAnalysis.actualPowerLossPercent,
      powerLossWatts: activeAnalysis.powerLossWatts,
      powerLossPercent: activeAnalysis.actualPowerLossPercent,
      estimatedEfficiency: activeAnalysis.estimatedEfficiency,
      powerDeliveredWatts: activeAnalysis.powerDeliveredWatts,
      recommendedCableSize: finalRecommended,
      warningLevel: warningLevel,
      statusTitleKey: statusTitleKey,
      statusMessageKey: statusMessageKey,
      material: material,
      maxAcceptableLoss: maxAcceptableLoss,
      minimumAcceptableSize: finalMinAcceptable,
      professionalChoiceSize: finalProChoice,
      allSizes: analyses,
      meetsTarget: hasCompliantSize,
      speakerQuantity: speakerQuantity,
      perSpeakerImpedance: perSpeakerImpedance ?? validLoad,
      wiring: wiring,
    );
  }
}
