import '../models/models.dart';

class DmxCalculator {
  static DmxResult calculate({
    required int startAddress,
    required int channelCount,
    int fixtureCount = 4,
  }) {
    final validStart = startAddress < 1 ? 1 : (startAddress > 512 ? 512 : startAddress);
    final validChannels = channelCount < 1 ? 1 : (channelCount > 64 ? 64 : channelCount);
    final count = fixtureCount.clamp(1, 128);

    final endAddress = validStart + validChannels - 1;
    final nextFixtureAddress = validStart + (count * validChannels);
    final addressRange = '$validStart–$endAddress';
    final isValid = validStart <= 512 && endAddress <= 512;

    // Dynamic fixture sequence for specified fixture count
    final fixtures = <DmxFixtureSequence>[];
    for (int i = 0; i < count; i++) {
      final fixStart = validStart + (i * validChannels);
      final fixEnd = fixStart + validChannels - 1;
      final fixNext = fixStart + validChannels;

      if (fixStart <= 512) {
        fixtures.add(
          DmxFixtureSequence(
            fixtureNumber: i + 1,
            startAddress: fixStart,
            endAddress: fixEnd > 512 ? 512 : fixEnd,
            nextAddress: fixNext,
            rangeString: '$fixStart–${fixEnd > 512 ? 512 : fixEnd}',
          ),
        );
      }
    }

    return DmxResult(
      currentAddress: validStart,
      channelCount: validChannels,
      nextFixtureAddress: nextFixtureAddress,
      addressRange: addressRange,
      endAddress: endAddress,
      isValid: isValid,
      subsequentFixtures: fixtures,
      fixtureCount: count,
    );
  }
}
