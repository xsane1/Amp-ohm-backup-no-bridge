import '../models/models.dart';

class AmplifierCalculator {
  static AmpCalculationResult calculate({
    required double speakerRms,
    required int speakerCount,
    required double speakerImpedance,
    required WiringConfiguration wiring,
    required double headroom,
    double? finalLoadOverride,
    double? totalSystemRmsOverride,
  }) {
    final count = speakerCount.clamp(1, 32);

    // Step 1: Calculate Final Load
    double rawLoad;
    if (wiring == WiringConfiguration.parallel) {
      rawLoad = speakerImpedance / count;
    } else {
      rawLoad = speakerImpedance * count;
    }
    final finalLoad = finalLoadOverride != null
        ? double.parse(finalLoadOverride.toStringAsFixed(2))
        : double.parse(rawLoad.toStringAsFixed(2));

    // Step 2: Total RMS (preserve decimal values if present)
    final double rawTotalRms = totalSystemRmsOverride ?? (speakerRms * count);
    final totalSystemRms = double.parse(rawTotalRms.toStringAsFixed(2));

    // Step 3: Recommended Amplifier Power (preserve decimal values if present)
    final recommendedAmpPower = double.parse((totalSystemRms * headroom).toStringAsFixed(2));

    // Classification & Recommendation Availability
    OhmLoadCategory category;
    StatusLevel status;
    String titleKey;
    String descKey;
    bool isRecAvailable = true;

    if (finalLoad < 2.0) {
      // Below 2Ω: Extreme Load (Red) - Not recommended, NO recommendation
      category = OhmLoadCategory.extreme;
      status = StatusLevel.danger;
      titleKey = 'ampClassExtremeTitle';
      descKey = 'ampClassExtremeMsg';
      isRecAvailable = false;
    } else if ((finalLoad - 2.0).abs() < 0.005) {
      // Exactly 2Ω: Requires 2Ω Stable Amp (Yellow) - Recommendation YES
      category = OhmLoadCategory.requires2Ohm;
      status = StatusLevel.warning;
      titleKey = 'ohmClassRequires2Ohm';
      descKey = 'ohmClassRequires2OhmMsg';
      isRecAvailable = true;
    } else if (finalLoad > 2.0 && finalLoad < 4.0) {
      // Above 2Ω and Below 4Ω: High Current Load (Yellow) - Recommendation YES
      category = OhmLoadCategory.highCurrent;
      status = StatusLevel.warning;
      titleKey = 'ohmClassHighCurrent';
      descKey = 'ohmClassHighCurrentMsg';
      isRecAvailable = true;
    } else if (finalLoad >= 4.0 && finalLoad <= 8.0) {
      // 4Ω to 8Ω: Safe Load (Green) - Recommendation YES
      category = OhmLoadCategory.safe;
      status = StatusLevel.safe;
      titleKey = 'ohmClassSafe';
      descKey = 'ohmClassSafeMsg';
      isRecAvailable = true;
    } else if (finalLoad > 8.0 && finalLoad <= 16.0) {
      // Above 8Ω and Up To 16Ω: Pro Load (Blue) - Recommendation YES
      category = OhmLoadCategory.proLoad;
      status = StatusLevel.info;
      titleKey = 'ohmClassProLoad';
      descKey = (finalLoad - 16.0).abs() < 0.005 ? 'ohmClass16OhmMsg' : 'ohmClassProLoadMsg';
      isRecAvailable = true;
    } else {
      // Above 16Ω: Uncommon Load (Blue) - Recommendation available with advisory
      category = OhmLoadCategory.uncommon;
      status = StatusLevel.info;
      titleKey = 'ampClassUncommonTitle';
      descKey = 'ampClassUncommonMsg';
      isRecAvailable = true;
    }

    return AmpCalculationResult(
      speakerRms: speakerRms,
      speakerCount: count,
      totalSystemRms: totalSystemRms,
      speakerImpedance: speakerImpedance,
      wiring: wiring,
      headroom: headroom,
      finalLoad: finalLoad,
      recommendedAmpPower: recommendedAmpPower,
      loadCategory: category,
      status: status,
      statusTitleKey: titleKey,
      statusDescriptionKey: descKey,
      isRecommendationAvailable: isRecAvailable,
    );
  }
}
