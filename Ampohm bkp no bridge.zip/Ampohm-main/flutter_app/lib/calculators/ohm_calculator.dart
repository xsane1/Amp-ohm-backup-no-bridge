import '../models/models.dart';

class OhmCalculator {
  static OhmCalculationResult calculate({
    required double speakerRms, // Watts RMS (Validated >= 200W)
    required int speakerCount, // 1 to 32
    required double speakerImpedance, // 2, 4, 6, 8, 16
    required WiringConfiguration wiring, // Parallel or Series
  }) {
    final count = speakerCount.clamp(1, 32);
    double rawImpedance;

    if (wiring == WiringConfiguration.parallel) {
      rawImpedance = speakerImpedance / count;
    } else {
      rawImpedance = speakerImpedance * count;
    }

    // Maximum 2 decimal places rounding
    final totalImpedance = double.parse(rawImpedance.toStringAsFixed(2));
    final totalSystemRms = speakerRms * count;
    final perSpeakerPower = speakerRms;

    OhmLoadCategory loadCategory;
    StatusLevel status;
    String statusTitleKey;
    String statusDescriptionKey;
    bool canRecommendAmp;

    if (totalImpedance < 2.0) {
      // < 2Ω: Extreme Load (Red / Danger) - No Amp Recommendation
      loadCategory = OhmLoadCategory.extreme;
      status = StatusLevel.danger;
      statusTitleKey = 'ohmClassExtreme';
      statusDescriptionKey = 'ohmClassExtremeMsg';
      canRecommendAmp = false;
    } else if ((totalImpedance - 2.0).abs() < 0.005) {
      // 2Ω: Requires 2Ω Stable Amp (Yellow / Caution) - Amp recommendation enabled
      loadCategory = OhmLoadCategory.requires2Ohm;
      status = StatusLevel.warning;
      statusTitleKey = 'ohmClassRequires2Ohm';
      statusDescriptionKey = 'ohmClassRequires2OhmMsg';
      canRecommendAmp = true;
    } else if (totalImpedance > 2.0 && totalImpedance < 4.0) {
      // > 2Ω and < 4Ω: High Current Load (Yellow / Caution) - Amp recommendation enabled
      loadCategory = OhmLoadCategory.highCurrent;
      status = StatusLevel.warning;
      statusTitleKey = 'ohmClassHighCurrent';
      statusDescriptionKey = 'ohmClassHighCurrentMsg';
      canRecommendAmp = true;
    } else if (totalImpedance >= 4.0 && totalImpedance <= 8.0) {
      // 4Ω to 8Ω: Safe Load (Green / Safe) - Amp recommendation enabled
      loadCategory = OhmLoadCategory.safe;
      status = StatusLevel.safe;
      statusTitleKey = 'ohmClassSafe';
      statusDescriptionKey = 'ohmClassSafeMsg';
      canRecommendAmp = true;
    } else if (totalImpedance > 8.0 && totalImpedance <= 16.0) {
      // > 8Ω and <= 16Ω: Professional Load (Blue / Info) - Amp recommendation enabled
      loadCategory = OhmLoadCategory.proLoad;
      status = StatusLevel.info;
      statusTitleKey = 'ohmClassProLoad';
      statusDescriptionKey = (totalImpedance - 16.0).abs() < 0.005 ? 'ohmClass16OhmMsg' : 'ohmClassProLoadMsg';
      canRecommendAmp = true;
    } else {
      // > 16Ω: Uncommon Load (Blue / Info) - Amp recommendation enabled
      loadCategory = OhmLoadCategory.uncommon;
      status = StatusLevel.info;
      statusTitleKey = 'ohmClassUncommon';
      statusDescriptionKey = 'ohmClassUncommonMsg';
      canRecommendAmp = true;
    }

    return OhmCalculationResult(
      totalImpedance: totalImpedance,
      speakerRms: speakerRms,
      speakerCount: count,
      totalSystemRms: totalSystemRms,
      perSpeakerPower: perSpeakerPower,
      wiring: wiring,
      speakerImpedance: speakerImpedance,
      loadCategory: loadCategory,
      status: status,
      statusTitleKey: statusTitleKey,
      statusDescriptionKey: statusDescriptionKey,
      canRecommendAmp: canRecommendAmp,
    );
  }
}
