import '../models/models.dart';

class TopSpeakerCalculator {
  static TopSpeakerResult calculate({
    required double speakerRms,
    required int speakerCount,
  }) {
    final validRms = speakerRms < 200 ? 200.0 : speakerRms;
    final validCount = speakerCount < 1 ? 1 : (speakerCount > 32 ? 32 : speakerCount);

    final programPower = validRms * 2.0;
    final peakPower = validRms * 4.0;
    final totalRms = validRms * validCount;
    final totalProgram = programPower * validCount;
    final totalPeak = peakPower * validCount;
    final recommendedAmpPower = totalRms * 1.5;

    return TopSpeakerResult(
      speakerRms: double.parse(validRms.toStringAsFixed(0)),
      speakerCount: validCount,
      programPower: double.parse(programPower.toStringAsFixed(0)),
      peakPower: double.parse(peakPower.toStringAsFixed(0)),
      totalRms: double.parse(totalRms.toStringAsFixed(0)),
      totalProgram: double.parse(totalProgram.toStringAsFixed(0)),
      totalPeak: double.parse(totalPeak.toStringAsFixed(0)),
      recommendedAmpPower: double.parse(recommendedAmpPower.toStringAsFixed(0)),
    );
  }
}
