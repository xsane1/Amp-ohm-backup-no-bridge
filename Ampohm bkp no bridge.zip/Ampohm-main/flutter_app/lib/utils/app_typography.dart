import 'package:flutter/material.dart';

class AppTypography {
  /// Devanagari native system font fallbacks prioritized for Android, iOS, and Web.
  /// Placing system Devanagari fonts first prevents generic Latin fonts from
  /// applying artificial faux-bolding onto Devanagari glyphs.
  static const List<String> hindiFontFallback = [
    'Noto Sans Devanagari',
    'Kohinoor Devanagari',
    'Devanagari Sangam MN',
    'sans-serif',
  ];

  static bool isDevanagari(String text) {
    return text.contains(RegExp(r'[\u0900-\u097F]'));
  }

  /// Resolves the ideal font weight for Hindi (Devanagari) scripts.
  /// Devanagari characters feature an intricate continuous top bar (shirorekha),
  /// upper/lower matras, and complex conjuncts.
  /// Weights >= w700 (w700/w800/w900) cause severe stroke dilation, ink-bleed,
  /// and fill in glyph counter-spaces on Android/iOS.
  /// Mapping heavy weights to w600 (SemiBold) preserves strong visual distinction
  /// for headings while keeping conjuncts and matras crisp and legible.
  /// Medium-weight subheadings and card titles (w600) resolve to w500 (Medium).
  static FontWeight resolveWeight(FontWeight originalWeight, {required bool isHindi}) {
    if (!isHindi) return originalWeight;
    if (originalWeight == FontWeight.w900 ||
        originalWeight == FontWeight.w800 ||
        originalWeight == FontWeight.w700 ||
        originalWeight == FontWeight.bold) {
      return FontWeight.w600;
    }
    if (originalWeight == FontWeight.w600) {
      return FontWeight.w500;
    }
    return originalWeight;
  }

  /// Devanagari characters must not have negative letter spacing, as it clashes
  /// upper/lower matras and breaks conjunct alignment. Positive tracking is capped.
  static double? resolveLetterSpacing(double? originalSpacing, {required bool isHindi}) {
    if (!isHindi) return originalSpacing;
    if (originalSpacing == null) return 0.0;
    if (originalSpacing < 0.0) return 0.0;
    if (originalSpacing > 0.25) return 0.2;
    return originalSpacing;
  }

  /// Devanagari requires sufficient line height so top matras (े, ै, ो, ौ, ं)
  /// and bottom matras (ु, ू, ृ, ्) are not clipped by the bounding box.
  static double? resolveHeight(double? originalHeight, {required bool isHindi, double minHeight = 1.25}) {
    if (!isHindi) return originalHeight;
    if (originalHeight == null) return minHeight;
    return originalHeight < minHeight ? minHeight : originalHeight;
  }

  /// Universal style helper that creates a balanced TextStyle for Hindi/Devanagari
  /// while preserving exact Latin styling for English.
  static TextStyle style({
    bool? isHindi,
    String? text,
    double? fontSize,
    FontWeight fontWeight = FontWeight.normal,
    Color? color,
    double? letterSpacing,
    double? height,
    TextDecoration? decoration,
    TextBaseline? textBaseline,
    List<String>? fontFamilyFallback,
  }) {
    final effectiveIsHindi = isHindi ?? (text != null && isDevanagari(text));
    final effectiveWeight = resolveWeight(fontWeight, isHindi: effectiveIsHindi);
    final effectiveSpacing = resolveLetterSpacing(letterSpacing, isHindi: effectiveIsHindi);
    final effectiveHeight = resolveHeight(height, isHindi: effectiveIsHindi);

    return TextStyle(
      fontSize: fontSize,
      fontWeight: effectiveWeight,
      color: color,
      letterSpacing: effectiveSpacing,
      height: effectiveHeight,
      decoration: decoration,
      textBaseline: textBaseline,
      fontFamilyFallback: fontFamilyFallback ?? hindiFontFallback,
    );
  }

  /// Returns a clean, legible TextStyle for titles and headings.
  /// When in Hindi mode, softens heavy weights (w900/w800/w700 -> w600) and removes
  /// negative letter spacing to prevent character and matra clumping.
  static TextStyle title({
    required bool isHindi,
    double fontSize = 16,
    FontWeight fontWeight = FontWeight.w800,
    Color? color,
    double? letterSpacing,
    double? height,
  }) {
    final effectiveWeight = resolveWeight(fontWeight, isHindi: isHindi);
    final effectiveSpacing = resolveLetterSpacing(letterSpacing, isHindi: isHindi);
    final effectiveHeight = resolveHeight(height, isHindi: isHindi, minHeight: 1.25);

    return TextStyle(
      fontSize: fontSize,
      fontWeight: effectiveWeight,
      color: color,
      letterSpacing: effectiveSpacing,
      height: effectiveHeight,
      fontFamilyFallback: hindiFontFallback,
    );
  }

  /// Returns a clean, legible TextStyle for body and secondary text.
  static TextStyle body({
    required bool isHindi,
    double fontSize = 12,
    FontWeight fontWeight = FontWeight.normal,
    Color? color,
    double? letterSpacing,
    double? height,
  }) {
    final effectiveWeight = isHindi
        ? (fontWeight == FontWeight.bold ||
                fontWeight == FontWeight.w900 ||
                fontWeight == FontWeight.w800 ||
                fontWeight == FontWeight.w700
            ? FontWeight.w600
            : (fontWeight == FontWeight.w600 ? FontWeight.w500 : fontWeight))
        : fontWeight;

    final effectiveSpacing = resolveLetterSpacing(letterSpacing, isHindi: isHindi);
    final effectiveHeight = resolveHeight(height, isHindi: isHindi, minHeight: 1.3);

    return TextStyle(
      fontSize: fontSize,
      fontWeight: effectiveWeight,
      color: color,
      letterSpacing: effectiveSpacing,
      height: effectiveHeight,
      fontFamilyFallback: hindiFontFallback,
    );
  }
}
