/**
 * Automated Verification Script for Amp Ohm Subscription Lifecycle & Ad Access Logic
 * 
 * Verifies all 8 scenarios:
 * 1. New successful subscription purchase
 * 2. User cancels auto-renewal 1 day after purchase
 * 3. User cancels auto-renewal 15 days after purchase
 * 4. Subscription reaches its actual expiration date
 * 5. Refund request is pending
 * 6. Refund or revocation makes the entitlement inactive
 * 7. App restart while subscription is active
 * 8. Temporary RevenueCat network failure
 */

interface MockEntitlementInfo {
  identifier: string;
  isActive: boolean;
  willRenew: boolean;
  expirationDate: string | null;
  periodType: string;
}

interface MockCustomerInfo {
  entitlements: {
    all: Record<string, MockEntitlementInfo>;
    active: Record<string, MockEntitlementInfo>;
  };
  activeSubscriptions: string[];
}

class SubscriptionLifecycleSimulator {
  private isPremium = false;
  private activeTier = 'free';
  private expirationDate: Date | null = null;
  private storageCache: { isPremium: boolean; activeTier: string; expirationDate: string | null } = {
    isPremium: false,
    activeTier: 'free',
    expirationDate: null,
  };

  public updateCustomerInfo(customerInfo: MockCustomerInfo): boolean {
    const entitlement = customerInfo.entitlements.all['ampohm Pro'] ||
                        customerInfo.entitlements.all['pro'] ||
                        customerInfo.entitlements.all['ampohm_pro'];

    let hasActiveEntitlement = entitlement?.isActive ?? false;
    let expDate: Date | null = null;

    if (entitlement?.expirationDate) {
      expDate = new Date(entitlement.expirationDate);
    }

    if (!hasActiveEntitlement && Object.keys(customerInfo.entitlements.active).length > 0) {
      hasActiveEntitlement = true;
    }

    if (!hasActiveEntitlement && customerInfo.activeSubscriptions.length > 0) {
      hasActiveEntitlement = true;
    }

    // Cancellation & Expiration enforcement:
    // If user cancelled subscription before expiry, willRenew is false, but isActive remains true until expirationDate.
    // When expirationDate passes, access strictly ends.
    if (expDate && Date.now() > expDate.getTime()) {
      hasActiveEntitlement = false;
    }

    this.isPremium = hasActiveEntitlement;
    this.expirationDate = expDate;
    this.activeTier = this.isPremium ? 'yearly' : 'free';

    // Persist cache
    this.storageCache = {
      isPremium: this.isPremium,
      activeTier: this.activeTier,
      expirationDate: this.expirationDate ? this.expirationDate.toISOString() : null,
    };

    return this.isPremium;
  }

  public simulateAppRestart(): void {
    // Restore from cache and validate expiration
    this.isPremium = this.storageCache.isPremium;
    this.activeTier = this.storageCache.activeTier;
    if (this.storageCache.expirationDate) {
      this.expirationDate = new Date(this.storageCache.expirationDate);
      if (Date.now() > this.expirationDate.getTime()) {
        this.isPremium = false;
        this.activeTier = 'free';
      }
    }
  }

  public simulateNetworkFailureRefresh(): void {
    // Mimics refreshSubscriptionStatus error catch block:
    // Do NOT treat temporary network failure as proof that subscription expired.
    // Retain active subscription if cached expiration date is in the future.
    if (this.expirationDate && Date.now() < this.expirationDate.getTime()) {
      // Retained active subscription
    } else if (this.expirationDate && Date.now() > this.expirationDate.getTime()) {
      this.isPremium = false;
      this.activeTier = 'free';
    }
  }

  public getIsPremium(): boolean {
    return this.isPremium;
  }

  public canShowAds(hasRewardPass: boolean, bannerMasterEnabled: boolean): boolean {
    // Priority 1: Subscription active -> No ads anywhere
    if (this.isPremium) return false;
    // Priority 2: 60-min reward pass active -> No ads
    if (hasRewardPass) return false;
    // Priority 3: Remote kill switch off -> No ads
    if (!bannerMasterEnabled) return false;
    // Free user without pass -> Show ads
    return true;
  }

  public isCalculatorUnlocked(hasRewardPass: boolean): boolean {
    // Priority 1: Subscription active -> Unlocked
    if (this.isPremium) return true;
    // Priority 2: Reward pass active -> Unlocked
    if (hasRewardPass) return true;
    // Free user -> Locked
    return false;
  }
}

// RUN THE 8 SCENARIOS
console.log('--- STARTING AMP OHM SUBSCRIPTION LIFECYCLE AUDIT SUITE ---');
const sim = new SubscriptionLifecycleSimulator();
let allPassed = true;

function assert(scenarioNum: number, condition: boolean, message: string) {
  if (condition) {
    console.log(`[PASS] Scenario ${scenarioNum}: ${message}`);
  } else {
    console.error(`[FAIL] Scenario ${scenarioNum}: ${message}`);
    allPassed = false;
  }
}

// SCENARIO 1: New successful subscription purchase
const now = Date.now();
const oneMonthLater = new Date(now + 30 * 24 * 60 * 60 * 1000).toISOString();

const purchaseCustomerInfo: MockCustomerInfo = {
  entitlements: {
    all: {
      'ampohm Pro': {
        identifier: 'ampohm Pro',
        isActive: true,
        willRenew: true,
        expirationDate: oneMonthLater,
        periodType: 'normal',
      },
    },
    active: {
      'ampohm Pro': {
        identifier: 'ampohm Pro',
        isActive: true,
        willRenew: true,
        expirationDate: oneMonthLater,
        periodType: 'normal',
      },
    },
  },
  activeSubscriptions: ['ampohm_pro_monthly'],
};

sim.updateCustomerInfo(purchaseCustomerInfo);
assert(1, sim.getIsPremium() === true && !sim.canShowAds(false, true) && sim.isCalculatorUnlocked(false),
  'New purchase confirmed: isPremium=true, zero ads, all calculators unlocked immediately without restart');

// SCENARIO 2: User cancels auto-renewal 1 day after purchase
// 1 day passed, 29 days remain
const oneDayLater = now + 1 * 24 * 60 * 60 * 1000;
const cancelledDay1CustomerInfo: MockCustomerInfo = {
  entitlements: {
    all: {
      'ampohm Pro': {
        identifier: 'ampohm Pro',
        isActive: true,          // RevenueCat keeps isActive=true because paid period is valid
        willRenew: false,         // Auto-renew turned off
        expirationDate: oneMonthLater,
        periodType: 'normal',
      },
    },
    active: {
      'ampohm Pro': {
        identifier: 'ampohm Pro',
        isActive: true,
        willRenew: false,
        expirationDate: oneMonthLater,
        periodType: 'normal',
      },
    },
  },
  activeSubscriptions: ['ampohm_pro_monthly'],
};

sim.updateCustomerInfo(cancelledDay1CustomerInfo);
assert(2, sim.getIsPremium() === true && !sim.canShowAds(false, true),
  'Auto-renewal cancelled 1 day after purchase: willRenew=false, isActive=true, access preserved and ad-free');

// SCENARIO 3: User cancels auto-renewal 15 days after purchase
// 15 days passed, 15 days remain
const cancelledDay15CustomerInfo: MockCustomerInfo = {
  entitlements: {
    all: {
      'ampohm Pro': {
        identifier: 'ampohm Pro',
        isActive: true,          // Still within 30-day paid billing period
        willRenew: false,
        expirationDate: oneMonthLater,
        periodType: 'normal',
      },
    },
    active: {
      'ampohm Pro': {
        identifier: 'ampohm Pro',
        isActive: true,
        willRenew: false,
        expirationDate: oneMonthLater,
        periodType: 'normal',
      },
    },
  },
  activeSubscriptions: ['ampohm_pro_monthly'],
};

sim.updateCustomerInfo(cancelledDay15CustomerInfo);
assert(3, sim.getIsPremium() === true && !sim.canShowAds(false, true),
  'Auto-renewal cancelled 15 days after purchase: access continues until verified expiration date');

// SCENARIO 4: Subscription reaches actual expiration date
const pastDate = new Date(Date.now() - 1000).toISOString();
const expiredCustomerInfo: MockCustomerInfo = {
  entitlements: {
    all: {
      'ampohm Pro': {
        identifier: 'ampohm Pro',
        isActive: false,         // Period ended
        willRenew: false,
        expirationDate: pastDate,
        periodType: 'normal',
      },
    },
    active: {},
  },
  activeSubscriptions: [],
};

sim.updateCustomerInfo(expiredCustomerInfo);
assert(4, sim.getIsPremium() === false && sim.canShowAds(false, true) && !sim.isCalculatorUnlocked(false),
  'Subscription expired naturally: returns to free-user rules, ads resume, calculator gate active');

// SCENARIO 5: Refund request is pending
// User requested refund on Google Play, but Google Play has not decided/revoked yet.
const futureExpDate = new Date(Date.now() + 20 * 24 * 60 * 60 * 1000).toISOString();
const pendingRefundCustomerInfo: MockCustomerInfo = {
  entitlements: {
    all: {
      'ampohm Pro': {
        identifier: 'ampohm Pro',
        isActive: true,          // Pending refund is NOT revoked yet
        willRenew: true,
        expirationDate: futureExpDate,
        periodType: 'normal',
      },
    },
    active: {
      'ampohm Pro': {
        identifier: 'ampohm Pro',
        isActive: true,
        willRenew: true,
        expirationDate: futureExpDate,
        periodType: 'normal',
      },
    },
  },
  activeSubscriptions: ['ampohm_pro_monthly'],
};

sim.updateCustomerInfo(pendingRefundCustomerInfo);
assert(5, sim.getIsPremium() === true && !sim.canShowAds(false, true),
  'Refund pending: entitlement remains active in RevenueCat until Google Play decision; user maintains Pro access');

// SCENARIO 6: Refund or revocation makes entitlement inactive
const revokedCustomerInfo: MockCustomerInfo = {
  entitlements: {
    all: {
      'ampohm Pro': {
        identifier: 'ampohm Pro',
        isActive: false,         // Google Play revoked purchase token
        willRenew: false,
        expirationDate: futureExpDate, // Expiration timestamp might still be in future, but isActive is false
        periodType: 'normal',
      },
    },
    active: {},                  // Removed from active entitlements
  },
  activeSubscriptions: [],
};

sim.updateCustomerInfo(revokedCustomerInfo);
assert(6, sim.getIsPremium() === false && sim.canShowAds(false, true),
  'Refund/revocation granted: isActive=false causes immediate removal of Pro access and restores free ad rules');

// SCENARIO 7: App restart while subscription is active
// Re-grant active subscription
sim.updateCustomerInfo(purchaseCustomerInfo);
assert(7.1, sim.getIsPremium() === true, 'Pre-condition: Active subscription set before restart');

// Now simulate cold app launch
sim.simulateAppRestart();
assert(7, sim.getIsPremium() === true && !sim.canShowAds(false, true),
  'App restart with active subscription: restored immediately from cache without flicker, zero ads');

// SCENARIO 8: Temporary RevenueCat network failure
// Simulate device in tunnel / offline: network call fails
sim.simulateNetworkFailureRefresh();
assert(8, sim.getIsPremium() === true && !sim.canShowAds(false, true),
  'Temporary network failure: valid unexpired subscription is NOT marked expired, ad-free access retained');

if (allPassed) {
  console.log('--- ALL 8 SUBSCRIPTION AUDIT SCENARIOS EXECUTED & PASSED ---');
} else {
  console.error('--- SOME SCENARIOS FAILED ---');
  process.exit(1);
}
