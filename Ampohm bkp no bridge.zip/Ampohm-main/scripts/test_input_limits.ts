import { calculateAmplifier } from '../src/calculators/calculations';

function testInputHandling() {
  console.log('--- STARTING INPUT LIMITS & TRUNCATION PREVENTION TEST SUITE ---');

  // Test 1: Valid values (5555, 10000, 100000)
  const validValues = [5555, 10000, 100000];
  for (const val of validValues) {
    const isValid = val >= 200 && val <= 100000;
    if (!isValid) throw new Error(`Expected ${val} to be valid`);
    const res = calculateAmplifier({ speakerRms: val, speakerCount: 2, speakerImpedance: 8 });
    if (res.speakerRms !== val) throw new Error(`Speaker RMS was altered from ${val} to ${res.speakerRms}`);
    console.log(`[PASS] Valid input ${val} preserved exactly: ${res.speakerRms}W`);
  }

  // Test 2: Invalid values (100001, 150000)
  const invalidValues = [100001, 150000];
  for (const val of invalidValues) {
    const isValid = val >= 200 && val <= 100000;
    if (isValid) throw new Error(`Expected ${val} to be invalid`);
    // Crucial: The entered number must NOT be clamped to 20000 or anything else
    let displayedInput = String(val);
    if (displayedInput === '20000') throw new Error(`Previous bug detected! ${val} was replaced with 20000`);
    console.log(`[PASS] Invalid input ${val} retains exact input string "${displayedInput}", validation correctly blocks calculation`);
  }

  // Test 3: Simulation of digit by digit typing of 150000
  // '1' -> '15' -> '150' -> '1500' -> '15000' -> '150000'
  const typedSequence = ['1', '15', '150', '1500', '15000', '150000'];
  let currentVal = '';
  for (const step of typedSequence) {
    currentVal = step;
    const num = parseFloat(currentVal);
    const isValid = num >= 200 && num <= 100000;
    // Verify that at no point does currentVal get mutated into 20000
    if (currentVal === '20000' && step !== '20000') {
      throw new Error(`Typing interrupted: converted ${step} to 20000!`);
    }
    console.log(`  Typing step "${currentVal}": numeric=${num}, valid=${isValid}`);
  }
  if (currentVal !== '150000') throw new Error('Failed digit-by-digit preservation');
  console.log('[PASS] Digit-by-digit typing of 150000 preserved without truncation');

  // Test 4: Editing in the middle (e.g. 150000 -> change '5' to '0' -> 100000)
  const editedMiddle = currentVal.replace('15', '10');
  const editedNum = parseFloat(editedMiddle);
  if (editedNum !== 100000 || !(editedNum >= 200 && editedNum <= 100000)) {
    throw new Error('Middle edit failed');
  }
  console.log(`[PASS] Editing middle '150000' -> '${editedMiddle}' re-enables calculation immediately`);

  // Test 5: Deleting digits (e.g. 150000 -> delete last zero -> 15000)
  const deletedDigits = currentVal.slice(0, -1);
  const deletedNum = parseFloat(deletedDigits);
  if (deletedNum !== 15000 || !(deletedNum >= 200 && deletedNum <= 100000)) {
    throw new Error('Deleting digit failed');
  }
  console.log(`[PASS] Deleting digits '${currentVal}' -> '${deletedDigits}' correctly validates as within limit`);

  // Test 6: Decimal values preservation
  const decimalVal = 1001.10;
  const isDecimalValid = decimalVal >= 200 && decimalVal <= 100000;
  if (!isDecimalValid) throw new Error('Decimal valid check failed');
  const resDecimal = calculateAmplifier({ speakerRms: decimalVal, speakerCount: 1, speakerImpedance: 8 });
  if (resDecimal.speakerRms !== 1001.10) throw new Error('Decimal value altered');
  console.log(`[PASS] Decimal input ${decimalVal} preserved`);

  // Test 7: Speaker count up to 32
  const maxSpeakers = 32;
  const res32 = calculateAmplifier({ speakerRms: 500, speakerCount: maxSpeakers, speakerImpedance: 8 });
  if (res32.speakerCount !== 32) throw new Error(`Speaker count not 32: ${res32.speakerCount}`);
  console.log(`[PASS] Speaker count supports up to ${res32.speakerCount} speakers`);

  console.log('--- ALL INPUT LIMIT AUDITS PASSED SUCCESSFULLY ---');
}

testInputHandling();
