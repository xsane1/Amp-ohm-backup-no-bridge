const fs = require('fs');
const path = require('path');

function walk(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  for (const file of list) {
    const full = path.join(dir, file);
    const stat = fs.statSync(full);
    if (stat && stat.isDirectory()) {
      results = results.concat(walk(full));
    } else if (file.endsWith('.dart')) {
      results.push(full);
    }
  }
  return results;
}

const files = walk('./flutter_app/lib');
console.log('Total dart files found:', files.length);

for (const file of files) {
  const content = fs.readFileSync(file, 'utf8');
  let openP = 0, openB = 0, openK = 0;
  for (let i = 0; i < content.length; i++) {
    const c = content[i];
    if (c === '(') openP++;
    if (c === ')') openP--;
    if (c === '{') openB++;
    if (c === '}') openB--;
    if (c === '[') openK++;
    if (c === ']') openK--;
  }
  if (openP !== 0 || openB !== 0 || openK !== 0) {
    console.error(`Syntax imbalance in ${file}: () => ${openP}, {} => ${openB}, [] => ${openK}`);
  }
}
console.log('Check finished.');
