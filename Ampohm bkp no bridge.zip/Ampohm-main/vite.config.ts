import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import fs from 'fs';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    publicDir: path.resolve(__dirname, 'public'),
    plugins: [
      react(), 
      tailwindcss(),
      {
        name: 'serve-public-static',
        configureServer(server) {
          server.middlewares.use((req, res, next) => {
            if (req.url && (req.url.startsWith('/backup/') || req.url === '/manifest.json' || req.url === '/sw.js' || req.url?.startsWith('/pwa-') || req.url === '/apple-touch-icon.png' || req.url === '/icon.svg' || req.url === '/favicon.ico')) {
              const filePath = path.resolve(__dirname, 'public', req.url.slice(1));
              if (fs.existsSync(filePath)) {
                if (req.url.endsWith('.zip')) {
                  res.setHeader('Content-Type', 'application/zip');
                  res.setHeader('Content-Disposition', 'attachment; filename="AMP_OHM_COMPLETE_CODE_BACKUP.zip"');
                }
                else if (req.url.endsWith('.json')) res.setHeader('Content-Type', 'application/manifest+json');
                else if (req.url.endsWith('.js')) res.setHeader('Content-Type', 'application/javascript');
                else if (req.url.endsWith('.png')) res.setHeader('Content-Type', 'image/png');
                else if (req.url.endsWith('.svg')) res.setHeader('Content-Type', 'image/svg+xml');
                else if (req.url.endsWith('.ico')) res.setHeader('Content-Type', 'image/x-icon');
                res.end(fs.readFileSync(filePath));
                return;
              }
            }
            next();
          });
        }
      }
    ],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modifyâfile watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
