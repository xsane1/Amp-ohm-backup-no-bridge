/**
 * Remote Config & AdMob Management Service
 * 
 * Capabilities:
 * 1. Remote Ad Control via Firestore ('app_config/ads_settings'):
 *    - Global master toggle to turn off/on all ads instantly without updating app
 *    - Banner, Interstitial, and Reward ad toggles
 *    - Remote reward duration (default: 60 minutes)
 * 2. 1-Hour Reward Ad Pass:
 *    - Watching a rewarded ad grants a 60-minute ad-free pass across ALL calculators!
 * 3. Pro Subscription Entitlement:
 *    - Pro subscribers get 100% ad-free experience permanently
 *    - Calculation History & Result Share (WhatsApp/Export) reserved strictly for Pro subscribers
 */

import { doc, getDoc, onSnapshot } from 'firebase/firestore';
import { db } from './firebase';
import { subscriptionService } from './subscriptionService';

/**
 * Official Google AdMob Sample / Test Ad Unit IDs (Android & iOS)
 * Use these test IDs during development & testing to prevent invalid click policy violations.
 * Reference: https://developers.google.com/admob/android/test-ads
 */
export const ADMOB_TEST_IDS = {
  // Android Official Google Test IDs
  android: {
    appId: 'ca-app-pub-3940256099942544~3347511713',
    banner: 'ca-app-pub-3940256099942544/6300978111',
    interstitial: 'ca-app-pub-3940256099942544/1033173712',
    rewarded: 'ca-app-pub-3940256099942544/5224354917',
    rewardedInterstitial: 'ca-app-pub-3940256099942544/5354046379',
  },
  // iOS Official Google Test IDs
  ios: {
    appId: 'ca-app-pub-3940256099942544~1458602516',
    banner: 'ca-app-pub-3940256099942544/2934735716',
    interstitial: 'ca-app-pub-3940256099942544/4411468910',
    rewarded: 'ca-app-pub-3940256099942544/1712485313',
    rewardedInterstitial: 'ca-app-pub-3940256099942544/6978759866',
  }
};

export interface RemoteAdsConfig {
  adsMasterEnabled: boolean;
  bannerAdsEnabled: boolean;
  interstitialAdsEnabled: boolean;
  rewardAdsEnabled: boolean;
  rewardDurationMinutes: number;
  announcement?: string;
}

const DEFAULT_REMOTE_CONFIG: RemoteAdsConfig = {
  adsMasterEnabled: true,
  bannerAdsEnabled: true,
  interstitialAdsEnabled: true,
  rewardAdsEnabled: true,
  rewardDurationMinutes: 60, // 60 minutes unlock across all calculators
};

const STORAGE_KEY_REWARD_EXPIRY = 'proaudio_reward_ad_expiry_v1';

class AdService {
  private config: RemoteAdsConfig = { ...DEFAULT_REMOTE_CONFIG };
  private listeners: Array<(config: RemoteAdsConfig) => void> = [];
  private lastInterstitialTime = 0;
  private minInterstitialIntervalMs = 60 * 1000; // 60s cooldown

  constructor() {
    this.initRemoteConfigSync();
  }

  /**
   * Listen to real-time remote ads control from Firestore
   */
  private initRemoteConfigSync() {
    try {
      const configRef = doc(db, 'app_config', 'ads_settings');
      
      onSnapshot(configRef, (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data() as Partial<RemoteAdsConfig>;
          this.config = {
            ...DEFAULT_REMOTE_CONFIG,
            ...data,
          };
          this.notifyListeners();
        }
      }, () => {
        // Offline fallback: keep default config
      });
    } catch (_) {
      // Fallback safe
    }
  }

  public getConfig(): RemoteAdsConfig {
    return this.config;
  }

  public subscribe(callback: (config: RemoteAdsConfig) => void): () => void {
    this.listeners.push(callback);
    callback(this.config);
    return () => {
      this.listeners = this.listeners.filter(cb => cb !== callback);
    };
  }

  private notifyListeners() {
    this.listeners.forEach(cb => cb(this.config));
  }

  /**
   * Check if the user currently has an active 1-hour reward pass
   */
  public getRemainingRewardTimeMs(): number {
    try {
      const storedExpiry = localStorage.getItem(STORAGE_KEY_REWARD_EXPIRY);
      if (!storedExpiry) return 0;
      const expiry = parseInt(storedExpiry, 10);
      const remaining = expiry - Date.now();
      return remaining > 0 ? remaining : 0;
    } catch (_) {
      return 0;
    }
  }

  public hasActiveRewardPass(): boolean {
    return this.getRemainingRewardTimeMs() > 0;
  }

  public getRewardTimeRemainingMinutes(): number {
    const ms = this.getRemainingRewardTimeMs();
    return Math.ceil(ms / (60 * 1000));
  }

  /**
   * Grants a 60-minute reward unlock across all calculators
   */
  public grantRewardPass(durationMinutes?: number): number {
    const minutes = durationMinutes || this.config.rewardDurationMinutes || 60;
    const expiryTime = Date.now() + (minutes * 60 * 1000);
    try {
      localStorage.setItem(STORAGE_KEY_REWARD_EXPIRY, expiryTime.toString());
      this.notifyListeners();
    } catch (_) {}
    return minutes;
  }

  public clearRewardPass(): void {
    try {
      localStorage.removeItem(STORAGE_KEY_REWARD_EXPIRY);
      this.notifyListeners();
    } catch (_) {}
  }

  /**
   * Master check: Should any ad be shown?
   * Returns FALSE if:
   * 1. User is Pro Subscriber (Premium)
   * 2. Remote Config turned off master ads switch
   */
  public canShowAd(): boolean {
    // 1. Pro users are 100% ad-free
    if (subscriptionService.isPremium() || !subscriptionService.isAdsEnabled()) {
      return false;
    }

    // 2. Remote master toggle
    if (!this.config.adsMasterEnabled) {
      return false;
    }

    return true;
  }

  /**
   * Banner ads remain visible for free users even after watching reward ads.
   * Total ads (banner ads included) are removed ONLY when user is a Pro Subscriber (Premium).
   */
  public canShowBanner(): boolean {
    if (subscriptionService.isPremium() || !subscriptionService.isAdsEnabled()) {
      return false;
    }
    if (this.hasActiveRewardPass()) {
      return false;
    }
    return this.canShowAd() && this.config.bannerAdsEnabled;
  }

  /**
   * Interstitial ads respect the 2-hour pass
   */
  public canShowInterstitial(): boolean {
    if (this.hasActiveRewardPass()) {
      return false;
    }
    return this.canShowAd() && this.config.interstitialAdsEnabled;
  }

  /**
   * Watch ads to unlock / Reward ads:
   * Returns true ONLY if:
   * 1. User is not premium
   * 2. Remote master & reward ads enabled
   * 3. User does NOT have active 2-hour reward pass (once watched, reward ad hides for 2 hours)
   */
  public canShowRewardAd(): boolean {
    if (subscriptionService.isPremium()) return false;
    return this.config.adsMasterEnabled && this.config.rewardAdsEnabled && !this.hasActiveRewardPass();
  }

  /**
   * Request an interstitial ad with cooldown
   */
  public maybeShowInterstitial(source: string): boolean {
    if (!this.canShowInterstitial()) {
      return false;
    }

    const now = Date.now();
    if (now - this.lastInterstitialTime < this.minInterstitialIntervalMs) {
      return false; // In cooldown
    }

    this.lastInterstitialTime = now;
    return true;
  }
}

export const adService = new AdService();
