/**
 * Server-Authoritative Membership & Anti-Tamper Security Service
 * 
 * Protects against modded APKs, memory editors (Lucky Patcher, GameGuardian),
 * and unauthorized local storage tampering.
 * 
 * Multi-Collection Fallback Support:
 * Supports Firestore collection names:
 * - `vip_users` (Recommended short collection name)
 * - `vip` (Ultra short collection name)
 * - `vip_entitlements` (Original collection name)
 * 
 * Document ID Support:
 * - Direct email (e.g. `aslammohammad565@gmail.com`)
 * - Sanitized key (e.g. `aslammohammad565_gmail_com`)
 */

import { doc, getDoc, onSnapshot } from 'firebase/firestore';
import { db } from './firebase';

export interface ServerMembershipRecord {
  tier: 'free' | 'monthly' | 'yearly';
  status: 'active' | 'suspended' | 'expired';
  adsDisabled: boolean;
  unlockedCalculators?: string[];
  note?: string;
  grantedAt?: string;
}

const STORAGE_KEY_VERIFIED_EMAIL = 'proaudio_verified_email_v1';
const VIP_COLLECTIONS = ['vip_users', 'vip', 'vip_entitlements'];

/**
 * Clean sanitization for email hash key (lower-cased, whitespace stripped, non-alphanumeric replaced)
 */
export function sanitizeEmailKey(email: string): string {
  return email.trim().toLowerCase().replace(/[^a-z0-9]/g, '_');
}

class ServerMembershipService {
  private verifiedEmail: string | null = null;
  private serverRecord: ServerMembershipRecord | null = null;
  private isServerVerified: boolean = false;
  private listeners: Array<(record: ServerMembershipRecord | null) => void> = [];
  private unsubscribeListener: (() => void) | null = null;

  constructor() {
    this.init();
  }

  private init() {
    try {
      const savedEmail = localStorage.getItem(STORAGE_KEY_VERIFIED_EMAIL);
      if (savedEmail) {
        this.verifiedEmail = savedEmail.trim().toLowerCase();
        this.syncWithServer(this.verifiedEmail);
      }
    } catch (_) {}
  }

  /**
   * Helper to fetch doc from collection list checking both exact email and sanitized key
   */
  private async findRemoteDoc(email: string): Promise<{ data: ServerMembershipRecord; collection: string; docId: string } | null> {
    const cleanEmail = email.trim().toLowerCase();
    const docKey = sanitizeEmailKey(cleanEmail);

    for (const coll of VIP_COLLECTIONS) {
      try {
        // Check exact email
        const snapExact = await getDoc(doc(db, coll, cleanEmail));
        if (snapExact.exists()) {
          const data = snapExact.data() as ServerMembershipRecord;
          if (data.status === 'active') {
            return { data, collection: coll, docId: cleanEmail };
          }
        }

        // Check sanitized key if different
        if (docKey !== cleanEmail) {
          const snapSanitized = await getDoc(doc(db, coll, docKey));
          if (snapSanitized.exists()) {
            const data = snapSanitized.data() as ServerMembershipRecord;
            if (data.status === 'active') {
              return { data, collection: coll, docId: docKey };
            }
          }
        }
      } catch (_) {}
    }

    return null;
  }

  /**
   * Real-time sync with server-side document
   */
  public async syncWithServer(email: string): Promise<boolean> {
    const cleanEmail = email.trim().toLowerCase();

    if (this.unsubscribeListener) {
      this.unsubscribeListener();
      this.unsubscribeListener = null;
    }

    try {
      const found = await this.findRemoteDoc(cleanEmail);
      if (found) {
        const docRef = doc(db, found.collection, found.docId);
        this.unsubscribeListener = onSnapshot(
          docRef,
          (snapshot) => {
            if (snapshot.exists()) {
              const data = snapshot.data() as Partial<ServerMembershipRecord>;
              if (data.status === 'active') {
                this.serverRecord = {
                  tier: (data.tier === 'monthly' ? 'monthly' : 'yearly'),
                  status: 'active',
                  adsDisabled: data.adsDisabled !== false,
                  unlockedCalculators: data.unlockedCalculators || ['all'],
                  grantedAt: data.grantedAt,
                };
                this.isServerVerified = true;
                this.verifiedEmail = cleanEmail;
                localStorage.setItem(STORAGE_KEY_VERIFIED_EMAIL, cleanEmail);
                this.notify();
                return;
              }
            }

            this.serverRecord = null;
            this.isServerVerified = false;
            this.notify();
          },
          () => {
            this.serverRecord = null;
            this.isServerVerified = false;
            this.notify();
          }
        );

        this.serverRecord = found.data;
        this.isServerVerified = true;
        this.notify();
        return true;
      }

      this.serverRecord = null;
      this.isServerVerified = false;
      this.notify();
      return false;
    } catch (_) {
      return false;
    }
  }

  /**
   * Verify an email submitted via Contact/Support stealth trigger
   */
  public async verifyAndActivateEmail(email: string): Promise<{ success: boolean; tier?: string; message: string }> {
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      return { success: false, message: 'Invalid email format' };
    }

    try {
      const found = await this.findRemoteDoc(cleanEmail);

      if (found) {
        this.verifiedEmail = cleanEmail;
        this.serverRecord = found.data;
        this.isServerVerified = true;
        localStorage.setItem(STORAGE_KEY_VERIFIED_EMAIL, cleanEmail);

        // Start active sync
        this.syncWithServer(cleanEmail);
        this.notify();

        return {
          success: true,
          tier: found.data.tier,
          message: `VIP Access Verified: ${found.data.tier.toUpperCase()} Membership Active.`,
        };
      }

      return {
        success: false,
        message: 'Normal email recorded.',
      };
    } catch (err: any) {
      console.warn('[ServerMembership] Verify query error:', err.message);
      return { success: false, message: 'Network offline or unverified' };
    }
  }

  /**
   * Returns whether server grants active ad-free / pro status
   */
  public isServerAdFree(): boolean {
    if (!this.isServerVerified || !this.serverRecord) return false;
    return this.serverRecord.status === 'active' && this.serverRecord.adsDisabled;
  }

  public getServerTier(): 'free' | 'monthly' | 'yearly' {
    if (!this.isServerVerified || !this.serverRecord) return 'free';
    return this.serverRecord.tier;
  }

  public getVerifiedEmail(): string | null {
    return this.verifiedEmail;
  }

  public subscribe(fn: (record: ServerMembershipRecord | null) => void): () => void {
    this.listeners.push(fn);
    fn(this.serverRecord);
    return () => {
      this.listeners = this.listeners.filter(l => l !== fn);
    };
  }

  private notify() {
    this.listeners.forEach(fn => {
      try {
        fn(this.serverRecord);
      } catch (_) {}
    });
  }

  public clearVIP() {
    this.verifiedEmail = null;
    this.serverRecord = null;
    this.isServerVerified = false;
    localStorage.removeItem(STORAGE_KEY_VERIFIED_EMAIL);
    if (this.unsubscribeListener) {
      this.unsubscribeListener();
      this.unsubscribeListener = null;
    }
    this.notify();
  }
}

export const serverMembershipService = new ServerMembershipService();
