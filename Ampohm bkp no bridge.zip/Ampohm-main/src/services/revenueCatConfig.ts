/**
 * RevenueCat Configuration for AMP OHM
 * App: AMP OHM
 * Package: com.ampohm.app
 * Entitlement: ampohm Pro
 */

export const REVENUECAT_CONFIG = {
  apiKey: 'test_QiAZRaEuqdieuLEgUlnkQffEFvn',
  appId: 'ampohm',
  packageName: 'com.ampohm.app',
  entitlementId: 'ampohm Pro',
  packages: {
    monthly: '$rc_monthly',
    yearly: '$rc_annual',
  },
  isLive: true,
};
