/**
 * Remote App Version & Force Update Service
 * 
 * Controls on-demand remote force update via Firestore:
 * Document Path: `app_config/version_control`
 * 
 * Rules:
 * - By default: `forceUpdateEnabled = false` (No users are ever prompted for force updates on routine updates).
 * - When activated by admin/dashboard (`forceUpdateEnabled = true`):
 *   Checks if current app version is lower than `minRequiredVersion`.
 *   If lower, displays a non-dismissable Force Update Modal with direct update action.
 * - If user is on a modern PWA or web browser, "Update Now" triggers instant cache invalidation
 *   and service worker update to immediately fetch latest release.
 * - If Android APK, "Update Now" redirects to the provided Play Store / Download URL.
 */

import { doc, onSnapshot } from 'firebase/firestore';
import { db } from './firebase';

export const CURRENT_APP_VERSION = '1.0.4';
export const CURRENT_APP_BUILD_NUMBER = 104;

export interface RemoteVersionConfig {
  forceUpdateEnabled: boolean;
  minRequiredVersion: string;
  minRequiredBuildNumber: number;
  latestVersion: string;
  updateTitle?: string;
  updateMessage?: string;
  updateUrl?: string;
  releaseNotes?: string[];
  forceUpdateType?: 'immediate' | 'flexible';
}

export const DEFAULT_VERSION_CONFIG: RemoteVersionConfig = {
  forceUpdateEnabled: false, // Default is OFF so small updates never bother the user
  minRequiredVersion: '1.0.0',
  minRequiredBuildNumber: 100,
  latestVersion: CURRENT_APP_VERSION,
  updateTitle: 'Important Update Required',
  updateMessage: 'A critical update is required to keep your calculations and system stable. Please update now to continue.',
  updateUrl: 'https://play.google.com/store/apps/details?id=com.proaudio.toolkit',
  releaseNotes: [
    'Critical audio calculation stability updates',
    'Performance enhancements and bug fixes'
  ],
  forceUpdateType: 'immediate',
};

/**
 * Compare two semantic version strings (e.g. "1.0.4" vs "1.1.0")
 * Returns:
 *  -1 if v1 < v2
 *   1 if v1 > v2
 *   0 if v1 === v2
 */
export function compareVersions(v1: string, v2: string): number {
  const parts1 = v1.split('.').map(Number);
  const parts2 = v2.split('.').map(Number);
  const len = Math.max(parts1.length, parts2.length);

  for (let i = 0; i < len; i++) {
    const num1 = parts1[i] || 0;
    const num2 = parts2[i] || 0;
    if (num1 < num2) return -1;
    if (num1 > num2) return 1;
  }
  return 0;
}

class VersionControlService {
  private config: RemoteVersionConfig = DEFAULT_VERSION_CONFIG;
  private listeners: ((config: RemoteVersionConfig, shouldForceUpdate: boolean) => void)[] = [];
  private unsubscribe: (() => void) | null = null;
  private isInitialized = false;

  constructor() {
    this.init();
  }

  public init() {
    if (this.isInitialized) return;
    this.isInitialized = true;

    try {
      const configRef = doc(db, 'app_config', 'version_control');
      this.unsubscribe = onSnapshot(
        configRef,
        (snapshot) => {
          if (snapshot.exists()) {
            const data = snapshot.data() as Partial<RemoteVersionConfig>;
            this.config = {
              ...DEFAULT_VERSION_CONFIG,
              ...data,
            };
          } else {
            this.config = DEFAULT_VERSION_CONFIG;
          }
          this.notifyListeners();
        },
        (error) => {
          // If network or permission error, silently fallback to safe defaults (no blocking)
          console.warn('[VersionControlService] Firestore listener warning:', error.message);
          this.config = DEFAULT_VERSION_CONFIG;
          this.notifyListeners();
        }
      );
    } catch (err) {
      console.warn('[VersionControlService] Init error:', err);
      this.config = DEFAULT_VERSION_CONFIG;
      this.notifyListeners();
    }
  }

  public getConfig(): RemoteVersionConfig {
    return this.config;
  }

  public shouldForceUpdate(): boolean {
    // 1. If dashboard admin switch is OFF, NEVER force update
    if (!this.config.forceUpdateEnabled) {
      return false;
    }

    // 2. If dashboard admin switch is ON, check if current version is below minimum required
    const isVersionOutdated = compareVersions(CURRENT_APP_VERSION, this.config.minRequiredVersion) < 0;
    const isBuildOutdated = CURRENT_APP_BUILD_NUMBER < (this.config.minRequiredBuildNumber || 0);

    return isVersionOutdated || isBuildOutdated;
  }

  public subscribe(callback: (config: RemoteVersionConfig, shouldForceUpdate: boolean) => void): () => void {
    this.listeners.push(callback);
    // Initial emission
    callback(this.config, this.shouldForceUpdate());

    return () => {
      this.listeners = this.listeners.filter((cb) => cb !== callback);
    };
  }

  private notifyListeners() {
    const shouldForce = this.shouldForceUpdate();
    this.listeners.forEach((callback) => {
      try {
        callback(this.config, shouldForce);
      } catch (e) {
        console.error('[VersionControlService] Listener error:', e);
      }
    });
  }

  public destroy() {
    if (this.unsubscribe) {
      this.unsubscribe();
      this.unsubscribe = null;
    }
    this.listeners = [];
    this.isInitialized = false;
  }
}

export const versionControlService = new VersionControlService();
