/**
 * Firebase Analytics Preparation Service
 * 
 * Centralized telemetry and event tracking architecture designed for
 * seamless drop-in integration with the official Firebase Analytics SDK.
 * 
 * Tracks:
 * - App Opens
 * - Home Screen Visits
 * - Calculator Opens (Ohm, Amp, Top Speaker, Cable Loss, DMX)
 * - Completed Calculations with parameters
 * - Language Changes
 * - Settings Visits
 * - Usage Reports: Most Used, Least Used, Daily, and Monthly Usage.
 */

export type CalculatorId = 
  | 'ohm_calculator' 
  | 'amplifier_calculator' 
  | 'top_speaker_calculator' 
  | 'cable_loss_calculator' 
  | 'dmx_calculator';

export interface AnalyticsEvent {
  name: string;
  timestamp: number;
  params?: Record<string, any>;
}

export interface CalculatorUsageStats {
  calculatorId: CalculatorId;
  name: string;
  openCount: number;
  calculationCount: number;
  lastUsedTimestamp?: number;
}

const STORAGE_KEY_COUNTS = 'proaudio_analytics_counts_v1';
const STORAGE_KEY_LOGS = 'proaudio_analytics_logs_v1';

class AnalyticsService {
  private counts: Record<string, number> = {};
  private calculationHistory: { id: CalculatorId; timestamp: number }[] = [];

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    try {
      const storedCounts = localStorage.getItem(STORAGE_KEY_COUNTS);
      if (storedCounts) {
        this.counts = JSON.parse(storedCounts);
      }
      const storedLogs = localStorage.getItem(STORAGE_KEY_LOGS);
      if (storedLogs) {
        this.calculationHistory = JSON.parse(storedLogs);
      }
    } catch (_) {
      // Graceful fallback for non-storage environments
      this.counts = {};
      this.calculationHistory = [];
    }
  }

  private persist() {
    try {
      localStorage.setItem(STORAGE_KEY_COUNTS, JSON.stringify(this.counts));
      // Keep only last 500 calculation logs for memory/quota efficiency
      const trimmedLogs = this.calculationHistory.slice(-500);
      localStorage.setItem(STORAGE_KEY_LOGS, JSON.stringify(trimmedLogs));
    } catch (_) {}
  }

  /**
   * Internal dispatcher that mirrors events to console in dev mode
   * and prepares for Firebase Analytics: `logEvent(analytics, name, params)`
   */
  private dispatch(eventName: string, params: Record<string, any> = {}) {
    const event: AnalyticsEvent = {
      name: eventName,
      timestamp: Date.now(),
      params,
    };

    // Increment aggregate event counter
    this.counts[eventName] = (this.counts[eventName] || 0) + 1;
    this.persist();

    // Firebase Analytics Hook:
    // When Firebase is initialized in production, uncomment or connect:
    // if (window.firebaseAnalytics) {
    //   window.firebaseAnalytics.logEvent(eventName, params);
    // }

    if (process.env.NODE_ENV === 'development') {
      // Concise debug logging
      // console.debug(`[Analytics] ${eventName}:`, params);
    }
  }

  // ==========================================
  // Core Tracked Events
  // ==========================================

  public logAppOpen() {
    this.dispatch('app_open', {
      platform: 'web',
      timestamp: Date.now(),
    });
  }

  public logHomeScreenVisit() {
    this.dispatch('screen_view', {
      screen_name: 'home',
      screen_class: 'HomeScreen',
    });
  }

  public logSettingsVisit() {
    this.dispatch('screen_view', {
      screen_name: 'settings',
      screen_class: 'SettingsScreen',
    });
  }

  public logCalculatorOpen(calculatorId: CalculatorId, calculatorName: string) {
    this.counts[`open_${calculatorId}`] = (this.counts[`open_${calculatorId}`] || 0) + 1;
    this.dispatch('calculator_open', {
      calculator_id: calculatorId,
      calculator_name: calculatorName,
    });
  }

  public logCalculationCompleted(calculatorId: CalculatorId, params: Record<string, any> = {}) {
    this.counts[`calc_${calculatorId}`] = (this.counts[`calc_${calculatorId}`] || 0) + 1;
    this.calculationHistory.push({
      id: calculatorId,
      timestamp: Date.now(),
    });
    this.dispatch('calculation_completed', {
      calculator_id: calculatorId,
      ...params,
    });

    // Map to telemetry service for anonymous Firebase sync
    try {
      import('./telemetryService').then(({ telemetryService }) => {
        const keyMap: Record<CalculatorId, 'ohm' | 'amplifier' | 'topSpeaker' | 'cableLoss' | 'dmx'> = {
          ohm_calculator: 'ohm',
          amplifier_calculator: 'amplifier',
          top_speaker_calculator: 'topSpeaker',
          cable_loss_calculator: 'cableLoss',
          dmx_calculator: 'dmx',
        };
        const key = keyMap[calculatorId];
        if (key) {
          telemetryService.trackCalculation(key);
        }
      }).catch(() => {});
    } catch (_) {}
  }

  public logLanguageChange(previousLanguage: string, newLanguage: string) {
    this.dispatch('language_change', {
      previous_language: previousLanguage,
      new_language: newLanguage,
    });
  }

  public logSubscriptionView() {
    this.dispatch('subscription_screen_view', {
      source: 'settings',
    });
  }

  // ==========================================
  // Usage Reporting (Most / Least / Daily / Monthly)
  // ==========================================

  public getUsageReport() {
    const calculators: { id: CalculatorId; name: string }[] = [
      { id: 'ohm_calculator', name: 'Ohm Calculator' },
      { id: 'amplifier_calculator', name: 'Amplifier Calculator' },
      { id: 'top_speaker_calculator', name: 'Top Speaker Calculator' },
      { id: 'cable_loss_calculator', name: 'Cable Loss Calculator' },
      { id: 'dmx_calculator', name: 'DMX Address Calculator' },
    ];

    const stats: CalculatorUsageStats[] = calculators.map((calc) => {
      return {
        calculatorId: calc.id,
        name: calc.name,
        openCount: this.counts[`open_${calc.id}`] || 0,
        calculationCount: this.counts[`calc_${calc.id}`] || 0,
      };
    });

    // Sort by calculation count
    const sorted = [...stats].sort((a, b) => b.calculationCount - a.calculationCount);
    const mostUsed = sorted[0]?.calculationCount > 0 ? sorted[0] : null;
    const leastUsed = sorted[sorted.length - 1];

    // Daily & Monthly usage calculation based on timestamps
    const now = Date.now();
    const oneDayAgo = now - 24 * 60 * 60 * 1000;
    const thirtyDaysAgo = now - 30 * 24 * 60 * 60 * 1000;

    const dailyCalculations = this.calculationHistory.filter(h => h.timestamp >= oneDayAgo).length;
    const monthlyCalculations = this.calculationHistory.filter(h => h.timestamp >= thirtyDaysAgo).length;
    const totalCalculations = this.calculationHistory.length;

    return {
      stats,
      mostUsed,
      leastUsed,
      dailyCalculations,
      monthlyCalculations,
      totalCalculations,
      appOpens: this.counts['app_open'] || 1,
    };
  }
}

export const analyticsService = new AnalyticsService();
