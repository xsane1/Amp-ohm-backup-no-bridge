/**
 * RevenueCat Preparation Service & Central Entitlement System
 * 
 * Provides an uncoupled, centralized entitlement management layer ready for
 * RevenueCat SDK integration (`react-native-purchases` / `@revenuecat/purchases-js`).
 * 
 * Central Entitlement System:
 * - Does NOT hardcode premium logic into views.
 * - Supports granular entitlements:
 *   - 'remove_ads'
 *   - 'advanced_calculators'
 *   - 'speaker_database'
 *   - 'amplifier_database'
 *   - 'wiring_library'
 *   - 'pdf_export'
 * - Subscription tiers:
 *   - 'free'
 *   - 'monthly'
 *   - 'yearly'
 */

import { REVENUECAT_CONFIG } from './revenueCatConfig';
import { serverMembershipService } from './serverMembershipService';

export type SubscriptionTier = 'free' | 'monthly' | 'yearly';

export type Entitlement = 
  | 'remove_ads' 
  | 'advanced_calculators' 
  | 'speaker_database' 
  | 'amplifier_database' 
  | 'wiring_library' 
  | 'pdf_export';

export interface SubscriptionPackage {
  id: SubscriptionTier;
  title: string;
  price: string;
  period: string;
  badge?: string;
  description: string;
  revenueCatPackageId: string;
}

const STORAGE_KEY_TIER = 'proaudio_subscription_tier_v1';

class SubscriptionService {
  private currentTier: SubscriptionTier = 'free';
  private listeners: Set<() => void> = new Set();

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY_TIER);
      if (stored && ['free', 'monthly', 'yearly'].includes(stored)) {
        this.currentTier = stored as SubscriptionTier;
      }
    } catch (_) {
      this.currentTier = 'free';
    }
  }

  private persist() {
    try {
      localStorage.setItem(STORAGE_KEY_TIER, this.currentTier);
    } catch (_) {}
    this.notifyListeners();
  }

  public addListener(callback: () => void): () => void {
    this.listeners.add(callback);
    return () => this.listeners.delete(callback);
  }

  private notifyListeners() {
    this.listeners.forEach((fn) => {
      try {
        fn();
      } catch (_) {}
    });
  }

  /**
   * Check if user has active premium access (combines verified server membership & validated tier)
   */
  public isPremium(): boolean {
    if (serverMembershipService.isServerAdFree()) {
      return true;
    }
    return this.currentTier !== 'free';
  }

  /**
   * Check if user has a specific entitlement unlocked
   */
  public hasEntitlement(entitlement: Entitlement): boolean {
    // 1. Server-authoritative VIP record grants all entitlements
    if (serverMembershipService.isServerAdFree()) {
      return true;
    }

    if (this.currentTier === 'free') {
      return false;
    }

    // All active paid tiers (monthly, yearly) grant full pro entitlements
    switch (entitlement) {
      case 'remove_ads':
      case 'advanced_calculators':
      case 'speaker_database':
      case 'amplifier_database':
      case 'wiring_library':
      case 'pdf_export':
        return true;
      default:
        return false;
    }
  }

  /**
   * Check if advertisements should be enabled
   * Returns false if server verified VIP or premium subscriber.
   */
  public isAdsEnabled(): boolean {
    if (serverMembershipService.isServerAdFree()) {
      return false;
    }
    return !this.hasEntitlement('remove_ads');
  }

  /**
   * Get the current active subscription tier
   */
  public getCurrentTier(): SubscriptionTier {
    const serverTier = serverMembershipService.getServerTier();
    if (serverTier !== 'free') {
      return serverTier;
    }
    return this.currentTier;
  }

  // Display Pricing
  private priceMonthly = '₹49';
  private priceAnnual = '₹399';

  /**
   * Available subscription options (Monthly and Yearly with ₹49 and ₹399 Most Popular)
   */
  public getAvailablePackages(): SubscriptionPackage[] {
    return [
      {
        id: 'yearly',
        title: 'Pro Yearly',
        price: '₹399',
        period: '/ year',
        badge: 'Most Popular',
        description: 'Best value. Full access to all calculators & 100% ad-free.',
        revenueCatPackageId: '$rc_annual',
      },
      {
        id: 'monthly',
        title: 'Pro Monthly',
        price: '₹49',
        period: '/ month',
        description: 'Flexible monthly access. Cancel anytime in Google Play.',
        revenueCatPackageId: '$rc_monthly',
      },
    ];
  }

  /**
   * Purchase / Activate a tier
   * Future RevenueCat Hook: `await Purchases.purchasePackage(packageToPurchase)`
   */
  public async purchaseTier(tier: SubscriptionTier): Promise<boolean> {
    // In production or mobile wrapper with RevenueCat SDK:
    // Purchases.configure({ apiKey: REVENUECAT_CONFIG.apiKey });
    // const { customerInfo } = await Purchases.purchasePackage(rcPackage);
    
    // Log RevenueCat entitlement acquisition
    console.info(`[RevenueCat] Entitlement '${REVENUECAT_CONFIG.entitlementId}' granted for tier: ${tier} (API Key: ${REVENUECAT_CONFIG.apiKey.slice(0, 12)}...)`);
    
    this.currentTier = tier;
    this.persist();

    // Sync anonymously to Firebase
    try {
      const { telemetryService } = await import('./telemetryService');
      telemetryService.syncSubscriptionStatus(tier);
    } catch (_) {}

    return true;
  }

  /**
   * Restore Purchases
   * Future RevenueCat Hook: `await Purchases.restorePurchases()`
   */
  public async restorePurchases(): Promise<boolean> {
    // In production:
    // const customerInfo = await Purchases.restorePurchases();
    // return this.updateFromCustomerInfo(customerInfo);
    
    // For test simulation, if tier is active keep it, otherwise restore yearly
    if (this.currentTier === 'free') {
      this.currentTier = 'yearly';
      this.persist();
      try {
        const { telemetryService } = await import('./telemetryService');
        telemetryService.syncSubscriptionStatus('yearly');
      } catch (_) {}
      return true;
    }
    return true;
  }

  /**
   * Reset / Downgrade for testing or cancellation simulation
   */
  public resetToFree() {
    this.currentTier = 'free';
    this.persist();
    try {
      import('./telemetryService').then(({ telemetryService }) => {
        telemetryService.syncSubscriptionStatus('free');
      }).catch(() => {});
    } catch (_) {}
  }
}

export const subscriptionService = new SubscriptionService();
