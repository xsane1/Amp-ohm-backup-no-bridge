export interface HistoryDetail {
  label: string;
  value: string;
}

export interface HistoryEntry {
  id: string;
  calculatorId: 'calc_ohm' | 'calc_amp' | 'calc_cable_loss' | 'calc_dmx';
  calculatorName: string;
  resultSummary: string;
  badge?: {
    text: string;
    type: 'safe' | 'warning' | 'danger' | 'info';
  };
  details: HistoryDetail[];
  timestamp: number;
}

const STORAGE_KEY = 'amp_ohm_calculation_history';
const MAX_ENTRIES = 60;

class HistoryService {
  private listeners: (() => void)[] = [];

  getHistory(): HistoryEntry[] {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      if (!data) return [];
      const parsed = JSON.parse(data);
      return Array.isArray(parsed) ? parsed : [];
    } catch (e) {
      console.warn('Failed to load history from localStorage', e);
      return [];
    }
  }

  addEntry(entry: Omit<HistoryEntry, 'id' | 'timestamp'>): HistoryEntry {
    try {
      const current = this.getHistory();
      const newEntry: HistoryEntry = {
        ...entry,
        id: 'hist_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
        timestamp: Date.now(),
      };

      // Keep most recent first, filter duplicates within 2 seconds
      const filtered = current.filter(
        (item) =>
          item.calculatorId !== newEntry.calculatorId ||
          item.resultSummary !== newEntry.resultSummary ||
          Date.now() - item.timestamp > 2000
      );

      const updated = [newEntry, ...filtered].slice(0, MAX_ENTRIES);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      this.notify();
      return newEntry;
    } catch (e) {
      console.warn('Failed to save calculation history', e);
      return {
        ...entry,
        id: 'hist_' + Date.now(),
        timestamp: Date.now(),
      };
    }
  }

  clearHistory(): void {
    try {
      localStorage.removeItem(STORAGE_KEY);
      this.notify();
    } catch (e) {
      console.warn('Failed to clear history', e);
    }
  }

  deleteEntry(id: string): void {
    try {
      const current = this.getHistory();
      const updated = current.filter((item) => item.id !== id);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      this.notify();
    } catch (e) {
      console.warn('Failed to delete history item', e);
    }
  }

  subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach((listener) => {
      try {
        listener();
      } catch (err) {
        console.error(err);
      }
    });
  }
}

export const historyService = new HistoryService();
