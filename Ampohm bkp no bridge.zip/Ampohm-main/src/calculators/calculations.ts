import { 
  OhmResult, 
  AmpResult, 
  CableLossCalculationParams,
  CableLossResult, 
  CableSizeOption,
  CableMaterialOption,
  MaxAcceptableLossOption,
  CableStatusBadgeLevel,
  CableSizeAnalysis,
  CableWarningLevel,
  ContextualWarningItem,
  DmxCalculationParams,
  DmxResult,
  DmxFixtureSequence,
  DmxFixtureEntry,
  StatusLevel,
  LoadClassification,
  HeadroomMultiplier 
} from '../types';

/**
 * 1. Ohm Calculator
 */
export function calculateOhm(params: {
  speakerRms: number; // Watts RMS (Min 200W)
  speakerCount: number; // 1 to 32
  speakerImpedance: number; // 2, 4, 6, 8, 16 Ω
  wiring: 'parallel' | 'series';
}): OhmResult {
  const { speakerRms, speakerCount, speakerImpedance, wiring } = params;
  const count = Math.min(32, Math.max(1, Math.round(speakerCount)));
  
  let rawImpedance: number;
  if (wiring === 'parallel') {
    rawImpedance = speakerImpedance / count;
  } else {
    rawImpedance = speakerImpedance * count;
  }

  // Maximum 2 decimal places rounding
  const totalImpedance = Math.round(rawImpedance * 100) / 100;
  const totalSystemRms = Math.round(speakerRms * count);
  const perSpeakerPower = speakerRms;

  let classification: 'extreme' | 'requires_2ohm' | 'high_current' | 'safe' | 'pro_load' | 'uncommon';
  let status: StatusLevel;
  let badgeColor: 'red' | 'yellow' | 'green' | 'blue';
  let statusTitleKey: string;
  let statusMessageKey: string;
  let canRecommendAmp: boolean;

  if (totalImpedance < 2.0) {
    // < 2Ω: Extreme Load (Red / Danger) - No Amp Recommendation
    classification = 'extreme';
    status = 'danger';
    badgeColor = 'red';
    statusTitleKey = 'ohmClassExtreme';
    statusMessageKey = 'ohmClassExtremeMsg';
    canRecommendAmp = false;
  } else if (Math.abs(totalImpedance - 2.0) < 0.005) {
    // Exactly 2Ω: Requires 2Ω Stable Amp (Yellow / Caution) - Amp recommendation enabled
    classification = 'requires_2ohm';
    status = 'warning';
    badgeColor = 'yellow';
    statusTitleKey = 'ohmClassRequires2Ohm';
    statusMessageKey = 'ohmClassRequires2OhmMsg';
    canRecommendAmp = true;
  } else if (totalImpedance > 2.0 && totalImpedance < 4.0) {
    // > 2Ω and < 4Ω: High Current Load (Yellow / Caution) - Amp recommendation enabled
    classification = 'high_current';
    status = 'warning';
    badgeColor = 'yellow';
    statusTitleKey = 'ohmClassHighCurrent';
    statusMessageKey = 'ohmClassHighCurrentMsg';
    canRecommendAmp = true;
  } else if (totalImpedance >= 4.0 && totalImpedance <= 8.0) {
    // 4Ω to 8Ω: Safe Load (Green / Safe) - Amp recommendation enabled
    classification = 'safe';
    status = 'safe';
    badgeColor = 'green';
    statusTitleKey = 'ohmClassSafe';
    statusMessageKey = 'ohmClassSafeMsg';
    canRecommendAmp = true;
  } else if (totalImpedance > 8.0 && totalImpedance <= 16.0) {
    // > 8Ω and <= 16Ω: Professional Load (Blue / Info) - Amp recommendation enabled
    classification = 'pro_load';
    status = 'info';
    badgeColor = 'blue';
    statusTitleKey = 'ohmClassProLoad';
    statusMessageKey = Math.abs(totalImpedance - 16.0) < 0.005 ? 'ohmClass16OhmMsg' : 'ohmClassProLoadMsg';
    canRecommendAmp = true;
  } else {
    // > 16Ω: Uncommon Load (Blue / Info) - Amp recommendation enabled with advisory
    classification = 'uncommon';
    status = 'info';
    badgeColor = 'blue';
    statusTitleKey = 'ohmClassUncommon';
    statusMessageKey = 'ohmClassUncommonMsg';
    canRecommendAmp = true;
  }

  return {
    totalImpedance,
    speakerRms,
    speakerCount: count,
    totalSystemRms,
    perSpeakerPower,
    speakerImpedance,
    wiring,
    classification,
    status,
    badgeColor,
    statusTitleKey,
    statusMessageKey,
    canRecommendAmp,
  };
}

/**
 * 2. Amplifier Calculator
 */
export function calculateAmplifier(params: {
  speakerRms: number;
  speakerCount?: number;
  speakerImpedance?: number;
  wiring?: 'parallel' | 'series';
  headroom?: HeadroomMultiplier;
  finalLoad?: number;
  totalSystemRms?: number;
  // Fallbacks for legacy callers if any:
  nominalImpedance?: number;
  usageType?: 'live' | 'dj' | 'speech';
}): AmpResult {
  const speakerRms = Math.max(0, params.speakerRms);
  const count = Math.min(32, Math.max(1, params.speakerCount ?? 1));
  const impedance = params.speakerImpedance ?? params.nominalImpedance ?? 8;
  const wiring = params.wiring ?? 'parallel';
  
  // Headroom determination
  let headroom: HeadroomMultiplier = params.headroom ?? 1.50;
  if (!params.headroom && params.usageType) {
    if (params.usageType === 'speech') headroom = 1.25;
    else if (params.usageType === 'dj') headroom = 2.00;
    else headroom = 1.50;
  }

  // Step 1: Calculate Final Load (max 2 decimals)
  const rawLoad = params.finalLoad !== undefined 
    ? params.finalLoad 
    : (wiring === 'parallel' ? impedance / count : impedance * count);
  const finalLoad = Number(rawLoad.toFixed(2));

  // Step 2: Calculate Total RMS (preserve decimals if present)
  const rawTotalRms = params.totalSystemRms !== undefined
    ? params.totalSystemRms
    : speakerRms * count;
  const totalSystemRms = Number(rawTotalRms.toFixed(2));

  // Step 3: Calculate Recommended Amplifier Power (Total RMS * Headroom, preserve decimals)
  const recommendedAmpPower = Number((totalSystemRms * headroom).toFixed(2));

  // Load Classification & Recommendation Availability
  let classification: LoadClassification;
  let status: StatusLevel;
  let badgeColor: 'red' | 'yellow' | 'green' | 'blue';
  let statusTitleKey: string;
  let statusMessageKey: string;
  let isRecommendationAvailable = true;

  if (finalLoad < 2.0) {
    // Below 2Ω: Extreme Load (Red) - Not Recommended, NO recommendation
    classification = 'extreme';
    status = 'danger';
    badgeColor = 'red';
    statusTitleKey = 'ampClassExtremeTitle';
    statusMessageKey = 'ampClassExtremeMsg';
    isRecommendationAvailable = false;
  } else if (Math.abs(finalLoad - 2.0) < 0.005) {
    // Exactly 2Ω: Requires 2Ω Stable Amplifier (Yellow) - Recommendation YES
    classification = 'requires_2ohm';
    status = 'warning';
    badgeColor = 'yellow';
    statusTitleKey = 'ohmClassRequires2Ohm';
    statusMessageKey = 'ohmClassRequires2OhmMsg';
    isRecommendationAvailable = true;
  } else if (finalLoad > 2.0 && finalLoad < 4.0) {
    // Above 2Ω and Below 4Ω: High Current Load (Yellow) - Recommendation YES
    classification = 'high_current';
    status = 'warning';
    badgeColor = 'yellow';
    statusTitleKey = 'ohmClassHighCurrent';
    statusMessageKey = 'ohmClassHighCurrentMsg';
    isRecommendationAvailable = true;
  } else if (finalLoad >= 4.0 && finalLoad <= 8.0) {
    // 4Ω to 8Ω: Safe Load (Green) - Recommendation YES
    classification = 'safe';
    status = 'safe';
    badgeColor = 'green';
    statusTitleKey = 'ohmClassSafe';
    statusMessageKey = 'ohmClassSafeMsg';
    isRecommendationAvailable = true;
  } else if (finalLoad > 8.0 && finalLoad <= 16.0) {
    // Above 8Ω and Up To 16Ω: Professional Load (Blue) - Recommendation YES
    classification = 'pro_load';
    status = 'info';
    badgeColor = 'blue';
    statusTitleKey = 'ohmClassProLoad';
    statusMessageKey = Math.abs(finalLoad - 16.0) < 0.005 ? 'ohmClass16OhmMsg' : 'ohmClassProLoadMsg';
    isRecommendationAvailable = true;
  } else {
    // Above 16Ω: Uncommon Load (Blue) - Recommendation available with advisory info
    classification = 'uncommon';
    status = 'info';
    badgeColor = 'blue';
    statusTitleKey = 'ampClassUncommonTitle';
    statusMessageKey = 'ampClassUncommonMsg';
    isRecommendationAvailable = true;
  }

  return {
    speakerRms,
    speakerCount: count,
    totalSystemRms,
    speakerImpedance: impedance,
    wiring,
    headroom,
    finalLoad,
    recommendedAmpPower,
    classification,
    badgeColor,
    status,
    statusTitleKey,
    statusMessageKey,
    isRecommendationAvailable,
  };
}



/**
 * 4. Speaker Cable Recommendation & Loss Calculator
 * Uses industry-standard loudspeaker line resistance calculations.
 * Supports Pure Copper (0.0175 Ω·mm²/m) and CCA (0.0280 Ω·mm²/m).
 * Standard pro audio metric cable gauges: 1.5, 2.5, 4.0, 6.0, 10.0 mm².
 * Provides Minimum Acceptable, Recommended, and Professional Choice tiers.
 */
export const COPPER_RESISTIVITY = 0.0175; // Ohm * mm² / m at operating temperature
export const CCA_RESISTIVITY = 0.0280;    // Ohm * mm² / m (~1.6x pure copper resistance)
export const STANDARD_CABLE_SIZES: CableSizeOption[] = [1.5, 2.5, 4, 6, 10];

export const CABLE_SIZE_AWG_MAP: Record<CableSizeOption, string> = {
  1.5: '16 AWG',
  2.5: '13 AWG',
  4: '11 AWG',
  6: '9 AWG',
  10: '7 AWG',
};

export function getAwgEquivalent(size?: CableSizeOption | null): string {
  if (!size) return '';
  return CABLE_SIZE_AWG_MAP[size] || '';
}

export function getResistivity(material: CableMaterialOption = 'copper'): number {
  return material === 'cca' ? CCA_RESISTIVITY : COPPER_RESISTIVITY;
}

export function calculateCableResistance(
  lengthMeters: number, 
  cableSizeMm2: number, 
  material: CableMaterialOption = 'copper'
): number {
  const rho = getResistivity(material);
  // 2-way circuit loop resistance = 2 * (rho * length / crossSectionArea)
  return (2 * rho * lengthMeters) / cableSizeMm2;
}

export function getCableStatusBadge(resistanceRatioPercent: number, targetLoss: number = 5.0): {
  statusBadge: CableStatusBadgeLevel;
  badgeLabel: string;
  badgeEmoji: string;
} {
  if (resistanceRatioPercent <= targetLoss) {
    if (resistanceRatioPercent <= 2.5) {
      return {
        statusBadge: 'excellent',
        badgeLabel: 'Excellent',
        badgeEmoji: '🟢',
      };
    } else if (targetLoss > 5.0 && resistanceRatioPercent > 5.0) {
      return {
        statusBadge: 'acceptable',
        badgeLabel: 'Acceptable',
        badgeEmoji: '🟡',
      };
    } else {
      return {
        statusBadge: 'recommended',
        badgeLabel: 'Recommended',
        badgeEmoji: '🟢',
      };
    }
  } else {
    if (resistanceRatioPercent <= 12.0) {
      return {
        statusBadge: 'high_loss',
        badgeLabel: 'High Loss',
        badgeEmoji: '🟠',
      };
    } else {
      return {
        statusBadge: 'not_recommended',
        badgeLabel: 'Target Exceeded',
        badgeEmoji: '🔴',
      };
    }
  }
}

export function calculateCableLoss(params: CableLossCalculationParams): CableLossResult {
  const { 
    cableLength, 
    power, 
    load, 
    material = 'copper', 
    maxAcceptableLoss = 5,
    cableSize: userCableSize 
  } = params;

  const validLength = Math.max(0.1, cableLength);
  const validPower = Math.max(1, power);
  const validLoad = load || 4;
  const isCca = material === 'cca';
  const targetLoss = maxAcceptableLoss || 5;

  // Track compliant sizes using full-precision unrounded resistance ratio
  let recommendedSize: CableSizeOption | null = null;
  let proChoiceSize: CableSizeOption | null = null;

  // Compute metrics across all 5 standard cable sizes (1.5, 2.5, 4.0, 6.0, 10.0 mm²)
  const allSizes: CableSizeAnalysis[] = STANDARD_CABLE_SIZES.map((sz) => {
    // R_loop = (2 * rho * L) / A (outgoing + return conductors)
    const loopR = calculateCableResistance(validLength, sz, material);
    const roundedLoopR = Math.round(loopR * 1000) / 1000;
    
    // A. Cable Resistance Ratio (%) = (R_loop / R_load) * 100
    const rawResistanceRatio = (loopR / validLoad) * 100;
    const roundedResistanceRatio = Math.round(rawResistanceRatio * 100) / 100;

    // Total loop series impedance: Z_total = R_load + R_loop
    const totalZ = validLoad + loopR;

    // B. Actual Cable Power-Loss Percentage (%) = (R_loop / (R_load + R_loop)) * 100
    const rawActualPowerLoss = (loopR / totalZ) * 100;
    const roundedActualPowerLoss = Math.round(rawActualPowerLoss * 10) / 10;

    // C. Electrical Power Dissipated in Cable & Delivered to Speaker
    // Modeled as amplifier ideal voltage source: V_source = sqrt(P_ideal * R_load)
    const vSource = Math.sqrt(validPower * validLoad);
    const iCircuit = vSource / totalZ;
    const vDrop = Math.round(iCircuit * loopR * 100) / 100;
    const pLossWatts = Math.round(Math.pow(iCircuit, 2) * loopR * 10) / 10;
    const pSpeakerWatts = Math.round(Math.pow(iCircuit, 2) * validLoad * 10) / 10;

    // D. Level Reduction in dB = 20 * log10(R_load / (R_load + R_loop))
    const rawLevelLossDb = 20 * Math.log10(validLoad / totalZ);
    const levelLossDb = Math.round(rawLevelLossDb * 100) / 100;

    // Delivery Efficiency (%) = (P_speaker / (P_speaker + P_loss)) * 100 = (R_load / totalZ) * 100
    const effPct = Math.round((validLoad / totalZ) * 1000) / 10;

    // Target compliance: unrounded comparison of resistance ratio against target
    const isCompliant = rawResistanceRatio <= targetLoss;
    const { statusBadge, badgeLabel, badgeEmoji } = getCableStatusBadge(rawResistanceRatio, targetLoss);

    // Select smallest size meeting target (STANDARD_CABLE_SIZES is in ascending order)
    if (isCompliant && recommendedSize === null) {
      recommendedSize = sz;
    }
    // Professional touring grade target (<= 2.5% resistance ratio for high damping factor)
    if (rawResistanceRatio <= 2.5 && proChoiceSize === null) {
      proChoiceSize = sz;
    }

    return {
      size: sz,
      loopResistance: roundedLoopR,
      resistanceRatioPercent: roundedResistanceRatio,
      actualPowerLossPercent: roundedActualPowerLoss,
      powerLossWatts: pLossWatts,
      powerDeliveredWatts: pSpeakerWatts,
      levelLossDb,
      voltageDrop: vDrop,
      powerLossPercent: roundedActualPowerLoss, // backward compatibility alias
      efficiencyPercent: effPct,
      isCompliant,
      statusBadge,
      badgeLabel,
      badgeEmoji,
    };
  });

  const meetsTarget = recommendedSize !== null;
  // If no available size meets target: recommended is null, and 10 mm² is identified as lowest-loss alternative
  const finalRec: CableSizeOption | null = meetsTarget ? recommendedSize : null;
  const displayCableSize: CableSizeOption = meetsTarget ? recommendedSize! : 10;
  // "Min Acceptable": genuinely meets target; null if none meets target
  const finalMin: CableSizeOption | null = meetsTarget ? recommendedSize : null;
  // "Pro Choice": strictly evaluates resistance ratio <= 2.5% benchmark
  const finalPro: CableSizeOption | null = proChoiceSize;

  // Primary active evaluation is based on user cable size or display cable size
  const activeEvaluatedSize = userCableSize || displayCableSize;
  const activeAnalysis = allSizes.find((s) => s.size === activeEvaluatedSize) || allSizes[allSizes.length - 1];

  const loopResistance = activeAnalysis.loopResistance;
  const resistanceRatioPercent = activeAnalysis.resistanceRatioPercent;
  const actualPowerLossPercent = activeAnalysis.actualPowerLossPercent;
  const voltageDrop = activeAnalysis.voltageDrop;
  const ampVoltage = Math.sqrt(validPower * validLoad);
  const voltageDropPercent = Math.round((voltageDrop / ampVoltage) * 1000) / 10;
  const powerLossWatts = activeAnalysis.powerLossWatts;
  const powerLossPercent = activeAnalysis.actualPowerLossPercent;
  const levelLossDb = activeAnalysis.levelLossDb;
  const estimatedEfficiency = activeAnalysis.efficiencyPercent;
  const powerDeliveredWatts = activeAnalysis.powerDeliveredWatts;

  const { statusBadge, badgeLabel, badgeEmoji } = getCableStatusBadge(resistanceRatioPercent, targetLoss);

  let statusSummary = '';
  if (statusBadge === 'excellent') {
    statusSummary = 'High fidelity with negligible power dissipation and optimal bass punch.';
  } else if (statusBadge === 'recommended') {
    statusSummary = 'Pro live sound standard (<5% loss). Crisp transients and balanced efficiency.';
  } else if (statusBadge === 'acceptable') {
    statusSummary = 'Acceptable for standard runs, but higher gauge recommended for subwoofers.';
  } else if (statusBadge === 'high_loss') {
    statusSummary = 'Noticeable loss of acoustic output and bass control. Upgrade to a thicker cable.';
  } else {
    statusSummary = 'Severe loss (>12%). Cable run is too long or wire is too thin for this load.';
  }

  const ccaWarning =
    'CCA cable has higher resistance than pure copper. For longer cable runs, increased losses and reduced performance may occur. Consider using a larger cable size or pure copper cable.';

  // Build Contextual Warnings per professional warning system specification:
  // Strictly avoid absolute words ("will damage", "will fail", "will burn").
  // Use words such as: "may occur", "can increase", "may reduce", "consider".
  const contextualWarnings: ContextualWarningItem[] = [];

  // 1. Distance Warnings (Mutually exclusive tiers for clean presentation: 200m+ vs 100m+ vs 50m+)
  if (validLength >= 200) {
    contextualWarnings.push({
      id: 'extreme-distance',
      type: 'danger',
      iconType: 'extreme_run',
      title: 'Extreme Cable Distance',
      message: 'This cable run is unusually long for passive speaker systems. Significant power loss may occur even with large cable sizes. Professional installations often place amplifiers closer to loudspeakers for such distances.',
    });
  } else if (validLength >= 100) {
    contextualWarnings.push({
      id: 'very-long-run',
      type: 'warning',
      iconType: 'extreme_run',
      title: 'Very Long Cable Run',
      message: 'Long cable runs may reduce amplifier power delivered to the speaker. Bass impact and overall system efficiency may be reduced. Consider larger cable sizes or relocating amplifiers closer to loudspeakers.',
    });
  } else if (validLength >= 50) {
    contextualWarnings.push({
      id: 'long-cable-run',
      type: 'warning',
      iconType: 'long_run',
      title: 'Long Cable Run',
      message: 'Long cable runs increase cable resistance and power loss. Consider using larger cable sizes for improved performance.',
    });
  }

  // 2. IMPEDANCE SOUND STANDARD WARNINGS
  if (validLoad < 2) {
    contextualWarnings.push({
      id: 'impedance-below-2-ohm',
      type: 'danger',
      iconType: 'high_current',
      title: 'Impedance Below 2Ω',
      message: 'Calculated impedance is below 2Ω. Many amplifiers are not designed to operate safely at extremely low impedances. Reduce speaker quantity or change wiring configuration.',
    });
  } else if (validLoad === 2) {
    contextualWarnings.push({
      id: 'high-current-system',
      type: 'warning',
      iconType: 'high_current',
      title: 'High Current Load (2Ω System)',
      message: '2Ω systems draw massive current from the amplifier. Cable resistance causes higher percentage loss and reduces damping factor. Ensure amplifier is 2Ω stable and use heavy gauge cable (4 mm² - 10 mm²).',
    });
  } else if (validLoad > 16) {
    contextualWarnings.push({
      id: 'impedance-above-16-ohm',
      type: 'danger',
      iconType: 'high_loss',
      title: 'Impedance Above 16Ω',
      message: 'Calculated impedance is above 16Ω. Such loads are uncommon in professional PA systems and may significantly reduce available amplifier power. Reduce speaker quantity or use a different wiring configuration.',
    });
  } else if (validLoad === 16) {
    contextualWarnings.push({
      id: 'low-current-high-z-system',
      type: 'warning',
      iconType: 'high_loss',
      title: 'High Impedance Load (16Ω System)',
      message: '16Ω systems draw very low current. Cable loss is minimal, but the amplifier will deliver significantly reduced wattage compared to 4Ω or 8Ω ratings. Verify that amplifier output voltage headroom is adequate.',
    });
  }

  // 3. CCA WARNING (Trigger: CCA selected AND cable length > 30m)
  if (isCca && validLength > 30) {
    contextualWarnings.push({
      id: 'cca-cable-advisory',
      type: 'warning',
      iconType: 'cca',
      title: 'CCA Cable Advisory',
      message: 'CCA cable has higher resistance than pure copper. For longer cable runs, increased losses and reduced performance may occur. Consider using a larger cable size or pure copper cable.',
    });
  }

  // 4. LOSS WARNINGS (Loss > 15% vs Loss > 10% vs Loss > 5%)
  if (powerLossPercent > 15.0) {
    contextualWarnings.push({
      id: 'excessive-cable-loss',
      type: 'danger',
      iconType: 'high_loss',
      title: 'Excessive Cable Loss',
      message: 'This configuration is not recommended for professional sound reinforcement. Review cable length, impedance and cable size.',
    });
  } else if (powerLossPercent > 10.0) {
    contextualWarnings.push({
      id: 'high-cable-loss',
      type: 'danger',
      iconType: 'high_loss',
      title: 'High Cable Loss',
      message: 'A significant amount of amplifier power may be dissipated in the cable. Reduced output level and softer low-frequency performance may occur. Consider increasing cable size.',
    });
  } else if (powerLossPercent > 5.0) {
    contextualWarnings.push({
      id: 'reduced-efficiency',
      type: 'warning',
      iconType: 'high_loss',
      title: 'Reduced Efficiency',
      message: 'A noticeable amount of amplifier power is being lost in the cable. Using a larger cable size may improve system performance.',
    });
  }

  // Recommendation Reason:
  const recommendationReason = meetsTarget
    ? `Selected because it meets your chosen ${targetLoss}% cable loss target.`
    : `None of the standard cable sizes meets the ${targetLoss}% limit over ${validLength}m @ ${validLoad}Ω. 10 mm² provides lowest loss (${allSizes[allSizes.length - 1].powerLossPercent}%).`;

  // Backward compatibility warning levels
  let warningLevel: CableWarningLevel = 'green';
  let status: StatusLevel = 'safe';
  let statusTitleKey = 'cableLossLowTitle';
  let statusMessageKey = 'cableLossLowMsg';

  if (powerLossPercent > 10.0) {
    warningLevel = 'red';
    status = 'danger';
    statusTitleKey = 'cableLossHighTitle';
    statusMessageKey = 'cableLossHighMsg';
  } else if (powerLossPercent >= 3.0) {
    warningLevel = 'yellow';
    status = 'warning';
    statusTitleKey = 'cableLossModerateTitle';
    statusMessageKey = 'cableLossModerateMsg';
  }

  return {
    cableLength: validLength,
    power: validPower,
    load: validLoad,
    material,
    materialName: isCca ? 'CCA (Copper Clad Aluminium)' : 'Pure Copper (OFC)',
    maxAcceptableLoss: targetLoss,
    loopResistance,
    resistanceRatioPercent,
    actualPowerLossPercent,
    levelLossDb,
    voltageDrop,
    voltageDropPercent,
    powerLossWatts,
    powerLossPercent,
    estimatedEfficiency,
    powerDeliveredWatts,
    recommendedCableSize: finalRec,
    displayCableSize,
    recommendationReason,
    minimumAcceptableSize: finalMin,
    professionalChoiceSize: finalPro,
    meetsTarget,
    statusBadge,
    badgeLabel,
    badgeEmoji,
    statusSummary,
    isCca,
    ccaWarning,
    contextualWarnings,
    allSizes,
    // Backward compatibility
    cableSize: activeEvaluatedSize,
    warningLevel,
    status,
    statusTitleKey,
    statusMessageKey,
  };
}

/**
 * Format a DMX channel address to standard 3-digit padded format (e.g., 1 -> "001", 17 -> "017")
 */
export function formatDmxAddress(addr: number): string {
  if (isNaN(addr) || addr < 0) return '001';
  return String(Math.floor(addr)).padStart(3, '0');
}

/**
 * 5. DMX Address Calculator
 * Start Address: 1–512
 * Channels Per Fixture: e.g. 7, 14, 16, 22, 32...
 * Number of Fixtures: 1, 2, 3, 4...
 */
export function calculateDmx(params: DmxCalculationParams): DmxResult {
  const startAddress = Math.max(1, Math.min(512, params.startAddress || 1));
  const channelCount = Math.max(1, params.channelCount || 1);
  const fixtureCount = Math.max(1, Math.min(128, params.fixtureCount || 4));

  const fixtures: DmxFixtureSequence[] = [];
  let currentStart = startAddress;

  for (let i = 1; i <= fixtureCount; i++) {
    const curEnd = currentStart + channelCount - 1;
    const nextStart = currentStart + channelCount;
    const exceeds512 = curEnd > 512 || currentStart > 512;

    fixtures.push({
      fixtureNumber: i,
      startAddress: currentStart,
      endAddress: curEnd,
      nextAddress: nextStart,
      rangeString: `${formatDmxAddress(currentStart)}–${formatDmxAddress(curEnd)}`,
      formattedStart: formatDmxAddress(currentStart),
      formattedEnd: formatDmxAddress(curEnd),
      exceeds512,
    });

    currentStart = nextStart;
  }

  const nextFixtureAddress = currentStart;
  const formattedNextFreeAddress = formatDmxAddress(nextFixtureAddress);
  const endAddress = startAddress + (fixtureCount * channelCount) - 1;
  const addressRange = `${formatDmxAddress(startAddress)}–${formatDmxAddress(endAddress)}`;
  const exceedsUniverse = endAddress > 512 || startAddress > 512;
  const isValid = startAddress >= 1 && startAddress <= 512 && channelCount >= 1 && fixtureCount >= 1;

  return {
    currentAddress: startAddress,
    channelCount,
    fixtureCount,
    nextFixtureAddress,
    formattedNextFreeAddress,
    addressRange,
    endAddress,
    isValid,
    exceedsUniverse,
    fixtures,
    subsequentFixtures: fixtures,
  };
}

/**
 * Formats a load/impedance value cleanly for user-facing descriptions:
 * E.g., 64 -> "64", 48 -> "48", 2.66666... -> "2.67", 8.0 -> "8"
 */
export function formatLoadValue(val: number): string {
  if (Number.isInteger(val)) {
    return `${val}`;
  }
  const rounded = Number(val.toFixed(2));
  return Number.isInteger(rounded) ? `${rounded}` : val.toFixed(2);
}

/**
 * Replaces any {load} placeholders in a message with the cleanly formatted load value.
 */
export function formatStatusMessage(message: string, load: number): string {
  if (!message) return '';
  const formatted = formatLoadValue(load);
  return message.replace(/\{load\}/g, formatted);
}

/**
 * Formats a power/wattage value cleanly:
 * E.g., 1500 -> "1500", 1501.65 -> "1501.65", 1001.1 -> "1001.10"
 */
export function formatPowerValue(val: number): string {
  if (Number.isInteger(val)) {
    return `${val}`;
  }
  return val.toFixed(2);
}

