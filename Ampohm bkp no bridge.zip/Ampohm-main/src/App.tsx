import React, { useState, useEffect } from 'react';
import { ActiveScreen } from './types';
import { LanguageProvider } from './localization/LanguageContext';
import { ThemeProvider, useTheme } from './theme/ThemeContext';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { HomeScreen } from './components/screens/HomeScreen';
import { MoreToolsScreen } from './components/screens/MoreToolsScreen';
import { SettingsScreen } from './components/screens/SettingsScreen';
import { HistoryScreen } from './components/screens/HistoryScreen';
import { GuideScreen } from './components/screens/GuideScreen';
import { OhmCalculatorView, OhmTransferToAmpData, OhmSavedState } from './components/calculators/OhmCalculatorView';
import { AmplifierCalculatorView } from './components/calculators/AmplifierCalculatorView';
import { CableLossCalculatorView } from './components/calculators/CableLossCalculatorView';
import { DmxCalculatorView } from './components/calculators/DmxCalculatorView';
import { FlutterProjectModal } from './components/screens/FlutterProjectModal';
import { RevenueCatPaywallModal } from './components/subscription/RevenueCatPaywallModal';
import { ForceUpdateModal } from './components/modals/ForceUpdateModal';
import { subscriptionService } from './services/subscriptionService';
import { adService } from './services/adService';
import { analyticsService } from './services/analyticsService';
import { telemetryService } from './services/telemetryService';
import { versionControlService, RemoteVersionConfig, DEFAULT_VERSION_CONFIG } from './services/versionService';
import { serverMembershipService } from './services/serverMembershipService';
import { useLanguage } from './localization/LanguageContext';
import { Wifi, Signal } from 'lucide-react';

function AppContent() {
  const { isNightMode } = useTheme();
  const { language, t, isHindi } = useLanguage();
  const [currentScreen, setCurrentScreen] = useState<ActiveScreen>('home');
  const [isFlutterModalOpen, setIsFlutterModalOpen] = useState(false);
  const [isPaywallOpen, setIsPaywallOpen] = useState(false);
  const [ampTransferParams, setAmpTransferParams] = useState<OhmTransferToAmpData | null>(null);
  const [savedOhmState, setSavedOhmState] = useState<OhmSavedState | null>(null);

  // Remote Force Update State (Controlled via Firestore app_config/version_control)
  const [forceUpdateConfig, setForceUpdateConfig] = useState<RemoteVersionConfig>(DEFAULT_VERSION_CONFIG);
  const [mustForceUpdate, setMustForceUpdate] = useState(false);
  const [, setMembershipRevision] = useState(0);

  // App Opening Splash Screen State
  const [showSplash, setShowSplash] = useState(true);
  const [splashFadeOut, setSplashFadeOut] = useState(false);

  useEffect(() => {
    const fadeTimer = setTimeout(() => {
      setSplashFadeOut(true);
    }, 1800);
    const removeTimer = setTimeout(() => {
      setShowSplash(false);
    }, 2300);
    return () => {
      clearTimeout(fadeTimer);
      clearTimeout(removeTimer);
    };
  }, []);

  // Connect App to Mobile Hardware Back Button & Browser History
  useEffect(() => {
    // If not home, push a state so pressing hardware back button goes back to home or previous modal
    if (currentScreen !== 'home') {
      window.history.pushState({ screen: currentScreen }, '');
    }

    const handlePopState = () => {
      // Prioritize closing any open modals first
      if (isPaywallOpen) {
        setIsPaywallOpen(false);
        return;
      }
      if (isFlutterModalOpen) {
        setIsFlutterModalOpen(false);
        return;
      }

      // If user is inside a screen/calculator, return to home
      if (currentScreen !== 'home') {
        if (currentScreen === 'calc_amp' && ampTransferParams) {
          setAmpTransferParams(null);
          setCurrentScreen('calc_ohm');
        } else {
          navigateToHome();
        }
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, [currentScreen, isPaywallOpen, isFlutterModalOpen, ampTransferParams]);

  useEffect(() => {
    analyticsService.logAppOpen();
    // Initialize anonymous Firestore telemetry session (Zero-Login)
    telemetryService.initSession(language, isNightMode ? 'night' : 'day');

    // Subscribe to remote version control and on-demand force update switch
    const unsubscribeVersion = versionControlService.subscribe((config, shouldForce) => {
      setForceUpdateConfig(config);
      setMustForceUpdate(shouldForce);
    });

    // Subscribe to real-time server-authoritative membership changes
    const unsubscribeMembership = serverMembershipService.subscribe(() => {
      setMembershipRevision(prev => prev + 1);
    });

    const unsubscribeSub = subscriptionService.addListener(() => {
      setMembershipRevision(prev => prev + 1);
    });

    return () => {
      unsubscribeVersion();
      unsubscribeMembership();
      unsubscribeSub();
    };
  }, [language, isNightMode]);

  /**
   * Open calculators immediately with zero lag or blocking
   */
  const handleRequestCalculatorOpen = (screen: ActiveScreen) => {
    setCurrentScreen(screen);
  };

  const navigateToHome = () => {
    setAmpTransferParams(null);
    setSavedOhmState(null);
    setCurrentScreen('home');
  };

  const handleNavigateToAmpFromOhm = (data: OhmTransferToAmpData) => {
    setSavedOhmState({
      speakerRms: data.speakerRms,
      speakerCount: data.speakerCount,
      speakerImpedance: data.speakerImpedance,
      wiring: data.wiring,
      viewMode: 'result',
    });
    setAmpTransferParams({ ...data });
    setCurrentScreen('calc_amp');
  };

  const handleBackFromAmp = () => {
    if (ampTransferParams) {
      setAmpTransferParams(null);
      setCurrentScreen('calc_ohm');
    } else {
      navigateToHome();
    }
  };

  const renderActiveView = () => {
    switch (currentScreen) {
      case 'home':
        return (
          <HomeScreen 
            onSelectCalculator={handleRequestCalculatorOpen} 
            onOpenRemoveAds={() => setIsPaywallOpen(true)}
            onOpenSettings={() => setCurrentScreen('settings')}
          />
        );
      case 'more_tools':
        return <MoreToolsScreen onSelectCalculator={handleRequestCalculatorOpen} />;
      case 'history':
        return <HistoryScreen onSelectCalculator={handleRequestCalculatorOpen} />;
      case 'guide':
        return <GuideScreen onSelectCalculator={handleRequestCalculatorOpen} />;
      case 'settings':
        return (
          <SettingsScreen 
            onOpenFlutterExport={() => setIsFlutterModalOpen(true)} 
            onOpenSubscription={() => setIsPaywallOpen(true)}
          />
        );
      case 'calc_ohm':
        return (
          <OhmCalculatorView 
            onBack={navigateToHome} 
            onNavigateToAmp={handleNavigateToAmpFromOhm} 
            savedState={savedOhmState}
            onOpenSubscription={() => setIsPaywallOpen(true)}
          />
        );
      case 'calc_amp':
        return (
          <AmplifierCalculatorView 
            onBack={handleBackFromAmp} 
            initialData={ampTransferParams}
            onOpenSubscription={() => setIsPaywallOpen(true)}
          />
        );
      case 'calc_cable_loss':
        return (
          <CableLossCalculatorView 
            onBack={navigateToHome} 
            onOpenSubscription={() => setIsPaywallOpen(true)}
          />
        );
      case 'calc_dmx':
        return (
          <DmxCalculatorView 
            onBack={navigateToHome} 
            onOpenSubscription={() => setIsPaywallOpen(true)}
          />
        );
      default:
        return (
          <HomeScreen 
            onSelectCalculator={handleRequestCalculatorOpen} 
            onOpenRemoveAds={() => setIsPaywallOpen(true)}
            onOpenSettings={() => setCurrentScreen('settings')}
          />
        );
    }
  };

  return (
    <div className={`min-h-screen flex justify-center items-start sm:py-6 selection:bg-blue-100 selection:text-blue-900 transition-colors duration-300 ${
      isNightMode 
        ? 'bg-[#080B11] bg-[radial-gradient(ellipse_80%_60%_at_50%_-10%,rgba(29,78,216,0.22),rgba(8,11,17,1))]' 
        : 'bg-[#C9D7E8] bg-[radial-gradient(ellipse_80%_60%_at_50%_-10%,rgba(147,197,253,0.45),rgba(201,215,232,1))]'
    }`}>
      {/* Mobile Device Frame Container with Pro Studio Canvas */}
      <div className={`w-full max-w-md min-h-screen sm:min-h-[844px] sm:rounded-[44px] relative flex flex-col overflow-hidden border transition-all duration-300 ${
        isHindi ? 'hindi-mode' : ''
      } ${
        isNightMode 
          ? 'bg-[#070B12] border-slate-800/80 shadow-[0_25px_70px_rgba(0,0,0,0.8),0_0_0_1px_rgba(255,255,255,0.08)]' 
          : 'bg-[#DDE5F0] border-slate-300/80 shadow-[0_25px_70px_rgba(15,23,42,0.15),0_0_0_1px_rgba(255,255,255,0.7)]'
      }`}>
        
        {/* Animated App Splash Screen on Opening */}
        {showSplash && (
          <div 
            onClick={() => setShowSplash(false)}
            className={`absolute inset-0 z-[100] flex flex-col items-center justify-center bg-[#070B14] bg-[radial-gradient(circle_at_50%_35%,#1E293B_0%,#0B1120_50%,#070B14_100%)] select-none cursor-pointer transition-opacity duration-500 p-6 text-center ${
              splashFadeOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
            }`}
          >
            <div className="flex flex-col items-center">
              {/* High-Quality App Opening Splash Graphic */}
              <div className="relative mb-6">
                <div className="absolute -inset-4 bg-amber-500/25 rounded-[36px] blur-xl opacity-80 animate-pulse"></div>
                <div className="relative w-36 h-36 rounded-[32px] overflow-hidden drop-shadow-2xl flex items-center justify-center">
                  <img 
                    src="/splash-logo.png" 
                    alt="AMP OHM" 
                    className="w-full h-full object-contain"
                  />
                </div>
              </div>

              {/* Title */}
              <div className="text-3xl font-black tracking-[0.2em] text-white uppercase font-sans mb-1.5">
                AMP <span className="text-[#38BDF8]">OHM</span>
              </div>

              {/* Tagline */}
              <div className="px-3.5 py-1 rounded-full bg-blue-600/15 border border-blue-400/30 text-[#38BDF8] text-[10px] font-bold tracking-[0.22em] uppercase mb-10">
                PRO AUDIO AND LIGHTING TOOL
              </div>

              {/* Shimmer Progress Indicator */}
              <div className="w-36 h-1 bg-slate-800 rounded-full overflow-hidden relative border border-blue-500/30">
                <div className="w-full h-full bg-gradient-to-r from-transparent via-amber-400 to-transparent animate-pulse"></div>
              </div>

              <p className="mt-4 text-[11px] text-slate-500 tracking-wider">
                Tap anywhere to skip
              </p>
            </div>
          </div>
        )}
        
        {/* Status Bar Simulation */}
        <div className={`bg-transparent text-[11px] px-6 pt-3 pb-1 flex items-center justify-between font-sans select-none z-50 transition-colors ${
          isNightMode ? 'text-white' : 'text-[#0F172A]'
        }`}>
          <span className="font-bold text-xs tracking-tight ml-0.5">9:41</span>
          
          {/* Subtle Dynamic Island sensor pill */}
          <div className="w-20 h-4 bg-slate-900/90 rounded-full mx-auto shrink-0 shadow-xs ring-1 ring-white/10" />

          <div className="flex items-center gap-1.5 text-[11px] font-semibold mr-0.5">
            <Signal className="w-3.5 h-3.5 stroke-[2.2]" />
            <Wifi className="w-3.5 h-3.5 stroke-[2.2]" />
            <div className="flex items-center gap-0.5 ml-0.5">
              <span className="text-[10px] font-bold">100</span>
              <div className={`w-5 h-2.5 border rounded-[3px] p-[1px] flex items-center ${
                isNightMode ? 'border-white/80' : 'border-slate-800/70'
              }`}>
                <div className={`w-full h-full rounded-[1.5px] ${
                  isNightMode ? 'bg-[#38BDF8]' : 'bg-[#2563EB]'
                }`} />
              </div>
            </div>
          </div>
        </div>

        {/* Top Header - Shown on secondary screens that do not have their own back header */}
        {(currentScreen === 'more_tools' || currentScreen === 'settings' || currentScreen === 'history' || currentScreen === 'guide') && (
          <Header 
            onOpenFlutterExport={() => setIsFlutterModalOpen(true)} 
            onOpenSettings={() => setCurrentScreen('settings')}
          />
        )}

        {/* Screen Content */}
        <main className={`flex-1 overflow-y-auto ${isHindi ? 'hindi-mode' : ''}`}>
          {renderActiveView()}
        </main>

        {/* Bottom Navigation */}
        <BottomNav
          currentScreen={currentScreen}
          onNavigate={(screen) => setCurrentScreen(screen)}
        />

        {/* Flutter Source Code Modal */}
        <FlutterProjectModal
          isOpen={isFlutterModalOpen}
          onClose={() => setIsFlutterModalOpen(false)}
        />

        {/* RevenueCat Paywall Modal */}
        <RevenueCatPaywallModal
          isOpen={isPaywallOpen}
          onClose={() => setIsPaywallOpen(false)}
        />

        {/* Remote Force Update Modal - Only shown when dashboard switch is explicitly enabled */}
        {mustForceUpdate && (
          <ForceUpdateModal
            config={forceUpdateConfig}
            language={language}
            isNightMode={isNightMode}
          />
        )}
      </div>
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <ThemeProvider>
        <AppContent />
      </ThemeProvider>
    </LanguageProvider>
  );
}
