import React, { useState } from 'react';
import { useLanguage } from '../localization/LanguageContext';
import { 
  Radio, 
  Database, 
  Server, 
  GitFork, 
  Box, 
  Clock 
} from 'lucide-react';

export const ComingSoonSection: React.FC = () => {
  const { t } = useLanguage();
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const comingSoonTools = [
    {
      id: 'subwoofer',
      title: t.csSubwooferTitle,
      desc: t.csSubwooferDesc,
      icon: <Radio className="w-5 h-5 text-slate-400" />
    },
    {
      id: 'speaker_db',
      title: t.csSpeakerDbTitle,
      desc: t.csSpeakerDbDesc,
      icon: <Database className="w-5 h-5 text-slate-400" />
    },
    {
      id: 'amp_db',
      title: t.csAmpDbTitle,
      desc: t.csAmpDbDesc,
      icon: <Server className="w-5 h-5 text-slate-400" />
    },
    {
      id: 'wiring_lib',
      title: t.csWiringLibTitle,
      desc: t.csWiringLibDesc,
      icon: <GitFork className="w-5 h-5 text-slate-400" />
    }
  ];

  const handleCardClick = () => {
    setToastMessage(t.comingSoonAlert);
    setTimeout(() => {
      setToastMessage(null);
    }, 2400);
  };

  return (
    <section className="mt-8 mb-4">
      <div className="flex items-center justify-between mb-3 px-1">
        <div>
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-500" />
            <h2 className="text-sm font-bold tracking-wider uppercase text-slate-800">
              {t.comingSoonTitle}
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            {t.comingSoonSubtitle}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {comingSoonTools.map((tool) => (
          <div
            key={tool.id}
            onClick={handleCardClick}
            className="p-3.5 rounded-xl border border-dashed border-slate-300 bg-slate-50/70 hover:bg-slate-100/80 cursor-not-allowed transition flex items-start gap-3 relative overflow-hidden"
          >
            <div className="w-9 h-9 rounded-lg bg-slate-200/80 flex items-center justify-center shrink-0">
              {tool.icon}
            </div>

            <div className="flex-1 min-w-0 pr-16">
              <h4 className="text-xs font-semibold text-slate-700 truncate">
                {tool.title}
              </h4>
              <p className="text-[11px] text-slate-500 line-clamp-2 mt-0.5">
                {tool.desc}
              </p>
            </div>

            <span className="absolute top-3 right-3 text-[10px] font-bold tracking-wider uppercase px-2 py-0.5 rounded bg-slate-200 text-slate-600 border border-slate-300">
              {t.comingSoonBadge}
            </span>
          </div>
        ))}
      </div>

      {toastMessage && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white text-xs font-medium px-4 py-2.5 rounded-full shadow-lg border border-slate-700 animate-fade-in flex items-center gap-2">
          <Clock className="w-3.5 h-3.5 text-amber-400" />
          <span>{toastMessage}</span>
        </div>
      )}
    </section>
  );
};
