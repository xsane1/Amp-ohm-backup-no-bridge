import React from 'react';
import { ToolCategory } from '../types';
import { useLanguage } from '../localization/LanguageContext';
import { Sliders, Lightbulb, Clock, Layers } from 'lucide-react';

interface CategoryChipsProps {
  selected: ToolCategory;
  onSelect: (category: ToolCategory) => void;
}

export const CategoryChips: React.FC<CategoryChipsProps> = ({ selected, onSelect }) => {
  const { t } = useLanguage();

  const categories: { id: ToolCategory; label: string; icon: React.ReactNode }[] = [
    { id: 'all', label: t.catAll, icon: <Layers className="w-3.5 h-3.5" /> },
    { id: 'audio', label: t.catAudio, icon: <Sliders className="w-3.5 h-3.5" /> },
    { id: 'lighting', label: t.catLighting, icon: <Lightbulb className="w-3.5 h-3.5" /> },
    { id: 'future', label: t.catFuture, icon: <Clock className="w-3.5 h-3.5" /> },
  ];

  return (
    <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none select-none">
      {categories.map((cat) => {
        const isSelected = selected === cat.id;
        return (
          <button
            key={cat.id}
            type="button"
            onClick={() => onSelect(cat.id)}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all duration-150 active:scale-95 cursor-pointer shadow-xs ${
              isSelected
                ? 'bg-blue-800 text-white shadow-blue-800/20 shadow-md ring-2 ring-blue-700 ring-offset-1'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200 hover:border-slate-300'
            }`}
          >
            <span className={isSelected ? 'text-amber-400' : 'text-slate-500'}>
              {cat.icon}
            </span>
            <span>{cat.label}</span>
          </button>
        );
      })}
    </div>
  );
};
