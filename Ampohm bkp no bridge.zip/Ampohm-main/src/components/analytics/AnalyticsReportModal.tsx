import React from 'react';
import { analyticsService } from '../../services/analyticsService';
import { 
  BarChart3, 
  X, 
  TrendingUp, 
  Clock, 
  Calendar, 
  CheckCircle2, 
  Activity,
  Flame,
  Award
} from 'lucide-react';

interface AnalyticsReportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AnalyticsReportModal: React.FC<AnalyticsReportModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const report = analyticsService.getUsageReport();

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200 my-8">
        {/* Header */}
        <div className="flex items-start justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <span className="p-1.5 bg-blue-100 text-blue-900 rounded-lg">
              <BarChart3 className="w-4 h-4 text-blue-800" />
            </span>
            <div>
              <h3 className="text-base font-extrabold text-slate-900">Analytics & Usage Telemetry</h3>
              <p className="text-[11px] text-slate-500">Firebase Analytics Event & Usage Aggregator</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Highlights Grid */}
        <div className="grid grid-cols-2 gap-2.5 my-4">
          <div className="p-3 bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl border border-amber-200">
            <div className="flex items-center gap-1.5 text-amber-900 text-[10px] font-extrabold uppercase tracking-wider">
              <Flame className="w-3.5 h-3.5 text-amber-600" />
              <span>Most Used</span>
            </div>
            <div className="text-xs font-black text-slate-900 mt-1 truncate">
              {report.mostUsed ? report.mostUsed.name : 'Ohm Calculator'}
            </div>
            <div className="text-[10px] text-amber-800 font-bold mt-0.5">
              {report.mostUsed ? `${report.mostUsed.calculationCount} calculations` : '0 calculations'}
            </div>
          </div>

          <div className="p-3 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl border border-blue-200">
            <div className="flex items-center gap-1.5 text-blue-900 text-[10px] font-extrabold uppercase tracking-wider">
              <Award className="w-3.5 h-3.5 text-blue-600" />
              <span>Total Workflows</span>
            </div>
            <div className="text-base font-black text-blue-950 mt-1">
              {report.totalCalculations}
            </div>
            <div className="text-[10px] text-blue-700 font-bold mt-0.5">
              Completed on device
            </div>
          </div>
        </div>

        {/* Temporal Usage Stats */}
        <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100 space-y-2 mb-4">
          <div className="text-[11px] font-extrabold uppercase tracking-wider text-slate-500 mb-1 flex items-center justify-between">
            <span>Periodic Metrics</span>
            <Activity className="w-3.5 h-3.5 text-slate-400" />
          </div>

          <div className="flex items-center justify-between py-1 text-xs">
            <div className="flex items-center gap-2 text-slate-600">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              <span>Daily Usage (Last 24 Hours)</span>
            </div>
            <span className="font-extrabold text-slate-900 font-mono">
              {report.dailyCalculations}
            </span>
          </div>

          <div className="flex items-center justify-between py-1 text-xs">
            <div className="flex items-center gap-2 text-slate-600">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>Monthly Usage (Last 30 Days)</span>
            </div>
            <span className="font-extrabold text-slate-900 font-mono">
              {report.monthlyCalculations}
            </span>
          </div>

          <div className="flex items-center justify-between py-1 text-xs">
            <div className="flex items-center gap-2 text-slate-600">
              <TrendingUp className="w-3.5 h-3.5 text-slate-400" />
              <span>App Launches</span>
            </div>
            <span className="font-extrabold text-slate-900 font-mono">
              {report.appOpens}
            </span>
          </div>
        </div>

        {/* Per-Calculator Breakdown */}
        <div className="space-y-2 mb-5">
          <div className="text-[11px] font-extrabold uppercase tracking-wider text-slate-500">
            Usage Breakdown by Tool
          </div>

          <div className="space-y-1.5">
            {report.stats.map((item) => (
              <div
                key={item.calculatorId}
                className="p-2.5 rounded-xl border border-slate-200 bg-white flex items-center justify-between text-xs"
              >
                <div>
                  <div className="font-bold text-slate-900">{item.name}</div>
                  <div className="text-[10px] text-slate-500">
                    Opened {item.openCount} times
                  </div>
                </div>

                <div className="text-right">
                  <div className="font-black text-blue-900 font-mono text-sm">
                    {item.calculationCount}
                  </div>
                  <div className="text-[9px] uppercase tracking-wider font-bold text-slate-400">
                    Calculated
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition"
        >
          Close Report
        </button>
      </div>
    </div>
  );
};
