import React, { useState, useEffect } from 'react';
import { historyService, HistoryEntry } from '../../services/historyService';
import { useLanguage } from '../../localization/LanguageContext';
import { useTheme } from '../../theme/ThemeContext';
import { 
  History, 
  Trash2, 
  Clock, 
  Layers, 
  Zap, 
  Speaker, 
  Cable, 
  SlidersHorizontal
} from 'lucide-react';
import { ActiveScreen } from '../../types';

interface HistoryScreenProps {
  onNavigateToCalculator?: (screen: ActiveScreen) => void;
}

export const HistoryScreen: React.FC<HistoryScreenProps> = ({ onNavigateToCalculator }) => {
  const { isHindi } = useLanguage();
  const { isNightMode } = useTheme();
  const [historyList, setHistoryList] = useState<HistoryEntry[]>([]);
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  useEffect(() => {
    setHistoryList(historyService.getHistory());
    const unsubHistory = historyService.subscribe(() => {
      setHistoryList(historyService.getHistory());
    });
    return () => {
      unsubHistory();
    };
  }, []);

  const handleClearHistory = () => {
    historyService.clearHistory();
    setShowClearConfirm(false);
  };

  const handleDeleteItem = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    historyService.deleteEntry(id);
  };

  const formatTimestamp = (timestamp: number) => {
    const date = new Date(timestamp);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();

    const timeStr = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    if (isToday) {
      return isHindi ? `आज, ${timeStr}` : `Today, ${timeStr}`;
    }

    const dateStr = date.toLocaleDateString([], { day: 'numeric', month: 'short' });
    return `${dateStr}, ${timeStr}`;
  };

  const getCalcIcon = (calcId: string) => {
    switch (calcId) {
      case 'calc_ohm':
        return <Layers className="w-4 h-4 text-blue-500" />;
      case 'calc_amp':
        return <Zap className="w-4 h-4 text-amber-500" />;
      case 'calc_cable_loss':
        return <Cable className="w-4 h-4 text-emerald-500" />;
      case 'calc_dmx':
        return <SlidersHorizontal className="w-4 h-4 text-purple-500" />;
      default:
        return <History className="w-4 h-4 text-blue-500" />;
    }
  };

  return (
    <div className={`min-h-full pb-24 px-3 sm:px-4 pt-3 select-none transition-colors duration-200 ${
      isNightMode ? 'bg-[#0A0E17] text-slate-100' : 'bg-[#E5EBF3] text-slate-800'
    }`}>
      {/* Top Banner Card */}
      <div className={`rounded-2xl p-4 sm:p-5 border shadow-sm mb-3.5 transition-colors ${
        isNightMode ? 'bg-[#141C30] border-slate-800' : 'bg-white border-slate-200'
      }`}>
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 shadow-2xs ${
              isNightMode ? 'bg-blue-950/60 border border-blue-700/40 text-blue-400' : 'bg-blue-50 border border-blue-200/70 text-[#1D4ED8]'
            }`}>
              <History className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div>
              <h2 className={`text-base sm:text-lg font-black tracking-tight leading-tight ${
                isNightMode ? 'text-white' : 'text-[#0F172A]'
              }`}>
                {isHindi ? 'कैलकुलेशन हिस्ट्री' : 'Calculation History'}
              </h2>
              <p className={`text-[10px] sm:text-[11px] font-medium mt-0.5 ${
                isNightMode ? 'text-slate-400' : 'text-slate-500'
              }`}>
                {isHindi ? 'आपकी पिछली सभी कैलकुलेशन का ऑफलाइन सुरक्षित रिकॉर्ड' : 'Offline saved records for your past rig calculations'}
              </p>
            </div>
          </div>

          {historyList.length > 0 && (
            <button
              type="button"
              onClick={() => setShowClearConfirm(true)}
              className={`text-xs font-semibold px-2.5 py-1.5 rounded-xl border flex items-center gap-1.5 transition active:scale-95 shadow-2xs ${
                isNightMode
                  ? 'bg-red-950/40 text-red-400 border-red-900/60 hover:bg-red-950/60'
                  : 'bg-red-50 text-red-600 border-red-200 hover:bg-red-100'
              }`}
              title={isHindi ? 'हिस्ट्री साफ़ करें' : 'Clear History'}
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{isHindi ? 'साफ़ करें' : 'Clear'}</span>
            </button>
          )}
        </div>
      </div>

      {historyList.length === 0 ? (
        /* EMPTY STATE */
        <div className={`rounded-2xl p-8 border text-center shadow-sm ${
          isNightMode ? 'bg-[#141C30] border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <div className={`w-12 h-12 rounded-2xl mx-auto flex items-center justify-center mb-3 ${
            isNightMode ? 'bg-slate-800 text-slate-500' : 'bg-slate-100 text-slate-400'
          }`}>
            <Clock className="w-6 h-6 stroke-[1.8]" />
          </div>
          <h3 className={`text-sm font-bold mb-1 ${isNightMode ? 'text-slate-200' : 'text-slate-800'}`}>
            {isHindi ? 'कोई कैलकुलेशन हिस्ट्री नहीं है' : 'No Calculation History Yet'}
          </h3>
          <p className={`text-xs leading-relaxed max-w-xs mx-auto ${
            isNightMode ? 'text-slate-400' : 'text-slate-500'
          }`}>
            {isHindi 
              ? 'जब भी आप Ohm, Amp, Speaker, Cable या DMX टूल्स में कैलकुलेशन करेंगे, उनके नतीजे यहाँ तारीख और समय के साथ सुरक्षित रहेंगे।' 
              : 'When you run calculations in Ohm, Amp, Speaker, Cable, or DMX tools, the results will automatically be saved here with dates and times.'}
          </p>
        </div>
      ) : (
        /* PREMIUM HISTORY LIST */
        <div className="space-y-2.5">
          {historyList.map((item) => (
            <div
              key={item.id}
              onClick={() => onNavigateToCalculator && onNavigateToCalculator(item.calculatorId)}
              className={`rounded-2xl p-3.5 sm:p-4 border shadow-2xs transition-all cursor-pointer group active:scale-[0.99] ${
                isNightMode 
                  ? 'bg-[#141C30] border-slate-800 hover:border-slate-700' 
                  : 'bg-white border-slate-200 hover:border-blue-200 hover:shadow-xs'
              }`}
            >
              {/* Card Header: Tool Name + Date/Time */}
              <div className="flex items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <div className={`p-1.5 rounded-lg ${
                    isNightMode ? 'bg-slate-800/80' : 'bg-slate-100'
                  }`}>
                    {getCalcIcon(item.calculatorId)}
                  </div>
                  <span className={`text-xs font-bold ${
                    isNightMode ? 'text-slate-200' : 'text-slate-900'
                  }`}>
                    {item.calculatorName}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span className={`text-[10px] font-medium flex items-center gap-1 ${
                    isNightMode ? 'text-slate-400' : 'text-slate-500'
                  }`}>
                    <Clock className="w-3 h-3 text-slate-400" />
                    {formatTimestamp(item.timestamp)}
                  </span>
                  
                  <button
                    type="button"
                    onClick={(e) => handleDeleteItem(item.id, e)}
                    className="p-1 rounded-md text-slate-400 hover:text-red-500 hover:bg-red-50/10 transition"
                    title={isHindi ? 'हटाएं' : 'Delete'}
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>

              {/* Main Result Value */}
              <div className="flex items-baseline justify-between gap-2 my-1.5">
                <div className={`text-lg sm:text-xl font-extrabold tracking-tight ${
                  isNightMode ? 'text-white' : 'text-[#0F172A]'
                }`}>
                  {item.resultSummary}
                </div>

                {item.badge && (
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                    item.badge.type === 'danger'
                      ? isNightMode 
                        ? 'bg-red-950/80 text-red-300 border-red-800' 
                        : 'bg-red-50 text-red-700 border-red-200'
                      : item.badge.type === 'warning'
                      ? isNightMode
                        ? 'bg-amber-950/80 text-amber-300 border-amber-800'
                        : 'bg-amber-50 text-amber-700 border-amber-200'
                      : isNightMode
                      ? 'bg-blue-950/80 text-blue-300 border-blue-800'
                      : 'bg-blue-50 text-blue-700 border-blue-200'
                  }`}>
                    {item.badge.text}
                  </span>
                )}
              </div>

              {/* Detailed Breakdown Chips */}
              {item.details && item.details.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-2 pt-2 border-t border-slate-100 dark:border-slate-800/80">
                  {item.details.map((detail, dIdx) => (
                    <div
                      key={dIdx}
                      className={`text-[10px] px-2 py-0.5 rounded-md font-medium border ${
                        isNightMode 
                          ? 'bg-[#101726] border-slate-800 text-slate-300' 
                          : 'bg-slate-50 border-slate-200 text-slate-600'
                      }`}
                    >
                      <span className="text-slate-400 mr-1">{detail.label}:</span>
                      <span className="font-bold">{detail.value}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Confirmation Modal for Clearing History */}
      {showClearConfirm && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className={`rounded-3xl max-w-sm w-full p-5 shadow-2xl border ${
            isNightMode ? 'bg-[#141C30] border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
          }`}>
            <h3 className="text-sm font-black mb-1.5">
              {isHindi ? 'हिस्ट्री मिटाएं?' : 'Clear all history?'}
            </h3>
            <p className={`text-xs mb-4 leading-relaxed ${isNightMode ? 'text-slate-400' : 'text-slate-600'}`}>
              {isHindi 
                ? 'क्या आप पिछली सभी सेव की गई कैलकुलेशन मिटाना चाहते हैं? इसे वापस नहीं लाया जा सकेगा।' 
                : 'Are you sure you want to delete all saved calculations from this device? This cannot be undone.'}
            </p>
            <div className="flex gap-2 justify-end">
              <button
                type="button"
                onClick={() => setShowClearConfirm(false)}
                className={`px-3.5 py-2 rounded-xl text-xs font-semibold border ${
                  isNightMode ? 'border-slate-700 bg-slate-800 text-slate-300' : 'border-slate-200 bg-slate-100 text-slate-700'
                }`}
              >
                {isHindi ? 'रद्द करें' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={handleClearHistory}
                className="px-3.5 py-2 rounded-xl text-xs font-bold bg-red-600 hover:bg-red-700 text-white shadow-xs"
              >
                {isHindi ? 'हाँ, मिटाएं' : 'Clear All'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
