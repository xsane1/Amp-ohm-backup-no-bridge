import React, { useState } from 'react';
import { X, Copy, Check, Terminal, FolderTree, FileCode, Smartphone } from 'lucide-react';
import { useLanguage } from '../../localization/LanguageContext';

interface FlutterProjectModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FlutterProjectModal: React.FC<FlutterProjectModalProps> = ({ isOpen, onClose }) => {
  const { t } = useLanguage();
  const [copiedFile, setCopiedFile] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<string>('pubspec.yaml');

  if (!isOpen) return null;

  const flutterFiles: Record<string, { path: string; language: string; content: string }> = {
    'pubspec.yaml': {
      path: 'pubspec.yaml',
      language: 'yaml',
      content: `name: proaudio_toolkit
description: "Professional Audio Engineering Toolkit for Sound Engineers, DJ Operators, and PA Technicians"
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.0.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  flutter_localizations:
    sdk: flutter
  shared_preferences: ^2.2.2
  google_fonts: ^6.1.0
  provider: ^6.1.1
  cupertino_icons: ^1.0.6

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.0

flutter:
  uses-material-design: true
`
    },
    'main.dart': {
      path: 'lib/main.dart',
      language: 'dart',
      content: `import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'localization/app_localizations.dart';
import 'screens/home_screen.dart';
import 'screens/more_tools_screen.dart';
import 'screens/settings_screen.dart';
import 'services/preference_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  
  final prefService = PreferenceService();
  await prefService.init();

  runApp(
    ChangeNotifierProvider(
      create: (_) => prefService,
      child: const ProAudioApp(),
    ),
  );
}

class ProAudioApp extends StatelessWidget {
  const ProAudioApp({super.key});

  @override
  Widget build(BuildContext context) {
    final prefService = Provider.of<PreferenceService>(context);

    return MaterialApp(
      title: 'ProAudio Toolkit',
      debugShowCheckedModeBanner: false,
      locale: prefService.locale,
      supportedLocales: const [
        Locale('en', ''),
        Locale('hi', ''),
      ],
      localizationsDelegates: const [
        AppLocalizationsDelegate(),
      ],
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: Colors.white,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1E40AF), // Royal Blue
          primary: const Color(0xFF1E40AF),
          secondary: const Color(0xFFD97706), // Gold / Amber
          surface: Colors.white,
          onSurface: const Color(0xFF0F172A), // Dark Navy
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1E3A8A),
          foregroundColor: Colors.white,
          elevation: 2,
        ),
      ),
      home: const MainNavigationScreen(),
    );
  }
}

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 0;

  final List<Widget> _screens = const [
    HomeScreen(),
    MoreToolsScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);

    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (index) {
          setState(() => _currentIndex = index);
        },
        destinations: [
          NavigationDestination(
            icon: const Icon(Icons.home_outlined),
            selectedIcon: const Icon(Icons.home, color: Color(0xFF1E40AF)),
            label: t.navHome,
          ),
          NavigationDestination(
            icon: const Icon(Icons.build_outlined),
            selectedIcon: const Icon(Icons.build, color: Color(0xFF1E40AF)),
            label: t.navMoreTools,
          ),
          NavigationDestination(
            icon: const Icon(Icons.settings_outlined),
            selectedIcon: const Icon(Icons.settings, color: Color(0xFF1E40AF)),
            label: t.navSettings,
          ),
        ],
      ),
    );
  }
}
`
    },
    'app_localizations.dart': {
      path: 'lib/localization/app_localizations.dart',
      language: 'dart',
      content: `import 'package:flutter/material.dart';

class AppLocalizations {
  final Locale locale;
  AppLocalizations(this.locale);

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations) ??
        AppLocalizations(const Locale('en'));
  }

  bool get isHindi => locale.languageCode == 'hi';

  String get appName => isHindi ? 'प्रोऑडियो टूलकिट' : 'ProAudio Toolkit';
  String get appSubtitle => isHindi ? 'प्रोफेशनल ऑडियो इंजीनियरिंग टूलकिट' : 'Professional Audio Engineering Toolkit';
  String get navHome => isHindi ? 'होम' : 'Home';
  String get navMoreTools => isHindi ? 'अधिक टूल्स' : 'More Tools';
  String get navSettings => isHindi ? 'सेटिंग्स' : 'Settings';
  String get ohmTitle => isHindi ? 'ओम कैलकुलेटर' : 'OHM CALCULATOR';
  String get ampTitle => isHindi ? 'एम्पलीफायर कैलकुलेटर' : 'AMPLIFIER CALCULATOR';
  String get topSpeakerTitle => isHindi ? 'टॉप स्पीकर कैलकुलेटर' : 'TOP SPEAKER CALCULATOR';
  String get cableLossTitle => isHindi ? 'केबल लॉस कैलकुलेटर' : 'SPEAKER CABLE LOSS CALCULATOR';
  String get dmxTitle => isHindi ? 'DMX एड्रेस कैलकुलेटर' : 'DMX ADDRESS CALCULATOR';
  String get safe => isHindi ? 'सुरक्षित ऑपरेटिंग लोड' : 'Safe Operating Load';
  String get warning => isHindi ? 'सावधानी / सब-ऑप्टिमल' : 'Caution / Sub-optimal';
  String get danger => isHindi ? 'खतरा / उच्च जोखिम' : 'Danger / High Risk';
  String get comingSoon => isHindi ? 'जल्द आ रहा है' : 'Coming Soon';
}

class AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => ['en', 'hi'].contains(locale.languageCode);

  @override
  Future<AppLocalizations> load(Locale locale) async => AppLocalizations(locale);

  @override
  bool shouldReload(AppLocalizationsDelegate old) => false;
}
`
    },
    'ohm_calculator.dart': {
      path: 'lib/calculators/ohm_calculator.dart',
      language: 'dart',
      content: `enum WiringType { parallel, series, seriesParallel }

class OhmResult {
  final double totalImpedance;
  final double perSpeakerPower;
  final String status; // 'safe', 'warning', 'danger'

  const OhmResult({
    required this.totalImpedance,
    required this.perSpeakerPower,
    required this.status,
  });
}

class OhmCalculator {
  static OhmResult calculate({
    required WiringType wiring,
    required int speakerCount,
    required double speakerImpedance,
    required double totalAmpPower,
    required double minAmpLoad,
  }) {
    double total = speakerImpedance;

    switch (wiring) {
      case WiringType.parallel:
        total = speakerImpedance / (speakerCount > 0 ? speakerCount : 1);
        break;
      case WiringType.series:
        total = speakerImpedance * speakerCount;
        break;
      case WiringType.seriesParallel:
        final pairs = ((speakerCount + 1) / 2).floor();
        total = (speakerImpedance * pairs) / 2;
        break;
    }

    final perSpeaker = totalAmpPower / (speakerCount > 0 ? speakerCount : 1);

    String status = 'safe';
    if (total < minAmpLoad * 0.95) {
      status = 'danger';
    } else if (total <= minAmpLoad * 1.05) {
      status = 'warning';
    }

    return OhmResult(
      totalImpedance: double.parse(total.toStringAsFixed(2)),
      perSpeakerPower: double.parse(perSpeaker.toStringAsFixed(1)),
      status: status,
    );
  }
}
`
    },
    'AndroidManifest.xml': {
      path: 'android/app/src/main/AndroidManifest.xml',
      language: 'xml',
      content: `<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.ampohm.app">

    <application
        android:label="AMP OHM"
        android:name="\${applicationName}"
        android:icon="@mipmap/ic_launcher"
        android:allowBackup="false"
        android:hardwareAccelerated="true">
        
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:launchMode="singleTop"
            android:theme="@style/LaunchTheme"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|smallestScreenSize|locale|layoutDirection|fontScale|screenLayout|density|uiMode"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>

        <!-- Google AdMob Official Android Test App ID -->
        <!-- Replace with your real AdMob App ID in production -->
        <meta-data
            android:name="com.google.android.gms.ads.APPLICATION_ID"
            android:value="ca-app-pub-3940256099942544~3347511713"/>
    </application>
</manifest>
`
    }
  };

  const handleCopy = (key: string, content: string) => {
    navigator.clipboard.writeText(content);
    setCopiedFile(key);
    setTimeout(() => setCopiedFile(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-150">
      <div className="bg-slate-900 text-slate-100 rounded-2xl max-w-3xl w-full h-[88vh] flex flex-col shadow-2xl border border-slate-700 overflow-hidden">
        {/* Modal Header */}
        <div className="px-5 py-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white">
              <Smartphone className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <span>Production Flutter Android Codebase</span>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Clean Architecture
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Ready to clone into Android Studio or build with <code className="text-amber-400">flutter build apk --release</code>
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Instructions Banner */}
        <div className="bg-blue-950/80 px-5 py-2.5 border-b border-blue-900/60 flex items-center justify-between text-xs text-blue-200">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-amber-400 shrink-0" />
            <span>Files are organized in the workspace under <code>/flutter_app</code></span>
          </div>
          <span className="font-mono text-[11px] bg-blue-900/90 text-amber-300 px-2.5 py-0.5 rounded border border-blue-700">
            flutter run
          </span>
        </div>

        {/* Body Split View */}
        <div className="flex-1 flex flex-col sm:flex-row overflow-hidden">
          {/* File Tree Sidebar */}
          <div className="w-full sm:w-60 bg-slate-950/70 border-b sm:border-b-0 sm:border-r border-slate-800 p-3 overflow-y-auto">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
              <FolderTree className="w-3.5 h-3.5 text-blue-400" />
              <span>Project Files</span>
            </div>

            <div className="space-y-1">
              {Object.keys(flutterFiles).map((fileKey) => {
                const isSelected = selectedFile === fileKey;
                return (
                  <button
                    key={fileKey}
                    type="button"
                    onClick={() => setSelectedFile(fileKey)}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-mono transition flex items-center gap-2 ${
                      isSelected
                        ? 'bg-blue-600 text-white font-semibold shadow-xs'
                        : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                    }`}
                  >
                    <FileCode className="w-3.5 h-3.5 shrink-0 opacity-80" />
                    <span className="truncate">{fileKey}</span>
                  </button>
                );
              })}
            </div>

            {/* Build Guide summary */}
            <div className="mt-6 pt-4 border-t border-slate-800 text-[11px] text-slate-400 space-y-2">
              <div className="font-bold text-slate-300 uppercase text-[10px] tracking-wider">
                Google Play Build:
              </div>
              <div className="p-2 rounded bg-slate-900 border border-slate-800 font-mono text-[10px] text-amber-300 select-all">
                flutter build appbundle
              </div>
              <p className="text-[10px] leading-relaxed text-slate-500">
                Produces production <code className="text-slate-300">app-release.aab</code> for Google Play Console.
              </p>
            </div>
          </div>

          {/* Code Viewer Panel */}
          <div className="flex-1 flex flex-col bg-slate-900 overflow-hidden">
            <div className="px-4 py-2.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between text-xs font-mono">
              <span className="text-slate-300">{flutterFiles[selectedFile].path}</span>
              <button
                type="button"
                onClick={() => handleCopy(selectedFile, flutterFiles[selectedFile].content)}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs transition"
              >
                {copiedFile === selectedFile ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">{t.copied}</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-400" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>

            <div className="flex-1 p-4 overflow-auto font-mono text-xs text-slate-200 leading-relaxed whitespace-pre bg-slate-900/90">
              {flutterFiles[selectedFile].content}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
