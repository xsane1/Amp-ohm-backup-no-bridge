import React, { useState } from 'react';
import { ActiveScreen } from '../../types';
import { useLanguage } from '../../localization/LanguageContext';
import { CalculatorCard } from '../CalculatorCard';
import { ComingSoonSection } from '../ComingSoonSection';
import { Search, Wrench } from 'lucide-react';

interface MoreToolsScreenProps {
  onSelectCalculator: (screen: ActiveScreen) => void;
}

export const MoreToolsScreen: React.FC<MoreToolsScreenProps> = ({ onSelectCalculator }) => {
  const { t } = useLanguage();
  const [query, setQuery] = useState('');

  const tools = [
    {
      id: 'calc_ohm' as ActiveScreen,
      title: t.ohmCalcTitle,
      description: t.ohmCalcDesc,
      category: 'audio' as const,
      badge: 'Impedance & Load',
    },
    {
      id: 'calc_amp' as ActiveScreen,
      title: t.ampCalcTitle,
      description: t.ampCalcDesc,
      category: 'audio' as const,
      badge: 'Amplifier Sizing',
    },
    {
      id: 'calc_cable_loss' as ActiveScreen,
      title: t.cableLossCalcTitle,
      description: t.cableLossCalcDesc,
      category: 'audio' as const,
      badge: 'Cable & Damping',
    },
    {
      id: 'calc_dmx' as ActiveScreen,
      title: t.dmxCalcTitle,
      description: t.dmxCalcDesc,
      category: 'lighting' as const,
      badge: 'DMX Lighting',
    },
  ];

  const filtered = tools.filter(
    (item) =>
      item.title.toLowerCase().includes(query.toLowerCase()) ||
      item.description.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="pb-24 max-w-xl mx-auto px-4 pt-3">
      {/* Header */}
      <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-900 text-amber-400 flex items-center justify-center shrink-0">
            <Wrench className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900">{t.navMoreTools}</h2>
            <p className="text-xs text-slate-600">Quick Access Audio & Lighting Engineering Utilities</p>
          </div>
        </div>

        {/* Search bar */}
        <div className="mt-3 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search audio, lighting, or formulas..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-700"
          />
        </div>
      </div>

      {/* Tools List */}
      <div className="space-y-3 mb-6">
        {filtered.map((tool) => (
          <CalculatorCard
            key={tool.id}
            id={tool.id}
            title={tool.title}
            description={tool.description}
            category={tool.category}
            badge={tool.badge}
            onClick={onSelectCalculator}
          />
        ))}

        {filtered.length === 0 && (
          <div className="text-center py-8 text-xs text-slate-500 bg-white rounded-2xl border border-slate-200">
            No active tools matched "{query}".
          </div>
        )}
      </div>

      <ComingSoonSection />
    </div>
  );
};
