import React, { useState } from 'react';
import { useLanguage } from '../../localization/LanguageContext';
import { useTheme } from '../../theme/ThemeContext';
import { 
  Languages, 
  Check, 
  ChevronRight, 
  Info, 
  Mail, 
  Shield, 
  FileText, 
  AlertTriangle, 
  Send, 
  AlertCircle, 
  Instagram, 
  Youtube, 
  Code2, 
  Sparkles,
  ExternalLink,
  WifiOff,
  Download
} from 'lucide-react';
import { AboutModal } from '../settings/AboutModal';
import { ContactModal } from '../settings/ContactModal';
import { PrivacyPolicyModal } from '../settings/PrivacyPolicyModal';
import { TermsConditionsModal } from '../settings/TermsConditionsModal';
import { DisclaimerModal } from '../settings/DisclaimerModal';
import { CURRENT_APP_VERSION } from '../../services/versionService';
import { subscriptionService } from '../../services/subscriptionService';
import { adService } from '../../services/adService';
import { RewardAdModal } from '../ads/RewardAdModal';
import { Video, Gift, Clock } from 'lucide-react';

interface SettingsScreenProps {
  onOpenFlutterExport?: () => void;
  onOpenSubscription?: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({ 
  onOpenFlutterExport,
  onOpenSubscription 
}) => {
  const { language, setLanguage, isHindi } = useLanguage();
  const { isNightMode } = useTheme();
  const isPremium = subscriptionService.isPremium();
  const currentTier = subscriptionService.getCurrentTier();

  // Modals
  const [showAbout, setShowAbout] = useState(false);
  const [showContact, setShowContact] = useState(false);
  const [showPrivacy, setShowPrivacy] = useState(false);
  const [showTerms, setShowTerms] = useState(false);
  const [showDisclaimer, setShowDisclaimer] = useState(false);
  const [showRewardModal, setShowRewardModal] = useState(false);
  const [rewardPassActive, setRewardPassActive] = useState(adService.hasActiveRewardPass());
  const [passRemainingMins, setPassRemainingMins] = useState(adService.getRewardTimeRemainingMinutes());

  // Rapid tap protection for language switching
  const [isSwitchingLang, setIsSwitchingLang] = useState(false);

  const handleLanguageChange = (newLang: 'en' | 'hi') => {
    if (language === newLang || isSwitchingLang) return;
    setIsSwitchingLang(true);
    setLanguage(newLang);
    setTimeout(() => setIsSwitchingLang(false), 250);
  };

  return (
    <div className={`min-h-full pb-24 max-w-xl mx-auto px-4 pt-3 select-none transition-colors duration-200 ${
      isNightMode ? 'bg-[#0A0E17] text-slate-100' : 'bg-[#E5EBF3] text-slate-800'
    }`}>
      {/* Screen Title Banner */}
      <div className={`rounded-2xl p-4 sm:p-5 border shadow-sm mb-3.5 transition-colors ${
        isNightMode ? 'bg-[#141C30] border-slate-800' : 'bg-white border-slate-200'
      }`}>
        <h2 className={`text-base sm:text-lg font-black tracking-tight leading-tight ${
          isNightMode ? 'text-white' : 'text-[#0F172A]'
        }`}>
          {isHindi ? 'सेटिंग्स एवं जानकारी' : 'Settings & Information'}
        </h2>
        <p className={`text-[10px] sm:text-[11px] font-medium ${
          isNightMode ? 'text-slate-400' : 'text-slate-500'
        }`}>
          {isHindi ? 'भाषा, सपोर्ट, कनेक्ट और एप्लिकेशन विवरण' : 'Language, support, connect and application details'}
        </p>
      </div>

      {/* 1. Language Selection Card */}
      <div className={`rounded-2xl p-4 sm:p-5 border shadow-sm mb-3.5 transition-colors ${
        isNightMode ? 'bg-[#141C30] border-slate-800' : 'bg-white border-slate-200'
      }`}>
        <div className="flex items-center gap-2.5 mb-2.5">
          <div className={`p-1.5 rounded-lg ${
            isNightMode ? 'bg-blue-950 text-blue-400' : 'bg-blue-50 text-blue-600'
          }`}>
            <Languages className="w-4 h-4" />
          </div>
          <div>
            <h3 className={`text-xs sm:text-sm font-bold ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
              {isHindi ? 'ऐप की भाषा' : 'App Language'}
            </h3>
            <p className={`text-[10px] sm:text-[11px] ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
              {isHindi ? 'अंग्रेजी या सरल पेशेवर हिन्दी' : 'Choose English or Professional Hindi'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2.5 mt-3">
          {/* English */}
          <button
            type="button"
            disabled={isSwitchingLang}
            onClick={() => handleLanguageChange('en')}
            className={`p-3 rounded-xl border flex items-center justify-between text-left transition ${
              language === 'en'
                ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                : isNightMode
                ? 'bg-[#0F1626] text-slate-300 border-slate-800 hover:bg-slate-800/60'
                : 'bg-slate-50 text-slate-800 border-slate-200 hover:bg-slate-100'
            }`}
          >
            <div>
              <div className="text-xs font-bold">English</div>
              <div className={`text-[10px] ${language === 'en' ? 'text-blue-100' : 'text-slate-400'}`}>
                Standard Pro Audio
              </div>
            </div>
            {language === 'en' && <Check className="w-4 h-4 text-amber-300" />}
          </button>

          {/* Hindi */}
          <button
            type="button"
            disabled={isSwitchingLang}
            onClick={() => handleLanguageChange('hi')}
            className={`p-3 rounded-xl border flex items-center justify-between text-left transition ${
              language === 'hi'
                ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                : isNightMode
                ? 'bg-[#0F1626] text-slate-300 border-slate-800 hover:bg-slate-800/60'
                : 'bg-slate-50 text-slate-800 border-slate-200 hover:bg-slate-100'
            }`}
          >
            <div>
              <div className="text-xs font-bold">हिन्दी (Hindi)</div>
              <div className={`text-[10px] ${language === 'hi' ? 'text-blue-100' : 'text-slate-400'}`}>
                ऑडियो एवं लाइटिंग टूल्स
              </div>
            </div>
            {language === 'hi' && <Check className="w-4 h-4 text-amber-300" />}
          </button>
        </div>
      </div>

      {/* Main Settings Menu Items */}
      <div className={`rounded-2xl border shadow-sm overflow-hidden mb-3.5 divide-y transition-colors ${
        isNightMode 
          ? 'bg-[#141C30] border-slate-800 divide-slate-800' 
          : 'bg-white border-slate-200 divide-slate-100'
      }`}>
        <div className={`px-4 py-2.5 text-[10px] font-bold uppercase tracking-wider ${
          isNightMode ? 'bg-[#0F1626] text-slate-400' : 'bg-slate-50 text-slate-500'
        }`}>
          {isHindi ? 'सपोर्ट एवं ऐप जानकारी' : 'Support & App Info'}
        </div>

        {/* Contact Us */}
        <button
          type="button"
          onClick={() => setShowContact(true)}
          className={`w-full px-4 py-3.5 flex items-center justify-between transition text-xs font-medium ${
            isNightMode ? 'hover:bg-slate-800/40 text-slate-200' : 'hover:bg-slate-50 text-slate-800'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="p-1.5 bg-blue-500/10 text-blue-500 rounded-lg">
              <Mail className="w-4 h-4" />
            </div>
            <div className="text-left">
              <div className={`font-bold ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                {isHindi ? 'संपर्क करें (Contact Us)' : 'Contact Us'}
              </div>
              <div className={`text-[10px] ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                audioxpert123@gmail.com
              </div>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        {/* Send Feedback */}
        <a
          href="mailto:audioxpert123@gmail.com?subject=AMP%20OHM%20Feedback"
          className={`w-full px-4 py-3.5 flex items-center justify-between transition text-xs font-medium ${
            isNightMode ? 'hover:bg-slate-800/40 text-slate-200' : 'hover:bg-slate-50 text-slate-800'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="p-1.5 bg-emerald-500/10 text-emerald-500 rounded-lg">
              <Send className="w-4 h-4" />
            </div>
            <div className="text-left">
              <div className={`font-bold ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                {isHindi ? 'फीडबैक भेजें (Send Feedback)' : 'Send Feedback'}
              </div>
              <div className={`text-[10px] ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                {isHindi ? 'अपने सुझाव और अनुभव साझा करें' : 'Share your ideas & suggestions'}
              </div>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </a>

        {/* Report Issue */}
        <a
          href="mailto:audioxpert123@gmail.com?subject=AMP%20OHM%20Issue%20Report"
          className={`w-full px-4 py-3.5 flex items-center justify-between transition text-xs font-medium ${
            isNightMode ? 'hover:bg-slate-800/40 text-slate-200' : 'hover:bg-slate-50 text-slate-800'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="p-1.5 bg-amber-500/10 text-amber-500 rounded-lg">
              <AlertCircle className="w-4 h-4" />
            </div>
            <div className="text-left">
              <div className={`font-bold ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                {isHindi ? 'समस्या रिपोर्ट करें (Report Issue)' : 'Report Issue'}
              </div>
              <div className={`text-[10px] ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                {isHindi ? 'कोई बग या गणना में कमी बताएं' : 'Report bugs or formula issues'}
              </div>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </a>

        {/* Pro Membership / Subscription */}
        {onOpenSubscription && (
          <button
            type="button"
            onClick={onOpenSubscription}
            className={`w-full px-4 py-3.5 flex items-center justify-between transition text-xs font-medium ${
              isNightMode ? 'hover:bg-slate-800/40 text-slate-200' : 'hover:bg-slate-50 text-slate-800'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="p-1.5 bg-amber-500/10 text-amber-500 rounded-lg">
                <Sparkles className="w-4 h-4" />
              </div>
              <div className="text-left">
                <div className="flex items-center gap-2">
                  <span className={`font-bold ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                    {isHindi ? 'प्रो मेंबरशिप (Pro Subscription)' : 'Pro Subscription'}
                  </span>
                  {isPremium ? (
                    <span className="text-[9px] font-black uppercase px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      Active: {currentTier}
                    </span>
                  ) : (
                    <span className="text-[9px] font-black uppercase px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30">
                      Free Tier
                    </span>
                  )}
                </div>
                <div className={`text-[10px] ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                  {isHindi ? 'ऐड्स हटाएं, शेयर रिजल्ट्स एवं हिस्ट्री अनलॉक करें' : 'Remove ads, unlock share results & calculation history'}
                </div>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>
        )}

        {/* Reward Ad - 2 Hour Reward Pass (for free users) */}
        {!isPremium && (
          <button
            type="button"
            onClick={() => setShowRewardModal(true)}
            className={`w-full px-4 py-3.5 flex items-center justify-between transition text-xs font-medium ${
              isNightMode ? 'hover:bg-slate-800/40 text-slate-200' : 'hover:bg-slate-50 text-slate-800'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="p-1.5 bg-purple-500/10 text-purple-400 rounded-lg">
                <Video className="w-4 h-4" />
              </div>
              <div className="text-left">
                <div className="flex items-center gap-2">
                  <span className={`font-bold ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                    {isHindi ? 'कैलकुलेटर अनलॉक (2-Hour Pass)' : 'Unlock Calculators (2-Hour Pass)'}
                  </span>
                  {rewardPassActive ? (
                    <span className="text-[9px] font-black uppercase px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-400 border border-purple-500/30 flex items-center gap-1">
                      <Clock className="w-2.5 h-2.5" />
                      {passRemainingMins}m Left
                    </span>
                  ) : (
                    <span className="text-[9px] font-black uppercase px-1.5 py-0.5 rounded bg-purple-500/15 text-purple-400 border border-purple-500/30 flex items-center gap-1">
                      <Gift className="w-2.5 h-2.5" />
                      Watch Video
                    </span>
                  )}
                </div>
                <div className={`text-[10px] ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                  {rewardPassActive
                    ? (isHindi ? `पास सक्रिय है! अगले ${passRemainingMins} मिनट तक कैलकुलेटर अनलॉक रहेगा` : `Pass active! Calculators unlocked for next ${passRemainingMins} mins`)
                    : (isHindi ? '1 वीडियो देखकर सभी कैलकुलेटर 2 घंटे के लिए अनलॉक करें (बैनर ऐड्स प्रो में हटेंगे)' : 'Watch 1 video to unlock all calculators for 2 hours (Banner ads removed via Pro)')}
                </div>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>
        )}

        {/* About AMP OHM */}
        <button
          type="button"
          onClick={() => setShowAbout(true)}
          className={`w-full px-4 py-3.5 flex items-center justify-between transition text-xs font-medium ${
            isNightMode ? 'hover:bg-slate-800/40 text-slate-200' : 'hover:bg-slate-50 text-slate-800'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="p-1.5 bg-indigo-500/10 text-indigo-500 rounded-lg">
              <Info className="w-4 h-4" />
            </div>
            <div className="text-left">
              <div className={`font-bold ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                {isHindi ? 'About AMP OHM' : 'About AMP OHM'}
              </div>
              <div className={`text-[10px] ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                Audio &amp; Lighting Tools • Developed by AudioXpert
              </div>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        {/* App Version */}
        <div className={`w-full px-4 py-3.5 flex items-center justify-between text-xs font-medium ${
          isNightMode ? 'text-slate-200' : 'text-slate-800'
        }`}>
          <div className="flex items-center gap-3">
            <div className="p-1.5 bg-slate-500/10 text-slate-400 rounded-lg">
              <Sparkles className="w-4 h-4" />
            </div>
            <div className="text-left">
              <div className={`font-bold ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                {isHindi ? 'ऐप वर्जन' : 'App Version'}
              </div>
              <div className={`text-[10px] ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                Production Release
              </div>
            </div>
          </div>
          <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded-md bg-blue-600/10 text-blue-500 border border-blue-500/20">
            v{CURRENT_APP_VERSION}
          </span>
        </div>

        {/* Privacy Policy */}
        <button
          type="button"
          onClick={() => setShowPrivacy(true)}
          className={`w-full px-4 py-3.5 flex items-center justify-between transition text-xs font-medium ${
            isNightMode ? 'hover:bg-slate-800/40 text-slate-200' : 'hover:bg-slate-50 text-slate-800'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="p-1.5 bg-emerald-500/10 text-emerald-500 rounded-lg">
              <Shield className="w-4 h-4" />
            </div>
            <div className="text-left">
              <div className={`font-bold ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                {isHindi ? 'प्राइवेसी पॉलिसी (Privacy Policy)' : 'Privacy Policy'}
              </div>
              <div className={`text-[10px] ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                {isHindi ? 'स्थानीय व सुरक्षित, कोई डेटा ट्रैकिंग नहीं' : 'Local & secure, zero personal data collection'}
              </div>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        {/* Terms & Conditions */}
        <button
          type="button"
          onClick={() => setShowTerms(true)}
          className={`w-full px-4 py-3.5 flex items-center justify-between transition text-xs font-medium ${
            isNightMode ? 'hover:bg-slate-800/40 text-slate-200' : 'hover:bg-slate-50 text-slate-800'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="p-1.5 bg-purple-500/10 text-purple-500 rounded-lg">
              <FileText className="w-4 h-4" />
            </div>
            <div className="text-left">
              <div className={`font-bold ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                {isHindi ? 'नियम एवं शर्तें (Terms & Conditions)' : 'Terms & Conditions'}
              </div>
              <div className={`text-[10px] ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                {isHindi ? 'उपयोग के दिशा-निर्देश' : 'Usage guidelines & technical terms'}
              </div>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>

        {/* Disclaimer */}
        <button
          type="button"
          onClick={() => setShowDisclaimer(true)}
          className={`w-full px-4 py-3.5 flex items-center justify-between transition text-xs font-medium ${
            isNightMode ? 'hover:bg-slate-800/40 text-slate-200' : 'hover:bg-slate-50 text-slate-800'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="p-1.5 bg-amber-500/10 text-amber-500 rounded-lg">
              <AlertTriangle className="w-4 h-4" />
            </div>
            <div className="text-left">
              <div className={`font-bold ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                {isHindi ? 'डिस्क्लेमर (Disclaimer)' : 'Disclaimer'}
              </div>
              <div className={`text-[10px] ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                {isHindi ? 'हार्डवेयर व एम्पलीफायर सुरक्षा सूचना' : 'Loudspeaker & amplifier safety notice'}
              </div>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400" />
        </button>
      </div>

      {/* CONNECT SECTION */}
      <div className={`rounded-2xl p-4 sm:p-5 border shadow-sm mb-3.5 transition-colors ${
        isNightMode ? 'bg-[#141C30] border-slate-800' : 'bg-white border-slate-200'
      }`}>
        <h3 className={`text-xs sm:text-sm font-black mb-1 ${isNightMode ? 'text-white' : 'text-[#0F172A]'}`}>
          {isHindi ? 'कनेक्ट (Connect)' : 'Connect'}
        </h3>
        <p className={`text-[10px] sm:text-[11px] mb-3 ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
          {isHindi ? 'AudioXpert के ऑफिशियल चैनलों से जुड़ें' : 'Follow official AudioXpert channels'}
        </p>

        <div className="space-y-2">
          {/* Instagram */}
          <a
            href="https://instagram.com/audio_xpert"
            target="_blank"
            rel="noopener noreferrer"
            className={`p-3 rounded-xl border flex items-center justify-between transition ${
              isNightMode 
                ? 'bg-[#0F1626] border-slate-800 hover:border-pink-500/50' 
                : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Instagram className="w-4 h-4 text-pink-500" />
              <span className="font-bold text-xs">Instagram</span>
            </div>
            <span className="font-mono text-xs font-bold text-pink-500 flex items-center gap-1">
              @audio_xpert
              <ExternalLink className="w-3 h-3 text-pink-400" />
            </span>
          </a>

          {/* YouTube */}
          <a
            href="https://youtube.com/@audioxpertt"
            target="_blank"
            rel="noopener noreferrer"
            className={`p-3 rounded-xl border flex items-center justify-between transition ${
              isNightMode 
                ? 'bg-[#0F1626] border-slate-800 hover:border-red-500/50' 
                : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Youtube className="w-4 h-4 text-red-500" />
              <span className="font-bold text-xs">YouTube</span>
            </div>
            <span className="font-mono text-xs font-bold text-red-500 flex items-center gap-1">
              @audioxpertt
              <ExternalLink className="w-3 h-3 text-red-400" />
            </span>
          </a>

          {/* Email */}
          <a
            href="mailto:audioxpert123@gmail.com"
            className={`p-3 rounded-xl border flex items-center justify-between transition ${
              isNightMode 
                ? 'bg-[#0F1626] border-slate-800 hover:border-blue-500/50' 
                : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
            }`}
          >
            <div className="flex items-center gap-2.5">
              <Mail className="w-4 h-4 text-blue-500" />
              <span className="font-bold text-xs">Email</span>
            </div>
            <span className="font-mono text-xs font-bold text-blue-500">
              audioxpert123@gmail.com
            </span>
          </a>
        </div>
      </div>

      {/* DEVELOPER CREDITS & FOOTER */}
      <div className="text-center py-4 space-y-1">
        <div className={`text-xs font-bold ${isNightMode ? 'text-slate-300' : 'text-slate-700'}`}>
          Developed by <span className="text-blue-500">AudioXpert</span>
        </div>
        <div className={`text-[10px] ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
          AMP OHM • Audio &amp; Lighting Tools • v{CURRENT_APP_VERSION}
        </div>
      </div>

      {/* Modals */}
      <AboutModal
        isOpen={showAbout}
        onClose={() => setShowAbout(false)}
      />

      <ContactModal
        isOpen={showContact}
        onClose={() => setShowContact(false)}
      />

      <PrivacyPolicyModal
        isOpen={showPrivacy}
        onClose={() => setShowPrivacy(false)}
      />

      <TermsConditionsModal
        isOpen={showTerms}
        onClose={() => setShowTerms(false)}
      />

      <DisclaimerModal
        isOpen={showDisclaimer}
        onClose={() => setShowDisclaimer(false)}
      />

      {/* Reward Ad Modal */}
      <RewardAdModal
        isOpen={showRewardModal}
        onClose={() => {
          setShowRewardModal(false);
          setRewardPassActive(adService.hasActiveRewardPass());
          setPassRemainingMins(adService.getRewardTimeRemainingMinutes());
        }}
        onRewardClaimed={() => {
          setRewardPassActive(true);
          setPassRemainingMins(adService.getRewardTimeRemainingMinutes());
        }}
      />
    </div>
  );
};
