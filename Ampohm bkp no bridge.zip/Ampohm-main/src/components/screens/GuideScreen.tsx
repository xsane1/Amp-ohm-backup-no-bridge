import React, { useState } from 'react';
import { useLanguage } from '../../localization/LanguageContext';
import { useTheme } from '../../theme/ThemeContext';
import { 
  BookOpen, 
  Layers, 
  Zap, 
  SlidersHorizontal, 
  Info, 
  Radio, 
  Cable, 
  ExternalLink
} from 'lucide-react';

interface GuideSection {
  id: string;
  calcScreen?: string;
  calcNameEn?: string;
  calcNameHi?: string;
  titleEn: string;
  titleHi: string;
  badge: string;
  category: 'speaker' | 'amp' | 'lighting' | 'cable';
  icon: any;
  summaryEn: string;
  summaryHi: string;
  pointsEn: { heading: string; detail: string }[];
  pointsHi: { heading: string; detail: string }[];
  fieldTipEn: string;
  fieldTipHi: string;
}

interface GuideScreenProps {
  onSelectCalculator?: (screen: any) => void;
}

export const GuideScreen: React.FC<GuideScreenProps> = ({ onSelectCalculator }) => {
  const { isHindi } = useLanguage();
  const { isNightMode } = useTheme();
  const [activeCategory, setActiveCategory] = useState<'all' | 'speaker' | 'amp' | 'lighting' | 'cable'>('all');

  const guideSections: GuideSection[] = [
    {
      id: 'speaker_ohm',
      calcScreen: 'calc_ohm',
      calcNameEn: 'Ohm Calculator',
      calcNameHi: 'Ohm कैलकुलेटर',
      titleEn: 'Where to find Speaker Impedance (Ohm)',
      titleHi: 'Speaker Ohm (Impedance) कहाँ मिलेगा?',
      badge: 'SPEAKER OHM',
      category: 'speaker',
      icon: Layers,
      summaryEn: 'How to check nominal impedance (4Ω, 8Ω, or 16Ω) on cabinets, raw drivers, and testing with a digital multimeter.',
      summaryHi: 'स्पीकर कैबिनेट, रॉ ड्राइवर मैग्नेट और मल्टीमीटर से सही Ohm (4Ω, 8Ω या 16Ω) पता करने का आसान तरीका।',
      pointsEn: [
        {
          heading: '1. Back Speakon Plate (Rear Terminal)',
          detail: 'Check the metal or plastic connector plate on the back of the cabinet. Most professional PA cabinets clearly state nominal impedance: "8Ω", "4Ω", or "16Ω".',
        },
        {
          heading: '2. Raw Driver / Woofer Magnet Sticker',
          detail: 'If you open the cabinet, look at the back of the speaker magnet. A stamped foil sticker or stamped metal casing will display: "8 Ohm" or "4 Ohm" along with the model number.',
        },
        {
          heading: '3. Testing with a Digital Multimeter (DMM)',
          detail: 'If the label is torn or faded: set your multimeter to DC Resistance (Ω) and touch the probes to (+) and (-) terminals.\n• 8Ω Speaker reads approximately 5.6Ω to 6.8Ω DC resistance.\n• 4Ω Speaker reads approximately 2.8Ω to 3.4Ω DC resistance.\n(DC resistance is always roughly 70-80% of nominal impedance).',
        },
        {
          heading: '4. Dual Voice Coil (DVC) Subwoofers',
          detail: 'Heavy subwoofers often have two sets of terminals (Dual 4Ω or Dual 2Ω). Always verify whether they are wired internally in parallel (2Ω) or series (8Ω).',
        },
      ],
      pointsHi: [
        {
          heading: '1. कैबिनेट के पीछे Speakon प्लेट पर',
          detail: 'स्पीकर कैबिनेट के पिछले हिस्से पर लगी मेटल या प्लास्टिक प्लेट देखें। वहां साफ़ लिखा होता है: "8Ω" या "4Ω"।',
        },
        {
          heading: '2. स्पीकर मैग्नेट के पीछे का स्टिकर',
          detail: 'अगर कैबिनेट कस्टम बनी है, तो जाली खोलकर वूफर मैग्नेट के पीछे देखें। वहां मॉडल नंबर के साथ "8 Ohm", "4 Ohm" या "16 Ohm" प्रिंटेड रहता है।',
        },
        {
          heading: '3. मल्टीमीटर से चेक करने का प्रैक्टिकल तरीका',
          detail: 'अगर स्टिकर मिट चुका है: डिजिटल मल्टीमीटर को Resistance (Ω) मोड पर लगाएं और दोनों टर्मिनल छुएं:\n• 8Ω का स्पीकर मीटर में लगभग 5.6Ω से 6.8Ω दिखाएगा।\n• 4Ω का स्पीकर मीटर में लगभग 2.8Ω से 3.4Ω दिखाएगा।\n(मल्टीमीटर DC रेजिस्टेंस नापता है जो नाममात्र Ohm से थोड़ा कम होता है)।',
        },
        {
          heading: '4. डुअल वॉइस कॉइल (DVC) सबवूफर',
          detail: 'बड़े बेस/सबवूफर में दो टर्मिनल हो सकते हैं (Dual 4Ω या Dual 2Ω)। कनेक्शन चेक करें कि वे अंदर सीरीज में हैं या पैरेलल में।',
        },
      ],
      fieldTipEn: 'Sound Tech Rule: 90% of standard stage tops and single 18" subwoofers are 8Ω. Dual 18" subwoofers with internal parallel wiring are usually 4Ω.',
      fieldTipHi: 'साउंड ऑपरेटर टिप: ज्यादातर सिंगल 15" या 18" बेस 8Ω के होते हैं। डबल 18" बेस कैबिनेट अंदर से पैरेलल जुड़ने पर आमतौर पर 4Ω बन जाते हैं।',
    },
    {
      id: 'rms_power',
      calcScreen: 'calc_amp',
      calcNameEn: 'Amplifier Calculator',
      calcNameHi: 'एम्पलीफायर कैलकुलेटर',
      titleEn: 'Where to find RMS Power (Wattage)',
      titleHi: 'RMS Power (वॉटेज) कहाँ मिलेगी?',
      badge: 'RMS POWER',
      category: 'speaker',
      icon: Zap,
      summaryEn: 'How to find genuine continuous coil wattage and avoid misleading PMPO or peak numbers.',
      summaryHi: 'स्पीकर की असली कंटीन्यूअस (RMS) पावर पहचानें और नकली PMPO या Peak नंबरों के धोखे से बचें।',
      pointsEn: [
        {
          heading: '1. Rear Cabinet Label: Look for "RMS" or "AES"',
          detail: 'Always identify ratings labeled "RMS Power", "AES", or "Continuous Power" (e.g. "600W RMS"). This is the continuous heat dissipation capacity of the voice coil.',
        },
        {
          heading: '2. Never Trust "PMPO" or Cheap Peak Marketing',
          detail: 'Ignore sticker claims like "5000W PMPO" or "3000W Max". These are instantaneous split-second burst numbers designed for consumer retail.',
        },
        {
          heading: '3. Quick Conversion Formula',
          detail: 'If only Program or Peak is provided by the manufacturer:\n• RMS = Program Power ÷ 2 (e.g. 1200W Program = 600W RMS)\n• RMS = Peak Power ÷ 4 (e.g. 2400W Peak = 600W RMS).',
        },
        {
          heading: '4. Voice Coil Size as Reality Check',
          detail: '• 3 inch Voice Coil: typically 350W – 500W RMS\n• 4 inch Voice Coil: typically 600W – 1000W RMS\n• 4.5 to 5 inch Voice Coil: typically 1200W – 1800W RMS.',
        },
      ],
      pointsHi: [
        {
          heading: '1. पीछे का लेबल: "RMS" या "AES" ही देखें',
          detail: 'कैबिनेट या स्पीकर के पीछे हमेशा "RMS" या "AES" पावर देखें (जैसे 600W RMS)। यही स्पीकर की असली लगातार चलने वाली क्षमता होती है।',
        },
        {
          heading: '2. PMPO या Max Peak के धोखे में न आएं',
          detail: 'बाजार के स्पीकर्स पर अक्सर 4000W PMPO या 2500W Peak लिखा होता है। लाइव प्रोग्राम में अगर इतना लोड दिया तो कॉइल तुरंत जल जाएगी।',
        },
        {
          heading: '3. निकालने का सीधा फॉर्मूला',
          detail: 'अगर कंपनी ने सिर्फ Program या Peak पावर दी है:\n• RMS = Program Power का आधा (1200W Program = 600W RMS)\n• RMS = Peak Power का चौथा हिस्सा (2400W Peak = 600W RMS)।',
        },
        {
          heading: '4. वॉइस कॉइल साइज से पहचान',
          detail: '• 3 इंच कॉइल: 350W से 500W RMS\n• 4 इंच कॉइल: 600W से 1000W RMS\n• 4.5 से 5 इंच इन-आउट कॉइल: 1200W से 1800W RMS तक।',
        },
      ],
      fieldTipEn: 'Rental Pro Rule: Never match amplifiers based on Peak power. Always match based on continuous RMS + 1.5x headroom for clean, unclipped audio.',
      fieldTipHi: 'डीजे और रेंटल टिप: एम्पलीफायर हमेशा RMS पावर के हिसाब से 1.5 गुना हेडरुम रखकर सिलेक्ट करें ताकि एम्पलीफायर लाल क्लिप न मारे।',
    },
    {
      id: 'dmx_address',
      calcScreen: 'calc_dmx',
      calcNameEn: 'DMX Calculator',
      calcNameHi: 'DMX कैलकुलेटर',
      titleEn: 'Where to find DMX Starting Address',
      titleHi: 'DMX Address कहाँ मिलेगा?',
      badge: 'DMX START ADDR',
      category: 'lighting',
      icon: SlidersHorizontal,
      summaryEn: 'How to read and set the starting DMX address on digital displays of Moving Heads, Sharpy beams, and LED Par cans.',
      summaryHi: 'मूविंग हेड, शार्पी बीम और एलईडी पार लाइट के डिजिटल डिस्प्ले से DMX एड्रेस देखने और सेट करने का तरीका।',
      pointsEn: [
        {
          heading: '1. Fixture Digital LCD / LED Display',
          detail: 'Look at the digital screen on the base of the fixture. When powered on, the display shows the active address (e.g. "A001", "d001", or "ADDR: 001").',
        },
        {
          heading: '2. Navigating the Menu Buttons',
          detail: 'Press the "MENU" button until you see "ADDR" or "DMX Address". Press "ENTER", use UP/DOWN buttons to set the starting channel, and press "ENTER" again to save.',
        },
        {
          heading: '3. Lighting Console / Controller Patch Sheet',
          detail: 'Check your DMX Controller (e.g. Pilot 2000, Tiger Touch, GrandMA, DMX512) fixture schedule. If Fixture 1 is at 1 and takes 16 channels, Fixture 2 must be set to 17.',
        },
        {
          heading: '4. Letter Prefix Meaning ("A" vs "d")',
          detail: '• "A001": Standard DMX 512 mode (channels 1 to 512).\n• "d001": In some fixtures, signifies 512-channel reception mode with digital lock.',
        },
      ],
      pointsHi: [
        {
          heading: '1. लाइट के बेस पर डिजिटल डिस्प्ले',
          detail: 'शार्पी या पार लाइट के नीचे 4-डिजिट स्क्रीन होती है। लाइट ऑन करते ही वहां चालू एड्रेस जैसे "A001" या "d001" लिखा दिखता है।',
        },
        {
          heading: '2. मेनू बटन से सेटिंग',
          detail: '"MENU" बटन दबाएं जब तक स्क्रीन पर "ADDR" न आ जाए। "ENTER" दबाकर UP/DOWN तीरों से मनचाहा एड्रेस सेट करें और फिर से "ENTER" दबाकर सेव करें।',
        },
        {
          heading: '3. कंट्रोलर / पैच शीट के अनुसार',
          detail: 'अपने DMX कंट्रोलर (जैसे Pilot 2000, GrandMA आदि) में देखें। अगर पहली लाइट चैनल 1 पर 16 चैनल ले रही है, तो दूसरी लाइट का एड्रेस 17 रखना होगा।',
        },
        {
          heading: '4. "A" और "d" का मतलब',
          detail: 'डिस्प्ले पर "A001" या "d001" दोनों का मतलब DMX चैनल 1 ही होता है।',
        },
      ],
      fieldTipEn: 'Lighting Tech Rule: If lights flicker or misbehave, check for overlapping DMX address ranges across fixtures or missing 120Ω DMX terminators.',
      fieldTipHi: 'लाइट ऑपरेटर टिप: अगर लाइटें अपने आप हिलने लगें, तो चेक करें कि दो लाइटों के एड्रेस आपस में टकरा (overlap) तो नहीं रहे।',
    },
    {
      id: 'channel_count',
      calcScreen: 'calc_dmx',
      calcNameEn: 'DMX Calculator',
      calcNameHi: 'DMX कैलकुलेटर',
      titleEn: 'Where to find Channel Count (Personality Mode)',
      titleHi: 'Channel Count (मोड) कहाँ मिलेगा?',
      badge: 'CHANNELS',
      category: 'lighting',
      icon: Radio,
      summaryEn: 'Understanding fixture channel modes (e.g. 16CH vs 20CH in Sharpy, 4CH vs 8CH in LED Par) on display menus and user manuals.',
      summaryHi: 'शार्पी में 16CH vs 20CH और पार लाइट में 4CH vs 8CH जैसे चैनल मोड मेनू और मैन्युअल में कहाँ मिलते हैं।',
      pointsEn: [
        {
          heading: '1. Fixture Menu: "CHMD" or "MODE"',
          detail: 'Press "MENU" on the fixture until you reach "CHMD" (Channel Mode) or "MODE". You can toggle between basic mode (e.g. 16CH) and extended mode (e.g. 20CH).',
        },
        {
          heading: '2. Fixture User Manual (DMX Chart)',
          detail: 'Open the booklet that came with the fixture. Under "DMX Chart", it details how many channels the fixture consumes and what each channel controls (Pan, Tilt, Color, Gobo, Prism, Shutter).',
        },
        {
          heading: '3. Common Stage Fixture Standards',
          detail: '• 7R / 230W / 260W Sharpy Beam: typically 16CH (Standard) or 20CH (Extended).\n• RGBW LED Par Can: typically 4CH (RGBW) or 8CH (RGBW + Strobe + Dimmer + Macro).\n• Strobe / Blinder: typically 2CH to 4CH.',
        },
      ],
      pointsHi: [
        {
          heading: '1. मेनू में "CHMD" या "MODE" विकल्प',
          detail: 'लाइट के डिस्प्ले पर MENU दबाकर "CHMD" (चैनल मोड) या "MODE" खोलें। वहां 16CH, 20CH आदि विकल्प दिखते हैं।',
        },
        {
          heading: '2. लाइट के मैन्युअल का DMX चार्ट',
          detail: 'लाइट के साथ आए मैन्युअल में "DMX Protocol / Channel Chart" का पेज देखें। वहां लिखा होता है कि लाइट कितने चैनल इस्तेमाल करती है।',
        },
        {
          heading: '3. आम स्टेज लाइट्स के सामान्य चैनल',
          detail: '• 7R बीम शार्पी: 16 चैनल (स्टैंडर्ड मोड) या 20 चैनल (एक्सटेंडेड मोड)\n• LED पार कैन: 4 चैनल (RGBW) या 8 चैनल (कलर + स्ट्रोब + डिमर)\n• LED बार / वाश: 6, 9 या 24 चैनल।',
        },
      ],
      fieldTipEn: 'Console Tip: Your controller fixture library and the physical light fixture must be set to the EXACT same channel mode, or Pan/Tilt and colors will be scrambled.',
      fieldTipHi: 'कंट्रोलर टिप: जो चैनल मोड लाइट के अंदर सेट है, कंट्रोलर में भी वही लाइब्रेरी लोड होनी चाहिए, वरना गोबो और पैन-टिल्ट उल्टा काम करेंगे।',
    },
    {
      id: 'cable_size',
      calcScreen: 'calc_cable',
      calcNameEn: 'Cable Calculator',
      calcNameHi: 'केबल कैलकुलेटर',
      titleEn: 'Where to find Speaker Cable Size (sq. mm / Gauge)',
      titleHi: 'Speaker Cable Size (sq. mm) कहाँ मिलेगी?',
      badge: 'CABLE GAUGE',
      category: 'cable',
      icon: Cable,
      summaryEn: 'How to read conductor cross-section printed on cable jackets and pick correct thickness for long runs.',
      summaryHi: 'स्पीकर केबल की मोटाई (2.5mm², 4mm²) केबल के ऊपर कहाँ छपी होती है और लंबी दूरी के लिए क्या सही है।',
      pointsEn: [
        {
          heading: '1. Printed Text Along Cable Sheath',
          detail: 'Examine the outer PVC rubber jacket every 1 meter. You will see white or debossed text: e.g. "2 x 2.5 SQ MM HIGH GRADE SPEAKER CABLE" or "2 x 4.0 SQ MM OFC".',
        },
        {
          heading: '2. Understanding the Numbers',
          detail: '• "2 x 2.5 mm²": Two copper conductors inside, each 2.5 square millimeter thickness.\n• "4 x 4.0 mm²": 4-core cable for bi-amped sub/top touring rigs.',
        },
        {
          heading: '3. Gauge (AWG) to Metric Conversion',
          detail: '• 16 AWG ≈ 1.5 mm² (Short runs < 10m)\n• 14 AWG ≈ 2.5 mm² (Standard mid-range runs < 25m)\n• 12 AWG ≈ 4.0 mm² (Heavy subwoofer runs 25m – 50m)\n• 10 AWG ≈ 6.0 mm² (High-current stadium runs > 50m).',
        },
      ],
      pointsHi: [
        {
          heading: '1. केबल के रबर कवर पर प्रिंटेड लिखावट',
          detail: 'स्पीकर वायर के रबर इंसुलेशन पर हर एक मीटर पर सफेद अक्षरों में लिखा होता है: जैसे "2 x 2.5 SQ.MM" या "2 x 4.0 SQ.MM OFC SPEAKER CABLE"।',
        },
        {
          heading: '2. नंबर का असली मतलब',
          detail: '• "2 x 2.5 mm²": केबल के अंदर दो तार हैं और हर तार की मोटाई 2.5 वर्ग मिलीमीटर है।\n• "2 x 4.0 mm²": भारी बेस (Subwoofer) के लिए मोटी 4 mm² केबल।',
        },
        {
          heading: '3. दूरी और मोटाई का नियम',
          detail: '• 15-20 मीटर तक टॉप स्पीकर: 2.5 mm² काफी है।\n• 30 से 50 मीटर लंबी दूरी या 2Ω/4Ω बेस: हमेशा 4.0 mm² या 6.0 mm² केबल लगाएं ताकि आवाज दबे नहीं।',
        },
      ],
      fieldTipEn: 'Stage Rule: Thinner cable causes voltage drop and muddy low-end bass punch. For long subwoofer lines, always use 4mm² copper cable minimum.',
      fieldTipHi: 'साउंड ऑपरेटर टिप: पतली केबल से बेस की पंच दब जाती है और केबल गर्म होती है। बेस के लिए कम से कम 4mm² तांबे की केबल ही लगाएं।',
    },
  ];

  const filtered = activeCategory === 'all' 
    ? guideSections 
    : guideSections.filter(s => s.category === activeCategory);

  return (
    <div className={`min-h-full pb-24 px-3 sm:px-4 pt-3 select-none transition-colors duration-200 ${
      isNightMode ? 'bg-[#0A0E17] text-slate-100' : 'bg-[#E5EBF3] text-slate-800'
    }`}>
      {/* Top Banner Card */}
      <div className={`rounded-2xl p-4 sm:p-5 border shadow-sm mb-3.5 transition-colors ${
        isNightMode ? 'bg-[#141C30] border-slate-800' : 'bg-white border-slate-200'
      }`}>
        <div className="flex items-center gap-2.5">
          <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 shadow-2xs ${
            isNightMode ? 'bg-blue-950/60 border border-blue-700/40 text-blue-400' : 'bg-blue-50 border border-blue-200/70 text-[#1D4ED8]'
          }`}>
            <BookOpen className="w-5 h-5 stroke-[2.2]" />
          </div>
          <div>
            <h2 className={`text-base sm:text-lg ${
              isHindi ? 'font-semibold tracking-normal' : 'font-bold tracking-tight'
            } leading-tight ${
              isNightMode ? 'text-white' : 'text-[#0F172A]'
            }`}>
              {isHindi ? 'अपने इक्विपमेंट की डिटेल्स कहाँ देखें' : 'Where to Find Your Equipment Details'}
            </h2>
            <p className={`text-[10px] sm:text-[11px] font-medium ${
              isNightMode ? 'text-slate-400' : 'text-slate-500'
            }`}>
              {isHindi 
                ? 'कैबिनेट, ड्राइवर, एम्पलीफायर और लाइट्स पर सही इनपुट वैल्यू पहचानें' 
                : 'Where to find real-world specifications on stage hardware'}
            </p>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-1.5 mt-3.5 overflow-x-auto pb-0.5 scrollbar-none">
          {[
            { id: 'all', label: isHindi ? 'सभी' : 'All' },
            { id: 'speaker', label: isHindi ? 'स्पीकर' : 'Speakers' },
            { id: 'amp', label: isHindi ? 'एम्पलीफायर' : 'Amplifiers' },
            { id: 'cable', label: isHindi ? 'केबल' : 'Cables' },
            { id: 'lighting', label: isHindi ? 'लाइटिंग' : 'Lighting' },
          ].map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setActiveCategory(cat.id as any)}
              className={`px-3 py-1 rounded-full text-xs font-bold transition whitespace-nowrap border shadow-2xs ${
                activeCategory === cat.id
                  ? isNightMode
                    ? 'bg-blue-600 text-white border-blue-500'
                    : 'bg-[#1D4ED8] text-white border-[#1D4ED8]'
                  : isNightMode
                  ? 'bg-slate-800/80 text-slate-400 border-slate-700 hover:text-slate-200'
                  : 'bg-slate-100 text-slate-600 border-slate-200 hover:bg-slate-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Direct Clean Guide Cards (No extra expand/accordion step) */}
      <div className="space-y-4">
        {filtered.map((item) => {
          const IconComp = item.icon;
          const points = isHindi ? item.pointsHi : item.pointsEn;

          return (
            <div
              key={item.id}
              className={`rounded-2xl border transition-all overflow-hidden shadow-sm ${
                isNightMode 
                  ? 'bg-[#141C30] border-slate-800' 
                  : 'bg-white border-slate-200'
              }`}
            >
              {/* Card Header */}
              <div className="p-4 flex items-start gap-3">
                <div className={`p-2.5 rounded-xl shrink-0 mt-0.5 shadow-2xs ${
                  isNightMode 
                    ? 'bg-blue-950/80 text-blue-400 border border-blue-800/50' 
                    : 'bg-blue-50 text-[#1D4ED8] border border-blue-100'
                }`}>
                  <IconComp className="w-5 h-5 stroke-[2.2]" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className={`text-[9px] font-extrabold uppercase px-2 py-0.5 rounded tracking-wider ${
                      isNightMode ? 'bg-slate-800 text-blue-300' : 'bg-slate-100 text-[#1D4ED8]'
                    }`}>
                      {item.badge}
                    </span>
                  </div>
                  <h3 className={`text-sm sm:text-base font-bold mt-1.5 tracking-tight leading-snug ${
                    isNightMode ? 'text-white' : 'text-[#0F172A]'
                  }`}>
                    {isHindi ? item.titleHi : item.titleEn}
                  </h3>
                  <p className={`text-[11.5px] mt-1 leading-relaxed ${
                    isNightMode ? 'text-slate-400' : 'text-slate-500'
                  }`}>
                    {isHindi ? item.summaryHi : item.summaryEn}
                  </p>
                </div>
              </div>

              {/* Divider */}
              <div className={`border-t ${isNightMode ? 'border-slate-800' : 'border-slate-100'}`} />

              {/* Direct Points List */}
              <div className={`p-4 space-y-2.5 ${
                isNightMode ? 'bg-[#0F1626]' : 'bg-slate-50/50'
              }`}>
                {points.map((pt, pIdx) => (
                  <div
                    key={pIdx}
                    className={`p-3 rounded-xl border text-xs ${
                      isNightMode 
                        ? 'bg-[#141C30] border-slate-800/80 text-slate-300' 
                        : 'bg-white border-slate-200/80 text-slate-700'
                    }`}
                  >
                    <h4 className={`font-bold text-xs flex items-center gap-1.5 mb-1.5 ${
                      isNightMode ? 'text-blue-300' : 'text-[#1D4ED8]'
                    }`}>
                      <span className="w-5 h-5 rounded-full bg-blue-500/10 text-blue-500 flex items-center justify-center text-[10px] font-black shrink-0">
                        {pIdx + 1}
                      </span>
                      <span>{pt.heading}</span>
                    </h4>
                    <p className="text-[11.5px] leading-relaxed whitespace-pre-line pl-6">
                      {pt.detail}
                    </p>
                  </div>
                ))}

                {/* Professional Field Tip Box */}
                <div className={`p-3.5 rounded-xl border flex items-start gap-2.5 mt-3 ${
                  isNightMode
                    ? 'bg-amber-950/30 border-amber-800/40 text-amber-200'
                    : 'bg-amber-50/90 border-amber-200 text-amber-900'
                }`}>
                  <Info className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  <div className="text-[11px] leading-relaxed font-medium">
                    {isHindi ? item.fieldTipHi : item.fieldTipEn}
                  </div>
                </div>

                {/* Direct Calculator Launcher */}
                {item.calcScreen && onSelectCalculator && (
                  <button
                    type="button"
                    onClick={() => onSelectCalculator(item.calcScreen)}
                    className={`w-full py-2.5 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition active:scale-98 mt-2 ${
                      isNightMode
                        ? 'bg-blue-600 hover:bg-blue-500 text-white shadow-sm'
                        : 'bg-[#1D4ED8] hover:bg-blue-700 text-white shadow-sm'
                    }`}
                  >
                    <span>{isHindi ? `इस गाइड का टूल (${item.calcNameHi || 'कैलकुलेटर'}) खोलें` : `Open Matching Tool (${item.calcNameEn || 'Calculator'})`}</span>
                    <ExternalLink className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
