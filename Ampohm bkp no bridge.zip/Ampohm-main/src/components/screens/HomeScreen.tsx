import React from 'react';
import { ActiveScreen } from '../../types';
import { useLanguage } from '../../localization/LanguageContext';
import { useTheme } from '../../theme/ThemeContext';
import { analyticsService, CalculatorId } from '../../services/analyticsService';
import { 
  ChevronRight, 
  Settings,
  Sun,
  Moon,
  Languages,
  Crown
} from 'lucide-react';
import { 
  WooferIllustration, 
  RackAmplifierIllustration, 
  CableLossIllustration, 
  DmxMovingHeadIllustration 
} from '../equipment/EquipmentIllustrations';

interface HomeScreenProps {
  onSelectCalculator: (screen: ActiveScreen) => void;
  onOpenRemoveAds?: () => void;
  onOpenFlutterExport?: () => void;
  onOpenSettings?: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({ 
  onSelectCalculator,
  onOpenRemoveAds,
  onOpenSettings,
}) => {
  const { language, setLanguage, isHindi } = useLanguage();
  const { isNightMode, toggleTheme } = useTheme();
  const handleCardClick = (screen: ActiveScreen, analyticsId: CalculatorId, title: string) => {
    try {
      analyticsService.logCalculatorOpen(analyticsId, title);
    } catch (_) {}
    onSelectCalculator(screen);
  };

  const matchesOhm = true;
  const matchesAmp = true;
  const matchesCable = true;
  const matchesDmx = true;
  const hasAudioMatches = true;
  const hasLightingMatches = true;

  return (
    <div className={`min-h-full flex flex-col justify-start gap-2 pb-20 px-3 sm:px-3.5 pt-0.5 select-none transition-colors duration-300 ${
      isNightMode 
        ? 'studio-mesh-pattern-dark text-white' 
        : 'studio-mesh-pattern-light text-slate-900'
    }`}>
      {/* HEADER: AMP OHM + Tagline + Day/Night Toggle + Language Toggle + Settings */}
      <div className="relative z-10 flex items-center justify-between pt-0.5 pb-1 shrink-0">
        <div className="relative flex items-center gap-1.5 min-w-0 pr-1">
          {/* App Logo */}
          <div className="w-7.5 h-7.5 sm:w-8 sm:h-8 flex items-center justify-center shrink-0">
            <img src="/app-logo.png" alt="AMP OHM" className="w-full h-full object-contain drop-shadow-xs" />
          </div>
          <div className="min-w-0">
            <h1 className={`relative z-10 text-[18px] sm:text-[20px] font-black tracking-tight uppercase leading-none ${
              isNightMode ? 'text-white' : 'text-[#0F172A]'
            }`}>
              AMP <span className={isNightMode ? 'text-[#38BDF8]' : 'text-[#2563EB]'}>OHM</span>
            </h1>
            <p className={`text-[8.5px] sm:text-[9.5px] font-semibold tracking-tight mt-0.5 leading-none truncate ${
              isNightMode ? 'text-slate-400' : 'text-slate-500'
            }`}>
              Audio &amp; Lighting Tools
            </p>
          </div>
        </div>

        {/* Right Action Icons: King Crown (Pro) + Day/Night Mode + Language Toggle + Settings */}
        <div className="flex items-center gap-1.5">
          {/* King Crown (Premium Pro Subscription) Button */}
          <button
            type="button"
            onClick={onOpenRemoveAds}
            className={`w-7.5 h-7.5 rounded-full flex items-center justify-center transition active:scale-95 shadow-xs border ${
              isNightMode
                ? 'bg-amber-500/15 hover:bg-amber-500/25 border-amber-500/40 text-amber-400'
                : 'bg-amber-50 hover:bg-amber-100 border-amber-300 shadow-[0_2px_8px_rgba(245,158,11,0.15)] text-amber-500'
            }`}
            title={isHindi ? "प्रीमियम प्रो सब्स्क्रिप्शन लें" : "Get Premium Pro Subscription"}
            aria-label="Get Premium Subscription"
          >
            <Crown className="w-3.5 h-3.5 fill-amber-400 text-amber-500 stroke-[2.2]" />
          </button>

          {/* Night Mode / Day Mode Toggle Button */}
          <button
            type="button"
            onClick={toggleTheme}
            className={`w-7.5 h-7.5 rounded-full flex items-center justify-center transition active:scale-95 shadow-xs border ${
              isNightMode
                ? 'bg-slate-800/80 hover:bg-slate-700/80 border-slate-700/60 text-white'
                : 'bg-white/90 hover:bg-white border-white/80 shadow-[0_2px_8px_rgba(15,23,42,0.06)] text-slate-700'
            }`}
            title={isNightMode ? (isHindi ? "दिन मोड चालू करें" : "Switch to Day Mode") : (isHindi ? "नाइट मोड चालू करें" : "Switch to Night Mode")}
            aria-label="Toggle Night Mode"
          >
            {isNightMode ? (
              <Sun className="w-3.5 h-3.5 stroke-[2.2] text-amber-300 animate-in spin-in-180 duration-300" />
            ) : (
              <Moon className="w-3.5 h-3.5 stroke-[2.2] text-slate-700" />
            )}
          </button>

          {/* Language Toggle Button in Header */}
          <button
            type="button"
            onClick={() => setLanguage(language === 'en' ? 'hi' : 'en')}
            className={`h-7.5 px-2 rounded-full shadow-xs border flex items-center gap-1 font-bold text-[10.5px] transition active:scale-95 ${
              isNightMode
                ? 'bg-slate-800/80 hover:bg-slate-700/80 border-slate-700/60 text-white'
                : 'bg-white/90 hover:bg-white border-white/80 shadow-[0_2px_8px_rgba(15,23,42,0.06)] text-slate-700'
            }`}
            title={language === 'en' ? 'हिन्दी में बदलें' : 'Switch to English'}
            aria-label="Toggle Language"
          >
            <Languages className={`w-3 h-3 ${isNightMode ? 'text-sky-400' : 'text-blue-600'}`} />
            <span>{language === 'en' ? 'हिन्दी' : 'ENG'}</span>
          </button>

          {/* Settings Button */}
          <button
            type="button"
            onClick={onOpenSettings}
            className={`w-7.5 h-7.5 rounded-full shadow-xs border flex items-center justify-center transition active:scale-95 ${
              isNightMode
                ? 'bg-slate-800/80 hover:bg-slate-700/80 border-slate-700/60 text-white'
                : 'bg-white/90 hover:bg-white border-white/80 shadow-[0_2px_8px_rgba(15,23,42,0.06)] text-slate-700'
            }`}
            title="Settings"
            aria-label="Settings"
          >
            <Settings className="w-3.5 h-3.5 stroke-[2.2]" />
          </button>
        </div>
      </div>

      {/* SECTION 1: AUDIO TOOLS */}
      {hasAudioMatches && (
        <div className="relative z-10 flex flex-col">
          <h2 className={`text-[12px] sm:text-[13px] font-bold mb-1 shrink-0 ${
            isHindi ? 'tracking-normal' : 'tracking-tight'
          } ${
            isNightMode ? 'text-slate-200' : 'text-[#0F172A]'
          }`}>
            {isHindi ? 'ऑडियो टूल्स' : 'Audio Tools'}
          </h2>

          <div className="grid grid-cols-2 gap-2.5 sm:gap-3">
            {/* Card 1: OHM CALCULATOR */}
            {matchesOhm && (
              <button
                type="button"
                onClick={() => handleCardClick('calc_ohm', 'ohm_calculator', 'Ohm Calculator')}
                className={`group relative text-left rounded-[24px] p-3.5 sm:p-4 border-[0.6px] border-black/70 transition-all overflow-hidden flex flex-col justify-between h-[188px] sm:h-[196px] active:scale-[0.98] ${
                  isNightMode
                    ? 'bg-[#111827] border-black/80 text-white shadow-[0_10px_25px_rgba(0,0,0,0.5)] ring-1 ring-white/[0.05] hover:border-sky-500/50'
                    : 'bg-white border-black/70 text-[#0F172A] shadow-[0_8px_24px_rgba(15,23,42,0.06),0_2px_6px_rgba(15,23,42,0.04)] hover:shadow-[0_12px_32px_rgba(15,23,42,0.12)]'
                }`}
              >
                {/* Top Right: Circular Action Button */}
                <div className="absolute top-2.5 right-2.5 sm:top-3 sm:right-3 z-20 w-7.5 h-7.5 sm:w-8 sm:h-8 rounded-full bg-[#FBBF24] flex items-center justify-center shadow-xs border border-amber-300/60 group-hover:scale-110 transition-transform shrink-0">
                  <ChevronRight className="w-4 h-4 stroke-[3] text-[#0F172A]" />
                </div>

                {/* Top: Calculator Title + Subheading */}
                <div className="relative z-10 w-full pr-8">
                  <div className={`w-6 h-1 rounded-full mb-1.5 ${isNightMode ? 'bg-[#38BDF8]' : 'bg-[#2563EB]'}`} />
                  <h3 className={`text-[15.5px] sm:text-[16.5px] uppercase transition-colors ${
                    isHindi 
                      ? 'font-bold tracking-normal leading-[1.2]' 
                      : 'font-black tracking-tight leading-[1.12]'
                  } ${
                    isNightMode ? 'text-white group-hover:text-sky-300' : 'text-[#0F172A] group-hover:text-blue-700'
                  }`}>
                    {isHindi ? (
                      <>
                        ओम
                        <br />
                        कैलकुलेटर
                      </>
                    ) : (
                      <>
                        OHM
                        <br />
                        CALCULATOR
                      </>
                    )}
                  </h3>
                  <p className={`text-[10.5px] sm:text-[11px] font-medium mt-1 leading-tight line-clamp-2 max-w-[115px] sm:max-w-[125px] ${
                    isHindi ? 'tracking-normal' : 'tracking-tight'
                  } ${
                    isNightMode ? 'text-slate-400' : 'text-slate-500'
                  }`}>
                    {isHindi 
                      ? 'स्पीकर इम्पीडेंस कैलकुलेट करें' 
                      : 'Calculate speaker impedance'}
                  </p>
                </div>

                {/* Corner: Equipment Image (touches border cleanly without clipping) */}
                <div className="absolute right-0 bottom-0 sm:right-0.5 sm:bottom-0.5 w-[88px] h-[88px] sm:w-[94px] sm:h-[94px] flex items-end justify-end pointer-events-none z-1 drop-shadow-[0_4px_14px_rgba(15,23,42,0.3)] group-hover:scale-105 transition-transform duration-300">
                  <WooferIllustration />
                </div>
              </button>
            )}

            {/* Card 2: AMPLIFIER CALCULATOR */}
            {matchesAmp && (
              <button
                type="button"
                onClick={() => handleCardClick('calc_amp', 'amplifier_calculator', 'Amplifier Calculator')}
                className={`group relative text-left rounded-[24px] p-3.5 sm:p-4 border-[0.6px] border-black/70 transition-all overflow-hidden flex flex-col justify-between h-[188px] sm:h-[196px] active:scale-[0.98] ${
                  isNightMode
                    ? 'bg-[#111827] border-black/80 text-white shadow-[0_10px_25px_rgba(0,0,0,0.5)] ring-1 ring-white/[0.05] hover:border-sky-500/50'
                    : 'bg-white border-black/70 text-[#0F172A] shadow-[0_8px_24px_rgba(15,23,42,0.06),0_2px_6px_rgba(15,23,42,0.04)] hover:shadow-[0_12px_32px_rgba(15,23,42,0.12)]'
                }`}
              >
                {/* Top Right: Circular Action Button */}
                <div className="absolute top-2.5 right-2.5 sm:top-3 sm:right-3 z-20 w-7.5 h-7.5 sm:w-8 sm:h-8 rounded-full bg-[#FBBF24] flex items-center justify-center shadow-xs border border-amber-300/60 group-hover:scale-110 transition-transform shrink-0">
                  <ChevronRight className="w-4 h-4 stroke-[3] text-[#0F172A]" />
                </div>

                {/* Top: Calculator Title + Subheading */}
                <div className="relative z-10 w-full pr-8">
                  <div className={`w-6 h-1 rounded-full mb-1.5 ${isNightMode ? 'bg-[#38BDF8]' : 'bg-[#2563EB]'}`} />
                  <h3 className={`text-[15.5px] sm:text-[16.5px] uppercase transition-colors ${
                    isHindi 
                      ? 'font-bold tracking-normal leading-[1.2]' 
                      : 'font-black tracking-tight leading-[1.12]'
                  } ${
                    isNightMode ? 'text-white group-hover:text-sky-300' : 'text-[#0F172A] group-hover:text-blue-700'
                  }`}>
                    {isHindi ? (
                      <>
                        एम्पलीफायर
                        <br />
                        कैलकुलेटर
                      </>
                    ) : (
                      <>
                        AMPLIFIER
                        <br />
                        CALCULATOR
                      </>
                    )}
                  </h3>
                  <p className={`text-[10.5px] sm:text-[11px] font-medium mt-1 leading-tight line-clamp-2 ${
                    isHindi ? 'tracking-normal' : 'tracking-tight'
                  } ${
                    isNightMode ? 'text-slate-400' : 'text-slate-500'
                  }`}>
                    {isHindi 
                      ? 'एम्प पावर सही मैच करें' 
                      : 'Match amp power correctly'}
                  </p>
                </div>

                {/* Corner: Rack Amplifier */}
                <div className="absolute right-0 bottom-0 w-28 h-26 sm:w-30 sm:h-28 flex items-end justify-end pointer-events-none z-1 drop-shadow-[0_4px_14px_rgba(15,23,42,0.3)] group-hover:scale-105 transition-transform duration-300">
                  <RackAmplifierIllustration isAnimated={isNightMode} />
                </div>
              </button>
            )}
          </div>

          {/* Card 3: SPEAKER CABLE LOSS CALCULATOR */}
          {matchesCable && (
            <button
              type="button"
              onClick={() => handleCardClick('calc_cable_loss', 'cable_loss_calculator', 'Cable Loss Calculator')}
              className={`group relative w-full text-left rounded-[24px] p-3.5 sm:p-4 px-4 sm:px-4.5 border-[0.6px] border-black/70 transition-all overflow-hidden flex flex-col justify-center h-[138px] sm:h-[144px] active:scale-[0.99] mt-2 sm:mt-2.5 ${
                isNightMode
                  ? 'bg-[#111827] border-black/80 text-white shadow-[0_10px_25px_rgba(0,0,0,0.5)] ring-1 ring-white/[0.05] hover:border-sky-500/50'
                  : 'bg-white border-black/70 text-[#0F172A] shadow-[0_8px_24px_rgba(15,23,42,0.06),0_2px_6px_rgba(15,23,42,0.04)] hover:shadow-[0_12px_32px_rgba(15,23,42,0.12)]'
              }`}
            >
              {/* Top Right: Circular Action Button */}
              <div className="absolute top-2.5 right-2.5 sm:top-3 sm:right-3 z-20 w-7.5 h-7.5 sm:w-8 sm:h-8 rounded-full bg-[#FBBF24] flex items-center justify-center shadow-xs border border-amber-300/60 group-hover:scale-110 transition-transform shrink-0">
                <ChevronRight className="w-4 h-4 stroke-[3] text-[#0F172A]" />
              </div>

              {/* Top: Calculator Title + Subheading */}
              <div className="relative z-10 w-full pr-28 max-w-[70%] sm:max-w-[72%]">
                <div className={`w-6 h-1 rounded-full mb-1.5 ${isNightMode ? 'bg-[#38BDF8]' : 'bg-[#2563EB]'}`} />
                <h3 className={`text-[15.5px] sm:text-[16.5px] uppercase transition-colors ${
                  isHindi 
                    ? 'font-bold tracking-normal leading-tight' 
                    : 'font-black tracking-tight leading-tight'
                } ${
                  isNightMode ? 'text-white group-hover:text-sky-300' : 'text-[#0F172A] group-hover:text-blue-700'
                }`}>
                  {isHindi ? 'स्पीकर केबल लॉस कैलकुलेटर' : 'SPEAKER CABLE LOSS CALCULATOR'}
                </h3>
                <p className={`text-[10.5px] sm:text-[11px] font-medium mt-1 leading-normal line-clamp-2 ${
                  isHindi ? 'tracking-normal' : 'tracking-tight'
                } ${
                  isNightMode ? 'text-slate-400' : 'text-slate-500'
                }`}>
                  {isHindi 
                    ? 'सही केबल साइज चुनें और पावर लॉस रोकें' 
                    : 'Choose right cable size & avoid power loss'}
                </p>
              </div>

              {/* Corner: Equipment Image */}
              <div className="absolute right-1 sm:right-2 bottom-0 w-30 h-30 sm:w-32 sm:h-32 flex items-end justify-end pointer-events-none z-1 drop-shadow-[0_4px_14px_rgba(15,23,42,0.3)] group-hover:scale-105 transition-transform duration-300">
                <CableLossIllustration />
              </div>
            </button>
          )}
        </div>
      )}

      {/* SECTION 2: LIGHTING TOOLS */}
      {hasLightingMatches && (
        <div className="relative z-10 shrink-0 mt-2 sm:mt-2.5">
          <h2 className={`text-[13px] sm:text-[14px] font-bold mb-1.5 ${
            isHindi ? 'tracking-normal' : 'tracking-tight'
          } ${
            isNightMode ? 'text-slate-200' : 'text-[#0F172A]'
          }`}>
            {isHindi ? 'लाइटिंग टूल्स' : 'Lighting Tools'}
          </h2>

          {/* DMX ADDRESS CALCULATOR */}
          <button
            type="button"
            onClick={() => handleCardClick('calc_dmx', 'dmx_calculator', 'DMX Calculator')}
            className={`group relative w-full text-left rounded-[24px] p-3.5 sm:p-4 px-4 sm:px-4.5 border-[0.6px] border-black/70 transition-all overflow-hidden flex flex-col justify-center h-[138px] sm:h-[144px] active:scale-[0.99] ${
              isNightMode
                ? 'bg-[#111827] border-black/80 text-white shadow-[0_10px_25px_rgba(0,0,0,0.5)] ring-1 ring-white/[0.05] hover:border-sky-500/50'
                : 'bg-white border-black/70 text-[#0F172A] shadow-[0_8px_24px_rgba(15,23,42,0.06),0_2px_6px_rgba(15,23,42,0.04)] hover:shadow-[0_12px_32px_rgba(15,23,42,0.12)]'
            }`}
          >
            {/* Top Right: Circular Action Button */}
            <div className="absolute top-2.5 right-2.5 sm:top-3 sm:right-3 z-20 w-7.5 h-7.5 sm:w-8 sm:h-8 rounded-full bg-[#FBBF24] flex items-center justify-center shadow-xs border border-amber-300/60 group-hover:scale-110 transition-transform shrink-0">
              <ChevronRight className="w-4 h-4 stroke-[3] text-[#0F172A]" />
            </div>

            {/* Top: Calculator Title + Subheading */}
            <div className="relative z-10 w-full pr-28 max-w-[70%] sm:max-w-[72%]">
              <div className={`w-6 h-1 rounded-full mb-1.5 ${isNightMode ? 'bg-[#38BDF8]' : 'bg-[#2563EB]'}`} />
              <h3 className={`text-[15.5px] sm:text-[16.5px] uppercase transition-colors ${
                isHindi 
                  ? 'font-bold tracking-normal leading-tight' 
                  : 'font-black tracking-tight leading-tight'
              } ${
                isNightMode ? 'text-white group-hover:text-sky-300' : 'text-[#0F172A] group-hover:text-blue-700'
              }`}>
                {isHindi ? 'DMX एड्रेस कैलकुलेटर' : 'DMX ADDRESS CALCULATOR'}
              </h3>
              <p className={`text-[10.5px] sm:text-[11px] font-medium mt-1 leading-normal line-clamp-2 ${
                isHindi ? 'tracking-normal' : 'tracking-tight'
              } ${
                isNightMode ? 'text-slate-400' : 'text-slate-500'
              }`}>
                {isHindi 
                  ? 'DMX एड्रेस और फिक्स्चर कैलकुलेट करें' 
                  : 'Calculate DMX address'}
              </p>
            </div>

            {/* Luminous Moving Head Stage Light Beam Shafts (Active strictly in Night Mode) */}
            {isNightMode && (
              <>
                <div 
                  className="absolute pointer-events-none z-0"
                  style={{
                    right: '32px',
                    bottom: '18px',
                    width: '360px',
                    height: '130px',
                    transformOrigin: 'bottom right',
                    transform: 'rotate(-24deg)',
                    background: 'linear-gradient(90deg, rgba(56, 189, 248, 0) 0%, rgba(56, 189, 248, 0.18) 25%, rgba(14, 165, 233, 0.46) 65%, rgba(255, 255, 255, 0.90) 100%)',
                    filter: 'blur(5px)',
                    opacity: 0.95,
                    mixBlendMode: 'screen',
                  }}
                />

                {/* Core Intense Laser Ray Shaft */}
                <div 
                  className="absolute pointer-events-none z-0"
                  style={{
                    right: '40px',
                    bottom: '26px',
                    width: '320px',
                    height: '32px',
                    transformOrigin: 'bottom right',
                    transform: 'rotate(-24deg)',
                    background: 'linear-gradient(90deg, rgba(56, 189, 248, 0) 0%, rgba(224, 242, 254, 0.40) 40%, rgba(255, 255, 255, 0.98) 100%)',
                    filter: 'blur(2.5px)',
                    opacity: 0.92,
                  }}
                />
              </>
            )}

            {/* Corner: Equipment Image */}
            <div className={`absolute right-1 sm:right-2 bottom-1 w-28 h-28 sm:w-30 sm:h-30 flex items-end justify-end pointer-events-none z-1 transition-transform duration-300 group-hover:scale-105 ${
              isNightMode 
                ? 'drop-shadow-[0_4px_20px_rgba(56,189,248,0.55)]' 
                : 'drop-shadow-[0_4px_14px_rgba(15,23,42,0.3)]'
            }`}>
              <DmxMovingHeadIllustration isAnimated={isNightMode} />
            </div>
          </button>
        </div>
      )}
    </div>
  );
};
