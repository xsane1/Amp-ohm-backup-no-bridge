import React, { useState } from 'react';
import { RefreshCw, Download, AlertTriangle, CheckCircle, ExternalLink } from 'lucide-react';
import { RemoteVersionConfig, CURRENT_APP_VERSION } from '../../services/versionService';

interface ForceUpdateModalProps {
  config: RemoteVersionConfig;
  language: 'en' | 'hi';
  isNightMode: boolean;
}

export const ForceUpdateModal: React.FC<ForceUpdateModalProps> = ({
  config,
  language,
  isNightMode,
}) => {
  const [isUpdating, setIsUpdating] = useState(false);

  const isHindi = language === 'hi';

  const handleUpdate = async () => {
    setIsUpdating(true);

    try {
      // 1. If running in a Progressive Web App (PWA) or web browser:
      // Clear cache storage and unregister old service workers, then reload fresh code
      if ('serviceWorker' in navigator) {
        const registrations = await navigator.serviceWorker.getRegistrations();
        for (const registration of registrations) {
          await registration.update();
          await registration.unregister();
        }
      }

      if ('caches' in window) {
        const cacheNames = await caches.keys();
        await Promise.all(cacheNames.map((name) => caches.delete(name)));
      }

      // 2. Check if updateUrl exists (e.g. Play Store or external APK link)
      if (config.updateUrl && config.updateUrl.startsWith('http')) {
        window.open(config.updateUrl, '_blank', 'noopener,noreferrer');
      }

      // 3. Force hard-reload page after a brief moment
      setTimeout(() => {
        window.location.reload();
      }, 500);
    } catch (e) {
      console.error('[ForceUpdateModal] Update error:', e);
      if (config.updateUrl) {
        window.location.href = config.updateUrl;
      } else {
        window.location.reload();
      }
    }
  };

  const defaultTitle = isHindi
    ? 'आवश्यक अपडेट उपलब्ध है'
    : 'Critical Update Required';

  const defaultMessage = isHindi
    ? 'सिस्टम स्थिरता और सटीक कैलकुलेशन के लिए इस वर्ज़न को अपडेट करना अनिवार्य है। कृपया जारी रखने के लिए अभी अपडेट करें।'
    : 'A critical update is required to maintain calculation accuracy and app stability. Please update now to continue using the toolkit.';

  return (
    <div
      id="force-update-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in"
      role="dialog"
      aria-modal="true"
    >
      <div
        id="force-update-card"
        className={`w-full max-w-md rounded-3xl p-6 sm:p-7 shadow-2xl border transition-all ${
          isNightMode
            ? 'bg-[#0E1526] border-slate-700/80 text-white'
            : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {/* Header Icon Badge */}
        <div className="flex items-center justify-center mb-5">
          <div className="w-16 h-16 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-500 shadow-inner">
            <AlertTriangle className="w-8 h-8 stroke-[2.5]" />
          </div>
        </div>

        {/* Version Badges */}
        <div className="flex items-center justify-center gap-2 mb-3 text-xs font-semibold">
          <span
            className={`px-2.5 py-1 rounded-full border ${
              isNightMode
                ? 'bg-slate-800 text-slate-300 border-slate-700'
                : 'bg-slate-100 text-slate-600 border-slate-200'
            }`}
          >
            {isHindi ? 'वर्तमान वर्ज़न' : 'Current'}: v{CURRENT_APP_VERSION}
          </span>
          <span className="text-slate-400">→</span>
          <span className="px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-500 border border-emerald-500/30 font-bold">
            {isHindi ? 'नया वर्ज़न' : 'Required'}: v{config.minRequiredVersion || config.latestVersion}
          </span>
        </div>

        {/* Title */}
        <h2 className="text-xl sm:text-2xl font-black text-center mb-2 tracking-tight">
          {config.updateTitle || defaultTitle}
        </h2>

        {/* Message */}
        <p
          className={`text-center text-sm mb-5 leading-relaxed ${
            isNightMode ? 'text-slate-300' : 'text-slate-600'
          }`}
        >
          {config.updateMessage || defaultMessage}
        </p>

        {/* Release Notes (if any configured in remote doc) */}
        {config.releaseNotes && config.releaseNotes.length > 0 && (
          <div
            className={`rounded-2xl p-4 mb-6 text-left border ${
              isNightMode
                ? 'bg-slate-900/60 border-slate-800'
                : 'bg-slate-50 border-slate-100'
            }`}
          >
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
              {isHindi ? 'इस अपडेट में नया:' : "What's New in this update:"}
            </div>
            <ul className="space-y-1.5">
              {config.releaseNotes.map((note, idx) => (
                <li key={idx} className="flex items-start gap-2 text-xs">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-500 mt-0.5 shrink-0" />
                  <span className={isNightMode ? 'text-slate-300' : 'text-slate-700'}>
                    {note}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Primary Action Button (Update Now) */}
        <button
          type="button"
          id="btn-force-update-now"
          onClick={handleUpdate}
          disabled={isUpdating}
          className="w-full py-4 px-6 rounded-2xl font-black text-base bg-[#FBBF24] hover:bg-[#F59E0B] text-[#0F172A] shadow-lg shadow-amber-500/20 active:scale-98 transition flex items-center justify-center gap-2 border border-amber-300/80 cursor-pointer disabled:opacity-50"
        >
          {isUpdating ? (
            <>
              <RefreshCw className="w-5 h-5 animate-spin" />
              <span>{isHindi ? 'अपडेट हो रहा है...' : 'Updating App...'}</span>
            </>
          ) : (
            <>
              <Download className="w-5 h-5 stroke-[2.5]" />
              <span>{isHindi ? 'अभी तुरंत अपडेट करें' : 'Update App Now'}</span>
            </>
          )}
        </button>

        {/* Footer Note */}
        <div className="mt-4 text-center">
          <p className="text-[11px] text-slate-400">
            {isHindi
              ? 'अपडेट के बाद नया वर्ज़न अपने आप लोड हो जाएगा।'
              : 'The latest build will immediately load after updating.'}
          </p>
        </div>
      </div>
    </div>
  );
};
