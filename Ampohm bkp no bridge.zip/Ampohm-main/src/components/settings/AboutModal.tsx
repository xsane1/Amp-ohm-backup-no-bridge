import React from 'react';
import { Info, X, Cpu, ExternalLink, Instagram, Youtube, Mail, Sparkles } from 'lucide-react';
import { useLanguage } from '../../localization/LanguageContext';
import { useTheme } from '../../theme/ThemeContext';
import { CURRENT_APP_VERSION } from '../../services/versionService';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AboutModal: React.FC<AboutModalProps> = ({ isOpen, onClose }) => {
  const { isHindi } = useLanguage();
  const { isNightMode } = useTheme();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className={`rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border animate-in fade-in zoom-in-95 duration-200 my-8 transition-colors ${
        isNightMode ? 'bg-[#141C30] border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-800'
      }`}>
        {/* Header */}
        <div className="flex items-start justify-between pb-3 border-b border-slate-200/60 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <span className={`p-2 rounded-xl shrink-0 ${
              isNightMode ? 'bg-blue-950/80 text-blue-400 border border-blue-800/40' : 'bg-blue-50 text-[#1D4ED8] border border-blue-100'
            }`}>
              <Info className="w-4 h-4 stroke-[2.2]" />
            </span>
            <div>
              <h3 className={`text-base font-black ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                {isHindi ? 'AMP OHM के बारे में' : 'About AMP OHM'}
              </h3>
              <p className={`text-[11px] ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                Audio &amp; Lighting Tools
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className={`p-1.5 rounded-xl transition ${
              isNightMode ? 'text-slate-400 hover:text-white hover:bg-slate-800' : 'text-slate-400 hover:text-slate-700 hover:bg-slate-100'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="my-4 space-y-3.5 text-xs">
          {/* Application Name & Version */}
          <div className={`p-3.5 rounded-2xl border space-y-1.5 ${
            isNightMode ? 'bg-[#0F1626] border-slate-800/80' : 'bg-slate-50 border-slate-200/80'
          }`}>
            <div className="text-[10px] uppercase tracking-wider font-extrabold text-blue-500">
              {isHindi ? 'एप्लिकेशन का नाम' : 'Application Name'}
            </div>
            <div className={`text-base font-black ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
              AMP <span className="text-blue-500">OHM</span>
            </div>
            <div className="flex items-center gap-2 pt-0.5">
              <span className="px-2 py-0.5 bg-blue-600 text-white rounded text-[10px] font-bold">
                App Version {CURRENT_APP_VERSION}
              </span>
              <span className={`text-[10px] ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                {isHindi ? 'ऑडियो एवं लाइटिंग टूल्स' : 'Audio & Lighting Tools'}
              </span>
            </div>
          </div>

          {/* Developer Information */}
          <div className={`p-3 rounded-2xl border space-y-1 ${
            isNightMode ? 'bg-[#0F1626] border-slate-800/80' : 'bg-slate-50 border-slate-200/80'
          }`}>
            <div className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400">
              {isHindi ? 'डेवलपर जानकारी' : 'Developer Information'}
            </div>
            <div className={`font-bold text-sm ${isNightMode ? 'text-slate-100' : 'text-slate-800'}`}>
              Developed by AudioXpert
            </div>
            <p className={`text-[11px] leading-relaxed ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
              {isHindi 
                ? 'लाइव साउंड इंजीनियर्स, डीजे, स्टेज ऑपरेटर्स और लाइटिंग तकनीशियनों के लिए समर्पित टूलकिट।' 
                : 'Dedicated professional suite crafted for live sound engineers, DJs, festival crews, and stage technicians.'}
            </p>
          </div>

          {/* Official Connect Info */}
          <div className="space-y-1.5">
            <div className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400">
              {isHindi ? 'कनेक्ट करें' : 'Connect'}
            </div>
            <div className="grid grid-cols-1 gap-2">
              <a
                href="https://instagram.com/audio_xpert"
                target="_blank"
                rel="noopener noreferrer"
                className={`p-2.5 rounded-xl border flex items-center justify-between transition ${
                  isNightMode ? 'bg-[#0F1626] border-slate-800 hover:border-pink-500/50' : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Instagram className="w-4 h-4 text-pink-500" />
                  <span className="font-semibold text-xs">Instagram</span>
                </div>
                <span className="text-[11px] font-mono text-pink-500 font-bold">@audio_xpert</span>
              </a>

              <a
                href="https://youtube.com/@audioxpertt"
                target="_blank"
                rel="noopener noreferrer"
                className={`p-2.5 rounded-xl border flex items-center justify-between transition ${
                  isNightMode ? 'bg-[#0F1626] border-slate-800 hover:border-red-500/50' : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Youtube className="w-4 h-4 text-red-500" />
                  <span className="font-semibold text-xs">YouTube</span>
                </div>
                <span className="text-[11px] font-mono text-red-500 font-bold">@audioxpertt</span>
              </a>

              <a
                href="mailto:audioxpert123@gmail.com"
                className={`p-2.5 rounded-xl border flex items-center justify-between transition ${
                  isNightMode ? 'bg-[#0F1626] border-slate-800 hover:border-blue-500/50' : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Mail className="w-4 h-4 text-blue-500" />
                  <span className="font-semibold text-xs">Email</span>
                </div>
                <span className="text-[11px] font-mono text-blue-500 font-bold">audioxpert123@gmail.com</span>
              </a>
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition shadow-xs"
        >
          {isHindi ? 'बंद करें' : 'Close'}
        </button>
      </div>
    </div>
  );
};
