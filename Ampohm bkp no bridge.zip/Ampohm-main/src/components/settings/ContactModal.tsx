import React, { useState } from 'react';
import { Mail, Instagram, Youtube, X, Copy, Check, MessageSquare, Send, AlertCircle, ShieldCheck } from 'lucide-react';
import { useLanguage } from '../../localization/LanguageContext';
import { useTheme } from '../../theme/ThemeContext';
import { serverMembershipService } from '../../services/serverMembershipService';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'contact' | 'feedback' | 'report';
}

export const ContactModal: React.FC<ContactModalProps> = ({ isOpen, onClose, initialTab = 'contact' }) => {
  const { isHindi } = useLanguage();
  const { isNightMode } = useTheme();
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [feedbackEmail, setFeedbackEmail] = useState(serverMembershipService.getVerifiedEmail() || '');
  const [feedbackMsg, setFeedbackMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [statusFeedback, setStatusFeedback] = useState<string | null>(null);
  const [isVipSuccess, setIsVipSuccess] = useState(false);

  if (!isOpen) return null;

  const handleFeedbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackEmail.trim()) return;

    setIsSubmitting(true);
    setStatusFeedback(null);
    setIsVipSuccess(false);

    try {
      // 1. Check Server VIP Entitlement
      const result = await serverMembershipService.verifyAndActivateEmail(feedbackEmail);
      if (result.success) {
        setIsVipSuccess(true);
        setStatusFeedback(isHindi ? '✨ VIP सर्वर ऐक्सेस एक्टिवेट हो गया!' : '✨ Server VIP Entitlement Verified & Activated!');
      } else {
        setStatusFeedback(isHindi ? 'धन्यवाद! आपकी सहायता रिक्वेस्ट दर्ज कर ली गई है।' : 'Thank you! Your inquiry has been registered.');
      }
      setFeedbackMsg('');
    } catch (_) {
      setStatusFeedback(isHindi ? 'अनुरोध दर्ज हुआ।' : 'Submitted successfully.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className={`rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border animate-in fade-in zoom-in-95 duration-200 my-8 transition-colors ${
        isNightMode ? 'bg-[#141C30] border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-800'
      }`}>
        {/* Header */}
        <div className="flex items-start justify-between pb-3 border-b border-slate-200/60 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <span className={`p-2 rounded-xl shrink-0 ${
              isNightMode ? 'bg-blue-950/80 text-blue-400 border border-blue-800/40' : 'bg-blue-50 text-[#1D4ED8] border border-blue-100'
            }`}>
              <MessageSquare className="w-4 h-4 stroke-[2.2]" />
            </span>
            <div>
              <h3 className={`text-base font-black ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                {isHindi ? 'संपर्क एवं सहायता' : 'Contact Us & Connect'}
              </h3>
              <p className={`text-[11px] ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                AudioXpert Engineering Support
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className={`p-1.5 rounded-xl transition ${
              isNightMode ? 'text-slate-400 hover:text-white hover:bg-slate-800' : 'text-slate-400 hover:text-slate-700 hover:bg-slate-100'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="my-4 space-y-3.5 text-xs">
          {/* Direct Email Card */}
          <div className={`p-3.5 rounded-2xl border flex items-center justify-between ${
            isNightMode ? 'bg-[#0F1626] border-slate-800' : 'bg-slate-50 border-slate-200'
          }`}>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-blue-500/10 text-blue-500 rounded-xl">
                <Mail className="w-4 h-4" />
              </div>
              <div>
                <div className={`text-[10px] uppercase font-bold tracking-wider ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                  {isHindi ? 'ऑफिशियल ईमेल' : 'Official Email'}
                </div>
                <a 
                  href="mailto:audioxpert123@gmail.com"
                  className="font-mono font-bold text-xs text-blue-500 hover:underline"
                >
                  audioxpert123@gmail.com
                </a>
              </div>
            </div>

            <button
              type="button"
              onClick={() => handleCopy('audioxpert123@gmail.com', 'email')}
              className={`p-2 rounded-xl border transition ${
                isNightMode ? 'bg-slate-800 border-slate-700 hover:bg-slate-700' : 'bg-white border-slate-200 hover:bg-slate-100'
              }`}
              title="Copy Email"
            >
              {copiedKey === 'email' ? (
                <Check className="w-3.5 h-3.5 text-emerald-500" />
              ) : (
                <Copy className="w-3.5 h-3.5 text-slate-400" />
              )}
            </button>
          </div>

          {/* Connect Section */}
          <div className="space-y-2">
            <div className="text-[10px] uppercase tracking-wider font-extrabold text-slate-400">
              {isHindi ? 'सोशल मीडिया व कम्युनिटी' : 'Connect'}
            </div>

            <div className="grid grid-cols-2 gap-2">
              {/* Instagram */}
              <a
                href="https://instagram.com/audio_xpert"
                target="_blank"
                rel="noopener noreferrer"
                className={`p-3 rounded-2xl border flex flex-col justify-between transition group ${
                  isNightMode ? 'bg-[#0F1626] border-slate-800 hover:border-pink-500/50' : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Instagram className="w-4 h-4 text-pink-500" />
                  <span className="font-bold text-xs">Instagram</span>
                </div>
                <span className="text-[11px] font-mono text-pink-500 font-semibold truncate">
                  @audio_xpert
                </span>
              </a>

              {/* YouTube */}
              <a
                href="https://youtube.com/@audioxpertt"
                target="_blank"
                rel="noopener noreferrer"
                className={`p-3 rounded-2xl border flex flex-col justify-between transition group ${
                  isNightMode ? 'bg-[#0F1626] border-slate-800 hover:border-red-500/50' : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Youtube className="w-4 h-4 text-red-500" />
                  <span className="font-bold text-xs">YouTube</span>
                </div>
                <span className="text-[11px] font-mono text-red-500 font-semibold truncate">
                  @audioxpertt
                </span>
              </a>
            </div>
          </div>

          {/* Quick Support & Inquiry Form */}
          <form onSubmit={handleFeedbackSubmit} className={`p-3 rounded-2xl border space-y-2.5 ${
            isNightMode ? 'bg-[#0F1626] border-slate-800' : 'bg-slate-50 border-slate-200'
          }`}>
            <div className="flex items-center justify-between">
              <span className={`text-[11px] font-bold ${isNightMode ? 'text-slate-300' : 'text-slate-700'}`}>
                {isHindi ? 'त्वरित सहायता व सुझाव' : 'Quick Support & Suggestions'}
              </span>
              {isVipSuccess && (
                <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded-full">
                  <ShieldCheck className="w-3 h-3" />
                  VIP Verified
                </span>
              )}
            </div>

            <input
              type="email"
              placeholder={isHindi ? 'आपका ईमेल (Email ID)' : 'Your email address'}
              value={feedbackEmail}
              onChange={(e) => setFeedbackEmail(e.target.value)}
              className={`w-full px-3 py-2 rounded-xl text-xs border outline-hidden transition ${
                isNightMode 
                  ? 'bg-slate-900/90 border-slate-700 text-white placeholder-slate-500 focus:border-blue-500' 
                  : 'bg-white border-slate-200 text-slate-800 placeholder-slate-400 focus:border-blue-500'
              }`}
              required
            />

            <input
              type="text"
              placeholder={isHindi ? 'कोई सवाल या सुझाव लिखें...' : 'Type feedback or query...'}
              value={feedbackMsg}
              onChange={(e) => setFeedbackMsg(e.target.value)}
              className={`w-full px-3 py-2 rounded-xl text-xs border outline-hidden transition ${
                isNightMode 
                  ? 'bg-slate-900/90 border-slate-700 text-white placeholder-slate-500 focus:border-blue-500' 
                  : 'bg-white border-slate-200 text-slate-800 placeholder-slate-400 focus:border-blue-500'
              }`}
            />

            <button
              type="submit"
              disabled={isSubmitting || !feedbackEmail.trim()}
              className="w-full py-2 px-3 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition shadow-xs"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isSubmitting ? (isHindi ? 'सत्यापित हो रहा है...' : 'Verifying...') : (isHindi ? 'सबमिट करें' : 'Submit')}</span>
            </button>

            {statusFeedback && (
              <p className={`text-[11px] font-semibold text-center mt-1 ${
                isVipSuccess ? 'text-amber-500' : 'text-emerald-500'
              }`}>
                {statusFeedback}
              </p>
            )}
          </form>

          {/* Action buttons: Send Feedback & Report Issue */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <a
              href="mailto:audioxpert123@gmail.com?subject=AMP%20OHM%20Feedback"
              className="p-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition shadow-xs"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isHindi ? 'फीडबैक भेजें' : 'Send Feedback'}</span>
            </a>

            <a
              href="mailto:audioxpert123@gmail.com?subject=AMP%20OHM%20Issue%20Report"
              className={`p-2.5 rounded-xl border font-bold text-xs flex items-center justify-center gap-1.5 transition ${
                isNightMode ? 'bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700' : 'bg-slate-100 border-slate-200 text-slate-800 hover:bg-slate-200'
              }`}
            >
              <AlertCircle className="w-3.5 h-3.5 text-amber-500" />
              <span>{isHindi ? 'समस्या रिपोर्ट करें' : 'Report Issue'}</span>
            </a>
          </div>

          {/* Developer Credit */}
          <div className={`text-center pt-2 text-[11px] ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
            Developed by <span className="font-bold text-blue-500">AudioXpert</span>
          </div>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition shadow-xs"
        >
          {isHindi ? 'बंद करें' : 'Close'}
        </button>
      </div>
    </div>
  );
};
