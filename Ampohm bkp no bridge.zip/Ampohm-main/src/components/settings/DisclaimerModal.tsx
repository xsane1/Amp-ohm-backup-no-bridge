import React from 'react';
import { AlertTriangle, X, ShieldAlert } from 'lucide-react';
import { useLanguage } from '../../localization/LanguageContext';
import { useTheme } from '../../theme/ThemeContext';

interface DisclaimerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DisclaimerModal: React.FC<DisclaimerModalProps> = ({ isOpen, onClose }) => {
  const { isHindi } = useLanguage();
  const { isNightMode } = useTheme();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className={`rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border animate-in fade-in zoom-in-95 duration-200 my-8 transition-colors ${
        isNightMode ? 'bg-[#141C30] border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-800'
      }`}>
        {/* Header */}
        <div className="flex items-start justify-between pb-3 border-b border-slate-200/60 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <span className={`p-2 rounded-xl shrink-0 ${
              isNightMode ? 'bg-amber-950/80 text-amber-400 border border-amber-800/40' : 'bg-amber-50 text-amber-700 border border-amber-100'
            }`}>
              <AlertTriangle className="w-4 h-4 stroke-[2.2]" />
            </span>
            <div>
              <h3 className={`text-base font-black ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                {isHindi ? 'डिस्क्लेमर (सावधानी)' : 'Technical Disclaimer'}
              </h3>
              <p className={`text-[11px] ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                Equipment Safety &amp; Operational Notice
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className={`p-1.5 rounded-xl transition ${
              isNightMode ? 'text-slate-400 hover:text-white hover:bg-slate-800' : 'text-slate-400 hover:text-slate-700 hover:bg-slate-100'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="my-4 space-y-3.5 text-xs max-h-80 overflow-y-auto pr-1 leading-relaxed">
          <div className={`p-3 rounded-xl border flex items-start gap-2.5 ${
            isNightMode 
              ? 'bg-amber-950/30 border-amber-800/40 text-amber-200' 
              : 'bg-amber-50 border-amber-200 text-amber-900'
          }`}>
            <ShieldAlert className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
            <p className="text-[11px] font-medium leading-relaxed">
              {isHindi
                ? 'यह ऐप एक गाइड और कैलकुलेटर है। लाइव सेटअप चालू करने से पहले हमेशा एम्पलीफायर के लोड रेटिंग और स्पीकर के असली RMS व ओह्म की पुष्टि करें।'
                : 'This app is an engineering calculation tool. Always verify physical amplifier specs, 2-ohm stability ratings, and genuine RMS limits before powering up.'}
            </p>
          </div>

          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-amber-400' : 'text-amber-700'}`}>
              {isHindi ? 'एम्पलीफायर क्लिपिंग व कॉइल बर्निंग' : 'Amplifier Clipping & Voice Coil Burning'}
            </h4>
            <p className={isNightMode ? 'text-slate-300' : 'text-slate-600'}>
              {isHindi
                ? 'कम पावर का एम्पलीफायर भी अगर रेड क्लिप (Distortion) में चलाया जाए तो स्क्वायर वेव बनने से स्पीकर की कॉइल जल सकती है। हमेशा साफ सिग्नल और उचित हेडरुम रखें।'
                : 'Underpowered amplifiers driven into sustained square-wave clipping will destroy speaker voice coils just as easily as overpowering. Maintain clean headroom.'}
            </p>
          </div>

          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-amber-400' : 'text-amber-700'}`}>
              {isHindi ? '2Ω से कम लोड की चेतावनी' : 'Sub-2 Ohm Extreme Loads'}
            </h4>
            <p className={isNightMode ? 'text-slate-300' : 'text-slate-600'}>
              {isHindi
                ? '2Ω से नीचे लोड डालने पर अधिकांश एम्पलीफायर ओवरहीट होकर प्रोटेक्ट मोड में चले जाते हैं या उनके ट्रांजिस्टर शॉर्ट हो सकते हैं। इसे पूरी तरह टालें।'
                : 'Loads below 2.0 ohms draw extreme current and can force amplifiers into thermal shutdown or permanent short-circuit failure. Strictly avoid sub-2Ω loading.'}
            </p>
          </div>

          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-amber-400' : 'text-amber-700'}`}>
              {isHindi ? 'सीमित देयता (Liability)' : 'Limitation of Liability'}
            </h4>
            <p className={isNightMode ? 'text-slate-300' : 'text-slate-600'}>
              {isHindi
                ? 'AudioXpert या डेवलपर उपकरण की किसी भी भौतिक क्षति, थर्मल डैमेज या इवेंट में रुकावट के लिए उत्तरदायी नहीं होंगे।'
                : 'AudioXpert shall not be held liable for any hardware damage, burned coils, blown amplifier channels, or gig disruptions.'}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition shadow-xs"
        >
          {isHindi ? 'स्वीकार करें' : 'I Understand'}
        </button>
      </div>
    </div>
  );
};
