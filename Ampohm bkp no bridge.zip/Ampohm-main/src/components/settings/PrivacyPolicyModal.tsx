import React from 'react';
import { Shield, X, Lock, CheckCircle2, CreditCard, Radio, Award } from 'lucide-react';
import { useLanguage } from '../../localization/LanguageContext';
import { useTheme } from '../../theme/ThemeContext';

interface PrivacyPolicyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PrivacyPolicyModal: React.FC<PrivacyPolicyModalProps> = ({ isOpen, onClose }) => {
  const { isHindi } = useLanguage();
  const { isNightMode } = useTheme();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className={`rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border animate-in fade-in zoom-in-95 duration-200 my-8 transition-colors ${
        isNightMode ? 'bg-[#141C30] border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-800'
      }`}>
        {/* Header */}
        <div className="flex items-start justify-between pb-3 border-b border-slate-200/60 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <span className={`p-2 rounded-xl shrink-0 ${
              isNightMode ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800/40' : 'bg-emerald-50 text-emerald-700 border border-emerald-100'
            }`}>
              <Shield className="w-4 h-4 stroke-[2.2]" />
            </span>
            <div>
              <h3 className={`text-base font-black ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                {isHindi ? 'प्राइवेसी पॉलिसी' : 'Privacy Policy'}
              </h3>
              <p className={`text-[11px] ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                AMP OHM Data & Privacy Standards
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className={`p-1.5 rounded-xl transition ${
              isNightMode ? 'text-slate-400 hover:text-white hover:bg-slate-800' : 'text-slate-400 hover:text-slate-700 hover:bg-slate-100'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="my-4 space-y-3.5 text-xs max-h-96 overflow-y-auto pr-1 leading-relaxed">
          {/* Highlight Badge */}
          <div className={`p-3 rounded-xl border text-[11px] font-medium flex items-start gap-2.5 ${
            isNightMode
              ? 'bg-emerald-950/40 border-emerald-800/50 text-emerald-300'
              : 'bg-emerald-50 border-emerald-200 text-emerald-900'
          }`}>
            <Lock className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
            <span>
              Privacy by Design: All audio and lighting calculation formulas execute strictly locally in volatile device memory (RAM). Zero calculation inputs or project specifications are transmitted to external servers.
            </span>
          </div>

          {/* Section 1 */}
          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-emerald-400' : 'text-emerald-800'}`}>
              1. Introduction
            </h4>
            <p className={isNightMode ? 'text-slate-300' : 'text-slate-600'}>
              Amp Ohm is developed by AudioXpert to provide sound engineers, audio operators, DJs, and stage lighting technicians with fast, reliable calculation tools. These include loudspeaker impedance (Series, Parallel, and Series-Parallel), amplifier power and headroom matching, top speaker array loading, speaker cable resistance and voltage drop, and DMX 512 fixture addressing. We respect your privacy and are committed to complete transparency regarding how data is handled.
            </p>
          </div>

          {/* Section 2 */}
          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-emerald-400' : 'text-emerald-800'}`}>
              2. Information and Data Handling
            </h4>
            <div className={`space-y-1.5 ${isNightMode ? 'text-slate-300' : 'text-slate-600'}`}>
              <p>• <strong>Calculator Inputs & Outputs:</strong> Numerical values entered into calculators (wattage, impedance, driver count, cable length, wire gauge, or DMX channels) are processed transiently in device RAM. They are not recorded in remote databases, uploaded to servers, or linked to your personal identity.</p>
              <p>• <strong>Locally Stored Preferences:</strong> Amp Ohm uses secure on-device local storage solely for operational preferences: theme setting (Night/Light Mode), language selection, 60-minute rewarded ad pass timestamp, cached subscription status for offline launches, and optional VIP pass verification email.</p>
              <p>• <strong>Third-Party SDK Data:</strong> Standardized diagnostic data and anonymous device identifiers are processed by integrated SDKs (Google AdMob, Google Play Billing, RevenueCat, and Firebase) to deliver ads, process purchases, verify entitlements, and retrieve remote configuration.</p>
              <p>• <strong>Data Amp Ohm Collects:</strong> Amp Ohm does not require user registration, account creation, logins, passwords, phone numbers, or user profiles.</p>
            </div>
          </div>

          {/* Section 3 */}
          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-emerald-400' : 'text-emerald-800'}`}>
              3. Calculator Data
            </h4>
            <p className={isNightMode ? 'text-slate-300' : 'text-slate-600'}>
              All calculation formulas run entirely on your local device. Your audio rig configurations, stage setups, speaker wiring combinations, and calculation results remain strictly on your device. No project files, calculation histories, or technical schematics are transmitted to AudioXpert or external servers.
            </p>
          </div>

          {/* Section 4 */}
          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-emerald-400' : 'text-emerald-800'}`}>
              4. Advertising (Google AdMob)
            </h4>
            <div className={`space-y-1.5 ${isNightMode ? 'text-slate-300' : 'text-slate-600'}`}>
              <p>The free edition is supported by advertising via Google AdMob (Google LLC). Implemented formats include:</p>
              <p>• <strong>Banner Ads:</strong> Displayed at the bottom of calculation result screens for free-tier users.</p>
              <p>• <strong>Rewarded Video Ads:</strong> User-initiated, opt-in rewarded ads. Watching a rewarded video unlocks a continuous 60-minute ad-free pass across all calculators in the app.</p>
              <p>• <strong>Ad-Free for Subscribers:</strong> Active Amp Ohm Pro subscribers receive an entirely ad-free experience across the entire application.</p>
              <p>• <strong>Data Processing:</strong> Google Mobile Ads SDK may collect anonymous advertising identifiers (Google Advertising ID / AAID), IP addresses for coarse geolocation, hardware specs, and interaction metrics under Google’s Privacy & Terms: <a href="https://policies.google.com/technologies/ads" target="_blank" rel="noreferrer" className="underline text-emerald-500">policies.google.com/technologies/ads</a></p>
            </div>
          </div>

          {/* Section 5 */}
          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-emerald-400' : 'text-emerald-800'}`}>
              5. In-App Purchases & Subscriptions
            </h4>
            <div className={`space-y-1.5 ${isNightMode ? 'text-slate-300' : 'text-slate-600'}`}>
              <p>• <strong>Google Play Billing:</strong> Subscription payments are processed securely through Google Play Billing (Google LLC). AudioXpert and Amp Ohm never collect, view, process, or store financial credentials or payment cards.</p>
              <p>• <strong>RevenueCat:</strong> We integrate RevenueCat to validate receipts, manage subscription states, verify the active "ampohm Pro" entitlement, and support purchase restorations.</p>
              <p>• <strong>Subscription Plans:</strong> Pro Monthly (ampohm_pro_monthly, fallback ₹49/mo) and Pro Yearly (ampohm_pro_annual, fallback ₹399/yr) auto-renewing subscriptions.</p>
              <p>• <strong>Auto-Renewal & Cancellation:</strong> Subscriptions renew automatically unless cancelled in Google Play at least 24 hours prior to the renewal date. Cancelling stops future billing while preserving Pro access until the paid period expires.</p>
              <p>• <strong>Restore Purchases:</strong> Active entitlements can be restored on any device using the same store account via "Restore Purchases".</p>
            </div>
          </div>

          {/* Section 6 */}
          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-emerald-400' : 'text-emerald-800'}`}>
              6. Data Security
            </h4>
            <p className={isNightMode ? 'text-slate-300' : 'text-slate-600'}>
              We employ standard and reasonable technical safeguards. All network communications with third-party infrastructure (Google Play, RevenueCat, AdMob, and Firebase) occur over encrypted HTTPS/TLS protocols. Device preferences are stored within sandboxed operating system storage. No electronic transmission or storage method is 100% infallible, but we adhere to industry-standard security practices.
            </p>
          </div>

          {/* Section 7 */}
          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-emerald-400' : 'text-emerald-800'}`}>
              7. Children’s Privacy
            </h4>
            <p className={isNightMode ? 'text-slate-300' : 'text-slate-600'}>
              Amp Ohm is a professional calculation and engineering utility designed specifically for audio engineers, sound operators, DJs, and stage electricians. The application is not intended for or directed toward children under 13 years of age, and we do not knowingly collect personal information from children under 13.
            </p>
          </div>

          {/* Section 8 */}
          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-emerald-400' : 'text-emerald-800'}`}>
              8. Third-Party Services
            </h4>
            <div className={`space-y-1 ${isNightMode ? 'text-slate-300' : 'text-slate-600'}`}>
              <p>• Google AdMob (Google LLC) – Advertising delivery and monetization for free users.</p>
              <p>• Google Play Billing (Google LLC) – In-app purchase and subscription processing.</p>
              <p>• RevenueCat (RevenueCat, Inc.) – Subscription entitlement management and verification.</p>
              <p>• Google Firebase / Cloud Firestore (Google LLC) – Anonymous remote configuration and version checks.</p>
            </div>
          </div>

          {/* Section 9 */}
          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-emerald-400' : 'text-emerald-800'}`}>
              9. Changes to This Privacy Policy
            </h4>
            <p className={isNightMode ? 'text-slate-300' : 'text-slate-600'}>
              AudioXpert may update this Privacy Policy periodically. The latest version will always remain accessible directly through the application’s Settings & Information section. Continued use of Amp Ohm following any update signifies your acceptance of the revised terms.
            </p>
          </div>

          {/* Section 10 */}
          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-emerald-400' : 'text-emerald-800'}`}>
              10. Contact Information
            </h4>
            <p className={isNightMode ? 'text-slate-300' : 'text-slate-600'}>
              For any questions or privacy inquiries regarding Amp Ohm, please contact AudioXpert directly at:{' '}
              <span className={`font-mono font-bold ${isNightMode ? 'text-emerald-400' : 'text-emerald-700'}`}>
                audioxpert123@gmail.com
              </span>.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition shadow-xs"
        >
          {isHindi ? 'समझ गया (I Understand)' : 'I Understand'}
        </button>
      </div>
    </div>
  );
};

