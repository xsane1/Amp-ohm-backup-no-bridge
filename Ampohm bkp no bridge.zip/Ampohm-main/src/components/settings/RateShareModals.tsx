import React, { useState } from 'react';
import { Star, Share2, X, Check, Copy, ThumbsUp } from 'lucide-react';
import { useTheme } from '../../theme/ThemeContext';

interface RateAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RateAppModal: React.FC<RateAppModalProps> = ({ isOpen, onClose }) => {
  const { isNightMode } = useTheme();
  const [rating, setRating] = useState(5);
  const [submitted, setSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = () => {
    setSubmitted(true);
    setTimeout(() => {
      onClose();
      setSubmitted(false);
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className={`rounded-3xl max-w-sm w-full p-5 sm:p-6 shadow-2xl border animate-in fade-in zoom-in-95 duration-200 transition-colors ${
        isNightMode ? 'bg-[#141C30] border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
      }`}>
        <div className={`flex items-start justify-between pb-3 border-b ${
          isNightMode ? 'border-slate-800' : 'border-slate-100'
        }`}>
          <div className="flex items-center gap-2">
            <span className={`p-1.5 rounded-lg ${
              isNightMode ? 'bg-amber-500/10 text-amber-400' : 'bg-amber-100 text-amber-900'
            }`}>
              <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
            </span>
            <h3 className={`text-base font-extrabold ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
              Rate AMP OHM
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className={`p-1.5 rounded-xl transition ${
              isNightMode ? 'text-slate-400 hover:text-white hover:bg-slate-800' : 'text-slate-400 hover:text-slate-700 hover:bg-slate-100'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submitted ? (
          <div className="py-8 text-center space-y-2">
            <div className="w-12 h-12 bg-emerald-500/10 text-emerald-500 rounded-full mx-auto flex items-center justify-center">
              <Check className="w-6 h-6 stroke-[3]" />
            </div>
            <div className={`text-sm font-bold ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
              Thank you for rating!
            </div>
            <p className={`text-xs ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
              Your feedback helps live sound engineers worldwide.
            </p>
          </div>
        ) : (
          <div className="py-4 space-y-4 text-center">
            <p className={`text-xs ${isNightMode ? 'text-slate-300' : 'text-slate-600'}`}>
              How would you rate your calculation experience with AMP OHM?
            </p>

            {/* Stars */}
            <div className="flex justify-center gap-2 py-2">
              {[1, 2, 3, 4, 5].map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setRating(s)}
                  className="p-1 transition transform hover:scale-110"
                >
                  <Star
                    className={`w-8 h-8 transition ${
                      s <= rating
                        ? 'text-amber-400 fill-amber-400 drop-shadow-xs'
                        : isNightMode ? 'text-slate-700 hover:text-amber-400/40' : 'text-slate-200 hover:text-amber-200'
                    }`}
                  />
                </button>
              ))}
            </div>

            <p className={`text-[11px] ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
              In production Android builds, this connects directly to the Google Play In-App Review API.
            </p>

            <button
              type="button"
              onClick={handleSubmit}
              className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition shadow-xs flex items-center justify-center gap-2"
            >
              <ThumbsUp className="w-4 h-4 text-amber-400" />
              <span>Submit Rating</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

interface ShareAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShareAppModal: React.FC<ShareAppModalProps> = ({ isOpen, onClose }) => {
  const { isNightMode } = useTheme();
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const shareText = "Check out AMP OHM - Professional Sound & Lighting Tools for audio crew, DJs and technicians! https://proaudiotoolkit.app";

  const handleShareNative = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'AMP OHM ProAudio Toolkit',
          text: shareText,
          url: 'https://proaudiotoolkit.app',
        });
        onClose();
        return;
      } catch (_) {}
    }
    handleCopy();
  };

  const handleCopy = () => {
    navigator.clipboard?.writeText(shareText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className={`rounded-3xl max-w-sm w-full p-5 sm:p-6 shadow-2xl border animate-in fade-in zoom-in-95 duration-200 transition-colors ${
        isNightMode ? 'bg-[#141C30] border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
      }`}>
        <div className={`flex items-start justify-between pb-3 border-b ${
          isNightMode ? 'border-slate-800' : 'border-slate-100'
        }`}>
          <div className="flex items-center gap-2">
            <span className={`p-1.5 rounded-lg ${
              isNightMode ? 'bg-blue-500/10 text-blue-400' : 'bg-blue-100 text-blue-900'
            }`}>
              <Share2 className="w-4 h-4 text-blue-500" />
            </span>
            <h3 className={`text-base font-extrabold ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
              Share AMP OHM
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className={`p-1.5 rounded-xl transition ${
              isNightMode ? 'text-slate-400 hover:text-white hover:bg-slate-800' : 'text-slate-400 hover:text-slate-700 hover:bg-slate-100'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="py-4 space-y-3">
          <p className={`text-xs ${isNightMode ? 'text-slate-300' : 'text-slate-600'}`}>
            Share this audio engineering toolkit with fellow sound crew, DJs, and stage technicians:
          </p>

          <div className={`p-3 rounded-xl border text-xs font-mono select-all ${
            isNightMode ? 'bg-[#0F1626] border-slate-800 text-slate-200' : 'bg-slate-50 border-slate-200 text-slate-700'
          }`}>
            {shareText}
          </div>

          <div className="space-y-2 pt-2">
            <button
              type="button"
              onClick={handleShareNative}
              className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition shadow-xs flex items-center justify-center gap-2"
            >
              <Share2 className="w-4 h-4 text-amber-400" />
              <span>Share with Crew</span>
            </button>

            <button
              type="button"
              onClick={handleCopy}
              className={`w-full py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
                isNightMode ? 'bg-slate-800 hover:bg-slate-700 text-slate-200' : 'bg-slate-100 hover:bg-slate-200 text-slate-800'
              }`}
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-500" />
                  <span className="text-emerald-500">Link Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 text-slate-400" />
                  <span>Copy Share Link</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
