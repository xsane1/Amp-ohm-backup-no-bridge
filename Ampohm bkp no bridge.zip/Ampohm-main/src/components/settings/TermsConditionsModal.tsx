import React from 'react';
import { FileText, X, Scale } from 'lucide-react';
import { useLanguage } from '../../localization/LanguageContext';
import { useTheme } from '../../theme/ThemeContext';

interface TermsConditionsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TermsConditionsModal: React.FC<TermsConditionsModalProps> = ({ isOpen, onClose }) => {
  const { isHindi } = useLanguage();
  const { isNightMode } = useTheme();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className={`rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border animate-in fade-in zoom-in-95 duration-200 my-8 transition-colors ${
        isNightMode ? 'bg-[#141C30] border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-800'
      }`}>
        {/* Header */}
        <div className="flex items-start justify-between pb-3 border-b border-slate-200/60 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <span className={`p-2 rounded-xl shrink-0 ${
              isNightMode ? 'bg-blue-950/80 text-blue-400 border border-blue-800/40' : 'bg-blue-50 text-[#1D4ED8] border border-blue-100'
            }`}>
              <Scale className="w-4 h-4 stroke-[2.2]" />
            </span>
            <div>
              <h3 className={`text-base font-black ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                {isHindi ? 'नियम एवं शर्तें' : 'Terms & Conditions'}
              </h3>
              <p className={`text-[11px] ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                AMP OHM Application Terms
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className={`p-1.5 rounded-xl transition ${
              isNightMode ? 'text-slate-400 hover:text-white hover:bg-slate-800' : 'text-slate-400 hover:text-slate-700 hover:bg-slate-100'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="my-4 space-y-3.5 text-xs max-h-96 overflow-y-auto pr-1 leading-relaxed">
          <div className={`p-3 rounded-xl border text-[11px] font-medium flex items-start gap-2.5 ${
            isNightMode
              ? 'bg-blue-950/40 border-blue-800/50 text-blue-300'
              : 'bg-blue-50 border-blue-200 text-blue-900'
          }`}>
            <Scale className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
            <span>
              Important Operational Notice: Amp Ohm provides mathematical reference calculations for sound and lighting systems. Always independently verify physical equipment ratings, minimum impedance loads, and manufacturer limits prior to live audio operation.
            </span>
          </div>

          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-blue-300' : 'text-blue-900'}`}>
              1. Acceptance of Terms
            </h4>
            <p className={isNightMode ? 'text-slate-300' : 'text-slate-600'}>
              By downloading, installing, accessing, or using the Amp Ohm mobile application, you agree to be bound by these Terms & Conditions. If you do not agree to these terms, please do not use and immediately uninstall the application.
            </p>
          </div>

          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-blue-300' : 'text-blue-900'}`}>
              2. About Amp Ohm
            </h4>
            <p className={isNightMode ? 'text-slate-300' : 'text-slate-600'}>
              Amp Ohm is an audio and lighting engineering calculation utility application developed by AudioXpert. It is designed to assist sound engineers, audio operators, stage technicians, DJs, and lighting professionals with system design, loudspeaker impedance matching, amplifier power recommendations, cable voltage drop estimations, and DMX 512 fixture addressing.
            </p>
          </div>

          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-blue-300' : 'text-blue-900'}`}>
              3. Permitted Use & License
            </h4>
            <div className={`space-y-1.5 ${isNightMode ? 'text-slate-300' : 'text-slate-600'}`}>
              <p>AudioXpert grants you a personal, non-exclusive, non-transferable, revocable, limited license to use Amp Ohm for lawful commercial, professional, and educational reference purposes in accordance with these Terms.</p>
              <p>You agree not to: (a) reverse engineer, decompile, disassemble, or attempt to derive the source code of the application; (b) modify, copy, adapt, or create derivative works; (c) rent, lease, sublicense, resell, or redistribute the application; or (d) use the application in violation of any applicable local, national, or international regulations.</p>
            </div>
          </div>

          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-blue-300' : 'text-blue-900'}`}>
              4. Calculator Accuracy and Limitations
            </h4>
            <div className={`space-y-1.5 ${isNightMode ? 'text-slate-300' : 'text-slate-600'}`}>
              <p>• <strong>Theoretical Estimates:</strong> All calculations provided by Amp Ohm (including speaker impedance, power matching, cable losses, and DMX dip-switch addressing) are mathematical estimates based on ideal engineering formulas and the specific numerical inputs provided by the user.</p>
              <p>• <strong>Real-World Variance:</strong> Actual performance in live event environments may vary significantly due to physical equipment manufacturing tolerances, dynamic speaker impedance fluctuations with frequency, voice coil heating and power compression, AC mains voltage variations, cable strand resistance, and environmental factors (such as ambient temperature and humidity).</p>
              <p>• <strong>Independent Verification Required:</strong> Calculation outputs do not constitute certified engineering blueprints or manufacturer-approved system designs. Users must independently verify critical calculations with manufacturer specification sheets, calibrated multimeters, and impedance meters.</p>
              <p>• <strong>Professional Advice:</strong> Amp Ohm is a reference tool and does not substitute for certified acoustic consulting, licensed electrical engineering, or professional sound system commissioning.</p>
            </div>
          </div>

          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-blue-300' : 'text-blue-900'}`}>
              5. Audio Equipment Safety & Warnings
            </h4>
            <div className={`space-y-1.5 ${isNightMode ? 'text-slate-300' : 'text-slate-600'}`}>
              <p>• <strong>Amplifier Impedance Limits:</strong> Parallel speaker wiring reduces total electrical impedance. Operating an amplifier into a load below its manufacturer-rated minimum impedance (e.g., running below 2Ω or 4Ω ratings) can trigger thermal protection shutdown, blown fuses, or permanent output transistor failure.</p>
              <p>• <strong>Power Ratings & Clipping:</strong> Always respect continuous RMS power ratings. Driving amplifiers into sustained clipping generates severe harmonic distortion and square waves that rapidly overheat and destroy loudspeaker voice coils and high-frequency compression drivers.</p>
              <p>• <strong>Speaker Wiring & Polarity:</strong> Ensure all Series, Parallel, or combined wiring harnesses are terminated with correct phase and polarity. Reversed polarity causes acoustic cancellation, while wiring short circuits can instantly damage power amplifiers.</p>
              <p>• <strong>Speaker Cable Selection:</strong> Select speaker cables with sufficient cross-sectional conductor area (AWG / mm²) for the cable run length and current load. Undersized cables cause high resistance, excessive voltage drop, cable heating, and degradation of amplifier damping factor.</p>
              <p>• <strong>Electrical Mains & Grounding:</strong> Stage power distribution must comply with electrical safety standards, proper circuit breaker ratings, and solid earth grounding. Never defeat equipment ground pins.</p>
              <p>• <strong>Acoustic Safety:</strong> High Sound Pressure Levels (SPL) produced by sound systems can cause permanent, irreversible hearing damage. Users are responsible for adhering to safe acoustic exposure limits.</p>
              <p>• <strong>No Safety Guarantee:</strong> Amp Ohm does NOT guarantee the physical safety, electrical compliance, or damage-free operation of your sound reinforcement or lighting hardware.</p>
            </div>
          </div>

          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-blue-300' : 'text-blue-900'}`}>
              6. User Responsibility
            </h4>
            <p className={isNightMode ? 'text-slate-300' : 'text-slate-600'}>
              You bear full and sole responsibility for: (a) verifying the accuracy and appropriateness of all values entered into the calculators; (b) inspecting and verifying the physical capabilities of all connected hardware; (c) ensuring compliance with manufacturer operational guidelines and safety codes; and (d) all outcomes, equipment configurations, and sound setups resulting from reliance on the application.
            </p>
          </div>

          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-blue-300' : 'text-blue-900'}`}>
              7. Ads and Rewarded Video Pass
            </h4>
            <div className={`space-y-1.5 ${isNightMode ? 'text-slate-300' : 'text-slate-600'}`}>
              <p>• <strong>Free Version Advertisements:</strong> The free edition of Amp Ohm displays non-intrusive banner advertisements on calculation result screens.</p>
              <p>• <strong>Rewarded Video Pass:</strong> Free-tier users can voluntarily choose to watch an opt-in Google AdMob rewarded video ad via the calculator unlock prompt. Successfully finishing the video ad grants a temporary 60-minute pass that unlocks all calculators and disables advertisements across the entire app for that period.</p>
              <p>• <strong>Ad Availability:</strong> Ad delivery depends on network connectivity and third-party ad inventory.</p>
              <p>• <strong>Remote Control:</strong> Ad frequency, formats, and killswitch toggles may be adjusted remotely by the developer via remote configuration.</p>
            </div>
          </div>

          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-blue-300' : 'text-blue-900'}`}>
              8. Amp Ohm Pro Subscriptions & In-App Purchases
            </h4>
            <div className={`space-y-1.5 ${isNightMode ? 'text-slate-300' : 'text-slate-600'}`}>
              <p>• <strong>Pro Benefits:</strong> Amp Ohm Pro membership grants 100% ad-free usage and unrestricted, immediate access to all calculators and export tools.</p>
              <p>• <strong>Available Plans:</strong> Pro access is available through Monthly recurring (ampohm_pro_monthly) and Yearly recurring (ampohm_pro_annual) subscriptions as shown in the in-app paywall.</p>
              <p>• <strong>Billing & Payment:</strong> Subscription payments are billed to your Google Play account upon purchase confirmation.</p>
              <p>• <strong>Automatic Renewal:</strong> Monthly and Yearly subscriptions renew automatically through Google Play unless cancelled at least 24 hours prior to the end of the current billing cycle.</p>
              <p>• <strong>Cancellation:</strong> You may cancel your subscription at any time through Google Play Store (Account &gt; Payments &amp; subscriptions &gt; Subscriptions).</p>
              <p>• <strong>Access Following Cancellation:</strong> Cancelling auto-renewal prevents future charges; your Pro entitlement remains active and completely ad-free until the verified expiration date of the currently paid billing period.</p>
              <p>• <strong>Expiration:</strong> When the paid entitlement period expires, the application automatically returns to standard free-user rules.</p>
              <p>• <strong>Restore Purchases:</strong> You can restore valid purchases made with the same Google Play account across reinstalls or device changes using the "Restore Purchases" feature.</p>
            </div>
          </div>

          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-blue-300' : 'text-blue-900'}`}>
              9. Refunds
            </h4>
            <p className={isNightMode ? 'text-slate-300' : 'text-slate-600'}>
              All subscription payments and billing transactions are processed by Google Play and are governed by applicable Google Play refund policies. AudioXpert does not directly handle, process, or guarantee refunds. To request a refund, please submit your request directly to Google Play Support according to their terms.
            </p>
          </div>

          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-blue-300' : 'text-blue-900'}`}>
              10. Intellectual Property
            </h4>
            <p className={isNightMode ? 'text-slate-300' : 'text-slate-600'}>
              All software code, visual interface designs, graphics, branding, logos, calculation formulas, and content within Amp Ohm are the proprietary intellectual property of AudioXpert and are protected by applicable copyright, trademark, and intellectual property laws. All rights not expressly granted herein are reserved.
            </p>
          </div>

          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-blue-300' : 'text-blue-900'}`}>
              11. Limitation of Liability
            </h4>
            <p className={isNightMode ? 'text-slate-300' : 'text-slate-600'}>
              To the maximum extent permitted by applicable law, AudioXpert, its developers, affiliates, and licensors shall not be held liable for any direct, indirect, incidental, special, punitive, or consequential damages whatsoever (including, without limitation, burned voice coils, damaged loudspeakers, amplifier thermal failure, destroyed cables, stage electrical accidents, bodily injury, lost profits, event cancellation, or business interruption) arising out of or related to the use of, or inability to use, the application or reliance on its calculation results.
            </p>
          </div>

          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-blue-300' : 'text-blue-900'}`}>
              12. Changes to the Application or Terms
            </h4>
            <p className={isNightMode ? 'text-slate-300' : 'text-slate-600'}>
              AudioXpert reserves the right to modify, enhance, or temporarily suspend features of the application or update these Terms & Conditions at any time. Updated terms will be made accessible within the application. Your continued use of Amp Ohm following any update constitutes your agreement to the modified terms.
            </p>
          </div>

          <div>
            <h4 className={`font-bold text-xs mb-1 ${isNightMode ? 'text-blue-300' : 'text-blue-900'}`}>
              13. Contact Information
            </h4>
            <p className={isNightMode ? 'text-slate-300' : 'text-slate-600'}>
              For any questions or legal inquiries regarding these Terms & Conditions, please contact AudioXpert at:{' '}
              <span className={`font-mono font-bold ${isNightMode ? 'text-blue-400' : 'text-blue-700'}`}>
                audioxpert123@gmail.com
              </span>.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition shadow-xs"
        >
          {isHindi ? 'स्वीकार करें' : 'I Understand'}
        </button>
      </div>
    </div>
  );
};
