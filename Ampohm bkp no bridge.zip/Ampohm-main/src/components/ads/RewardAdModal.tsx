import React, { useState, useEffect } from 'react';
import { adService, ADMOB_TEST_IDS } from '../../services/adService';
import { subscriptionService } from '../../services/subscriptionService';
import { useTheme } from '../../theme/ThemeContext';
import { useLanguage } from '../../localization/LanguageContext';
import { Video, Gift, Clock, CheckCircle, Sparkles, X, ShieldAlert, Copy, Check } from 'lucide-react';

interface RewardAdModalProps {
  isOpen: boolean;
  autoPlay?: boolean;
  onClose: () => void;
  onRewardClaimed?: (minutesAwarded: number) => void;
}

export const RewardAdModal: React.FC<RewardAdModalProps> = ({
  isOpen,
  autoPlay = true,
  onClose,
  onRewardClaimed,
}) => {
  const { isNightMode } = useTheme();
  const { isHindi } = useLanguage();
  const [isPlaying, setIsPlaying] = useState(autoPlay);
  const [countdown, setCountdown] = useState(15); // 15s simulated reward video
  const [rewardClaimed, setRewardClaimed] = useState(false);
  const [copiedTestId, setCopiedTestId] = useState(false);

  // Initialize playback when modal opens
  useEffect(() => {
    if (isOpen) {
      setIsPlaying(autoPlay);
      setCountdown(15);
      setRewardClaimed(false);
    } else {
      setIsPlaying(false);
      setRewardClaimed(false);
    }
  }, [isOpen, autoPlay]);

  const handleCopyId = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(ADMOB_TEST_IDS.android.rewarded);
    setCopiedTestId(true);
    setTimeout(() => setCopiedTestId(false), 2000);
  };

  useEffect(() => {
    let timer: any = null;
    if (isPlaying && countdown > 0) {
      timer = setInterval(() => {
        setCountdown((prev) => prev - 1);
      }, 1000);
    } else if (isPlaying && countdown === 0 && !rewardClaimed) {
      // Reward earned!
      setRewardClaimed(true);
      const minutes = adService.grantRewardPass(120);
      if (onRewardClaimed) {
        onRewardClaimed(minutes);
      }
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isPlaying, countdown, rewardClaimed, onRewardClaimed]);

  if (!isOpen) return null;

  const handleStartWatch = () => {
    setIsPlaying(true);
    setCountdown(15);
    setRewardClaimed(false);
  };

  const handleFinish = () => {
    setIsPlaying(false);
    setRewardClaimed(false);
    onClose();
  };

  const remainingRewardMins = adService.getRewardTimeRemainingMinutes();
  const hasPass = adService.hasActiveRewardPass();

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-xs overflow-y-auto animate-fadeIn"
      onClick={isPlaying && countdown > 0 ? undefined : onClose}
    >
      <div 
        className={`w-full max-w-sm rounded-3xl border p-5 shadow-2xl transition-all relative max-h-[92vh] overflow-y-auto my-auto ${
          isNightMode 
            ? 'bg-[#101726] border-slate-800 text-white' 
            : 'bg-white border-slate-200 text-slate-900'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button (only available before watching or after completing) */}
        {(!isPlaying || countdown === 0) && (
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full hover:bg-slate-200/50 dark:hover:bg-slate-800/80 text-slate-400 hover:text-slate-200 transition"
          >
            <X className="w-4 h-4" />
          </button>
        )}

        {/* STATE 1: REWARD CLAIMED */}
        {rewardClaimed ? (
          <div className="text-center py-4 space-y-3 animate-fadeIn">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center mx-auto shadow-[0_0_20px_rgba(16,185,129,0.3)]">
              <CheckCircle className="w-9 h-9 text-emerald-400" />
            </div>

            <h3 className="text-lg font-black text-emerald-400">
              {isHindi ? '2 घंटे के लिए कैलकुलेटर अनलॉक!' : 'Calculator Unlocked for 2 Hours!'}
            </h3>

            <p className={`text-xs px-2 leading-relaxed ${isNightMode ? 'text-slate-300' : 'text-slate-600'}`}>
              {isHindi
                ? 'मुबारक हो! अगले 2 घंटे (120 मिनट) के लिए कैलकुलेटर अनलॉक हो गया है। बैनर ऐड्स हटाने के लिए प्रो सब्सक्रिप्शन लें।'
                : 'Awesome! Calculator is now unlocked for the next 2 hours. To remove banner ads, upgrade to Pro.'}
            </p>

            <div className={`p-3 rounded-2xl border flex items-center justify-center gap-2 text-xs font-bold ${
              isNightMode ? 'bg-emerald-950/30 border-emerald-800/50 text-emerald-300' : 'bg-emerald-50 border-emerald-200 text-emerald-800'
            }`}>
              <Clock className="w-4 h-4" />
              <span>{isHindi ? 'वैलिडिटी: 2 घंटे (120 मिनट)' : 'Validity: 2 Hours (120 Mins)'}</span>
            </div>

            <button
              type="button"
              onClick={handleFinish}
              className="w-full py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-600 active:scale-95 text-slate-950 font-black text-xs transition shadow-lg mt-2"
            >
              {isHindi ? 'कैलकुलेशन जारी रखें' : 'Continue Calculating'}
            </button>
          </div>
        ) : isPlaying ? (
          /* STATE 2: PLAYING REWARD AD VIDEO */
          <div className="py-2 space-y-4 text-center animate-fadeIn">
            {/* AdMob Video Container Mock */}
            <div className="relative w-full aspect-video bg-black rounded-2xl overflow-hidden border border-slate-800 flex flex-col items-center justify-center shadow-inner">
              <div className="absolute top-2.5 left-3 flex items-center gap-1.5 bg-black/60 backdrop-blur-xs px-2 py-0.5 rounded-md text-[10px] text-white/90">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                <span>Google AdMob Test Reward Ad</span>
                <span className="font-mono text-[8px] text-amber-300 ml-1">
                  ({ADMOB_TEST_IDS.android.rewarded.substring(0, 16)}...)
                </span>
              </div>

              {/* Countdown badge */}
              <div className="absolute top-2.5 right-3 bg-amber-500 text-slate-950 px-2 py-0.5 rounded-full text-[11px] font-black tracking-wider flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>0:{countdown < 10 ? `0${countdown}` : countdown}</span>
              </div>

              {/* Video animation graphic */}
              <div className="space-y-2 p-4">
                <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center mx-auto text-amber-400">
                  <Video className="w-6 h-6 animate-pulse" />
                </div>
                <div className="text-white font-bold text-xs">
                  Pro Audio DJ Sound System Sponsor
                </div>
                <div className="text-[10px] text-slate-400">
                  {isHindi ? 'रिवॉर्ड पाने के लिए वीडियो पूरा देखें' : 'Watch video until timer completes to claim pass'}
                </div>
              </div>

              {/* Progress bar */}
              <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-slate-800">
                <div 
                  className="h-full bg-amber-400 transition-all duration-1000 ease-linear"
                  style={{ width: `${((15 - countdown) / 15) * 100}%` }}
                />
              </div>
            </div>

            <p className="text-[11px] text-slate-400 font-medium">
              {isHindi ? 'कृपया बैक बटन न दबाएं...' : 'Please stay on screen while ad completes...'}
            </p>
          </div>
        ) : (
          /* STATE 3: PROMPT / INVITATION */
          <div className="space-y-4 text-center py-2">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/20 text-amber-500 border border-amber-500/30 flex items-center justify-center mx-auto shadow-md">
              <Gift className="w-7 h-7" />
            </div>

            <div>
              <h3 className="text-base font-extrabold tracking-tight">
                {isHindi ? '2 घंटे का रिवॉर्ड पास प्राप्त करें' : 'Get 2-Hour Reward Pass'}
              </h3>
              <p className={`text-xs mt-1 leading-relaxed ${isNightMode ? 'text-slate-400' : 'text-slate-600'}`}>
                {isHindi 
                  ? 'सिर्फ एक छोटा सा स्पॉन्सर वीडियो देखें और अगले 2 घंटे के लिए सभी कैलकुलेटर में रिवॉर्ड ऐड्स बंद हो जाएंगे।'
                  : 'Watch a quick sponsored video to unlock a 2-hour pass that disables reward ads across all calculators.'}
              </p>
            </div>

            {hasPass && (
              <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold flex items-center justify-center gap-2">
                <Clock className="w-4 h-4" />
                <span>
                  {isHindi 
                    ? `आपके पास अभी भी ${remainingRewardMins} मिनट का पास एक्टिव है!` 
                    : `Active pass: ${remainingRewardMins} mins remaining!`}
                </span>
              </div>
            )}

            {/* Official Google AdMob Reward Test ID Badge & Quick Copy */}
            <div className={`p-2.5 rounded-xl border text-left flex items-center justify-between text-[11px] ${
              isNightMode ? 'bg-slate-900/90 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}>
              <div className="flex items-center gap-2 overflow-hidden">
                <div className="w-2 h-2 rounded-full bg-amber-400 animate-pulse shrink-0" />
                <div className="truncate">
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    AdMob Test Unit ID
                  </div>
                  <div className="font-mono text-[11px] text-amber-500 dark:text-amber-400 font-bold truncate">
                    {ADMOB_TEST_IDS.android.rewarded}
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={handleCopyId}
                className={`p-1.5 rounded-lg border ml-2 transition flex items-center gap-1 shrink-0 ${
                  copiedTestId
                    ? 'bg-emerald-500 text-white border-emerald-600'
                    : isNightMode
                      ? 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                      : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-300'
                }`}
                title="Copy Test Unit ID"
              >
                {copiedTestId ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span className="text-[9px] font-bold">{copiedTestId ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            <div className="space-y-2 pt-1">
              <button
                type="button"
                onClick={handleStartWatch}
                className="w-full py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-black text-xs transition shadow-md flex items-center justify-center gap-2"
              >
                <Video className="w-4 h-4" />
                <span>{isHindi ? 'वीडियो देखें (Watch Video)' : 'Watch Video (Unlock 2-Hour Pass)'}</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className={`w-full py-2.5 px-4 rounded-xl text-xs font-semibold transition ${
                  isNightMode ? 'text-slate-400 hover:text-slate-200' : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                {isHindi ? 'अभी नहीं (Maybe Later)' : 'Maybe Later'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
