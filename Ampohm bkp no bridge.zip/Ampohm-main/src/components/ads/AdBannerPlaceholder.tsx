import React, { useState, useEffect } from 'react';
import { subscriptionService } from '../../services/subscriptionService';
import { adService, RemoteAdsConfig, ADMOB_TEST_IDS } from '../../services/adService';
import { useTheme } from '../../theme/ThemeContext';
import { Sparkles, Info, X, Check, Copy, ExternalLink } from 'lucide-react';

const ADMOB_TEST_CONFIG = {
  appId: ADMOB_TEST_IDS.android.appId,
  homeBannerId: ADMOB_TEST_IDS.android.banner,
  resultBannerId: ADMOB_TEST_IDS.android.banner,
  rewardAdId: ADMOB_TEST_IDS.android.rewarded,
};

interface AdBannerPlaceholderProps {
  placement: 'home_bottom' | 'result_bottom';
  onOpenRemoveAds?: () => void;
}

export const AdBannerPlaceholder: React.FC<AdBannerPlaceholderProps> = ({
  placement,
  onOpenRemoveAds,
}) => {
  const { isNightMode } = useTheme();
  const [canShowBanner, setCanShowBanner] = useState(adService.canShowBanner());
  const [showDetails, setShowDetails] = useState(false);
  const [clickNotice, setClickNotice] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const unsubSub = subscriptionService.addListener(() => {
      setCanShowBanner(adService.canShowBanner());
    });
    const unsubAd = adService.subscribe(() => {
      setCanShowBanner(adService.canShowBanner());
    });
    const interval = setInterval(() => {
      setCanShowBanner(adService.canShowBanner());
    }, 15000);

    return () => {
      unsubSub();
      unsubAd();
      clearInterval(interval);
    };
  }, []);

  if (!canShowBanner) {
    return null; // Ad removed for Premium users, Reward Pass, or Remote Off
  }

  const handleCopyTestId = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(ADMOB_TEST_CONFIG.homeBannerId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleTestClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setClickNotice(true);
    setTimeout(() => setClickNotice(false), 3000);
  };

  return (
    <div className="w-full my-3 px-1">
      {/* Banner Container - Standard Google AdMob Test Banner Unit */}
      <div 
        className={`relative w-full rounded-2xl border transition-all overflow-hidden p-2.5 sm:p-3 shadow-xs ${
          isNightMode 
            ? 'bg-[#131B2A] border-[#1E293B] text-white' 
            : 'bg-white border-slate-200 text-slate-900 shadow-[0_2px_10px_rgba(0,0,0,0.04)]'
        }`}
      >
        {/* Top bar with Google Test Ad Indicator & AdChoices */}
        <div className="flex items-center justify-between gap-2 mb-1.5 pb-1 border-b border-dashed border-slate-200/40 dark:border-slate-800">
          <div className="flex items-center gap-1.5">
            {/* Official Google Green "Test Ad" Ribbon */}
            <span className="bg-[#0F9D58] text-white text-[9px] font-black tracking-wider uppercase px-1.5 py-0.5 rounded shadow-xs">
              Test Ad
            </span>
            <span className={`text-[9.5px] font-semibold tracking-tight ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
              Google Mobile Ads (AdMob)
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            {/* AdChoices icon button */}
            <button
              type="button"
              onClick={() => setShowDetails(true)}
              className="inline-flex items-center gap-0.5 text-[9px] font-medium text-[#1A73E8] hover:text-[#1557B0] transition px-1 py-0.5 rounded hover:bg-blue-50/60 dark:hover:bg-blue-950/40"
              title="Google AdChoices & Test Ad Details"
            >
              {/* Google AdChoices blue triangle icon */}
              <svg className="w-2.5 h-2.5 fill-[#1A73E8]" viewBox="0 0 24 24">
                <path d="M12 2L2 22h20L12 2zm0 4.5l6.5 13H5.5L12 6.5zM11 11h2v5h-2zm0 6h2v2h-2z"/>
              </svg>
              <span className="font-semibold">AdChoices</span>
            </button>

            {onOpenRemoveAds && (
              <button
                type="button"
                onClick={onOpenRemoveAds}
                className="flex items-center gap-0.5 text-[9.5px] font-bold text-amber-600 hover:text-amber-700 transition px-1.5 py-0.5 rounded hover:bg-amber-50 dark:hover:bg-amber-950/30"
                title="Remove Ads with Premium"
              >
                <Sparkles className="w-2.5 h-2.5" />
                <span>Remove Ads</span>
              </button>
            )}
          </div>
        </div>

        {/* Main Ad Banner Creative Body (Authentic 320x50 style) */}
        <div className="flex items-center justify-between gap-2.5">
          {/* Left: Google "G" Icon + Creative copy */}
          <div className="flex items-center gap-2.5 min-w-0 flex-1">
            {/* Official Google 4-Color "G" Emblem */}
            <div className="w-8 h-8 sm:w-9 sm:h-9 shrink-0 rounded-xl bg-white border border-slate-200/80 shadow-xs flex items-center justify-center p-1.5">
              <svg className="w-full h-full" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                />
                <path
                  fill="#34A853"
                  d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 10.04 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                />
                <path
                  fill="#EA4335"
                  d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                />
              </svg>
            </div>

            {/* Creative Headline & Subtitle */}
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <h4 className="text-[11.5px] sm:text-[12px] font-bold truncate leading-tight">
                  {placement === 'home_bottom' 
                    ? 'Google Play • Pro Sound & Stage Tools'
                    : 'Google AdMob: 320×50 Test Banner'}
                </h4>
              </div>
              <p className={`text-[10px] truncate leading-tight mt-0.5 ${isNightMode ? 'text-slate-400' : 'text-slate-600'}`}>
                {placement === 'home_bottom'
                  ? 'Official test ad creative • googleads.github.io'
                  : 'Nice job! This is an active test ad unit from Google.'}
              </p>
            </div>
          </div>

          {/* Right: Google CTA Action Button */}
          <div className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              onClick={handleTestClick}
              className="bg-[#1A73E8] hover:bg-[#1557B0] active:scale-95 text-white text-[10px] font-bold px-3 py-1.5 rounded-full transition-all shadow-xs flex items-center gap-1"
            >
              <span>VISIT</span>
              <ExternalLink className="w-2.5 h-2.5 opacity-80" />
            </button>
          </div>
        </div>

        {/* Transient Test Click Notification */}
        {clickNotice && (
          <div className="mt-2 py-1 px-2 rounded-lg bg-green-500/10 border border-green-500/30 text-green-600 dark:text-green-400 text-[10px] font-medium flex items-center gap-1.5 animate-fadeIn">
            <Check className="w-3 h-3 shrink-0" />
            <span>Google Test Ad Click recorded (Test Mode Active — Safe from policy strikes)</span>
          </div>
        )}
      </div>

      {/* Google Test Ad Details Modal */}
      {showDetails && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn"
          onClick={() => setShowDetails(false)}
        >
          <div 
            className={`w-full max-w-sm rounded-2xl border p-4 shadow-xl transition-all ${
              isNightMode 
                ? 'bg-[#131B2A] border-[#1E293B] text-white' 
                : 'bg-white border-slate-200 text-slate-900'
            }`}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <span className="bg-[#0F9D58] text-white text-[9px] font-black uppercase px-2 py-0.5 rounded">
                  Google AdMob
                </span>
                <h3 className="text-sm font-bold">Test Ad Information</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowDetails(false)}
                className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="py-3 space-y-2.5 text-xs">
              <p className={isNightMode ? 'text-slate-300' : 'text-slate-600'}>
                This banner is powered by Google AdMob&apos;s standard test credentials. Test ads allow you to test ad loading, formatting, and layout safely without violating Google policy.
              </p>

              {/* Test Ad Unit ID */}
              <div className={`p-2.5 rounded-xl border font-mono text-[10.5px] ${
                isNightMode ? 'bg-slate-900/80 border-slate-800 text-slate-300' : 'bg-slate-50 border-slate-200 text-slate-700'
              }`}>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-sans text-[10px] font-bold uppercase text-slate-400">
                    Banner Test Unit ID
                  </span>
                  <button
                    type="button"
                    onClick={handleCopyTestId}
                    className="flex items-center gap-1 text-[10px] text-blue-500 hover:text-blue-600 font-sans font-semibold"
                  >
                    {copied ? <Check className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3" />}
                    <span>{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <div className="break-all select-all font-semibold text-[#1A73E8]">
                  {ADMOB_TEST_CONFIG.homeBannerId}
                </div>
              </div>

              {/* Reward Ad Test Unit ID */}
              <div className={`p-2.5 rounded-xl border font-mono text-[10.5px] ${
                isNightMode ? 'bg-slate-900/80 border-slate-800 text-slate-300' : 'bg-slate-50 border-slate-200 text-slate-700'
              }`}>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-sans text-[10px] font-bold uppercase text-slate-400">
                    Reward Video Test Unit ID
                  </span>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      navigator.clipboard.writeText(ADMOB_TEST_CONFIG.rewardAdId);
                      setCopied(true);
                      setTimeout(() => setCopied(false), 2000);
                    }}
                    className="flex items-center gap-1 text-[10px] text-amber-500 hover:text-amber-600 font-sans font-semibold"
                  >
                    <Copy className="w-3 h-3" />
                    <span>Copy</span>
                  </button>
                </div>
                <div className="break-all select-all font-semibold text-amber-500">
                  {ADMOB_TEST_CONFIG.rewardAdId}
                </div>
              </div>

              {/* Test App ID */}
              <div className={`p-2.5 rounded-xl border font-mono text-[10.5px] ${
                isNightMode ? 'bg-slate-900/80 border-slate-800 text-slate-300' : 'bg-slate-50 border-slate-200 text-slate-700'
              }`}>
                <span className="block font-sans text-[10px] font-bold uppercase text-slate-400 mb-0.5">
                  AdMob Test App ID
                </span>
                <div className="break-all select-all font-semibold">
                  {ADMOB_TEST_CONFIG.appId}
                </div>
              </div>

              <div className="flex items-start gap-1.5 text-[10.5px] text-amber-500 dark:text-amber-400 bg-amber-500/10 p-2 rounded-xl">
                <Info className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                <span>
                  When publishing to Google Play, replace these test IDs with your real AdMob Ad Unit IDs from the Google AdMob console.
                </span>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex justify-end">
              <button
                type="button"
                onClick={() => setShowDetails(false)}
                className="px-4 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-800 text-xs font-semibold hover:bg-slate-300 dark:hover:bg-slate-700 transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
