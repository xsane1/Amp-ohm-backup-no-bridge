import React, { useState, useEffect } from 'react';
import { adService, ADMOB_TEST_IDS } from '../../services/adService';
import { subscriptionService } from '../../services/subscriptionService';
import { useTheme } from '../../theme/ThemeContext';
import { useLanguage } from '../../localization/LanguageContext';
import { RewardAdModal } from './RewardAdModal';
import { Video, Gift, Clock, Sparkles, CheckCircle2, Copy, Check } from 'lucide-react';

interface CalculatorRewardAdCardProps {
  className?: string;
  variant?: 'full' | 'compact';
}

export const CalculatorRewardAdCard: React.FC<CalculatorRewardAdCardProps> = ({
  className = '',
  variant = 'full',
}) => {
  const { isNightMode } = useTheme();
  const { isHindi } = useLanguage();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [hasPass, setHasPass] = useState(adService.hasActiveRewardPass());
  const [remainingMins, setRemainingMins] = useState(adService.getRewardTimeRemainingMinutes());
  const [copiedId, setCopiedId] = useState(false);
  const isPremium = subscriptionService.isPremium();

  useEffect(() => {
    const unsub = adService.subscribe(() => {
      setHasPass(adService.hasActiveRewardPass());
      setRemainingMins(adService.getRewardTimeRemainingMinutes());
    });

    const interval = setInterval(() => {
      setHasPass(adService.hasActiveRewardPass());
      setRemainingMins(adService.getRewardTimeRemainingMinutes());
    }, 15000);

    return () => {
      unsub();
      clearInterval(interval);
    };
  }, []);

  // Premium subscribers don't see any ads or reward prompts
  if (isPremium) {
    return null;
  }

  const handleCopyTestId = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(ADMOB_TEST_IDS.android.rewarded);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  // State A: Reward Pass is currently ACTIVE (Calculator is unlocked)
  if (hasPass) {
    return (
      <div 
        className={`w-full rounded-2xl p-3 border transition-all flex items-center justify-between gap-2.5 ${
          isNightMode 
            ? 'bg-emerald-950/25 border-emerald-800/40 text-emerald-300' 
            : 'bg-emerald-50/90 border-emerald-200 text-emerald-800 shadow-xs'
        } ${className}`}
      >
        <div className="flex items-center gap-2.5 min-w-0 flex-1">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-500 border border-emerald-500/30 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="text-[11px] font-black uppercase tracking-wider flex items-center gap-1.5 leading-tight">
              <span>{isHindi ? 'कैलकुलेटर अनलॉक है' : 'Calculator Unlocked'}</span>
              <Sparkles className="w-3 h-3 text-amber-400" />
            </div>
            <p className="text-[10px] font-medium opacity-90 truncate leading-tight mt-0.5">
              {isHindi 
                ? `2 घंटे का पास सक्रिय है (${remainingMins} मिनट शेष)` 
                : `2-Hour pass active (${remainingMins}m remaining)`}
            </p>
          </div>
        </div>

        <div className={`px-2.5 py-1 rounded-full text-[10px] font-black shrink-0 flex items-center gap-1 border ${
          isNightMode ? 'bg-emerald-900/40 border-emerald-700/50 text-emerald-200' : 'bg-emerald-100 border-emerald-300 text-emerald-900'
        }`}>
          <Clock className="w-3 h-3" />
          <span>{remainingMins}m</span>
        </div>
      </div>
    );
  }

  // State B: Reward Pass is NOT active — show the invitation to watch Reward Ad and unlock calculator
  if (variant === 'compact') {
    return (
      <>
        <div 
          className={`w-full rounded-2xl p-2.5 sm:p-3 border transition-all flex items-center justify-between gap-2 ${
            isNightMode 
              ? 'bg-gradient-to-r from-amber-950/20 via-slate-900 to-amber-950/10 border-amber-500/30 text-white' 
              : 'bg-gradient-to-r from-amber-50 via-white to-amber-50/50 border-amber-300/80 text-slate-900 shadow-xs'
          } ${className}`}
        >
          <div className="flex items-center gap-2.5 min-w-0 flex-1">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-500 border border-amber-500/40 flex items-center justify-center shrink-0">
              <Gift className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <div className="text-[11px] font-black tracking-tight leading-tight flex items-center gap-1.5">
                <span>{isHindi ? 'रिवॉर्ड ऐड देखें' : 'Watch Reward Ad'}</span>
                <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-600 dark:text-amber-400 uppercase">
                  Free
                </span>
              </div>
              <p className={`text-[10px] font-medium truncate mt-0.5 ${isNightMode ? 'text-slate-400' : 'text-slate-600'}`}>
                {isHindi ? '2 घंटे के लिए कैलकुलेटर अनलॉक करें' : 'Unlock calculator for 2 hours'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsModalOpen(true)}
            className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 text-[10.5px] font-black tracking-wide uppercase transition shadow-xs flex items-center gap-1 shrink-0"
          >
            <Video className="w-3 h-3" />
            <span>{isHindi ? 'देखें' : 'Watch'}</span>
          </button>
        </div>

        <RewardAdModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onRewardClaimed={(minutes) => {
            setHasPass(true);
            setRemainingMins(minutes || 120);
          }}
        />
      </>
    );
  }

  // Full Variant: Standard professional card placed inside calculator views
  return (
    <>
      <div 
        className={`w-full rounded-2xl p-3.5 sm:p-4 border transition-all ${
          isNightMode 
            ? 'bg-gradient-to-br from-[#161f33] via-[#111827] to-[#0f172a] border-amber-500/30 text-white shadow-lg' 
            : 'bg-gradient-to-br from-amber-50/80 via-white to-amber-50/40 border-amber-300 text-slate-900 shadow-xs'
        } ${className}`}
      >
        <div className="flex items-start justify-between gap-3 mb-2.5">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500 to-orange-500 text-slate-950 flex items-center justify-center shrink-0 shadow-xs">
              <Gift className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-[9px] font-black tracking-wider uppercase px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-500 dark:text-amber-400 border border-amber-500/30">
                  AdMob Reward Video
                </span>
                <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 uppercase">
                  2-Hour Pass
                </span>
              </div>
              <h4 className="text-[13px] sm:text-[14px] font-black tracking-tight mt-0.5 leading-snug">
                {isHindi ? 'रिवॉर्ड ऐड देखें • कैलकुलेटर अनलॉक करें' : 'Watch Reward Ad • Unlock Calculator (2 Hours)'}
              </h4>
            </div>
          </div>
        </div>

        <p className={`text-[11px] leading-relaxed mb-3 ${isNightMode ? 'text-slate-300' : 'text-slate-600'}`}>
          {isHindi 
            ? 'सिर्फ एक छोटा सा 15 सेकंड का वीडियो ऐड देखें और अगले 2 घंटे (120 मिनट) के लिए यह कैलकुलेटर अनलॉक करें। (नोट: सभी बैनर ऐड्स हटाने के लिए प्रो सब्सक्रिप्शन लें)'
            : 'Watch a quick 15-second sponsor video to unlock this calculator for 2 hours. (Note: Total ads / banner ads are removed only with Pro subscription).'}
        </p>

        {/* AdMob Test Unit ID Info & Action Buttons */}
        <div className="space-y-2">
          <div className={`p-2 rounded-xl border flex items-center justify-between text-[10px] ${
            isNightMode ? 'bg-slate-900/80 border-slate-800' : 'bg-white/80 border-slate-200'
          }`}>
            <div className="flex items-center gap-1.5 truncate">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse shrink-0" />
              <span className="font-semibold text-slate-400 uppercase tracking-wider text-[9px]">Test Unit:</span>
              <span className="font-mono text-amber-500 dark:text-amber-400 font-bold truncate">
                {ADMOB_TEST_IDS.android.rewarded}
              </span>
            </div>
            <button
              type="button"
              onClick={handleCopyTestId}
              className={`p-1 rounded-md border ml-2 transition flex items-center gap-1 shrink-0 ${
                copiedId
                  ? 'bg-emerald-500 text-white border-emerald-600'
                  : isNightMode
                    ? 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-300'
              }`}
              title="Copy Test Unit ID"
            >
              {copiedId ? <Check className="w-3 h-3 text-white" /> : <Copy className="w-3 h-3" />}
              <span className="text-[8.5px] font-bold">{copiedId ? 'Copied' : 'Copy'}</span>
            </button>
          </div>

          <button
            type="button"
            onClick={() => setIsModalOpen(true)}
            className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 active:scale-98 text-slate-950 font-black text-xs uppercase tracking-wider transition shadow-md flex items-center justify-center gap-2"
          >
            <Video className="w-4 h-4 fill-slate-950" />
            <span>{isHindi ? 'कैलकुलेटर अनलॉक करें (Watch Video)' : 'Unlock Calculator (Watch Video)'}</span>
          </button>
        </div>
      </div>

      <RewardAdModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onRewardClaimed={(minutes) => {
          setHasPass(true);
          setRemainingMins(minutes || 120);
        }}
      />
    </>
  );
};
