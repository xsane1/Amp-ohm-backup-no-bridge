import React, { useState, useEffect } from 'react';
import { adService } from '../../services/adService';
import { subscriptionService } from '../../services/subscriptionService';
import { useTheme } from '../../theme/ThemeContext';
import { useLanguage } from '../../localization/LanguageContext';
import { Gift, Sparkles, Clock, Check } from 'lucide-react';
import { RewardAdModal } from './RewardAdModal';

interface RewardAdButtonProps {
  className?: string;
  variant?: 'banner' | 'pill' | 'button';
}

export const RewardAdButton: React.FC<RewardAdButtonProps> = ({
  className = '',
  variant = 'pill',
}) => {
  const { isNightMode } = useTheme();
  const { isHindi } = useLanguage();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [hasPass, setHasPass] = useState(adService.hasActiveRewardPass());
  const [remainingMins, setRemainingMins] = useState(adService.getRewardTimeRemainingMinutes());
  const isPremium = subscriptionService.isPremium();

  useEffect(() => {
    const unsub = adService.subscribe(() => {
      setHasPass(adService.hasActiveRewardPass());
      setRemainingMins(adService.getRewardTimeRemainingMinutes());
    });

    const interval = setInterval(() => {
      setHasPass(adService.hasActiveRewardPass());
      setRemainingMins(adService.getRewardTimeRemainingMinutes());
    }, 30000);

    return () => {
      unsub();
      clearInterval(interval);
    };
  }, []);

  // Premium subscribers don't need reward ads
  // Also if the user has watched the ad and has an active reward pass, completely hide this reward ad button for 2 hours!
  if (isPremium || hasPass) {
    return null;
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setIsModalOpen(true)}
        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-extrabold tracking-wide uppercase transition-all shadow-xs active:scale-95 ${
          isNightMode
            ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 hover:brightness-110'
            : 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 hover:brightness-105'
        } ${className}`}
        title="Watch a reward video to unlock 2 hours pass"
      >
        <Gift className="w-3 h-3 animate-bounce" />
        <span>{isHindi ? 'कैलकुलेटर अनलॉक करें' : 'Unlock Calculator'}</span>
      </button>

      <RewardAdModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onRewardClaimed={(minutes) => {
          setHasPass(true);
          setRemainingMins(minutes || 120);
        }}
      />
    </>
  );
};
