import React from 'react';
import { ActiveScreen } from '../types';
import { useTheme } from '../theme/ThemeContext';
import { useLanguage } from '../localization/LanguageContext';
import { Home, History, BookOpen } from 'lucide-react';

interface BottomNavProps {
  currentScreen: ActiveScreen;
  onNavigate: (screen: ActiveScreen) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ 
  currentScreen, 
  onNavigate,
}) => {
  const { isNightMode } = useTheme();
  const { isHindi } = useLanguage();

  const isHome = currentScreen === 'home';
  const isHistory = currentScreen === 'history';
  const isGuide = currentScreen === 'guide' || currentScreen === 'more_tools';

  return (
    <nav className={`fixed sm:absolute bottom-0 left-0 right-0 z-40 backdrop-blur-md border-t transition-colors duration-200 ${
      isNightMode 
        ? 'bg-[#06090E]/95 border-slate-800/90 shadow-[0_-4px_24px_rgba(0,0,0,0.7)]' 
        : 'bg-white/90 border-white/80 shadow-[0_-6px_24px_rgba(15,23,42,0.06)]'
    }`}>
      <div className="max-w-md mx-auto px-4 flex items-center justify-around h-16">
        {/* Tab 1: Home */}
        <button
          type="button"
          onClick={() => onNavigate('home')}
          className="flex flex-col items-center justify-center flex-1 h-full py-1 transition active:scale-95 group"
          aria-label="Home"
        >
          <div className="flex flex-col items-center">
            {isHome ? (
              <div className={`w-10 h-8 rounded-xl flex items-center justify-center border ${
                isNightMode
                  ? 'bg-blue-600/30 text-[#38BDF8] border-blue-500/40'
                  : 'bg-blue-50 text-[#1D4ED8] border-blue-200'
              }`}>
                <Home className="w-5 h-5 stroke-[2.4]" />
              </div>
            ) : (
              <Home className={`w-5 h-5 stroke-[2] ${
                isNightMode 
                  ? 'text-blue-300/50 group-hover:text-blue-200' 
                  : 'text-slate-400 group-hover:text-slate-700'
              }`} />
            )}
            <span className={`text-[11px] mt-0.5 tracking-tight ${
              isHome 
                ? (isNightMode ? 'text-[#38BDF8] font-bold' : 'text-[#1D4ED8] font-bold') 
                : (isNightMode ? 'text-blue-300/60 font-medium' : 'text-slate-500 font-medium')
            }`}>
              {isHindi ? 'होम' : 'Home'}
            </span>
          </div>
        </button>

        {/* Tab 2: History */}
        <button
          type="button"
          onClick={() => onNavigate('history')}
          className="flex flex-col items-center justify-center flex-1 h-full py-1 transition active:scale-95 group"
          aria-label="History"
        >
          <div className="flex flex-col items-center">
            {isHistory ? (
              <div className={`w-10 h-8 rounded-xl flex items-center justify-center border ${
                isNightMode
                  ? 'bg-blue-600/30 text-[#38BDF8] border-blue-500/40'
                  : 'bg-blue-50 text-[#1D4ED8] border-blue-200'
              }`}>
                <History className="w-5 h-5 stroke-[2.4]" />
              </div>
            ) : (
              <History className={`w-5 h-5 stroke-[2] ${
                isNightMode 
                  ? 'text-blue-300/50 group-hover:text-blue-200' 
                  : 'text-slate-400 group-hover:text-slate-700'
              }`} />
            )}
            <span className={`text-[11px] mt-0.5 tracking-tight ${
              isHistory 
                ? (isNightMode ? 'text-[#38BDF8] font-bold' : 'text-[#1D4ED8] font-bold') 
                : (isNightMode ? 'text-blue-300/60 font-medium' : 'text-slate-500 font-medium')
            }`}>
              {isHindi ? 'हिस्ट्री' : 'History'}
            </span>
          </div>
        </button>

        {/* Tab 3: Guide */}
        <button
          type="button"
          onClick={() => onNavigate('guide')}
          className="flex flex-col items-center justify-center flex-1 h-full py-1 transition active:scale-95 group"
          aria-label="Guide"
        >
          <div className="flex flex-col items-center">
            {isGuide ? (
              <div className={`w-10 h-8 rounded-xl flex items-center justify-center border ${
                isNightMode
                  ? 'bg-blue-600/30 text-[#38BDF8] border-blue-500/40'
                  : 'bg-blue-50 text-[#1D4ED8] border-blue-200'
              }`}>
                <BookOpen className="w-5 h-5 stroke-[2.4]" />
              </div>
            ) : (
              <BookOpen className={`w-5 h-5 stroke-[2] ${
                isNightMode 
                  ? 'text-blue-300/50 group-hover:text-blue-200' 
                  : 'text-slate-400 group-hover:text-slate-700'
              }`} />
            )}
            <span className={`text-[11px] mt-0.5 tracking-tight ${
              isGuide 
                ? (isNightMode ? 'text-[#38BDF8] font-bold' : 'text-[#1D4ED8] font-bold') 
                : (isNightMode ? 'text-blue-300/60 font-medium' : 'text-slate-500 font-medium')
            }`}>
              {isHindi ? 'गाइड' : 'Guide'}
            </span>
          </div>
        </button>
      </div>
    </nav>
  );
};
