import React, { useState } from 'react';
import { Share2, Check } from 'lucide-react';
import { useLanguage } from '../localization/LanguageContext';
import { useTheme } from '../theme/ThemeContext';

export interface ShareDetailItem {
  label: string;
  value: string;
}

export interface ShareFinalResult {
  label?: string;
  labelEn?: string;
  labelHi?: string;
  value: string;
}

export interface ShareWarning {
  en?: string;
  hi?: string;
  message?: string;
}

interface ShareResultButtonProps {
  // Enhanced Standard Props
  calculatorTitle?: string;
  calculatorTitleEn?: string;
  calculatorTitleHi?: string;
  finalResults?: ShareFinalResult[];
  systemDetails?: string[];
  warning?: ShareWarning | string | null;

  // Fallback / legacy props
  title?: string;
  highlights?: string[];
  details?: string[] | ShareDetailItem[];
  items?: ShareDetailItem[];
  highlightResult?: string;
  className?: string;
}

export const ShareResultButton: React.FC<ShareResultButtonProps> = ({
  calculatorTitle,
  calculatorTitleEn,
  calculatorTitleHi,
  finalResults,
  systemDetails,
  warning,
  title,
  highlights,
  details,
  items,
  highlightResult,
  className = '',
}) => {
  const { isHindi } = useLanguage();
  const { isNightMode } = useTheme();
  const [copied, setCopied] = useState(false);

  const handleShare = async () => {
    // 1. Calculator Title & Top ASCII Border
    const calcTitle =
      calculatorTitle ||
      calculatorTitleEn ||
      (title ? title.replace(/[⚡🔊📏💡✅⚠️🚨]/g, '').trim() : 'Calculation Result');

    let cleanHeaderTitle = calcTitle
      .replace(/Result$/i, '')
      .replace(/Plan$/i, '')
      .trim();

    if (/ohm/i.test(calcTitle)) {
      cleanHeaderTitle = 'OHM & LOAD CALCULATION';
    } else if (/amplifier/i.test(calcTitle)) {
      cleanHeaderTitle = 'AMPLIFIER MATCHING REPORT';
    } else if (/cable/i.test(calcTitle)) {
      cleanHeaderTitle = 'CABLE LOSS CALCULATION';
    } else if (/top speaker/i.test(calcTitle)) {
      cleanHeaderTitle = 'TOP SPEAKER POWER CALCULATION';
    } else if (/dmx/i.test(calcTitle)) {
      cleanHeaderTitle = 'DMX 512 ADDRESS PATCH';
    } else {
      cleanHeaderTitle = cleanHeaderTitle.toUpperCase();
    }

    const lines: string[] = [
      '==============================',
      `AMP OHM - ${cleanHeaderTitle}`,
      '==============================',
    ];

    // 2. System Parameters (Clean English, bulleted)
    const rawDetails: string[] = [];
    if (systemDetails && systemDetails.length > 0) {
      systemDetails.forEach((d) => rawDetails.push(d));
    } else if (highlights && highlights.length > 0) {
      highlights.forEach((h) => rawDetails.push(h));
    } else if (details && details.length > 0) {
      details.forEach((d) => {
        if (typeof d === 'string') {
          rawDetails.push(d);
        } else {
          rawDetails.push(`${d.label}: ${d.value}`);
        }
      });
    } else if (items && items.length > 0) {
      items.forEach((item) => {
        rawDetails.push(`${item.label}: ${item.value}`);
      });
    }

    if (rawDetails.length > 0) {
      lines.push('System Parameters:');
      rawDetails.forEach((d) => {
        const cleanD = d.replace(/\s*\([^)]*[\u0900-\u097F][^)]*\)/g, '').trim();
        lines.push(cleanD.startsWith('•') ? cleanD : `• ${cleanD}`);
      });
      lines.push('');
    }

    // 3. Results & Classification
    if (finalResults && finalResults.length > 0) {
      lines.push('Results & Classification:');
      finalResults.forEach((res) => {
        const lbl = res.label || res.labelEn || 'Result';
        lines.push(`• ${lbl}: ${res.value}`);
      });
      lines.push('');
    } else if (highlightResult) {
      lines.push('Results & Classification:');
      lines.push(`• Final Result: ${highlightResult}`);
      lines.push('');
    }

    // 4. Warning (Clean English)
    if (warning) {
      const warnText = typeof warning === 'string'
        ? warning
        : (warning.en || warning.message || '');
      if (warnText) {
        lines.push(`⚠️ Warning: ${warnText}`);
        lines.push('');
      }
    }

    // 5. Clean Footer & Direct Clickable Links with Closing Border
    lines.push('Calculated with AMP OHM - Developed by AudioXpert');
    lines.push('━━━━━━━━━━━━━━━━━━');
    lines.push('📱 AMP OHM App:');
    lines.push('https://play.google.com/store/apps/details?id=com.ampohm.app');
    lines.push('');
    lines.push('📸 Instagram:');
    lines.push('https://instagram.com/audio_xpert');
    lines.push('');
    lines.push('▶️ YouTube:');
    lines.push('https://youtube.com/@audioxpertt');
    lines.push('==============================');

    const fullShareText = lines.join('\n');
    const shareSubject = calcTitle;

    if (typeof navigator !== 'undefined' && navigator.share) {
      try {
        await navigator.share({
          title: `AMP OHM - ${shareSubject.replace(/[^\w\s-]/g, '').trim()}`,
          text: fullShareText,
        });
        setCopied(true);
        setTimeout(() => setCopied(false), 2500);
        return;
      } catch (err: any) {
        if (err?.name === 'AbortError') {
          return;
        }
      }
    }

    // Fallback: Copy to clipboard
    try {
      if (typeof navigator !== 'undefined' && navigator.clipboard) {
        await navigator.clipboard.writeText(fullShareText);
        setCopied(true);
        setTimeout(() => setCopied(false), 2500);
      }
    } catch (e) {
      console.error('Failed to copy to clipboard', e);
    }
  };

  return (
    <button
      type="button"
      id="btn-share-result"
      onClick={handleShare}
      className={`w-full py-3.5 px-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2.5 transition shadow-xs active:scale-98 relative overflow-hidden ${
        copied
          ? 'bg-emerald-600 text-white border border-emerald-500 shadow-sm'
          : isNightMode
            ? 'bg-blue-950/70 hover:bg-blue-900/80 text-blue-300 border border-blue-800/80 hover:border-blue-600'
            : 'bg-blue-50 hover:bg-blue-100 text-[#1D4ED8] border border-blue-200 hover:border-blue-300'
      } ${className}`}
    >
      {copied ? (
        <>
          <Check className="w-4 h-4 text-white stroke-[2.5]" />
          <span>{isHindi ? 'परिणाम कॉपी हुआ! (Result Copied)' : 'Result Copied!'}</span>
        </>
      ) : (
        <>
          <Share2 className="w-4 h-4 text-current stroke-[2.2]" />
          <span>{isHindi ? 'परिणाम शेयर करें (Share Result)' : 'Share Result'}</span>
        </>
      )}
    </button>
  );
};
