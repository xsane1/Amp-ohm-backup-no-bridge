import React, { useState, useEffect } from 'react';
import { useLanguage } from '../../localization/LanguageContext';
import { useTheme } from '../../theme/ThemeContext';
import { adService } from '../../services/adService';
import { 
  Play, 
  Sparkles, 
  Crown, 
  X, 
  Layers,
  ArrowRight, 
  ChevronLeft,
  ArrowLeft,
  Video,
  AlertTriangle,
  RotateCcw
} from 'lucide-react';

interface CalculatorUnlockModalProps {
  isOpen: boolean;
  calculatorTitle: string;
  onClose: () => void;
  onUnlocked: () => void;
  onOpenSubscription: () => void;
}

type ModalViewMode = 'choice' | 'ad_playing' | 'ad_dismissed' | 'ad_failed';

export const CalculatorUnlockModal: React.FC<CalculatorUnlockModalProps> = ({
  isOpen,
  calculatorTitle,
  onClose,
  onUnlocked,
  onOpenSubscription,
}) => {
  const { t, isHindi } = useLanguage();
  const { isNightMode } = useTheme();

  const [viewMode, setViewMode] = useState<ModalViewMode>('choice');
  const [countdown, setCountdown] = useState(15);

  // Reset modal state whenever it is opened
  useEffect(() => {
    if (isOpen) {
      setViewMode('choice');
      setCountdown(15);
    }
  }, [isOpen]);

  // Hardware Back Button / PopState listener on mobile
  useEffect(() => {
    if (!isOpen) return;

    window.history.pushState({ modal: 'calculator_unlock' }, '');

    const handlePopState = () => {
      if (viewMode === 'ad_playing') {
        // User dismissed ad using Android back button before earning reward
        setViewMode('ad_dismissed');
      } else {
        onClose();
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (viewMode === 'ad_playing') {
          setViewMode('ad_dismissed');
        } else {
          onClose();
        }
      }
    };

    window.addEventListener('popstate', handlePopState);
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('popstate', handlePopState);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, viewMode, onClose]);

  // Rewarded ad countdown timer for simulated / web preview
  useEffect(() => {
    let interval: ReturnType<typeof setInterval> | null = null;
    if (viewMode === 'ad_playing' && countdown > 0) {
      interval = setInterval(() => {
        setCountdown((c) => c - 1);
      }, 1000);
    } else if (viewMode === 'ad_playing' && countdown === 0) {
      // Reward earned successfully after complete watch
      adService.grantRewardPass(60);
      onUnlocked();
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [viewMode, countdown, onUnlocked]);

  if (!isOpen) return null;

  // Option 1: Start Rewarded Ad
  const handleStartWatch = () => {
    // Check if real native AdMob bridge is available in Android / Flutter wrapper
    const win = window as any;
    if (win.flutter_inappwebview && win.flutter_inappwebview.callHandler) {
      win.flutter_inappwebview.callHandler('showRewardedAd')
        .then((rewardGranted: boolean) => {
          if (rewardGranted) {
            adService.grantRewardPass(60);
            onUnlocked();
          } else {
            setViewMode('ad_dismissed');
          }
        })
        .catch(() => {
          setViewMode('ad_failed');
        });
      return;
    }

    // Default high-fidelity simulated AdMob player
    setViewMode('ad_playing');
    setCountdown(15);
  };

  // Option 2: Open Subscription Paywall
  const handleBuySubscriptionClick = () => {
    onClose();
    onOpenSubscription();
  };

  // Dismiss early while ad is playing
  const handleDismissAdEarly = () => {
    setViewMode('ad_dismissed');
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-200"
      onClick={viewMode !== 'ad_playing' ? onClose : undefined}
    >
      <div 
        className={`w-full max-w-sm rounded-[28px] p-5 shadow-2xl border transition-all max-h-[92vh] overflow-y-auto my-auto ${
          isNightMode ? 'bg-[#0F172A] border-slate-700/80 text-white' : 'bg-white border-slate-200 text-slate-900 shadow-xl'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header with Circular Back Button */}
        <div className="flex items-center justify-between pb-3.5 border-b border-slate-500/20">
          <div className="flex items-center gap-2.5 min-w-0">
            {viewMode !== 'ad_playing' && (
              <button
                type="button"
                id="btn-unlock-modal-back"
                onClick={onClose}
                className={`w-8 h-8 rounded-full flex items-center justify-center transition active:scale-95 border shrink-0 ${
                  isNightMode
                    ? 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                }`}
                aria-label="Back"
              >
                <ChevronLeft className="w-4.5 h-4.5 stroke-[2.5]" />
              </button>
            )}

            <div className="p-1.5 bg-blue-600/15 rounded-xl text-blue-500 shrink-0">
              <Layers className="w-4 h-4" />
            </div>

            <div className="min-w-0">
              <h3 className="text-sm font-black tracking-tight leading-tight truncate">
                {t.calcChoiceTitle}
              </h3>
              <p className="text-[11px] text-blue-500 font-bold truncate max-w-[170px]">
                {calculatorTitle}
              </p>
            </div>
          </div>

          {/* Close button */}
          {viewMode !== 'ad_playing' ? (
            <button
              type="button"
              id="btn-close-unlock-modal"
              onClick={onClose}
              className={`p-1.5 rounded-xl transition ${
                isNightMode 
                  ? 'text-slate-400 hover:text-white hover:bg-slate-800' 
                  : 'text-slate-500 hover:text-slate-900 hover:bg-slate-100'
              }`}
              aria-label="Close"
            >
              <X className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={handleDismissAdEarly}
              className={`text-[10px] font-bold p-1 rounded-lg transition border ${
                isNightMode 
                  ? 'bg-slate-800 text-slate-300 hover:text-white border-slate-700' 
                  : 'bg-slate-100 text-slate-600 hover:text-slate-900 border-slate-300'
              }`}
              title="Close Ad"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* ========================================================= */}
        {/* STATE 1: CHOICE SELECTION (WATCH AD vs GET SUBSCRIPTION)   */}
        {/* ========================================================= */}
        {viewMode === 'choice' && (
          <div className="py-4 space-y-3.5">
            <p className={`text-xs leading-relaxed text-center px-1 font-medium ${
              isNightMode ? 'text-slate-300' : 'text-slate-600'
            }`}>
              {t.calcChoiceSubtitle}
            </p>

            {/* OPTION 1: WATCH AD */}
            <div className="space-y-1">
              <button
                type="button"
                id="btn-choice-watch-ad"
                onClick={handleStartWatch}
                className="w-full p-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs shadow-md active:scale-98 transition flex items-center justify-between group border border-amber-400/40"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-8 h-8 rounded-xl bg-slate-950 text-amber-400 flex items-center justify-center shrink-0 shadow-xs">
                    <Play className="w-4 h-4 fill-amber-400 ml-0.5" />
                  </div>
                  <div className="text-left min-w-0">
                    <div className="text-xs font-black leading-tight text-slate-950">
                      {t.calcChoiceWatchAdBtn}
                    </div>
                    <div className="text-[10px] font-semibold text-slate-900/85 mt-0.5 max-w-[195px] leading-tight">
                      {t.calcChoiceWatchAdDesc}
                    </div>
                  </div>
                </div>
                <span className="text-[10px] uppercase font-black px-2 py-0.5 rounded-full bg-slate-950/20 text-slate-950 shrink-0 ml-1">
                  {t.calcChoiceFreeBadge}
                </span>
              </button>
            </div>

            {/* Divider */}
            <div className="flex items-center gap-3 py-0.5">
              <div className={`flex-1 h-px ${isNightMode ? 'bg-slate-700/80' : 'bg-slate-200'}`} />
              <span className={`text-[10px] font-bold uppercase tracking-wider ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                {t.calcChoiceOr}
              </span>
              <div className={`flex-1 h-px ${isNightMode ? 'bg-slate-700/80' : 'bg-slate-200'}`} />
            </div>

            {/* OPTION 2: GET SUBSCRIPTION */}
            <button
              type="button"
              id="btn-choice-get-subscription"
              onClick={handleBuySubscriptionClick}
              className="w-full p-3.5 rounded-2xl bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 hover:from-blue-600 hover:to-indigo-700 text-white font-black text-xs shadow-md active:scale-98 transition flex items-center justify-between group border border-blue-500/30"
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-8 h-8 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center shrink-0 shadow-xs">
                  <Crown className="w-4 h-4 fill-slate-950" />
                </div>
                <div className="text-left min-w-0">
                  <div className="text-xs font-black leading-tight flex items-center gap-1.5">
                    <span>{t.calcChoiceGetSubBtn}</span>
                    <Sparkles className="w-3 h-3 text-amber-300" />
                  </div>
                  <div className="text-[10px] font-medium text-blue-100 mt-0.5 max-w-[195px] leading-tight">
                    {t.calcChoiceGetSubDesc}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-1 shrink-0 ml-1">
                <span className="text-[9.5px] uppercase font-bold px-1.5 py-0.5 rounded-full bg-white/20 text-white">
                  {t.calcChoiceProBadge}
                </span>
                <ArrowRight className="w-3.5 h-3.5 text-amber-300 group-hover:translate-x-0.5 transition" />
              </div>
            </button>

            {/* Cancel Action Button */}
            <button
              type="button"
              id="btn-choice-cancel"
              onClick={onClose}
              className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold transition active:scale-98 flex items-center justify-center gap-1.5 border mt-1 ${
                isNightMode
                  ? 'bg-slate-800/80 hover:bg-slate-800 text-slate-200 border-slate-700/70'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
              }`}
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>{t.calcChoiceCancel}</span>
            </button>
          </div>
        )}

        {/* ========================================================= */}
        {/* STATE 2: AD PLAYING                                       */}
        {/* ========================================================= */}
        {viewMode === 'ad_playing' && (
          <div className="py-4 text-center space-y-4 animate-in fade-in">
            {/* Header */}
            <div className={`flex items-center justify-center gap-1.5 text-[11px] font-bold ${
              isNightMode ? 'text-slate-300' : 'text-slate-700'
            }`}>
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
              <span>{t.calcAdSponsorHeader}</span>
            </div>

            {/* Video Player Graphic & Countdown */}
            <div className="relative w-28 h-28 mx-auto rounded-3xl bg-gradient-to-br from-blue-900 via-indigo-900 to-slate-950 flex flex-col items-center justify-center border border-blue-500/30 shadow-lg overflow-hidden">
              <div className="absolute inset-0 bg-blue-500/10 animate-pulse" />
              <Video className="w-6 h-6 text-amber-400 mb-1" />
              <span className="text-3xl font-black text-amber-400 tracking-tighter">
                {countdown}s
              </span>
              <span className="text-[9px] text-blue-200 uppercase font-extrabold tracking-wider mt-0.5">
                {isHindi ? 'रिवॉर्ड ऐड' : 'Rewarded Video'}
              </span>
            </div>

            <div>
              <h4 className={`text-sm font-black ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                {t.calcAdPlayingTitle}
              </h4>
              <p className={`text-xs mt-1 leading-relaxed ${isNightMode ? 'text-slate-400' : 'text-slate-600'}`}>
                {t.calcAdPlayingDesc}
              </p>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-slate-200 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
              <div 
                className="bg-amber-500 h-full transition-all duration-1000 ease-linear rounded-full shadow-xs"
                style={{ width: `${((15 - countdown) / 15) * 100}%` }}
              />
            </div>

            <p className="text-[10.5px] text-slate-400 font-medium">
              {t.calcAdPleaseWait}
            </p>
          </div>
        )}

        {/* ========================================================= */}
        {/* STATE 3: AD DISMISSED EARLY (Reward NOT earned)           */}
        {/* ========================================================= */}
        {viewMode === 'ad_dismissed' && (
          <div className="py-4 space-y-4 text-center animate-in zoom-in-95">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-500/15 text-amber-500 border border-amber-500/30 flex items-center justify-center shadow-xs">
              <AlertTriangle className="w-7 h-7" />
            </div>

            <div>
              <h4 className={`text-sm font-black ${isNightMode ? 'text-amber-400' : 'text-amber-600'}`}>
                {t.calcAdDismissedTitle}
              </h4>
              <p className={`text-xs mt-1.5 leading-relaxed ${isNightMode ? 'text-slate-300' : 'text-slate-600'}`}>
                {t.calcAdDismissedDesc}
              </p>
            </div>

            <div className="space-y-2 pt-2">
              <button
                type="button"
                id="btn-retry-watch-ad"
                onClick={handleStartWatch}
                className="w-full py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-black text-xs transition shadow-md flex items-center justify-center gap-2 border border-amber-400/40"
              >
                <RotateCcw className="w-4 h-4" />
                <span>{t.calcAdRetryBtn}</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold transition border ${
                  isNightMode ? 'text-slate-300 hover:text-white border-slate-700/60 bg-slate-800/40' : 'text-slate-600 hover:text-slate-900 border-slate-200 bg-slate-50'
                }`}
              >
                {t.calcAdCloseBtn}
              </button>
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* STATE 4: AD FAILED (Network or Load Error)                */}
        {/* ========================================================= */}
        {viewMode === 'ad_failed' && (
          <div className="py-4 space-y-4 text-center animate-in zoom-in-95">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-red-500/15 text-red-500 border border-red-500/30 flex items-center justify-center shadow-xs">
              <AlertTriangle className="w-7 h-7" />
            </div>

            <div>
              <h4 className={`text-sm font-black ${isNightMode ? 'text-red-400' : 'text-red-600'}`}>
                {t.calcAdFailedTitle}
              </h4>
              <p className={`text-xs mt-1.5 leading-relaxed ${isNightMode ? 'text-slate-300' : 'text-slate-600'}`}>
                {t.calcAdFailedDesc}
              </p>
            </div>

            <div className="space-y-2 pt-2">
              <button
                type="button"
                id="btn-retry-failed-ad"
                onClick={handleStartWatch}
                className="w-full py-3 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-black text-xs transition shadow-md flex items-center justify-center gap-2 border border-amber-400/40"
              >
                <RotateCcw className="w-4 h-4" />
                <span>{t.calcAdRetryBtn}</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold transition border ${
                  isNightMode ? 'text-slate-300 hover:text-white border-slate-700/60 bg-slate-800/40' : 'text-slate-600 hover:text-slate-900 border-slate-200 bg-slate-50'
                }`}
              >
                {t.calcAdCloseBtn}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
