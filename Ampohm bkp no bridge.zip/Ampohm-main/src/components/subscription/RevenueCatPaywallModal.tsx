import React, { useState, useEffect } from 'react';
import { subscriptionService, SubscriptionTier } from '../../services/subscriptionService';
import { analyticsService } from '../../services/analyticsService';
import { useLanguage } from '../../localization/LanguageContext';
import { useTheme } from '../../theme/ThemeContext';
import { 
  Check, 
  Sparkles, 
  ShieldCheck, 
  X, 
  RotateCcw,
  Zap,
  Layers,
  Database,
  FileText,
  Radio,
  Share2,
  History,
  Crown,
  ChevronLeft,
  ArrowLeft
} from 'lucide-react';

interface RevenueCatPaywallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RevenueCatPaywallModal: React.FC<RevenueCatPaywallModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { isHindi } = useLanguage();
  const { isNightMode } = useTheme();
  const [selectedTier, setSelectedTier] = useState<SubscriptionTier>('yearly');
  const [currentTier, setCurrentTier] = useState<SubscriptionTier>(subscriptionService.getCurrentTier());
  const [isLoading, setIsLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  // Connect to Android / Mobile Hardware Back Button & Browser History Back
  useEffect(() => {
    if (!isOpen) return;

    // Push a history state entry so Android hardware back button closes this modal instead of leaving the app
    window.history.pushState({ modal: 'paywall' }, '');

    const handlePopState = () => {
      onClose();
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('popstate', handlePopState);
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('popstate', handlePopState);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const packages = subscriptionService.getAvailablePackages();
  const isPremium = currentTier !== 'free';

  const handlePurchase = async (tier: SubscriptionTier) => {
    setIsLoading(true);
    setStatusMessage(null);
    try {
      await subscriptionService.purchaseTier(tier);
      setCurrentTier(tier);
      analyticsService.logCalculationCompleted('ohm_calculator', { purchase_tier: tier });
      setStatusMessage(isHindi ? 'प्रो सब्सक्रिप्शन सफलतापूर्वक अनलॉक हो गया!' : 'Pro entitlement successfully unlocked!');
    } catch (_) {
      setStatusMessage(isHindi ? 'लेन-देन पूरा नहीं हो सका। कृपया पुनः प्रयास करें।' : 'Unable to complete transaction. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRestore = async () => {
    setIsLoading(true);
    setStatusMessage(null);
    try {
      await subscriptionService.restorePurchases();
      setCurrentTier(subscriptionService.getCurrentTier());
      setStatusMessage(isHindi ? 'Google Play खाते से खरीदारी बहाल कर दी गई है।' : 'Purchases successfully restored from Google Play account.');
    } catch (_) {
      setStatusMessage(isHindi ? 'कोई पूर्व सक्रिय खरीदारी नहीं मिली।' : 'No previous active purchases found.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    subscriptionService.resetToFree();
    setCurrentTier('free');
    setStatusMessage(isHindi ? 'परीक्षण के लिए फ्री टियर पर वापस कर दिया गया।' : 'Reverted to Free tier for testing.');
  };

  const features = [
    { 
      icon: <Zap className="w-4 h-4 text-amber-500" />, 
      title: isHindi ? '100% ऐड-फ्री अनुभव' : '100% Ad-Free Operation', 
      desc: isHindi ? 'बिना किसी बैनर, पॉपअप या वीडियो ऐड के तुरंत गणना करें' : 'No banners, reward ads, or interruptions on any screen' 
    },
    { 
      icon: <Sparkles className="w-4 h-4 text-emerald-500" />, 
      title: isHindi ? 'सभी एडवांस्ड कैलकुलेटर्स अनलॉक' : 'Unlimited Calculators Access', 
      desc: isHindi ? 'Cable Loss, Ohm, Amp Match और DMX टूल्स का असीमित उपयोग' : 'Full uninterrupted access to Cable Loss, Ohm, Amp Matching & DMX' 
    },
    { 
      icon: <Database className="w-4 h-4 text-blue-500" />, 
      title: isHindi ? 'प्रो स्टेज प्रीसेट और वेन्यू लाइब्रेरी' : 'Pro Stage Presets & Venue Library', 
      desc: isHindi ? 'अपने बड़े टूरिंग वेन्यू, बैंड रिग और लाइटिंग पैच प्रीसेट सुरक्षित रखें' : 'Store custom touring rig presets, festival venue loads & DMX patches' 
    },
    { 
      icon: <Layers className="w-4 h-4 text-indigo-500" />, 
      title: isHindi ? 'एडवांस्ड कैलकुलेटर्स और टूल्स' : 'Advanced Stage Calculators', 
      desc: isHindi ? 'कार्डियोइड सब डिले, बॉक्स डिजाइन और फुल लाइन ऐरे सपोर्ट' : 'Cardioid sub delay, box design & line array alignment' 
    },
  ];

  return (
    <div 
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 overflow-y-auto"
      onClick={onClose}
    >
      <div 
        className={`rounded-3xl max-w-md w-full max-h-[90vh] flex flex-col shadow-2xl border transition-colors duration-200 animate-in fade-in zoom-in-95 duration-200 my-auto overflow-hidden ${
          isNightMode ? 'bg-[#0E1526] border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header with App matching Circular Back Button */}
        <div className={`px-5 py-3.5 border-b shrink-0 flex items-center justify-between sticky top-0 z-10 backdrop-blur-md ${
          isNightMode ? 'bg-[#0E1526]/95 border-slate-800' : 'bg-white/95 border-slate-100'
        }`}>
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              id="btn-paywall-header-back"
              onClick={onClose}
              className={`w-9 h-9 rounded-full flex items-center justify-center transition active:scale-95 border ${
                isNightMode
                  ? 'bg-slate-800/80 hover:bg-slate-700 text-slate-200 border-slate-700 shadow-sm'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200 shadow-xs'
              }`}
              aria-label="Back"
            >
              <ChevronLeft className="w-5 h-5 stroke-[2.5]" />
            </button>

            <div>
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-lg overflow-hidden shadow-xs flex items-center justify-center shrink-0">
                  <img src="/app-logo.png" alt="AMP OHM Logo" className="w-full h-full object-contain" />
                </div>
                <h3 className={`text-base font-extrabold tracking-tight ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                  AMP OHM Pro
                </h3>
              </div>
              <p className={`text-[11px] mt-0.5 ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                {isHindi ? 'सभी एडवांस्ड फीचर्स और 100% ऐड-फ्री एक्सेस' : 'All Advanced Calculators & 100% Ad-Free Experience'}
              </p>
            </div>
          </div>

          <button
            type="button"
            id="btn-paywall-header-close"
            onClick={onClose}
            className={`p-2 rounded-xl transition ${
              isNightMode ? 'text-slate-400 hover:text-white hover:bg-slate-800' : 'text-slate-400 hover:text-slate-700 hover:bg-slate-100'
            }`}
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content Body */}
        <div className="overflow-y-auto px-5 py-4 space-y-4 flex-1 overscroll-contain">
          {/* Pro Hero Card with App Logo */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-700 via-blue-600 to-indigo-700 text-white flex flex-col items-center text-center shadow-md relative overflow-hidden">
            <div className="w-14 h-14 rounded-2xl overflow-hidden shadow-md mb-2.5 flex items-center justify-center">
              <img src="/app-logo.png" alt="AMP OHM Logo" className="w-full h-full object-contain" />
            </div>
            <h4 className={`text-base tracking-tight ${isHindi ? 'font-bold' : 'font-black'}`}>
              {isHindi ? 'AMP OHM Pro मेंबरशिप' : 'AMP OHM Pro Membership'}
            </h4>
            <p className="text-[11.5px] text-blue-100 font-medium mt-0.5">
              {isHindi ? '100% ऐड-फ्री • सभी ऑडियो टूल्स अनलॉक' : '100% Ad-Free • All Professional Audio Tools Unlocked'}
            </p>
          </div>

          {/* Current status banner */}
        {isPremium && (
          <div className={`my-3 p-3 rounded-xl flex items-center justify-between text-xs border ${
            isNightMode 
              ? 'bg-emerald-950/40 border-emerald-800/60 text-emerald-300' 
              : 'bg-emerald-50 border-emerald-200 text-emerald-900'
          }`}>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-500 shrink-0" />
              <div>
                <span className="font-bold">{isHindi ? 'सक्रिय सब्सक्रिप्शन: ' : 'Active Entitlement: '}</span>
                <span className="capitalize font-mono font-bold text-emerald-400">{currentTier} Plan</span>
              </div>
            </div>
            <button
              type="button"
              onClick={handleReset}
              className="text-[10px] text-slate-400 hover:text-red-400 underline font-medium"
            >
              Reset to Free
            </button>
          </div>
        )}

        {statusMessage && (
          <div className="my-2 p-2.5 bg-blue-500/15 border border-blue-500/30 rounded-xl text-xs text-blue-400 font-medium">
            {statusMessage}
          </div>
        )}

        {/* Feature List */}
        <div className={`my-4 space-y-2.5 p-3.5 rounded-2xl border ${
          isNightMode ? 'bg-slate-900/60 border-slate-800' : 'bg-slate-50 border-slate-100'
        }`}>
          <div className={`text-[11px] font-bold uppercase tracking-wider mb-1 ${
            isNightMode ? 'text-slate-400' : 'text-slate-500'
          }`}>
            {isHindi ? 'प्रो सब्सक्रिप्शन के विशेष फायदे' : 'Included in Pro Upgrade'}
          </div>
          {features.map((feat, i) => (
            <div key={i} className="flex items-start gap-2.5">
              <div className="mt-0.5 shrink-0">{feat.icon}</div>
              <div>
                <div className={`text-xs font-bold ${isNightMode ? 'text-slate-100' : 'text-slate-800'}`}>
                  {feat.title}
                </div>
                <div className={`text-[10px] leading-snug ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                  {feat.desc}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Subscription Tier Selection */}
        <div className="space-y-2 mb-5">
          <div className={`text-[11px] font-bold uppercase tracking-wider ${
            isNightMode ? 'text-slate-400' : 'text-slate-500'
          }`}>
            {isHindi ? 'सब्सक्रिप्शन प्लान चुनें' : 'Select Subscription Plan'}
          </div>

          <div className="grid grid-cols-1 gap-2">
            {packages.map((pkg) => {
              const isSelected = selectedTier === pkg.id;
              const isCurrent = currentTier === pkg.id;

              return (
                <div
                  key={pkg.id}
                  onClick={() => setSelectedTier(pkg.id)}
                  className={`relative p-3 rounded-2xl border-2 cursor-pointer transition flex items-center justify-between ${
                    isSelected 
                      ? isNightMode 
                        ? 'border-blue-500 bg-blue-950/40 shadow-xs' 
                        : 'border-blue-900 bg-blue-50/60 shadow-xs' 
                      : isNightMode
                        ? 'border-slate-800 bg-slate-900/40 hover:border-slate-700'
                        : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  {pkg.badge && (
                    <span className="absolute -top-2.5 right-4 px-2 py-0.5 bg-amber-400 text-slate-950 font-extrabold text-[9px] rounded-full uppercase tracking-wider shadow-xs">
                      {pkg.badge}
                    </span>
                  )}

                  <div className="flex items-center gap-3">
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                      isSelected 
                        ? 'border-blue-500 bg-blue-600 text-white' 
                        : isNightMode ? 'border-slate-700' : 'border-slate-300'
                    }`}>
                      {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                    </div>
                    <div>
                      <div className={`text-xs font-bold flex items-center gap-2 ${
                        isNightMode ? 'text-white' : 'text-slate-900'
                      }`}>
                        <span>{pkg.title}</span>
                        {isCurrent && (
                          <span className="text-[9px] font-bold text-emerald-400 bg-emerald-500/20 px-1.5 py-0.5 rounded">
                            Active
                          </span>
                        )}
                      </div>
                      <div className={`text-[10px] ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                        {pkg.description}
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className={`text-sm font-extrabold ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                      {pkg.price}
                    </div>
                    <div className={`text-[10px] ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                      {pkg.period}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        </div>

        {/* Fixed / Sticky Bottom Actions Bar */}
        <div className={`px-5 py-3.5 border-t shrink-0 space-y-2 backdrop-blur-md ${
          isNightMode ? 'bg-[#0E1526]/95 border-slate-800' : 'bg-white/95 border-slate-100'
        }`}>
          <button
            type="button"
            disabled={isLoading}
            onClick={() => handlePurchase(selectedTier)}
            className={`w-full py-3.5 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white rounded-xl text-xs transition shadow-md flex items-center justify-center gap-2 disabled:opacity-50 ${
              isHindi ? 'font-bold' : 'font-extrabold'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>
              {isPremium 
                ? (isHindi ? `${selectedTier.toUpperCase()} में बदलें` : `Switch to ${selectedTier.toUpperCase()}`) 
                : (isHindi ? 'प्रो सब्सक्रिप्शन में अपग्रेड करें' : 'Upgrade to Pro')}
            </span>
          </button>

          <div className="flex items-center justify-between pt-0.5">
            <button
              type="button"
              disabled={isLoading}
              onClick={handleRestore}
              className={`text-[11px] font-semibold transition flex items-center gap-1 ${
                isNightMode ? 'text-slate-400 hover:text-slate-200' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <RotateCcw className="w-3 h-3" />
              <span>{isHindi ? 'खरीदारी रीस्टोर करें' : 'Restore Purchases'}</span>
            </button>

            <span className="text-[10px] text-slate-400">Google Play Subscriptions</span>
          </div>

          {/* Explicit Back / Close Button at bottom */}
          <button
            type="button"
            id="btn-paywall-bottom-back"
            onClick={onClose}
            className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold transition active:scale-98 flex items-center justify-center gap-1.5 border ${
              isNightMode
                ? 'bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-700/60'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
            }`}
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>{isHindi ? 'वापस जाएं (Back)' : 'Go Back'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
