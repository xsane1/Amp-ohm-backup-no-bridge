import React from 'react';
import { ActiveScreen } from '../types';
import { 
  Zap, 
  Cpu, 
  Speaker, 
  Activity, 
  Binary, 
  ChevronRight 
} from 'lucide-react';

interface CalculatorCardProps {
  id: ActiveScreen;
  title: string;
  description: string;
  category: 'audio' | 'lighting';
  badge?: string;
  onClick: (id: ActiveScreen) => void;
}

export const CalculatorCard: React.FC<CalculatorCardProps> = ({
  id,
  title,
  description,
  category,
  badge,
  onClick,
}) => {
  const getIcon = () => {
    switch (id) {
      case 'calc_ohm':
        return <Zap className="w-5 h-5 text-amber-400" />;
      case 'calc_amp':
        return <Cpu className="w-5 h-5 text-amber-400" />;
      case 'calc_cable_loss':
        return <Activity className="w-5 h-5 text-amber-400" />;
      case 'calc_dmx':
        return <Binary className="w-5 h-5 text-amber-400" />;
      default:
        return <Zap className="w-5 h-5 text-amber-400" />;
    }
  };

  const renderBlueprintWireframe = () => {
    switch (id) {
      case 'calc_ohm':
        // Speaker driver / voice coil technical wireframe
        return (
          <svg className="w-28 h-28 stroke-current" viewBox="0 0 100 100" fill="none" strokeWidth="1.2">
            {/* Outer chassis frame */}
            <circle cx="50" cy="50" r="44" strokeDasharray="3 2" />
            <circle cx="50" cy="50" r="38" />
            {/* Basket spoke ribs */}
            <line x1="50" y1="6" x2="50" y2="24" />
            <line x1="50" y1="76" x2="50" y2="94" />
            <line x1="6" y1="50" x2="24" y2="50" />
            <line x1="76" y1="50" x2="94" y2="50" />
            <line x1="18" y1="18" x2="32" y2="32" />
            <line x1="68" y1="68" x2="82" y2="82" />
            <line x1="18" y1="82" x2="32" y2="68" />
            <line x1="68" y1="32" x2="82" y2="18" />
            {/* Cone & Dust cap */}
            <circle cx="50" cy="50" r="24" />
            <circle cx="50" cy="50" r="14" />
            <circle cx="50" cy="50" r="7" strokeDasharray="2 1" />
          </svg>
        );

      case 'calc_amp':
        // 19" Rack-mount amplifier chassis wireframe
        return (
          <svg className="w-28 h-28 stroke-current" viewBox="0 0 100 100" fill="none" strokeWidth="1.2">
            {/* Chassis Outline */}
            <rect x="10" y="24" width="80" height="52" rx="2" />
            {/* Rack Ears & Mount Holes */}
            <line x1="18" y1="24" x2="18" y2="76" />
            <line x1="82" y1="24" x2="82" y2="76" />
            <circle cx="14" cy="32" r="2" />
            <circle cx="14" cy="68" r="2" />
            <circle cx="86" cy="32" r="2" />
            <circle cx="86" cy="68" r="2" />
            {/* Ventilation Fins */}
            <line x1="36" y1="30" x2="64" y2="30" />
            <line x1="36" y1="34" x2="64" y2="34" />
            <line x1="36" y1="38" x2="64" y2="38" />
            {/* Knobs / Attenuators */}
            <circle cx="34" cy="56" r="8" />
            <line x1="34" y1="48" x2="34" y2="52" />
            <circle cx="66" cy="56" r="8" />
            <line x1="66" y1="48" x2="66" y2="52" />
            {/* VU Meter Bars */}
            <rect x="45" y="48" width="10" height="3" />
            <rect x="45" y="54" width="10" height="3" />
            <rect x="45" y="60" width="10" height="3" />
          </svg>
        );


      case 'calc_cable_loss':
        // Cable Multi-conductor cross-section & wire bundle wireframe
        return (
          <svg className="w-28 h-28 stroke-current" viewBox="0 0 100 100" fill="none" strokeWidth="1.2">
            {/* Twisted pair / cable flow lines */}
            <path d="M10,20 Q30,40 50,20 T90,20" strokeDasharray="3 2" />
            <path d="M10,28 Q30,48 50,28 T90,28" />
            {/* Cutaway Cross Section */}
            <circle cx="50" cy="60" r="26" />
            <circle cx="50" cy="60" r="22" strokeDasharray="2 2" />
            {/* Inner Conductors (+ / -) */}
            <circle cx="41" cy="60" r="7" />
            <circle cx="59" cy="60" r="7" />
            <circle cx="41" cy="60" r="2.5" fill="currentColor" fillOpacity="0.3" />
            <circle cx="59" cy="60" r="2.5" fill="currentColor" fillOpacity="0.3" />
          </svg>
        );

      case 'calc_dmx':
        // DMX Moving Head / Lighting Fixture wireframe
        return (
          <svg className="w-28 h-28 stroke-current" viewBox="0 0 100 100" fill="none" strokeWidth="1.2">
            {/* Fixture Base */}
            <rect x="22" y="72" width="56" height="18" rx="2" />
            <rect x="30" y="77" width="16" height="7" strokeDasharray="2 1" />
            <circle cx="68" cy="80.5" r="2.5" />
            {/* Yoke Arms */}
            <path d="M28,72 L28,44 Q28,40 32,40 L40,40" />
            <path d="M72,72 L72,44 Q72,40 68,40 L60,40" />
            {/* Head / Lens Barrel */}
            <ellipse cx="50" cy="38" rx="16" ry="20" />
            <circle cx="50" cy="38" r="11" />
            <circle cx="50" cy="38" r="6" />
            {/* Beam projection lines */}
            <line x1="42" y1="20" x2="30" y2="8" strokeDasharray="2 2" />
            <line x1="58" y1="20" x2="70" y2="8" strokeDasharray="2 2" />
          </svg>
        );

      default:
        return null;
    }
  };

  return (
    <button
      type="button"
      onClick={() => onClick(id)}
      className="w-full text-left bg-white rounded-2xl p-4 sm:p-5 border border-black shadow-sm hover:shadow-md active:scale-[0.985] active:bg-blue-50/40 transition-all duration-150 flex flex-col justify-between group relative overflow-hidden"
    >
      {/* Blueprint background technical wireframe (opacity 5-8%, never blocks text) */}
      <div className="absolute right-2 bottom-1 pointer-events-none select-none opacity-[0.07] text-blue-950 transition-opacity group-hover:opacity-[0.10]">
        {renderBlueprintWireframe()}
      </div>

      {/* Top accent hairline for professional finish */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-700 via-blue-900 to-amber-500 opacity-90" />

      <div className="relative z-10">
        <div className="flex items-start justify-between gap-3 mb-2.5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-900 text-white flex items-center justify-center shadow-sm group-hover:bg-blue-800 transition-colors shrink-0">
              {getIcon()}
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-blue-700 font-mono">
                {category === 'audio' ? 'AUDIO TOOL' : 'LIGHTING TOOL'}
              </span>
              <h3 className={`text-base text-slate-900 leading-snug group-hover:text-blue-900 transition-colors ${
                /[\u0900-\u097F]/.test(title) ? 'font-semibold tracking-normal' : 'font-bold tracking-tight'
              }`}>
                {title}
              </h3>
            </div>
          </div>

          <div className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 group-hover:text-blue-800 group-hover:bg-blue-100 transition-colors shrink-0">
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>

        <p className="text-xs sm:text-sm text-slate-600 font-normal leading-relaxed pl-13">
          {description}
        </p>
      </div>

      {badge && (
        <div className="mt-3.5 pl-13 flex items-center relative z-10">
          <span className="inline-flex items-center text-[11px] font-semibold text-amber-700 bg-amber-50 border border-amber-200 px-2.5 py-0.5 rounded-md">
            {badge}
          </span>
        </div>
      )}
    </button>
  );
};
