import React, { useState, useMemo, useRef, useEffect } from 'react';
import { useLanguage } from '../../localization/LanguageContext';
import { useTheme } from '../../theme/ThemeContext';
import { calculateDmx, formatDmxAddress } from '../../calculators/calculations';
import { analyticsService } from '../../services/analyticsService';
import { historyService } from '../../services/historyService';
import { adService } from '../../services/adService';
import { subscriptionService } from '../../services/subscriptionService';
import { AdBannerPlaceholder } from '../ads/AdBannerPlaceholder';
import { CalculatorUnlockModal } from '../subscription/CalculatorUnlockModal';
import { ShareResultButton } from '../ShareResultButton';
import { CalculatorHeroHeader } from './CalculatorHeroHeader';
import { 
  ArrowLeft, 
  ArrowRight, 
  ArrowUp,
  ArrowDown,
  AlertTriangle, 
  CheckCircle2, 
  Check,
  RotateCcw,
  Minus, 
  Plus, 
  Layers, 
  SlidersHorizontal,
  Lightbulb,
  Info
} from 'lucide-react';

interface DmxCalculatorViewProps {
  onBack: () => void;
  onOpenSubscription?: () => void;
}

const PRESET_CHANNELS = [7, 14, 16, 22, 32];

export const DmxCalculatorView: React.FC<DmxCalculatorViewProps> = ({ 
  onBack,
  onOpenSubscription,
}) => {
  const { t, language, setLanguage } = useLanguage();
  const { isNightMode } = useTheme();

  // Screen View Mode: 'input' vs 'result'
  const [viewMode, setViewMode] = useState<'input' | 'result'>('input');

  // Exactly the 3 requested input fields:
  // 1. Start Address (1-512)
  const [startAddress, setStartAddress] = useState<number>(1);
  // 2. Channels Per Fixture (Numeric input + quick presets)
  const [channelCount, setChannelCount] = useState<number>(16);
  // 3. Number Of Fixtures (Plus / Minus selector)
  const [fixtureCount, setFixtureCount] = useState<number>(4);

  // Field tracking: Track addressed/checked fixtures by fixtureNumber
  const [addressedFixtures, setAddressedFixtures] = useState<number[]>([]);
  // Field checklist filter: 'all' | 'pending' | 'completed'
  const [fixtureFilter, setFixtureFilter] = useState<'all' | 'pending' | 'completed'>('all');

  // Validation
  const isStartValid = Number.isInteger(startAddress) && startAddress >= 1 && startAddress <= 512;
  const isCountValid = Number.isInteger(channelCount) && channelCount >= 1;
  const isFixturesValid = Number.isInteger(fixtureCount) && fixtureCount >= 1;
  const totalEndAddress = startAddress + (fixtureCount * channelCount) - 1;
  const exceedsUniverse = totalEndAddress > 512 || startAddress > 512;
  const isValid = isStartValid && isCountValid && isFixturesValid;

  const handleReset = () => {
    setStartAddress(1);
    setChannelCount(16);
    setFixtureCount(4);
    setAddressedFixtures([]);
    setFixtureFilter('all');
    setViewMode('input');
  };

  // Perform calculation
  const result = useMemo(() => {
    return calculateDmx({
      startAddress: Math.max(1, Math.min(512, startAddress || 1)),
      channelCount: Math.max(1, channelCount || 1),
      fixtureCount: Math.max(1, fixtureCount || 1),
    });
  }, [startAddress, channelCount, fixtureCount]);

  const addressedCount = addressedFixtures.length;
  const pendingCount = Math.max(0, result.fixtureCount - addressedCount);

  const displayedFixtures = useMemo(() => {
    if (fixtureFilter === 'pending') {
      return result.fixtures.filter((f) => !addressedFixtures.includes(f.fixtureNumber));
    }
    if (fixtureFilter === 'completed') {
      return result.fixtures.filter((f) => addressedFixtures.includes(f.fixtureNumber));
    }
    return result.fixtures;
  }, [result.fixtures, fixtureFilter, addressedFixtures]);

  const toggleFixtureAddressed = (fixtureNumber: number) => {
    setAddressedFixtures((prev) =>
      prev.includes(fixtureNumber)
        ? prev.filter((id) => id !== fixtureNumber)
        : [...prev, fixtureNumber]
    );
  };

  const resetAddressedProgress = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setAddressedFixtures([]);
  };

  const markAllAddressed = () => {
    setAddressedFixtures(result.fixtures.map((f) => f.fixtureNumber));
  };

  const fixturesContainerRef = useRef<HTMLDivElement>(null);

  // Compact scroll box inside card (scrollable list with height limit so internal scroll exists)
  const [isFixturesExpanded, setIsFixturesExpanded] = useState<boolean>(false);

  const handleScrollToTop = () => {
    if (fixturesContainerRef.current) {
      fixturesContainerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };


  // Active touch and wheel scroll forwarder:
  // When the user scrolls the sequential DMX list and reaches the bottom (or top),
  // continuing to swipe or scroll smoothly bubbles the scroll to the parent <main> container
  // so the user never gets stuck and never has to click outside the sequential DMX card!
  useEffect(() => {
    if (viewMode !== 'result') return;
    const container = fixturesContainerRef.current;
    if (!container) return;

    const getScrollParent = (): HTMLElement | null => {
      return container.closest('main') || document.querySelector('main');
    };

    let touchStartY = 0;
    let isTouching = false;

    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 1) {
        touchStartY = e.touches[0].clientY;
        isTouching = true;
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      if (!isTouching || e.touches.length !== 1) return;
      const currentY = e.touches[0].clientY;
      const deltaY = touchStartY - currentY; // positive = dragging UP (scrolling DOWN)
      touchStartY = currentY;

      if (Math.abs(deltaY) < 0.5) return;

      const maxScroll = container.scrollHeight - container.clientHeight;
      const isAtBottom = container.scrollTop >= maxScroll - 3;
      const isAtTop = container.scrollTop <= 3;
      const scrollParent = getScrollParent();

      if (deltaY > 0 && isAtBottom) {
        // Dragging up at the end of the list: seamlessly scroll outer page down!
        if (scrollParent) {
          scrollParent.scrollTop += deltaY;
        } else {
          window.scrollBy({ top: deltaY, behavior: 'auto' });
        }
      } else if (deltaY < 0 && isAtTop) {
        // Dragging down at top of list: seamlessly scroll outer page up!
        if (scrollParent) {
          scrollParent.scrollTop += deltaY;
        } else {
          window.scrollBy({ top: deltaY, behavior: 'auto' });
        }
      }
    };

    const onTouchEnd = () => {
      isTouching = false;
    };

    const onWheel = (e: WheelEvent) => {
      const maxScroll = container.scrollHeight - container.clientHeight;
      const isAtBottom = container.scrollTop >= maxScroll - 3;
      const isAtTop = container.scrollTop <= 3;
      const scrollParent = getScrollParent();

      if ((e.deltaY > 0 && isAtBottom) || (e.deltaY < 0 && isAtTop)) {
        if (scrollParent) {
          scrollParent.scrollTop += e.deltaY;
        } else {
          window.scrollBy({ top: e.deltaY, behavior: 'auto' });
        }
      }
    };

    container.addEventListener('touchstart', onTouchStart, { passive: true });
    container.addEventListener('touchmove', onTouchMove, { passive: true });
    container.addEventListener('touchend', onTouchEnd, { passive: true });
    container.addEventListener('touchcancel', onTouchEnd, { passive: true });
    container.addEventListener('wheel', onWheel, { passive: true });

    return () => {
      container.removeEventListener('touchstart', onTouchStart);
      container.removeEventListener('touchmove', onTouchMove);
      container.removeEventListener('touchend', onTouchEnd);
      container.removeEventListener('touchcancel', onTouchEnd);
      container.removeEventListener('wheel', onWheel);
    };
  }, [viewMode, result.fixtures, displayedFixtures, isFixturesExpanded]);

  const [isRewardModalOpen, setIsRewardModalOpen] = useState(false);
  const isCalculatingRef = useRef(false);

  const executeCalculation = () => {
    isCalculatingRef.current = true;

    // Reset checklist on fresh calculation
    setAddressedFixtures([]);
    setFixtureFilter('all');

    // Log to analytics
    analyticsService.logCalculationCompleted('dmx_calculator', {
      startAddress,
      channelCount,
      fixtureCount,
      endAddress: result.endAddress,
      nextFixtureAddress: result.nextFixtureAddress,
      exceedsUniverse: result.exceedsUniverse,
    });

    // Save to calculation history
    try {
      historyService.addEntry({
        calculatorId: 'calc_dmx',
        calculatorName: language === 'hi' ? 'DMX एड्रेस कैलकुलेटर' : 'DMX Address Calculator',
        resultSummary: `${fixtureCount} Fixtures (${channelCount} CH) • Next Free: ${result.formattedNextFreeAddress}`,
        badge: {
          text: result.exceedsUniverse ? 'Universe Exceeded' : 'Universe 1 OK',
          type: result.exceedsUniverse ? 'danger' : 'safe',
        },
        details: [
          { label: 'Start Address', value: `CH ${formatDmxAddress(startAddress)}` },
          { label: 'Channels / Fixture', value: `${channelCount} CH` },
          { label: 'Number of Fixtures', value: `${fixtureCount}` },
          { label: 'Next Free Address', value: `CH ${result.formattedNextFreeAddress}` },
          { label: 'Occupied Range', value: result.addressRange },
        ],
      });
    } catch (e) {
      console.warn('Could not save DMX calculation to history', e);
    }

    setViewMode('result');
    window.scrollTo({ top: 0, behavior: 'smooth' });

    setTimeout(() => {
      isCalculatingRef.current = false;
    }, 300);
  };

  const handleCalculate = () => {
    if (!isValid || isCalculatingRef.current) return;

    // 1. Active subscribers bypass ad checks
    if (subscriptionService.isPremium()) {
      executeCalculation();
      return;
    }

    // 2. If 60-minute unlock is still active across all calculators, show result immediately
    if (adService.hasActiveRewardPass()) {
      executeCalculation();
      return;
    }

    setIsRewardModalOpen(true);
  };

  const handleModifyInputs = () => {
    setViewMode('input');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // ==========================================
  // DEDICATED RESULT SCREEN
  // ==========================================
  if (viewMode === 'result') {
    return (
      <div className={`min-h-full flex flex-col transition-colors duration-200 ${isNightMode ? 'bg-[#070B14]' : 'bg-[#F8FAFC]'}`}>
        {/* Curved Blue Hero Header */}
        <CalculatorHeroHeader
          title={t.dmxResultTitle}
          subtitle={t.dmxResultSubtitle}
          onBack={handleModifyInputs}
        />

        {/* Content Container */}
        <div className={`flex-1 rounded-t-[36px] -mt-5 relative z-20 px-4 pt-6 pb-28 min-h-[calc(100vh-180px)] transition-colors duration-200 ${
          isNightMode 
            ? 'bg-[#0E1526] text-slate-100 shadow-[0_-10px_35px_rgba(0,0,0,0.5)] border-t border-slate-800/80' 
            : 'bg-white text-slate-900 shadow-[0_-10px_35px_rgba(0,0,0,0.06)]'
        }`}>
          {/* 1. DMX UNIVERSE LIMIT EXCEEDED WARNING */}
          {result.exceedsUniverse && (
            <div 
              id="warning-universe-limit-exceeded"
              className={`mb-4 p-4 rounded-2xl border-2 animate-in fade-in ${
                isNightMode ? 'bg-red-950/40 border-red-800/80 text-red-200' : 'bg-red-50 border-red-300 text-red-900'
              }`}
            >
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-red-600 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-sm">
                  <AlertTriangle className="w-5 h-5 stroke-[2.5]" />
                </div>
                <div>
                  <h3 className={`text-sm font-black tracking-wide ${isNightMode ? 'text-red-300' : 'text-red-900'}`}>
                    DMX Universe Limit Exceeded
                  </h3>
                  <p className={`text-xs font-semibold mt-1 leading-relaxed ${isNightMode ? 'text-red-200/90' : 'text-red-800'}`}>
                    {language === 'hi' 
                      ? `कुल आवश्यक चैनल DMX एड्रेस 512 को पार कर गए हैं (लास्ट चैनल: ${result.endAddress})। मानक DMX यूनिवर्स 1 में केवल 512 स्लॉट होते हैं। 512 से ऊपर के फिक्स्चर्स को यूनिवर्स 2 में 001 से पैच करें।`
                      : `Total addresses exceed DMX channel 512 (last channel: ${result.endAddress}). Standard DMX Universe 1 capacity is 512 channels. Move fixtures exceeding 512 to Universe 2 starting from address 001.`}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* 2. PROMINENT NEXT FREE ADDRESS CARD (Standard Pro-Blue Hero) */}
          <div 
            id="card-next-free-address"
            className="mb-4 rounded-2xl p-5 bg-gradient-to-br from-[#0A1A3A] via-[#0F295E] to-[#0A1628] text-white border border-blue-700/60 shadow-lg relative overflow-hidden"
          >
            {/* Ambient decorative glow */}
            <div className="absolute -right-8 -bottom-8 w-36 h-36 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />

            <div className="relative z-10">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-black uppercase tracking-widest text-amber-400">
                  {language === 'hi' ? 'अगला खाली एड्रेस' : 'Next Free Address'}
                </span>
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-amber-400 text-blue-950 font-sans">
                  {result.exceedsUniverse ? 'Exceeds Univ 1' : 'Universe 1'}
                </span>
              </div>

              <div className="flex items-baseline gap-2 mt-2">
                <span className="text-2xl sm:text-3xl font-black tracking-tight text-white font-mono">
                  Next Free Address → {result.formattedNextFreeAddress}
                </span>
              </div>

              <p className="text-xs text-blue-200/90 mt-1 font-medium">
                {result.exceedsUniverse
                  ? `Address ${result.formattedNextFreeAddress} requires Universe 2 (Port B) on your console.`
                  : `Next fixture can start at Channel ${result.formattedNextFreeAddress}.`}
              </p>
            </div>
          </div>

          {/* 3. SETUP SUMMARY CHIPS */}
          <div className="grid grid-cols-3 gap-2.5 mb-4">
            <div className={`p-3 rounded-xl border text-center transition-all ${
              isNightMode ? 'bg-[#131B2A] border-[#1E293B]' : 'bg-slate-50 border-slate-200'
            }`}>
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                {language === 'hi' ? 'स्टार्ट' : 'Start'}
              </span>
              <span className={`text-base font-black font-mono block mt-0.5 ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                {formatDmxAddress(result.currentAddress)}
              </span>
            </div>

            <div className={`p-3 rounded-xl border text-center transition-all ${
              isNightMode ? 'bg-[#131B2A] border-[#1E293B]' : 'bg-slate-50 border-slate-200'
            }`}>
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                {language === 'hi' ? 'चैनल / फिक्स्चर' : 'CH / Fixture'}
              </span>
              <span className="text-base font-black font-mono block mt-0.5 text-blue-600 dark:text-blue-400">
                {result.channelCount} CH
              </span>
            </div>

            <div className={`p-3 rounded-xl border text-center transition-all ${
              isNightMode ? 'bg-[#131B2A] border-[#1E293B]' : 'bg-slate-50 border-slate-200'
            }`}>
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                {language === 'hi' ? 'कुल फिक्स्चर' : 'Fixtures'}
              </span>
              <span className="text-base font-black font-mono block mt-0.5 text-emerald-600 dark:text-emerald-400">
                {result.fixtureCount}
              </span>
            </div>
          </div>

          {/* Ad Banner (Centered directly below colored DMX result box & chips) */}
          <div id="banner-ad-result" className="mb-4">
            <AdBannerPlaceholder placement="result_bottom" />
          </div>

          {/* ========================================================= */}
          {/* 4. SEQUENTIAL DMX ADDRESSES (Scrollable Fixtures List & Field Checklist) */}
          {/* ========================================================= */}
          <div 
            id="card-sequential-fixtures"
            className={`rounded-2xl border shadow-xs mb-4 flex flex-col transition-all overflow-hidden ${
              isNightMode ? 'bg-[#131B2A] border-[#1E293B]' : 'bg-white border-slate-200'
            }`}
          >
            {/* Header: Title + Progress Counter + Field Actions (Select All, Reset) */}
            <div 
              id="sequential-dmx-header"
              className={`border-b p-3.5 sm:p-4 transition-colors ${
                isNightMode ? 'bg-[#141E34] border-[#1E293B]' : 'bg-slate-50/95 border-slate-200'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="w-8 h-8 rounded-xl bg-blue-500/10 text-blue-500 dark:text-blue-400 flex items-center justify-center font-bold shrink-0">
                    <Layers className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <h3 className={`text-xs sm:text-sm font-black uppercase tracking-wider truncate ${isNightMode ? 'text-slate-100' : 'text-slate-900'}`}>
                      {language === 'hi' ? 'सीक्वेंशियल DMX एड्रेस' : 'Sequential DMX Addresses'}
                    </h3>
                    <p className="text-[10.5px] text-slate-500 dark:text-slate-400 truncate">
                      {result.channelCount} CH / {language === 'hi' ? 'फिक्स्चर' : 'Fixture'} • {result.fixtureCount} {language === 'hi' ? 'कुल' : 'Total'}
                    </p>
                  </div>
                </div>

                {/* Progress Badge and Field Checklist Controls */}
                <div className="flex items-center gap-1.5 shrink-0">
                  <span className={`text-[11px] font-black px-2.5 py-1 rounded-lg font-mono flex items-center gap-1 transition-all ${
                    addressedCount === result.fixtureCount
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : addressedCount > 0
                        ? isNightMode ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-700/80' : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        : isNightMode ? 'bg-slate-800 text-slate-300 border border-slate-700' : 'bg-slate-200/80 text-slate-700'
                  }`}>
                    {addressedCount === result.fixtureCount ? (
                      <CheckCircle2 className="w-3.5 h-3.5" />
                    ) : (
                      <Check className="w-3 h-3 stroke-[3]" />
                    )}
                    <span>{addressedCount}/{result.fixtureCount}</span>
                    <span className="text-[9.5px] font-sans font-semibold opacity-90">
                      {language === 'hi' ? 'सेट' : 'Done'}
                    </span>
                  </span>

                  {/* Select All Button for Field Techs */}
                  {addressedCount < result.fixtureCount && (
                    <button
                      type="button"
                      id="btn-select-all-dmx"
                      onClick={markAllAddressed}
                      title={language === 'hi' ? 'सभी फिक्स्चर को सेट मार्क करें' : 'Mark all fixtures as done'}
                      className={`text-[10px] font-bold px-2 py-1 rounded-md transition flex items-center gap-1 active:scale-95 ${
                        isNightMode
                          ? 'bg-blue-950/70 text-blue-300 border border-blue-800/80 hover:bg-blue-900/60'
                          : 'bg-blue-50 text-blue-700 border border-blue-200 hover:bg-blue-100'
                      }`}
                    >
                      <Check className="w-3 h-3 stroke-[2.5]" />
                      <span>{language === 'hi' ? 'सब चुनें' : 'All'}</span>
                    </button>
                  )}

                  {/* Reset Button */}
                  {addressedCount > 0 && (
                    <button
                      type="button"
                      id="btn-reset-dmx-progress"
                      onClick={resetAddressedProgress}
                      title={language === 'hi' ? 'प्रोग्रेस रीसेट करें' : 'Reset checklist'}
                      className={`text-[10px] font-bold px-2 py-1 rounded-md transition flex items-center gap-1 active:scale-95 ${
                        isNightMode
                          ? 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                          : 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 shadow-2xs'
                      }`}
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>{language === 'hi' ? 'रीसेट' : 'Reset'}</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Visual Progress Bar */}
              <div className={`w-full h-1.5 rounded-full overflow-hidden mt-2.5 ${isNightMode ? 'bg-slate-800' : 'bg-slate-200/80'}`}>
                <div 
                  className="bg-emerald-500 h-full transition-all duration-300 rounded-full"
                  style={{ width: `${(addressedCount / result.fixtureCount) * 100}%` }}
                />
              </div>

              {/* Field Tracking Subtitle & Filter Tabs */}
              <div className="flex flex-col gap-2 mt-2 pt-0.5">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-slate-500 dark:text-slate-400 font-medium flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block animate-pulse" />
                    {language === 'hi' 
                      ? (addressedCount === 0 
                          ? 'फिक्स्चर पर टैप करके पूरा (✓) मार्क करें' 
                          : `${addressedCount} सेट • ${pendingCount} बाकी`)
                      : (addressedCount === 0 
                          ? 'Tap fixture to mark complete (✓)' 
                          : `${addressedCount} Complete • ${pendingCount} Remaining`)
                    }
                  </span>

                  {addressedCount === result.fixtureCount ? (
                    <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1 text-[11px]">
                      <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                      {language === 'hi' ? 'सभी फिक्स्चर सेट!' : 'All fixtures set!'}
                    </span>
                  ) : result.fixtureCount > 4 ? (
                    <button
                      type="button"
                      onClick={handleScrollToTop}
                      className="text-[10.5px] font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-0.5 active:scale-95 transition-transform"
                    >
                      <ArrowUp className="w-3 h-3 stroke-[2.5]" />
                      <span>{language === 'hi' ? 'ऊपर जाएं' : 'Back to top'}</span>
                    </button>
                  ) : null}
                </div>

                {/* Filter Tabs for quick field navigation when > 4 fixtures */}
                {result.fixtureCount > 4 && (
                  <div className="flex items-center gap-1.5 pt-1">
                    <button
                      type="button"
                      onClick={() => setFixtureFilter('all')}
                      className={`text-[10.5px] font-bold px-2.5 py-1 rounded-lg transition-all ${
                        fixtureFilter === 'all'
                          ? 'bg-blue-600 text-white shadow-xs'
                          : isNightMode
                            ? 'bg-slate-800 text-slate-400 hover:text-slate-200'
                            : 'bg-slate-200/70 text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {language === 'hi' ? `सब (${result.fixtureCount})` : `All (${result.fixtureCount})`}
                    </button>
                    <button
                      type="button"
                      onClick={() => setFixtureFilter('pending')}
                      className={`text-[10.5px] font-bold px-2.5 py-1 rounded-lg transition-all ${
                        fixtureFilter === 'pending'
                          ? 'bg-amber-600 text-white shadow-xs'
                          : isNightMode
                            ? 'bg-slate-800 text-slate-400 hover:text-slate-200'
                            : 'bg-slate-200/70 text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {language === 'hi' ? `बाकी (${pendingCount})` : `Pending (${pendingCount})`}
                    </button>
                    <button
                      type="button"
                      onClick={() => setFixtureFilter('completed')}
                      className={`text-[10.5px] font-bold px-2.5 py-1 rounded-lg transition-all ${
                        fixtureFilter === 'completed'
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : isNightMode
                            ? 'bg-slate-800 text-slate-400 hover:text-slate-200'
                            : 'bg-slate-200/70 text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {language === 'hi' ? `पूर्ण (${addressedCount})` : `Done (${addressedCount})`}
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* SCROLLABLE FIXTURE LIST CONTAINER (Natural chaining without overscroll lock) */}
            <div 
              ref={fixturesContainerRef}
              id="slidable-fixtures-container"
              aria-label="Sequential DMX Addresses scrollable list"
              style={{ overscrollBehaviorY: 'auto' }}
              className={`px-2.5 sm:px-3.5 py-2.5 space-y-2 transition-all ${
                isFixturesExpanded
                  ? 'max-h-none overflow-visible'
                  : 'max-h-[340px] sm:max-h-[380px] overflow-y-auto scrollbar-thin scrollbar-thumb-slate-300 dark:scrollbar-thumb-slate-700 overscroll-y-auto'
              }`}
            >
              {displayedFixtures.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-400">
                  {fixtureFilter === 'pending' 
                    ? (language === 'hi' ? 'कोई फिक्स्चर बाकी नहीं है! सभी पूर्ण हो चुके हैं।' : 'No pending fixtures! All fixtures have been configured.')
                    : (language === 'hi' ? 'अभी कोई फिक्स्चर पूर्ण नहीं हुआ है।' : 'No completed fixtures yet. Tap items to check them off.')}
                </div>
              ) : (
                displayedFixtures.map((fixture) => {
                  const isAddressed = addressedFixtures.includes(fixture.fixtureNumber);

                  return (
                    <div
                      key={fixture.fixtureNumber}
                      id={`fixture-item-${fixture.fixtureNumber}`}
                      role="checkbox"
                      aria-checked={isAddressed}
                      tabIndex={0}
                      onClick={() => toggleFixtureAddressed(fixture.fixtureNumber)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault();
                          toggleFixtureAddressed(fixture.fixtureNumber);
                        }
                      }}
                      className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer select-none transition-all duration-150 active:scale-[0.99] ${
                        isAddressed
                          ? isNightMode
                            ? 'bg-emerald-950/30 border-emerald-600/70 text-slate-100 shadow-xs'
                            : 'bg-emerald-50/90 border-emerald-400 text-slate-900 shadow-xs'
                          : fixture.exceeds512
                            ? isNightMode
                              ? 'bg-red-950/20 border-red-800/40 text-slate-200'
                              : 'bg-red-50/50 border-red-200 text-slate-800'
                            : isNightMode
                              ? 'bg-[#182338] border-slate-700/80 text-slate-200 hover:bg-[#1E2C46]'
                              : 'bg-slate-50 border-slate-200 text-slate-800 hover:bg-slate-100'
                      }`}
                    >
                      {/* Left: Interactive Checkbox + Fixture Details */}
                      <div className="flex items-center gap-3 pointer-events-none min-w-0">
                        {/* Tactile Checkbox Box */}
                        <div className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 transition-all ${
                          isAddressed
                            ? 'bg-emerald-600 text-white shadow-xs ring-2 ring-emerald-500/40'
                            : isNightMode
                              ? 'border-2 border-slate-600 bg-slate-800/90'
                              : 'border-2 border-slate-300 bg-white shadow-2xs'
                        }`}>
                          {isAddressed && <Check className="w-4 h-4 stroke-[3]" />}
                        </div>

                        {/* Fixture Number Badge */}
                        <div className={`w-7 h-7 rounded-lg flex items-center justify-center font-black shrink-0 transition-all text-xs font-mono ${
                          isAddressed
                            ? isNightMode ? 'bg-emerald-900/60 text-emerald-300' : 'bg-emerald-200 text-emerald-900'
                            : fixture.exceeds512
                              ? 'bg-red-600 text-white'
                              : isNightMode
                                ? 'bg-slate-800 text-slate-200 border border-slate-700'
                                : 'bg-slate-200 text-slate-700'
                        }`}>
                          #{fixture.fixtureNumber}
                        </div>

                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span className={`text-sm font-bold truncate ${
                              isAddressed 
                                ? isNightMode ? 'text-emerald-300 font-extrabold' : 'text-emerald-950 font-extrabold'
                                : isNightMode ? 'text-slate-100' : 'text-slate-900'
                            }`}>
                              Fixture #{fixture.fixtureNumber}
                            </span>

                            {isAddressed && (
                              <span className="text-[9px] font-black uppercase px-1.5 py-0.5 rounded bg-emerald-600 text-white shrink-0">
                                ✓ {language === 'hi' ? 'सेट' : 'Done'}
                              </span>
                            )}

                            {fixture.exceeds512 && (
                              <span className="text-[9px] font-black uppercase px-1.5 py-0.5 rounded bg-red-600 text-white shrink-0">
                                Univ 2 (512+)
                              </span>
                            )}
                          </div>

                          <span className={`text-[11px] font-mono block mt-0.5 truncate ${
                            isAddressed 
                              ? isNightMode ? 'text-emerald-400/90' : 'text-emerald-700'
                              : 'text-slate-400 dark:text-slate-400'
                          }`}>
                            CH {fixture.formattedStart} – {fixture.formattedEnd} ({result.channelCount} CH)
                          </span>
                        </div>
                      </div>

                      {/* Right: Output Address: Fixture X → 001 */}
                      <div className="flex items-center gap-2 font-mono pointer-events-none shrink-0 ml-2">
                        <span className="text-slate-400 font-bold text-xs">→</span>
                        <span className={`text-base sm:text-lg font-black px-3 py-1 rounded-xl border font-mono tracking-wide transition-all ${
                          isAddressed
                            ? isNightMode
                              ? 'bg-emerald-900/60 text-emerald-200 border-emerald-500 shadow-xs'
                              : 'bg-emerald-100 text-emerald-950 border-emerald-400 font-black shadow-xs'
                            : fixture.exceeds512
                              ? 'bg-red-100 dark:bg-red-950/60 text-red-700 dark:text-red-300 border-red-300 dark:border-red-800'
                              : isNightMode
                                ? 'bg-slate-800 text-slate-100 border-slate-700'
                                : 'bg-white text-slate-900 border-slate-300 shadow-2xs'
                        }`}>
                          {fixture.formattedStart}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Card Footer: Next Available Slot + Quick Action Buttons */}
            <div className={`border-t flex items-center justify-between px-3 sm:px-4 py-2.5 text-xs font-mono font-bold rounded-b-2xl gap-2 flex-wrap ${
              isNightMode ? 'bg-[#141C30] border-[#1E293B] text-slate-300' : 'bg-slate-50 border-slate-200 text-slate-700'
            }`}>
              <div className="flex items-center gap-1.5 min-w-0">
                <span className="text-slate-400 uppercase tracking-wider text-[10px] shrink-0">
                  {language === 'hi' ? 'अगला स्लॉट:' : 'Next Slot:'}
                </span>
                <span className="text-amber-500 dark:text-amber-400 font-black text-xs sm:text-sm truncate">
                  → {result.formattedNextFreeAddress}
                </span>
              </div>

              <div className="flex items-center gap-1.5 shrink-0 ml-auto">
                {/* Toggle Expand / Fold for Fixtures */}
                {result.fixtureCount > 4 && (
                  <button
                    type="button"
                    id="btn-toggle-expand-fixtures"
                    onClick={() => setIsFixturesExpanded(!isFixturesExpanded)}
                    title={isFixturesExpanded 
                      ? (language === 'hi' ? 'लिस्ट छोटी करें' : 'Collapse list') 
                      : (language === 'hi' ? 'पूरी लिस्ट पेज पर खोलें' : 'Expand full list on page')}
                    className={`text-[10.5px] font-bold px-2 py-1 rounded-lg transition-all flex items-center gap-1 shrink-0 active:scale-95 ${
                      isNightMode
                        ? 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                        : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 shadow-2xs'
                    }`}
                  >
                    <span>{isFixturesExpanded 
                      ? (language === 'hi' ? 'कम करें' : 'Fold') 
                      : (language === 'hi' ? 'पूरी लिस्ट' : 'All')}</span>
                  </button>
                )}

                {/* Back to top of list */}
                {result.fixtureCount > 4 && (
                  <button
                    type="button"
                    id="btn-fixtures-scroll-top"
                    onClick={handleScrollToTop}
                    title={language === 'hi' ? 'ऊपर स्क्रोल करें' : 'Scroll back to top'}
                    className={`text-[10.5px] font-bold px-2 py-1 rounded-lg transition-all flex items-center gap-1 shrink-0 active:scale-95 ${
                      isNightMode
                        ? 'bg-blue-950/70 hover:bg-blue-900/80 text-blue-300 border border-blue-800/80'
                        : 'bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 shadow-2xs'
                    }`}
                  >
                    <ArrowUp className="w-3.5 h-3.5 stroke-[2.5]" />
                    <span>{language === 'hi' ? 'ऊपर' : 'Top'}</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* ========================================================= */}
          {/* 1. FIXTURE MODE WARNING (Informational Notice below results) */}
          {/* ========================================================= */}
          <div 
            id="notice-fixture-mode"
            className={`rounded-2xl border p-4 sm:p-5 mb-4 transition-colors ${
              isNightMode 
                ? 'bg-amber-950/30 border-amber-800/80 text-amber-200' 
                : 'bg-amber-50 border-amber-200 text-slate-800'
            }`}
          >
            <div className="flex items-start gap-3">
              <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
                isNightMode ? 'bg-amber-950/60 text-amber-400 border border-amber-800/60' : 'bg-amber-100 text-amber-700 border border-amber-200'
              }`}>
                <AlertTriangle className="w-4 h-4" />
              </div>

              <div className="space-y-2 text-xs leading-relaxed flex-1">
                <div>
                  <h4 className={`text-sm font-bold tracking-tight ${
                    isNightMode ? 'text-amber-300' : 'text-amber-900'
                  }`}>
                    {language === 'hi' ? '⚠ फिक्स्चर मोड सत्यापित (Verify) करें' : '⚠ Verify Fixture Mode'}
                  </h4>
                </div>

                <p className={isNightMode ? 'text-slate-200' : 'text-slate-700'}>
                  {language === 'hi' 
                    ? 'एड्रेस गणना चुने गए DMX चैनल काउंट पर आधारित है।' 
                    : 'Address calculations are based on the selected DMX channel count.'}
                </p>

                <p className={isNightMode ? 'text-slate-200' : 'text-slate-700'}>
                  {language === 'hi' 
                    ? 'हमेशा जांचें कि फिक्स्चर का एक्टिव DMX मोड चुने गए चैनल काउंट से मेल खाता है।' 
                    : "Always verify that the fixture's active DMX mode matches the selected channel count."}
                </p>

                <div className={`p-3 rounded-xl border font-sans text-[11px] ${
                  isNightMode ? 'bg-[#0E1526] border-amber-800/60 text-slate-300' : 'bg-white border-amber-200/80 text-slate-700'
                }`}>
                  <span className="font-bold text-amber-600 dark:text-amber-400 block mb-0.5">
                    {language === 'hi' ? 'उदाहरण:' : 'Example:'}
                  </span>
                  {language === 'hi' 
                    ? '16CH मोड में चलने वाले फिक्स्चर को उसी फिक्स्चर के 22CH मोड की तुलना में अलग एड्रेस की आवश्यकता होती है।' 
                    : 'A fixture running in 16CH mode requires different addresses than the same fixture running in 22CH mode.'}
                </div>
              </div>
            </div>
          </div>

          {/* Share Result Button */}
          <ShareResultButton
            calculatorTitle="DMX 512 ADDRESS PATCH"
            systemDetails={[
              `Start Address: ${result.fixtures[0]?.formattedStart || '001'}`,
              `Channels Per Fixture: ${result.channelCount} CH`,
              `Total Fixtures: ${result.fixtureCount}`,
              ...result.fixtures.map(
                (f) => `Fixture #${f.fixtureNumber}: Channels ${f.formattedStart}–${f.formattedEnd}${addressedFixtures.includes(f.fixtureNumber) ? ' [DONE]' : ''}`
              ),
            ]}
            finalResults={[
              {
                label: 'Universe Status',
                value: result.exceedsUniverse ? 'Universe Limit Exceeded (512+)' : 'Universe 1 Safe (Within 512)',
              },
              {
                label: 'Next Available Address',
                value: result.formattedNextFreeAddress,
              },
              {
                label: 'Setup Progress',
                value: `${addressedCount}/${result.fixtureCount} Fixtures Addressed`,
              },
            ]}
            className="mb-3"
          />

          {/* Modify Inputs CTA Button */}
          <button
            type="button"
            id="btn-modify-inputs"
            onClick={handleModifyInputs}
            className="w-full flex items-center justify-center gap-2 bg-[#FBBF24] hover:bg-[#F59E0B] text-[#0F172A] font-black py-3.5 px-4 rounded-xl shadow-md transition active:scale-[0.99] border border-amber-300/80"
          >
            <ArrowLeft className="w-4 h-4 stroke-[2.5]" />
            <span>{t.dmxModifyInputs}</span>
          </button>
        </div>
      </div>
    );
  }

  // ==========================================
  // DEDICATED INPUT SCREEN
  // ==========================================
  return (
    <div className={`min-h-full flex flex-col transition-colors duration-200 ${isNightMode ? 'bg-[#070B14]' : 'bg-[#F8FAFC]'}`}>
      {/* Curved Blue Hero Header */}
      <CalculatorHeroHeader
        title={t.dmxCalcTitle}
        subtitle={t.dmxCalcDesc}
        onBack={onBack}
        onReset={handleReset}
        resetAriaLabel={t.reset}
        actions={
          <div className="bg-black/20 backdrop-blur-md p-1 rounded-full border border-white/20 inline-flex items-center">
            <button
              type="button"
              onClick={() => setLanguage('en')}
              className={`px-3 py-1 rounded-full text-[11px] font-bold transition-all ${
                language === 'en'
                  ? 'bg-white text-[#1D4ED8] shadow-xs'
                  : 'text-white/80 hover:text-white'
              }`}
            >
              English
            </button>
            <button
              type="button"
              onClick={() => setLanguage('hi')}
              className={`px-3 py-1 rounded-full text-[11px] font-bold transition-all ${
                language === 'hi'
                  ? 'bg-white text-[#1D4ED8] shadow-xs'
                  : 'text-white/80 hover:text-white'
              }`}
            >
              हिंदी
            </button>
          </div>
        }
      />

      {/* Sheet Container with ONLY the 3 requested input fields */}
      <div className={`flex-1 rounded-t-[36px] -mt-5 relative z-20 px-4 pt-6 pb-28 min-h-[calc(100vh-180px)] transition-colors duration-200 ${
        isNightMode 
          ? 'bg-[#0E1526] text-slate-100 shadow-[0_-10px_35px_rgba(0,0,0,0.5)] border-t border-slate-800/80' 
          : 'bg-white text-slate-900 shadow-[0_-10px_35px_rgba(0,0,0,0.06)]'
      }`}>
        <div className="space-y-4">
          {/* ========================================================= */}
          {/* FIELD 1: Start Address (Numeric input 1-512) */}
          {/* ========================================================= */}
          <div 
            id="input-card-start-address"
            className={`rounded-2xl p-4 sm:p-5 border transition-all ${
              isNightMode ? 'bg-[#131B2A] border-[#1E293B] shadow-sm' : 'bg-white border-slate-200 shadow-xs'
            }`}
          >
            <div className="flex items-center justify-between mb-1.5">
              <label 
                htmlFor="input-start-address" 
                className={`text-xs font-bold uppercase tracking-wide ${isNightMode ? 'text-slate-100' : 'text-slate-900'}`}
              >
                1. {t.dmxStartAddress}
              </label>
              <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${
                isNightMode ? 'bg-slate-800 text-slate-300' : 'bg-slate-100 text-slate-600'
              }`}>
                1–512
              </span>
            </div>

            <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
              {language === 'hi' 
                ? 'फर्स्ट फिक्स्चर का प्रारंभिक DMX चैनल (1 से 512)।'
                : 'Initial DMX channel in Universe 1 (1 to 512).'}
            </p>

            {/* Plus / Minus Stepper & Numeric Input */}
            <div className={`flex items-center justify-between p-1.5 sm:p-2 rounded-[20px] border shadow-2xs transition-colors ${
              isNightMode ? 'bg-[#141C30] border-slate-800' : 'bg-[#F8FAFC] border-slate-200'
            }`}>
              <button
                type="button"
                id="btn-start-address-minus"
                disabled={startAddress <= 1}
                onClick={() => setStartAddress((prev) => Math.max(1, (prev || 1) - 1))}
                aria-label="Decrease start address"
                className={`w-11 h-11 rounded-[16px] flex items-center justify-center font-bold transition active:scale-95 disabled:opacity-30 disabled:pointer-events-none shrink-0 ${
                  isNightMode 
                    ? 'bg-slate-800 border border-slate-700/60 hover:bg-slate-700 text-slate-100' 
                    : 'bg-[#EEF2F8] border border-slate-200/80 hover:bg-slate-200 text-slate-800'
                }`}
              >
                <Minus className="w-4 h-4 stroke-[3]" />
              </button>

              <div className="flex-1 flex items-baseline justify-center gap-1.5 min-w-0">
                <input
                  id="input-start-address"
                  type="number"
                  min={1}
                  max={512}
                  value={startAddress === 0 ? '' : startAddress}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10);
                    setStartAddress(isNaN(val) ? 0 : val);
                  }}
                  className={`text-center text-2xl font-black font-mono bg-transparent outline-hidden border-b-2 transition py-0.5 ${
                    isStartValid
                      ? isNightMode 
                        ? 'text-white border-blue-500/40 focus:border-blue-400' 
                        : 'text-slate-900 border-blue-600/30 focus:border-blue-600'
                      : 'text-red-500 border-red-500'
                  }`}
                  style={{ width: `${Math.max(3, String(startAddress || '').length + 1)}ch` }}
                  placeholder="1"
                />
                <span className="text-xs font-semibold text-slate-400 select-none shrink-0">
                  {language === 'hi' ? 'DMX चैनल' : 'DMX CH'}
                </span>
              </div>

              <button
                type="button"
                id="btn-start-address-plus"
                disabled={startAddress >= 512}
                onClick={() => setStartAddress((prev) => Math.min(512, (prev || 0) + 1))}
                aria-label="Increase start address"
                className={`w-11 h-11 rounded-[16px] flex items-center justify-center font-bold transition active:scale-95 disabled:opacity-30 disabled:pointer-events-none shrink-0 ${
                  isNightMode 
                    ? 'bg-slate-800 border border-slate-700/60 hover:bg-slate-700 text-slate-100' 
                    : 'bg-[#EEF2F8] border border-slate-200/80 hover:bg-slate-200 text-slate-800'
                }`}
              >
                <Plus className="w-4 h-4 stroke-[3]" />
              </button>
            </div>

            {!isStartValid && (
              <div id="start-validation-warning" className="flex items-start gap-2 mt-2.5 p-2.5 bg-red-50 border border-red-200 rounded-xl text-red-800 text-xs">
                <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                <span>{t.dmxStartAddressWarning}</span>
              </div>
            )}
          </div>

          {/* ========================================================= */}
          {/* FIELD 2: Channels Per Fixture (Numeric input + quick presets) */}
          {/* Quick presets: 7 CH, 14 CH, 16 CH, 22 CH, 32 CH */}
          {/* ========================================================= */}
          <div 
            id="input-card-channels-per-fixture"
            className={`rounded-2xl p-4 sm:p-5 border transition-all ${
              isNightMode ? 'bg-[#131B2A] border-[#1E293B] shadow-sm' : 'bg-white border-slate-200 shadow-xs'
            }`}
          >
            <div className="flex items-center justify-between mb-1.5">
              <label 
                htmlFor="input-channels-per-fixture" 
                className={`text-xs font-bold uppercase tracking-wide ${isNightMode ? 'text-slate-100' : 'text-slate-900'}`}
              >
                2. {t.dmxChannelsPerFixture}
              </label>
              <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${
                isNightMode ? 'bg-slate-800 text-slate-300' : 'bg-slate-100 text-slate-600'
              }`}>
                {channelCount} CH
              </span>
            </div>

            <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
              {language === 'hi' 
                ? 'प्रत्येक लाइट फिक्स्चर द्वारा उपयोग किए जाने वाले चैनलों की संख्या।'
                : 'Channels required per light fixture (footprint).'}
            </p>

            {/* Plus / Minus Stepper & Numeric Input */}
            <div className={`flex items-center justify-between p-1.5 sm:p-2 rounded-[20px] border shadow-2xs transition-colors mb-3.5 ${
              isNightMode ? 'bg-[#141C30] border-slate-800' : 'bg-[#F8FAFC] border-slate-200'
            }`}>
              <button
                type="button"
                id="btn-channel-count-minus"
                disabled={channelCount <= 1}
                onClick={() => setChannelCount((prev) => Math.max(1, (prev || 1) - 1))}
                aria-label="Decrease channel count"
                className={`w-11 h-11 rounded-[16px] flex items-center justify-center font-bold transition active:scale-95 disabled:opacity-30 disabled:pointer-events-none shrink-0 ${
                  isNightMode 
                    ? 'bg-slate-800 border border-slate-700/60 hover:bg-slate-700 text-slate-100' 
                    : 'bg-[#EEF2F8] border border-slate-200/80 hover:bg-slate-200 text-slate-800'
                }`}
              >
                <Minus className="w-4 h-4 stroke-[3]" />
              </button>

              <div className="flex-1 flex items-baseline justify-center gap-1.5 min-w-0">
                <input
                  id="input-channels-per-fixture"
                  type="number"
                  min={1}
                  max={512}
                  value={channelCount === 0 ? '' : channelCount}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10);
                    setChannelCount(isNaN(val) ? 0 : val);
                  }}
                  className={`text-center text-2xl font-black font-mono bg-transparent outline-hidden border-b-2 transition py-0.5 ${
                    isCountValid
                      ? isNightMode 
                        ? 'text-white border-blue-500/40 focus:border-blue-400' 
                        : 'text-slate-900 border-blue-600/30 focus:border-blue-600'
                      : 'text-red-500 border-red-500'
                  }`}
                  style={{ width: `${Math.max(3, String(channelCount || '').length + 1)}ch` }}
                  placeholder="16"
                />
                <span className="text-xs font-semibold text-slate-400 select-none shrink-0">
                  {language === 'hi' ? 'चैनल' : 'CH'}
                </span>
              </div>

              <button
                type="button"
                id="btn-channel-count-plus"
                disabled={channelCount >= 512}
                onClick={() => setChannelCount((prev) => Math.min(512, (prev || 0) + 1))}
                aria-label="Increase channel count"
                className={`w-11 h-11 rounded-[16px] flex items-center justify-center font-bold transition active:scale-95 disabled:opacity-30 disabled:pointer-events-none shrink-0 ${
                  isNightMode 
                    ? 'bg-slate-800 border border-slate-700/60 hover:bg-slate-700 text-slate-100' 
                    : 'bg-[#EEF2F8] border border-slate-200/80 hover:bg-slate-200 text-slate-800'
                }`}
              >
                <Plus className="w-4 h-4 stroke-[3]" />
              </button>
            </div>

            {/* Quick Presets: 7 CH, 14 CH, 16 CH, 22 CH, 32 CH */}
            <div>
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                {language === 'hi' ? 'क्विक प्रीसेट्स:' : 'Quick Presets:'}
              </span>
              <div className="grid grid-cols-5 gap-1.5">
                {PRESET_CHANNELS.map((preset) => {
                  const isSelected = channelCount === preset;
                  return (
                    <button
                      key={preset}
                      type="button"
                      id={`btn-preset-${preset}ch`}
                      onClick={() => setChannelCount(preset)}
                      className={`py-2 px-1 text-xs font-black rounded-xl border text-center transition active:scale-95 ${
                        isSelected
                          ? 'bg-[#1D4ED8] text-white border-blue-600 shadow-xs'
                          : isNightMode
                            ? 'bg-slate-800/80 text-slate-300 border-slate-700 hover:bg-slate-800'
                            : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {preset} CH
                    </button>
                  );
                })}
              </div>
            </div>

            {!isCountValid && (
              <div id="count-validation-warning" className="flex items-start gap-2 mt-2.5 p-2.5 bg-red-50 border border-red-200 rounded-xl text-red-800 text-xs">
                <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                <span>{t.dmxChannelCountWarning}</span>
              </div>
            )}
          </div>

          {/* ========================================================= */}
          {/* FIELD 3: Number Of Fixtures (Plus / Minus selector) */}
          {/* Standardized Unified Stepper */}
          {/* ========================================================= */}
          <div 
            id="input-card-number-of-fixtures"
            className={`rounded-2xl p-4 sm:p-5 border transition-all ${
              isNightMode ? 'bg-[#131B2A] border-[#1E293B] shadow-sm' : 'bg-white border-slate-200 shadow-xs'
            }`}
          >
            <div className="flex items-center justify-between mb-1.5">
              <label 
                className={`text-xs font-bold uppercase tracking-wide ${isNightMode ? 'text-slate-100' : 'text-slate-900'}`}
              >
                3. {t.dmxNumberOfFixtures}
              </label>
              <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${
                isNightMode ? 'bg-slate-800 text-slate-300' : 'bg-slate-100 text-slate-600'
              }`}>
                {fixtureCount} {fixtureCount === 1 ? 'Fixture' : 'Fixtures'}
              </span>
            </div>

            <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
              {language === 'hi' 
                ? 'शृंखला में जोड़े जाने वाले कुल फिक्स्चर्स की संख्या (+/- से चुनें)।'
                : 'Total fixtures to sequentially address (Use + / - selector).'}
            </p>

            {/* Standardized Unified Stepper */}
            <div className={`flex items-center justify-between p-1.5 sm:p-2 rounded-[20px] border shadow-2xs transition-colors ${
              isNightMode ? 'bg-[#141C30] border-slate-800' : 'bg-[#F8FAFC] border-slate-200'
            }`}>
              <button
                type="button"
                id="btn-fixture-count-minus"
                disabled={fixtureCount <= 1}
                onClick={() => setFixtureCount((prev) => Math.max(1, prev - 1))}
                aria-label="Decrease fixture count"
                className={`w-11 h-11 rounded-[16px] flex items-center justify-center font-bold transition active:scale-95 disabled:opacity-30 disabled:pointer-events-none shrink-0 ${
                  isNightMode 
                    ? 'bg-slate-800 border border-slate-700/60 hover:bg-slate-700 text-slate-100' 
                    : 'bg-[#EEF2F8] border border-slate-200/80 hover:bg-slate-200 text-slate-800'
                }`}
              >
                <Minus className="w-4 h-4 stroke-[3]" />
              </button>

              <div className="flex-1 flex items-baseline justify-center gap-1.5 min-w-0">
                <span className={`text-2xl font-black tracking-tight font-mono ${
                  isNightMode ? 'text-white' : 'text-slate-900'
                }`}>
                  {fixtureCount}
                </span>
                <span className="text-xs font-semibold text-slate-400 select-none shrink-0">
                  {language === 'hi' 
                    ? (fixtureCount === 1 ? 'फिक्स्चर' : 'फिक्स्चर्स') 
                    : (fixtureCount === 1 ? 'Fixture' : 'Fixtures')}
                </span>
              </div>

              <button
                type="button"
                id="btn-fixture-count-plus"
                disabled={fixtureCount >= 128}
                onClick={() => setFixtureCount((prev) => Math.min(128, prev + 1))}
                aria-label="Increase fixture count"
                className={`w-11 h-11 rounded-[16px] flex items-center justify-center font-bold transition active:scale-95 disabled:opacity-30 disabled:pointer-events-none shrink-0 ${
                  isNightMode 
                    ? 'bg-slate-800 border border-slate-700/60 hover:bg-slate-700 text-slate-100' 
                    : 'bg-[#EEF2F8] border border-slate-200/80 hover:bg-slate-200 text-slate-800'
                }`}
              >
                <Plus className="w-4 h-4 stroke-[3]" />
              </button>
            </div>
          </div>

          {/* Quick Preview Footprint Callout */}
          {isValid && (
            <div className={`p-3.5 rounded-xl border flex items-center justify-between text-xs transition-colors ${
              exceedsUniverse
                ? isNightMode ? 'bg-amber-950/30 border-amber-800/80 text-amber-200' : 'bg-amber-50 border-amber-200 text-amber-900'
                : isNightMode
                  ? 'bg-[#131B2A] border-[#1E293B] text-slate-300'
                  : 'bg-blue-50/70 border-blue-200 text-blue-900'
            }`}>
              <div className="flex items-center gap-2">
                <Info className="w-4 h-4 shrink-0 text-blue-600 dark:text-blue-400" />
                <span>
                  Total Span: <strong>{fixtureCount * channelCount} Channels</strong> (CH {formatDmxAddress(startAddress)}–{formatDmxAddress(totalEndAddress)})
                </span>
              </div>
              {exceedsUniverse && (
                <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-red-600 text-white">
                  Exceeds 512
                </span>
              )}
            </div>
          )}

          {/* DMX Universe Limit Warning on Input Screen if Exceeds 512 */}
          {exceedsUniverse && (
            <div id="exceeds-universe-warning" className={`flex items-start gap-2.5 p-3.5 border rounded-xl text-xs ${
              isNightMode ? 'bg-red-950/40 border-red-800/80 text-red-200' : 'bg-red-50 border-red-200 text-red-900'
            }`}>
              <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold block">DMX Universe Limit Exceeded</span>
                <span>
                  {language === 'hi'
                    ? `कुल आवश्यक चैनल (${totalEndAddress}) 512 से अधिक हैं। कैलकुलेट करने पर सभी एड्रेस दिखाई देंगे।`
                    : `Address range reaches channel ${totalEndAddress} which exceeds Universe 1 (Limit: 512).`}
                </span>
              </div>
            </div>
          )}

          {/* CALCULATE BUTTON */}
          <div className="pt-2">
            <button
              type="button"
              id="btn-calculate-dmx"
              onClick={handleCalculate}
              disabled={!isValid}
              className={`w-full flex items-center justify-center gap-2 py-4 px-4 rounded-xl text-sm shadow-md transition active:scale-[0.99] ${
                language === 'hi' ? 'font-semibold tracking-normal' : 'font-black tracking-wide'
              } ${
                isValid
                  ? 'bg-[#FBBF24] hover:bg-[#F59E0B] text-[#0F172A] cursor-pointer border border-amber-300/80 shadow-amber-900/15'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed border border-slate-300 dark:bg-slate-800 dark:border-slate-700'
              }`}
            >
              <span>{t.dmxCalculateButton}</span>
              <ArrowRight className="w-4 h-4 stroke-[2.5]" />
            </button>

            {!isValid && (
              <p className="text-center text-[11px] text-red-600 mt-2 font-medium">
                Ensure Start Address is 1–512, Channels &gt;= 1, and Fixtures &gt;= 1.
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Unlock Dialog: Watch Ad (Top) OR Remove Ads/Subscription (Bottom) */}
      <CalculatorUnlockModal
        isOpen={isRewardModalOpen}
        calculatorTitle={t.dmxCalcTitle}
        onClose={() => setIsRewardModalOpen(false)}
        onUnlocked={() => {
          setIsRewardModalOpen(false);
          executeCalculation();
        }}
        onOpenSubscription={() => {
          setIsRewardModalOpen(false);
          onOpenSubscription?.();
        }}
      />
    </div>
  );
};
