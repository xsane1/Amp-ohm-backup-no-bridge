import React, { useState, useMemo, useCallback, useRef, useEffect } from 'react';
import { useLanguage } from '../../localization/LanguageContext';
import { useTheme } from '../../theme/ThemeContext';
import { calculateAmplifier, formatStatusMessage, formatLoadValue, formatPowerValue } from '../../calculators/calculations';
import { HeadroomMultiplier } from '../../types';
import { OhmTransferToAmpData } from './OhmCalculatorView';
import { analyticsService } from '../../services/analyticsService';
import { historyService } from '../../services/historyService';
import { adService } from '../../services/adService';
import { subscriptionService } from '../../services/subscriptionService';
import { AdBannerPlaceholder } from '../ads/AdBannerPlaceholder';
import { CalculatorUnlockModal } from '../subscription/CalculatorUnlockModal';
import { WiringDiagram } from './WiringDiagram';
import { ShareResultButton } from '../ShareResultButton';
import { CalculatorHeroHeader } from './CalculatorHeroHeader';
import { 
  ArrowLeft, 
  ChevronLeft,
  RotateCcw, 
  Cpu, 
  AlertTriangle, 
  CheckCircle2, 
  Info, 
  ArrowRight, 
  SlidersHorizontal,
  Layers,
  Sparkles,
  Radio,
  Music,
  Disc3,
  ShieldCheck,
  Minus,
  Plus
} from 'lucide-react';

interface AmplifierCalculatorViewProps {
  onBack: () => void;
  initialData?: OhmTransferToAmpData | null;
  onOpenSubscription?: () => void;
}

export const AmplifierCalculatorView: React.FC<AmplifierCalculatorViewProps> = ({ 
  onBack,
  initialData,
  onOpenSubscription,
}) => {
  const { t, language, setLanguage } = useLanguage();
  const { isNightMode } = useTheme();

  // Screen View Mode: 'input' vs 'result' (Opens directly in 'result' if transferred from OHM Calculator)
  const [viewMode, setViewMode] = useState<'input' | 'result'>(initialData ? 'result' : 'input');

  // Input states - initialized with transferred values if present, but NEVER locked
  const [speakerRms, setSpeakerRms] = useState<number>(initialData?.speakerRms ? Math.max(200, initialData.speakerRms) : 500);
  const [speakerCount, setSpeakerCount] = useState<number>(initialData?.speakerCount ?? 2);
  const [speakerImpedance, setSpeakerImpedance] = useState<number>(initialData?.speakerImpedance ?? 8);
  const [wiring, setWiring] = useState<'parallel' | 'series'>(initialData?.wiring ?? 'parallel');
  const [headroom, setHeadroom] = useState<HeadroomMultiplier>(1.50);

  // Auto-calculate and update state when transferred data arrives from OHM Calculator
  const autoLoggedTransferKeyRef = useRef<string>('');

  useEffect(() => {
    if (initialData) {
      const rms = Math.max(200, initialData.speakerRms || 500);
      const count = initialData.speakerCount || 2;
      const imp = initialData.speakerImpedance || 8;
      const wire = initialData.wiring || 'parallel';
      const key = `${rms}-${count}-${imp}-${wire}`;

      setSpeakerRms(rms);
      setSpeakerCount(count);
      setSpeakerImpedance(imp);
      setWiring(wire);
      setViewMode('result');
      window.scrollTo({ top: 0, behavior: 'smooth' });

      // Automatically log to analytics & history once per unique transfer data
      if (autoLoggedTransferKeyRef.current !== key) {
        autoLoggedTransferKeyRef.current = key;

        const autoResult = calculateAmplifier({
          speakerRms: rms,
          speakerCount: count,
          speakerImpedance: imp,
          wiring: wire,
          headroom: 1.50,
          finalLoad: initialData.finalLoad,
          totalSystemRms: initialData.totalSystemRms,
        });

        analyticsService.logCalculationCompleted('amplifier_calculator', {
          speakerRms: rms,
          speakerCount: count,
          speakerImpedance: imp,
          wiring: wire,
          headroom: 1.50,
          finalLoad: autoResult.finalLoad,
          recommendedWatts: autoResult.recommendedAmpPower,
        });

        historyService.addEntry({
          calculatorId: 'calc_amp',
          calculatorName: 'Amplifier Calculator',
          resultSummary: autoResult.isRecommendationAvailable
            ? `${formatPowerValue(autoResult.recommendedAmpPower)}W @ ${autoResult.finalLoad}Ω`
            : `${autoResult.finalLoad}Ω - Uncommon Load`,
          badge: {
            text: autoResult.isRecommendationAvailable ? `1.5x Headroom` : 'Uncommon Load',
            type: autoResult.classification === 'extreme' ? 'danger' : autoResult.classification === 'uncommon' ? 'warning' : 'info',
          },
          details: [
            { label: 'Total RMS', value: `${formatPowerValue(autoResult.totalSystemRms)}W` },
            { label: 'Load', value: `${autoResult.finalLoad}Ω` },
            { label: 'Speakers', value: `${count} × ${imp}Ω` },
          ],
        });
      }
    }
  }, [initialData]);

  // Validation: Minimum RMS is 200W, Maximum RMS is 100,000W
  const isRmsValid = speakerRms >= 200 && speakerRms <= 100000;
  const isRmsTooHigh = speakerRms > 100000;
  const isCountValid = speakerCount >= 1 && speakerCount <= 32;

  const handleRmsInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value.trim();
    if (raw === '') {
      setSpeakerRms(0);
      return;
    }
    // Allow digits and at most one decimal point
    const cleaned = raw.replace(/[^0-9.]/g, '');
    const parts = cleaned.split('.');
    const formatted = parts.length > 2 ? `${parts[0]}.${parts.slice(1).join('')}` : cleaned;
    const val = parseFloat(formatted);
    if (!isNaN(val)) {
      setSpeakerRms(Math.max(0, val));
    }
  };

  const handleRmsInputBlur = () => {
    if (speakerRms === 0) {
      setSpeakerRms(200);
    }
  };

  const handleReset = () => {
    setSpeakerRms(initialData?.speakerRms ? Math.max(200, initialData.speakerRms) : 500);
    setSpeakerCount(initialData?.speakerCount ?? 2);
    setSpeakerImpedance(initialData?.speakerImpedance ?? 8);
    setWiring(initialData?.wiring ?? 'parallel');
    setHeadroom(1.50);
    setViewMode('input');
  };

  // Impedance choices: 2, 4, 6, 8, 16 Ω
  const impedanceOptions = [2, 4, 6, 8, 16];

  // Headroom options with descriptions
  const headroomOptions: Array<{
    value: HeadroomMultiplier;
    label: string;
    description: string;
    icon: React.ReactNode;
  }> = [
    {
      value: 1.25,
      label: t.ampHeadroom125Label,
      description: t.ampHeadroom125Desc,
      icon: <Radio className="w-4 h-4 text-blue-400 shrink-0" />,
    },
    {
      value: 1.50,
      label: t.ampHeadroom150Label,
      description: t.ampHeadroom150Desc,
      icon: <Music className="w-4 h-4 text-emerald-400 shrink-0" />,
    },
    {
      value: 2.00,
      label: t.ampHeadroom200Label,
      description: t.ampHeadroom200Desc,
      icon: <Disc3 className="w-4 h-4 text-amber-400 shrink-0" />,
    },
  ];

  // Calculation result
  const result = useMemo(() => {
    return calculateAmplifier({
      speakerRms,
      speakerCount,
      speakerImpedance,
      wiring,
      headroom,
    });
  }, [speakerRms, speakerCount, speakerImpedance, wiring, headroom]);

  const [isRewardModalOpen, setIsRewardModalOpen] = useState(false);
  const isCalculatingRef = useRef(false);

  // Core execution of amplifier calculation
  const executeCalculation = () => {
    isCalculatingRef.current = true;

    analyticsService.logCalculationCompleted('amplifier_calculator', {
      speakerRms,
      speakerCount,
      speakerImpedance,
      wiring,
      headroom,
      finalLoad: result.finalLoad,
      recommendedWatts: result.recommendedAmpPower,
    });

    historyService.addEntry({
      calculatorId: 'calc_amp',
      calculatorName: 'Amplifier Calculator',
      resultSummary: result.isRecommendationAvailable
        ? `${formatPowerValue(result.recommendedAmpPower)}W @ ${result.finalLoad}Ω`
        : `${result.finalLoad}Ω - Uncommon Load`,
      badge: {
        text: result.isRecommendationAvailable ? `${headroom}x Headroom` : 'Uncommon Load',
        type: result.classification === 'extreme' ? 'danger' : result.classification === 'uncommon' ? 'warning' : 'info',
      },
      details: [
        { label: 'Total RMS', value: `${formatPowerValue(result.totalSystemRms)}W` },
        { label: 'Load', value: `${result.finalLoad}Ω` },
        { label: 'Speakers', value: `${speakerCount} × ${speakerImpedance}Ω` },
      ],
    });

    setViewMode('result');
    window.scrollTo({ top: 0, behavior: 'smooth' });

    setTimeout(() => {
      isCalculatingRef.current = false;
    }, 400);
  };

  // Navigate to dedicated result screen: active subscribers or users with an active 60-min unlock see results directly
  const handleCalculate = () => {
    if (!isRmsValid || isCalculatingRef.current) return;

    // 1. Active subscribers bypass ad checks
    if (subscriptionService.isPremium()) {
      executeCalculation();
      return;
    }

    // 2. If 60-minute unlock is still active across all calculators, show result immediately
    if (adService.hasActiveRewardPass()) {
      executeCalculation();
      return;
    }

    setIsRewardModalOpen(true);
  };

  // Modify Inputs: returns to input screen keeping previously entered values
  const handleModifyInputs = () => {
    setViewMode('input');
  };

  // Visuals according to load classification:
  // RED = Extreme load / Danger (< 2Ω like 0.89Ω, overload)
  // ORANGE = 2Ω / Caution / High-Current / Uncommon load
  // GREEN = Safe Load (4Ω, 8Ω Pro Load)
  const getBadgeVisuals = () => {
    switch (result.classification) {
      case 'extreme':
        return {
          bannerBg: 'from-[#550C16] via-[#821422] to-[#36080E]',
          glowShadow: 'shadow-[0_10px_30px_rgba(220,38,38,0.45)]',
          borderHighlight: 'border-red-500/80',
          card2LightBg: 'bg-red-50/50',
          card2NightBg: 'bg-[#1C090D]',
          card2Border: isNightMode ? 'border-red-900/70' : 'border-red-200',
          statusTheme: 'red' as const,
          bg: 'bg-red-600 text-white border-red-500 font-bold shadow-xs',
          card2Badge: isNightMode
            ? 'bg-red-950/90 text-red-300 border-red-700/80 font-extrabold'
            : 'bg-red-100 text-red-800 border-red-300 font-extrabold shadow-2xs',
          titleColor: 'text-red-200',
          innerBoxBg: 'bg-black/40 border border-red-400/40 text-red-100',
          card2InnerBox: isNightMode ? 'bg-red-950/60 border-red-800/60 text-red-200' : 'bg-red-50 border-red-200 text-red-900',
          card2LoadColor: isNightMode ? 'text-red-400' : 'text-red-600',
          icon: <AlertTriangle className="w-5 h-5 text-red-400 shrink-0" />,
        };
      case 'requires_2ohm':
      case 'high_current':
      case 'uncommon':
        return {
          bannerBg: 'from-[#522004] via-[#85360A] to-[#331302]',
          glowShadow: 'shadow-[0_10px_30px_rgba(234,88,12,0.45)]',
          borderHighlight: 'border-amber-500/80',
          card2LightBg: 'bg-amber-50/50',
          card2NightBg: 'bg-[#1C1208]',
          card2Border: isNightMode ? 'border-amber-900/70' : 'border-amber-200',
          statusTheme: 'orange' as const,
          bg: 'bg-amber-500 text-slate-950 border-amber-400 font-black shadow-xs',
          card2Badge: isNightMode
            ? 'bg-amber-950/90 text-amber-300 border-amber-700/80 font-extrabold'
            : 'bg-amber-100 text-amber-900 border-amber-300 font-extrabold shadow-2xs',
          titleColor: 'text-amber-200',
          innerBoxBg: 'bg-black/40 border border-amber-400/40 text-amber-100',
          card2InnerBox: isNightMode ? 'bg-amber-950/60 border-amber-800/60 text-amber-200' : 'bg-amber-50 border-amber-200 text-amber-950',
          card2LoadColor: isNightMode ? 'text-amber-400' : 'text-amber-600',
          icon: <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />,
        };
      case 'safe':
      case 'pro_load':
      default:
        return {
          bannerBg: 'from-[#064E3B] via-[#065F46] to-[#022C22]',
          glowShadow: 'shadow-[0_10px_30px_rgba(16,185,129,0.35)]',
          borderHighlight: 'border-emerald-500/80',
          card2LightBg: 'bg-emerald-50/50',
          card2NightBg: 'bg-[#081812]',
          card2Border: isNightMode ? 'border-emerald-900/70' : 'border-emerald-200',
          statusTheme: 'green' as const,
          bg: 'bg-emerald-600 text-white border-emerald-400 font-bold shadow-xs',
          card2Badge: isNightMode
            ? 'bg-emerald-950/90 text-emerald-300 border-emerald-700/80 font-extrabold'
            : 'bg-emerald-100 text-emerald-900 border-emerald-300 font-extrabold shadow-2xs',
          titleColor: 'text-emerald-200',
          innerBoxBg: 'bg-black/40 border border-emerald-400/40 text-emerald-100',
          card2InnerBox: isNightMode ? 'bg-emerald-950/60 border-emerald-800/60 text-emerald-200' : 'bg-emerald-50 border-emerald-200 text-emerald-950',
          card2LoadColor: isNightMode ? 'text-emerald-400' : 'text-emerald-600',
          icon: <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />,
        };
    }
  };

  const visuals = getBadgeVisuals();

  // Translated status titles and descriptions
  const statusTitle = (t as any)[result.statusTitleKey] || result.classification;
  const rawStatusMessage = (t as any)[result.statusMessageKey] || '';
  const statusMessage = formatStatusMessage(rawStatusMessage, result.finalLoad);

  return (
    <div className={`min-h-full flex flex-col transition-colors duration-200 ${isNightMode ? 'bg-[#070B14]' : 'bg-[#F8FAFC]'}`}>
      {/* 1. Curved Blue Hero Header (Matching user's reference image) */}
      <CalculatorHeroHeader
        title={viewMode === 'result' ? t.ampResultTitle : t.ampCalcTitle}
        subtitle={viewMode === 'result' ? t.ampResultSubtitle : t.ampCalcDesc}
        onBack={viewMode === 'result' ? (initialData ? onBack : handleModifyInputs) : onBack}
        onReset={handleReset}
        resetAriaLabel={t.reset}
        actions={
          <div className="bg-black/20 backdrop-blur-md p-1 rounded-full border border-white/20 inline-flex items-center">
            <button
              type="button"
              onClick={() => setLanguage('en')}
              className={`px-3 py-1 rounded-full text-[11px] font-bold transition-all ${
                language === 'en'
                  ? 'bg-white text-[#1D4ED8] shadow-xs'
                  : 'text-white/80 hover:text-white'
              }`}
            >
              English
            </button>
            <button
              type="button"
              onClick={() => setLanguage('hi')}
              className={`px-3 py-1 rounded-full text-[11px] font-bold transition-all ${
                language === 'hi'
                  ? 'bg-white text-[#1D4ED8] shadow-xs'
                  : 'text-white/80 hover:text-white'
              }`}
            >
              हिंदी
            </button>
          </div>
        }
        badge={
          initialData ? (
            <div className="py-1.5 px-3 rounded-xl bg-white/20 backdrop-blur-md border border-white/25 text-xs text-white flex items-center gap-2 shadow-xs">
              <Sparkles className="w-3.5 h-3.5 text-amber-300 shrink-0" />
              <span className="font-semibold text-[11px]">
                {t.ampTransferredNotice}
              </span>
            </div>
          ) : undefined
        }
      />

      {/* 2. Main Sheet */}
      <div className={`flex-1 rounded-t-[36px] -mt-5 relative z-20 px-4 pt-6 pb-28 min-h-[calc(100vh-180px)] transition-colors duration-200 ${
        isNightMode 
          ? 'bg-[#0E1526] text-slate-100 shadow-[0_-10px_35px_rgba(0,0,0,0.5)] border-t border-slate-800/80' 
          : 'bg-white text-slate-900 shadow-[0_-10px_35px_rgba(0,0,0,0.06)]'
      }`}>
        {/* ========================================================= */}
        {/* VIEW 1: INPUTS SCREEN                                     */}
        {/* ========================================================= */}
        {viewMode === 'input' && (
          <div className="space-y-5">
            {/* 1. Speaker RMS Power Input (Stepper + Direct Type) */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label 
                  htmlFor="amp-speaker-rms"
                  className={`block text-xs font-bold uppercase tracking-wider ${isNightMode ? 'text-slate-300' : 'text-slate-700'}`}
                >
                  {t.ampSpeakerRms}
                </label>
                <span className={`text-[11px] font-semibold ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                  200W – 100,000W
                </span>
              </div>
              <p className={`text-[11px] mb-2 ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                Continuous power rating of a single speaker (Max 1 Lakh W).
              </p>

              <div className={`flex items-center justify-between rounded-[20px] p-1.5 shadow-2xs border transition-colors ${
                isNightMode 
                  ? 'bg-[#141C30] border-slate-800' 
                  : 'bg-[#F8FAFC] border-slate-200'
              }`}>
                <button
                  type="button"
                  id="btn-amp-rms-minus"
                  onClick={() => setSpeakerRms((prev) => Math.max(0, (prev || 0) - 50))}
                  className={`w-11 h-11 rounded-[16px] flex items-center justify-center active:scale-95 transition shrink-0 ${
                    isNightMode 
                      ? 'bg-slate-800 text-slate-200 hover:bg-slate-700' 
                      : 'bg-[#EEF2F8] text-slate-700 hover:bg-slate-200'
                  }`}
                  aria-label="Decrease RMS"
                >
                  <Minus className="w-4 h-4 stroke-[3]" />
                </button>

                <div className="flex-1 flex items-baseline justify-center gap-1.5 min-w-0">
                  <input
                    type="number"
                    id="amp-speaker-rms"
                    min={0}
                    value={speakerRms === 0 ? '' : speakerRms}
                    onChange={handleRmsInputChange}
                    onBlur={handleRmsInputBlur}
                    placeholder="500"
                    className={`font-black text-2xl tracking-tight text-center bg-transparent border-b-2 border-transparent hover:border-slate-500 focus:border-[#2563EB] focus:outline-none rounded-md py-0.5 transition [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none ${
                      !isRmsValid 
                        ? 'text-red-500' 
                        : isNightMode ? 'text-white' : 'text-slate-900'
                    }`}
                    style={{ width: `${Math.max(3, String(speakerRms || '').length + 1)}ch` }}
                    aria-label="Speaker RMS Wattage"
                  />
                  <span className="text-xs font-semibold text-slate-400 select-none shrink-0">
                    {language === 'hi' ? 'वाट' : 'Watts'}
                  </span>
                </div>

                <button
                  type="button"
                  id="btn-amp-rms-plus"
                  disabled={speakerRms >= 100000}
                  onClick={() => setSpeakerRms((prev) => Math.min(100000, (prev || 0) + 50))}
                  className={`w-11 h-11 rounded-[16px] flex items-center justify-center active:scale-95 disabled:opacity-30 disabled:pointer-events-none transition shrink-0 ${
                    isNightMode 
                      ? 'bg-slate-800 text-slate-200 hover:bg-slate-700' 
                      : 'bg-[#EEF2F8] text-slate-700 hover:bg-slate-200'
                  }`}
                  aria-label="Increase RMS"
                >
                  <Plus className="w-4 h-4 stroke-[3]" />
                </button>
              </div>

              {/* Warning message for values < 200W or > 100,000W */}
              {!isRmsValid && (
                <div 
                  id="amp-rms-warning"
                  className={`mt-2 p-2.5 rounded-xl border text-xs flex items-start gap-2 ${
                    isNightMode 
                      ? 'bg-red-950/40 border-red-500/40 text-red-300' 
                      : 'bg-red-50 border-red-200 text-red-700'
                  }`}
                >
                  <AlertTriangle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                  <span className="leading-snug font-medium">
                    {isRmsTooHigh ? t.ampSpeakerRmsMaxWarning : t.ampSpeakerRmsMinWarning}
                  </span>
                </div>
              )}
            </div>

            {/* 2. Number of Speakers: Dedicated [-] VALUE [+] Stepper */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label 
                  className={`block text-xs font-bold uppercase tracking-wider ${isNightMode ? 'text-slate-300' : 'text-slate-700'}`}
                >
                  {t.ampSpeakerCount}
                </label>
                <span className={`text-[11px] font-semibold ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                  1 – 32 Speakers
                </span>
              </div>
              <p className={`text-[11px] mb-2 ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                Total speakers connected to amplifier channel.
              </p>

              <div className={`flex items-center justify-between p-1.5 sm:p-2 rounded-[20px] border shadow-2xs transition-colors ${
                isNightMode 
                  ? 'bg-[#141C30] border-slate-800' 
                  : 'bg-[#F8FAFC] border-slate-200'
              }`}>
                <button
                  type="button"
                  id="btn-amp-speaker-count-minus"
                  disabled={speakerCount <= 1}
                  onClick={() => setSpeakerCount((prev) => Math.max(1, prev - 1))}
                  aria-label="Decrease speaker count"
                  className={`w-11 h-11 rounded-[16px] flex items-center justify-center active:scale-95 disabled:opacity-30 disabled:pointer-events-none transition shrink-0 ${
                    isNightMode 
                      ? 'bg-slate-800 text-slate-100 hover:bg-slate-700 border border-slate-700/60' 
                      : 'bg-[#EEF2F8] text-slate-800 hover:bg-slate-200 border border-slate-200/80'
                  }`}
                >
                  <Minus className="w-4 h-4 stroke-[3]" />
                </button>

                <div className="flex-1 flex items-baseline justify-center gap-1.5 min-w-0">
                  <span className={`text-2xl font-black tracking-tight ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                    {speakerCount}
                  </span>
                  <span className="text-xs font-semibold text-slate-400 select-none shrink-0">
                    {language === 'hi' 
                      ? (speakerCount === 1 ? 'स्पीकर' : 'स्पीकर्स') 
                      : (speakerCount === 1 ? 'speaker' : 'speakers')}
                  </span>
                </div>

                <button
                  type="button"
                  id="btn-amp-speaker-count-plus"
                  disabled={speakerCount >= 32}
                  onClick={() => setSpeakerCount((prev) => Math.min(32, prev + 1))}
                  aria-label="Increase speaker count"
                  className={`w-11 h-11 rounded-[16px] flex items-center justify-center active:scale-95 disabled:opacity-30 disabled:pointer-events-none transition shrink-0 ${
                    isNightMode 
                      ? 'bg-slate-800 text-slate-100 hover:bg-slate-700 border border-slate-700/60' 
                      : 'bg-[#EEF2F8] text-slate-800 hover:bg-slate-200 border border-slate-200/80'
                  }`}
                >
                  <Plus className="w-4 h-4 stroke-[3]" />
                </button>
              </div>
            </div>

            {/* 3. Speaker Impedance: Matching Ohm Calculator Selection */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label 
                  className={`block text-xs font-bold uppercase tracking-wider ${isNightMode ? 'text-slate-300' : 'text-slate-700'}`}
                >
                  {t.ampSpeakerImpedance}
                </label>
                <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${
                  isNightMode 
                    ? 'text-blue-400 bg-blue-950/60 border-blue-800/50' 
                    : 'text-[#1D4ED8] bg-blue-50 border-blue-100/80'
                }`}>
                  {speakerImpedance} Ω
                </span>
              </div>
              <p className={`text-[11px] mb-2 ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                Nominal impedance of each speaker.
              </p>

              <div className="grid grid-cols-5 gap-2">
                {impedanceOptions.map((imp) => {
                  const isSelected = speakerImpedance === imp;
                  return (
                    <button
                      key={imp}
                      type="button"
                      id={`btn-amp-impedance-${imp}`}
                      onClick={() => setSpeakerImpedance(imp)}
                      className={`py-2.5 rounded-[18px] flex flex-col items-center justify-center transition-all ${
                        isSelected
                          ? isNightMode
                            ? 'bg-blue-950/60 border-2 border-blue-500 shadow-[0_0_12px_rgba(59,130,246,0.3)]'
                            : 'bg-[#EEF2F8] border-2 border-[#1D4ED8] shadow-xs'
                          : isNightMode
                            ? 'border border-slate-800 bg-[#141C30] hover:border-slate-700'
                            : 'border border-slate-200 bg-white hover:border-slate-300'
                      }`}
                    >
                      <span className={`font-bold text-base ${
                        isSelected 
                          ? isNightMode ? 'text-blue-400' : 'text-[#1D4ED8]' 
                          : isNightMode ? 'text-slate-200' : 'text-slate-800'
                      }`}>
                        {imp}
                      </span>
                      <span className={`text-[11px] mt-0.5 font-semibold ${
                        isSelected 
                          ? isNightMode ? 'text-blue-400' : 'text-[#1D4ED8]' 
                          : 'text-slate-400'
                      }`}>
                        Ω
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 4. Wiring Type: Parallel vs Series */}
            <div>
              <label className={`block text-xs font-bold uppercase tracking-wider mb-1 ${isNightMode ? 'text-slate-300' : 'text-slate-700'}`}>
                {t.ampWiringType}
              </label>
              <p className={`text-[11px] mb-2 ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                Select speaker circuit wiring configuration.
              </p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  id="btn-amp-wiring-parallel"
                  onClick={() => setWiring('parallel')}
                  className={`py-3 px-4 rounded-xl border text-center font-bold text-sm transition active:scale-98 ${
                    wiring === 'parallel'
                      ? isNightMode
                        ? 'bg-blue-600 text-white border-blue-500 shadow-sm'
                        : 'bg-blue-900 text-white border-blue-900 shadow-sm'
                      : isNightMode
                        ? 'bg-[#141C30] text-slate-300 border-slate-800 hover:border-slate-700'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {t.ampWiringParallel}
                </button>

                <button
                  type="button"
                  id="btn-amp-wiring-series"
                  onClick={() => setWiring('series')}
                  className={`py-3 px-4 rounded-xl border text-center font-bold text-sm transition active:scale-98 ${
                    wiring === 'series'
                      ? isNightMode
                        ? 'bg-blue-600 text-white border-blue-500 shadow-sm'
                        : 'bg-blue-900 text-white border-blue-900 shadow-sm'
                      : isNightMode
                        ? 'bg-[#141C30] text-slate-300 border-slate-800 hover:border-slate-700'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {t.ampWiringSeries}
                </button>
              </div>
            </div>

            {/* 5. Headroom Selector (1.25x, 1.50x, 2.00x) */}
            <div>
              <label className={`block text-xs font-bold uppercase tracking-wider mb-1 ${isNightMode ? 'text-slate-300' : 'text-slate-700'}`}>
                {t.ampHeadroomTitle}
              </label>
              <p className={`text-[11px] mb-2 ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                Safety headroom margin to avoid amplifier clipping.
              </p>
              <div className="space-y-2">
                {headroomOptions.map((opt) => {
                  const isSelected = headroom === opt.value;
                  return (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => setHeadroom(opt.value)}
                      className={`w-full p-3 rounded-xl border text-left transition active:scale-98 flex items-start gap-2.5 ${
                        isSelected
                          ? isNightMode
                            ? 'bg-blue-950/80 border-blue-500 text-white shadow-sm'
                            : 'bg-blue-900 text-white border-blue-900 shadow-sm'
                          : isNightMode
                            ? 'bg-[#141C30] text-slate-300 border-slate-800 hover:border-slate-700'
                            : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <div className="mt-0.5">{opt.icon}</div>
                      <div className="flex-1">
                        <div className="text-xs font-bold">{opt.label}</div>
                        <div className={`text-[11px] mt-0.5 leading-snug ${
                          isSelected 
                            ? isNightMode ? 'text-blue-300' : 'text-blue-200' 
                            : isNightMode ? 'text-slate-400' : 'text-slate-500'
                        }`}>
                          {opt.description}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

          {/* Calculate Button (Action Button) */}
          <button
            type="button"
            id="btn-calculate-amp-power"
            disabled={!isRmsValid || !isCountValid || speakerImpedance <= 0}
            onClick={handleCalculate}
            className={`w-full py-4 px-5 rounded-[22px] bg-[#FBBF24] hover:bg-[#F59E0B] text-[#0F172A] shadow-md active:scale-98 disabled:opacity-40 disabled:cursor-not-allowed transition flex items-center justify-center gap-2 border border-amber-300/80 ${
              language === 'hi'
                ? 'font-semibold text-base tracking-normal'
                : 'font-black text-base'
            }`}
          >
            <span>{t.ampCalculateButton}</span>
            <ArrowRight className="w-5 h-5 stroke-[2.5]" />
          </button>
        </div>
      )}

      {/* ========================================================= */}
      {/* VIEW 2: DEDICATED RESULT SCREEN                           */}
      {/* ========================================================= */}
      {viewMode === 'result' && (
        <div className="space-y-4">
          
          {/* CARD 1: RECOMMENDED AMPLIFIER POWER */}
          {result.isRecommendationAvailable ? (
            <div className={`bg-gradient-to-br ${visuals.bannerBg} rounded-[28px] p-5 text-white ${visuals.glowShadow} border ${visuals.borderHighlight} relative overflow-hidden`}>
              <div className="flex items-start justify-between gap-2 mb-2">
                <div>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[11px] font-semibold tracking-wider uppercase text-white/80">
                      {t.ampCard1Title}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-white/20 text-white tracking-wide uppercase backdrop-blur-xs border border-white/20">
                      {t.perChannelBadge}
                    </span>
                  </div>
                  <div className="flex items-baseline gap-1.5 mt-0.5 flex-wrap">
                    <span className="text-5xl font-black tracking-tight text-white">
                      {formatPowerValue(result.recommendedAmpPower)}
                    </span>
                    <span className="text-xl font-bold text-amber-300">
                      {t.ampCard1Unit}
                    </span>
                    <span className="text-xs font-semibold text-white/70 ml-1">
                      {t.perChannelSuffix}
                    </span>
                  </div>
                </div>

                <div className={`px-3 py-1 rounded-full text-xs font-bold border uppercase tracking-wider flex items-center gap-1.5 ${visuals.bg}`}>
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Target Sizing</span>
                </div>
              </div>

              <div className={`mt-3 p-3 rounded-xl ${visuals.innerBoxBg} text-xs flex items-center justify-between`}>
                <span className="text-[11px] text-white/80">Total System RMS</span>
                <span className="font-bold text-amber-300">
                  {formatPowerValue(result.totalSystemRms)} Watts
                </span>
              </div>
            </div>
          ) : (
            <div className={`bg-gradient-to-br ${visuals.bannerBg} rounded-[28px] p-5 text-white ${visuals.glowShadow} border ${visuals.borderHighlight} relative overflow-hidden`}>
              <div className="flex items-start gap-3">
                {visuals.icon}
                <div>
                  <div className={`text-base font-bold mb-1 ${visuals.titleColor}`}>
                    {statusTitle}
                  </div>
                  <p className="text-xs text-white/90 leading-relaxed">
                    {statusMessage}
                  </p>
                  <div className="mt-3 inline-flex items-center gap-1.5 py-1 px-2.5 rounded-lg bg-black/40 text-[11px] font-bold tracking-wider uppercase text-white/90">
                    <span>{t.ampCard1NotAvailable}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* CARD 2: FINAL LOAD */}
          <div className={`rounded-[28px] p-4 sm:p-5 border shadow-sm transition-colors ${
            isNightMode 
              ? `${visuals.card2NightBg} ${visuals.card2Border} text-slate-100` 
              : `${visuals.card2LightBg} ${visuals.card2Border} text-slate-900`
          }`}>
            <div className="flex items-start justify-between gap-2 mb-3">
              <div>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className={`text-xs font-bold uppercase tracking-wider block ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                    {t.ampCard2Title}
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    isNightMode ? 'bg-slate-800 text-blue-300' : 'bg-blue-100 text-blue-700'
                  }`}>
                    {t.perChannelBadge}
                  </span>
                </div>
                <div className="flex items-baseline gap-1.5 mt-0.5">
                  <span className={`text-3xl font-black ${visuals.card2LoadColor}`}>
                    {result.finalLoad.toFixed(2)}
                  </span>
                  <span className="text-lg font-bold text-amber-500">Ω</span>
                  <span className={`text-xs font-semibold ml-1 ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                    {t.perChannelSuffix}
                  </span>
                </div>
              </div>

              <div className={`px-3 py-1 rounded-full text-xs font-extrabold border uppercase tracking-wider ${visuals.card2Badge}`}>
                {statusTitle}
              </div>
            </div>

            {/* Load description message */}
            <div className={`p-3 rounded-xl border text-xs flex items-start gap-2.5 ${visuals.card2InnerBox}`}>
              {visuals.icon}
              <div className="leading-snug">
                <span className="font-bold block mb-0.5">{statusTitle}</span>
                <span>{statusMessage}</span>
              </div>
            </div>
          </div>

          {/* Per-Channel Clarification Banner */}
          <div className={`px-3 py-2 rounded-xl border flex items-center gap-2 transition-colors ${
            isNightMode 
              ? 'bg-blue-950/40 border-blue-900/40 text-blue-300' 
              : 'bg-blue-50/80 border-blue-200/80 text-blue-800'
          }`}>
            <Info className="w-4 h-4 text-blue-500 shrink-0" />
            <p className="text-[11px] font-medium leading-tight">
              {t.perChannelNotice}
            </p>
          </div>

          {/* AdMob Banner Area */}
          <div className="my-1">
            <AdBannerPlaceholder placement="result_bottom" />
          </div>

          {/* Compact Wiring Connection Diagram */}
          <WiringDiagram
            wiring={result.wiring}
            speakerCount={result.speakerCount}
            speakerImpedance={result.speakerImpedance}
          />

          {/* CARD 3: SYSTEM SUMMARY */}
          <div className={`rounded-2xl p-4 sm:p-5 border shadow-sm transition-colors ${
            isNightMode 
              ? 'bg-[#141C30] border-slate-800 text-slate-100' 
              : 'bg-white border-slate-200 text-slate-800'
          }`}>
            <div className={`flex items-center gap-2 mb-3 pb-2 border-b ${isNightMode ? 'border-slate-800' : 'border-slate-100'}`}>
              <Layers className="w-4 h-4 text-[#2563EB]" />
              <h3 className={`text-xs font-bold uppercase tracking-wider ${isNightMode ? 'text-slate-200' : 'text-slate-800'}`}>
                {t.ampCard3Title}
              </h3>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className={`p-3 rounded-xl border ${
                isNightMode ? 'bg-[#19233C] border-slate-800' : 'bg-slate-50 border-slate-100'
              }`}>
                <span className={`text-[11px] block ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>{t.ampSummaryTotalSpeakers}</span>
                <span className={`text-base font-bold mt-0.5 block ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                  {result.speakerCount} {result.speakerCount === 1 ? 'Speaker' : 'Speakers'}
                </span>
              </div>

              <div className={`p-3 rounded-xl border ${
                isNightMode ? 'bg-[#19233C] border-slate-800' : 'bg-slate-50 border-slate-100'
              }`}>
                <span className={`text-[11px] block ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>{t.ampSummarySpeakerRms}</span>
                <span className={`text-base font-bold mt-0.5 block ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                  {result.speakerRms} <span className="text-xs font-semibold text-slate-400">W RMS</span>
                </span>
              </div>

              <div className={`p-3 rounded-xl border ${
                isNightMode ? 'bg-[#19233C] border-slate-800' : 'bg-slate-50 border-slate-100'
              }`}>
                <span className={`text-[11px] block ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>{t.ampSummaryTotalRms}</span>
                <span className={`text-base font-bold mt-0.5 block ${isNightMode ? 'text-blue-400' : 'text-blue-900'}`}>
                  {result.totalSystemRms} <span className="text-xs font-semibold">W Total RMS</span>
                </span>
              </div>

              <div className={`p-3 rounded-xl border ${
                isNightMode ? 'bg-[#19233C] border-slate-800' : 'bg-slate-50 border-slate-100'
              }`}>
                <span className={`text-[11px] block ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>{t.ampSummaryHeadroom}</span>
                <span className={`text-sm font-bold mt-0.5 block ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                  {result.headroom.toFixed(2)}x
                </span>
              </div>

              <div className={`p-3 rounded-xl border col-span-2 flex items-center justify-between ${
                isNightMode ? 'bg-[#19233C] border-slate-800' : 'bg-slate-50 border-slate-100'
              }`}>
                <div>
                  <span className={`text-[11px] block ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>{t.ampSummaryWiring}</span>
                  <span className={`text-sm font-bold ${isNightMode ? 'text-white' : 'text-slate-900'} capitalize`}>
                    {result.wiring === 'parallel' ? t.ampWiringParallel : t.ampWiringSeries} ({result.speakerImpedance}Ω each)
                  </span>
                </div>
                <div className="text-right">
                  <span className={`text-[11px] block ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>Load Distribution</span>
                  <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                    isNightMode 
                      ? 'text-emerald-400 bg-emerald-950/60 border border-emerald-800/40' 
                      : 'text-emerald-800 bg-emerald-50 border border-emerald-200'
                  }`}>
                    Balanced
                  </span>
                </div>
              </div>

              <div className={`p-3 rounded-xl border col-span-2 flex items-center justify-between ${
                isNightMode ? 'bg-[#19233C] border-slate-800' : 'bg-slate-50 border-slate-100'
              }`}>
                <div>
                  <span className={`text-[11px] block ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>{t.perChannelScopeLabel}</span>
                  <span className={`text-sm font-bold ${isNightMode ? 'text-blue-300' : 'text-blue-700'}`}>
                    {t.perChannelScopeValue}
                  </span>
                </div>
                <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                  isNightMode ? 'text-blue-400 bg-blue-950/60 border border-blue-800/40' : 'text-blue-800 bg-blue-50 border border-blue-200'
                }`}>
                  1 Output
                </span>
              </div>
            </div>
          </div>

          {/* Share Result Button */}
          <ShareResultButton
            calculatorTitle="AMPLIFIER MATCHING REPORT"
            systemDetails={[
              `Cabinet Drivers: ${result.speakerCount} ${result.speakerCount === 1 ? 'Speaker' : 'Speakers'}`,
              `Cabinet Impedance: ${result.speakerImpedance}Ω each`,
              `Wiring Configuration: ${result.wiring === 'parallel' ? 'Parallel' : 'Series'}`,
              `Per Driver RMS: ${result.speakerRms}W RMS`,
              `Total System Power: ${result.totalSystemRms}W RMS`,
              `Headroom Applied: ${result.headroom.toFixed(2)}x (${Math.round((result.headroom - 1) * 100)}% Safety Headroom)`,
            ]}
            finalResults={
              result.isRecommendationAvailable
                ? [
                    {
                      label: 'Total Net Load',
                      value: `${result.finalLoad}Ω (Per Channel)`,
                    },
                    {
                      label: 'Recommended Amplifier Power',
                      value: `${formatPowerValue(result.recommendedAmpPower)}W RMS @ ${result.finalLoad}Ω`,
                    },
                    {
                      label: 'System Classification',
                      value:
                        result.classification === 'extreme'
                          ? 'EXTREME LOAD (< 2Ω DANGER)'
                          : result.classification === 'requires_2ohm'
                            ? 'REQUIRED 2 OHM STABLE AMPLIFIER'
                            : result.classification === 'high_current'
                              ? 'HIGH CURRENT (2Ω STABLE AMP REQUIRED)'
                              : result.classification === 'safe'
                                ? 'SAFE OPERATING LOAD (4Ω–8Ω)'
                                : result.classification === 'pro_load'
                                  ? 'PROFESSIONAL LOAD (8Ω–16Ω)'
                                  : 'UNCOMMON LOAD (> 16Ω)',
                    },
                  ]
                : [
                    {
                      label: 'Total Net Load',
                      value: `${result.finalLoad}Ω (Extreme Load)`,
                    },
                    {
                      label: 'Recommended Amplifier Power',
                      value: 'Not Recommended (Sub-2Ω Load)',
                    },
                    {
                      label: 'System Classification',
                      value: 'EXTREME LOAD (< 2Ω DANGER)',
                    },
                  ]
            }
            warning={
              !result.isRecommendationAvailable
                ? (result.finalLoad < 2.0
                    ? `This system load is ${formatLoadValue(result.finalLoad)}Ω. Load is unsafe for audio amplifiers. Please rewire speakers.`
                    : `This system load is ${formatLoadValue(result.finalLoad)}Ω. Uncommon for PA amplifiers. Amplifier recommendation is not available.`)
                : result.finalLoad < 4.0
                  ? `This system load is ${formatLoadValue(result.finalLoad)}Ω. Check that your amplifier is 2Ω stable.`
                  : null
            }
          />

          {/* Action: Modify Inputs */}
          <button
            type="button"
            id="btn-modify-amp-inputs"
            onClick={handleModifyInputs}
            className={`w-full py-3.5 px-4 rounded-xl font-bold text-sm active:scale-98 transition flex items-center justify-center gap-2 shadow-xs ${
              isNightMode 
                ? 'bg-[#141C30] text-slate-200 border border-slate-800 hover:bg-[#19233C]' 
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            <SlidersHorizontal className="w-4 h-4 text-slate-400" />
            <span>{t.ampModifyInputs}</span>
          </button>

          {/* Action: Back to OHM Calculator (when transferred) */}
          {initialData && (
            <button
              type="button"
              id="btn-back-to-ohm-calc"
              onClick={onBack}
              className={`w-full py-3 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition active:scale-98 ${
                isNightMode
                  ? 'text-blue-400 hover:text-blue-300 hover:bg-slate-800/50'
                  : 'text-blue-700 hover:text-blue-800 hover:bg-blue-50'
              }`}
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>{t.ampBackToOhm}</span>
            </button>
          )}
        </div>
      )}

      {/* Unlock Dialog: Watch Ad (Top) OR Remove Ads/Subscription (Bottom) */}
      <CalculatorUnlockModal
        isOpen={isRewardModalOpen}
        calculatorTitle={t.ampCalcTitle}
        onClose={() => setIsRewardModalOpen(false)}
        onUnlocked={() => {
          setIsRewardModalOpen(false);
          executeCalculation();
        }}
        onOpenSubscription={() => {
          setIsRewardModalOpen(false);
          onOpenSubscription?.();
        }}
      />
      </div>
    </div>
  );
};
