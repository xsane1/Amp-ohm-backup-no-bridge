import React, { useState, useMemo, useRef } from 'react';
import { useLanguage } from '../../localization/LanguageContext';
import { useTheme } from '../../theme/ThemeContext';
import { 
  calculateCableLoss, 
  STANDARD_CABLE_SIZES, 
  getResistivity,
  getAwgEquivalent,
  CABLE_SIZE_AWG_MAP
} from '../../calculators/calculations';
import { CableMaterialOption, CableSizeOption, MaxAcceptableLossOption } from '../../types';
import { analyticsService } from '../../services/analyticsService';
import { historyService } from '../../services/historyService';
import { adService } from '../../services/adService';
import { subscriptionService } from '../../services/subscriptionService';
import { AdBannerPlaceholder } from '../ads/AdBannerPlaceholder';
import { CalculatorUnlockModal } from '../subscription/CalculatorUnlockModal';
import { ShareResultButton } from '../ShareResultButton';
import { CalculatorHeroHeader } from './CalculatorHeroHeader';
import { 
  ArrowLeft, 
  AlertTriangle, 
  CheckCircle2, 
  ArrowRight, 
  SlidersHorizontal,
  Zap,
  Gauge,
  Sparkles,
  ShieldCheck,
  ShieldAlert,
  Layers,
  Award,
  Info,
  ChevronDown,
  ChevronUp,
  Flame,
  Volume2,
  Navigation,
  Minus,
  Plus
} from 'lucide-react';

interface CableLossCalculatorViewProps {
  onBack: () => void;
  onOpenSubscription?: () => void;
}

export const CableLossCalculatorView: React.FC<CableLossCalculatorViewProps> = ({ 
  onBack,
  onOpenSubscription,
}) => {
  const { t, language, setLanguage } = useLanguage();
  const { isNightMode } = useTheme();

  // Screen View Mode: 'input' vs 'result' (Dedicated Screen Pattern)
  const [viewMode, setViewMode] = useState<'input' | 'result'>('input');

  // Input states - preserved across navigation
  const [power, setPower] = useState<number>(500); // Amplifier power per channel (W)
  const [perSpeakerImpedance, setPerSpeakerImpedance] = useState<number>(8); // Nominal impedance of each speaker (2, 4, 8, 16 Ω)
  const [speakerQuantity, setSpeakerQuantity] = useState<number>(4); // Number of speakers connected
  const [wiring, setWiring] = useState<'parallel' | 'series'>('parallel'); // 'parallel' | 'series'
  const [cableLength, setCableLength] = useState<number>(20); // One-way distance (m)
  const [material, setMaterial] = useState<CableMaterialOption>('copper'); // 'copper' | 'cca'
  const [maxAcceptableLoss, setMaxAcceptableLoss] = useState<MaxAcceptableLossOption | null>(null); // null = unselected until user picks (defaults to 5% calculation under the hood if not specified)
  const [showAdvanced, setShowAdvanced] = useState<boolean>(false);
  const [showResultAdvanced, setShowResultAdvanced] = useState<boolean>(false);
  const [tipIndex, setTipIndex] = useState<number>(0);

  // Automatically calculate Final System Impedance based on:
  // - Per Speaker Impedance
  // - Speaker Quantity
  // - Wiring Configuration (Parallel / Series)
  // Formula:
  // Parallel: Per Speaker Impedance / Speaker Quantity
  // Series: Per Speaker Impedance * Speaker Quantity
  const calculatedImpedanceRaw = useMemo(() => {
    if (speakerQuantity <= 0) return perSpeakerImpedance;
    if (wiring === 'parallel') {
      return perSpeakerImpedance / speakerQuantity;
    } else {
      return perSpeakerImpedance * speakerQuantity;
    }
  }, [perSpeakerImpedance, speakerQuantity, wiring]);

  const calculatedImpedance = Math.round(calculatedImpedanceRaw * 100) / 100;
  const formattedImpedance = Number.isInteger(calculatedImpedance)
    ? calculatedImpedance.toString()
    : calculatedImpedance.toFixed(2);

  // Supported range: 2Ω to 16Ω inclusive
  const isImpedanceTooLow = calculatedImpedance < 2;
  const isImpedanceTooHigh = calculatedImpedance > 16;
  const isImpedanceSupported = calculatedImpedance >= 2 && calculatedImpedance <= 16;

  const handleSpeakerQuantityChange = (newQty: number) => {
    const clamped = Math.min(32, Math.max(1, newQty));
    setSpeakerQuantity(clamped);
  };

  const handleWiringChange = (newWiring: 'parallel' | 'series') => {
    setWiring(newWiring);
  };

  const handlePerSpeakerImpedanceChange = (newImp: number) => {
    setPerSpeakerImpedance(newImp);
  };

  // Validation
  const isLengthValid = cableLength > 0;
  const isPowerValid = power > 0;
  const isValid = isLengthValid && isPowerValid && isImpedanceSupported;

  const handleReset = () => {
    setPower(500);
    setPerSpeakerImpedance(8);
    setSpeakerQuantity(4);
    setWiring('parallel');
    setCableLength(20);
    setMaterial('copper');
    setMaxAcceptableLoss(null);
    setViewMode('input');
  };

  // Perform deterministic recommendation calculation (defaults to 5% if not explicitly selected)
  // Only generate recommendations when calculated impedance is within supported range (2Ω to 16Ω inclusive)
  const effectiveMaxLoss = maxAcceptableLoss ?? 5;

  const result = useMemo(() => {
    if (!isImpedanceSupported) return null;
    return calculateCableLoss({
      cableLength: Math.max(0.1, cableLength),
      power: Math.max(1, power),
      load: calculatedImpedance,
      material,
      maxAcceptableLoss: effectiveMaxLoss,
    });
  }, [isImpedanceSupported, cableLength, power, calculatedImpedance, material, effectiveMaxLoss]);

  const isCalculatingRef = useRef(false);

  const [isRewardModalOpen, setIsRewardModalOpen] = useState(false);

  const executeCalculation = () => {
    isCalculatingRef.current = true;
    setTipIndex(Math.floor(Math.random() * 4));

    analyticsService.logCalculationCompleted('cable_loss_calculator', {
      cableLength,
      power,
      load: calculatedImpedance,
      material,
      maxAcceptableLoss: effectiveMaxLoss,
      recommendedSize: result.recommendedCableSize ?? result.displayCableSize,
      resistanceRatioPercent: result.resistanceRatioPercent,
      powerLossPercent: result.actualPowerLossPercent,
      levelLossDb: result.levelLossDb,
      statusBadge: result.statusBadge,
      meetsTarget: result.meetsTarget,
    });

    historyService.addEntry({
      calculatorId: 'calc_cable_loss',
      calculatorName: language === 'hi' ? 'स्पीकर केबल रेकमेंडेशन' : 'Speaker Cable Recommendation',
      resultSummary: result.meetsTarget
        ? `Recommended: ${result.recommendedCableSize} mm² (${result.actualPowerLossPercent}% loss, ${result.levelLossDb} dB)`
        : `Target Exceeded: Lowest loss alternative is ${result.displayCableSize} mm² (${result.actualPowerLossPercent}% loss)`,
      badge: {
        text: result.badgeLabel,
        type: result.statusBadge === 'excellent' || result.statusBadge === 'recommended' ? 'safe' : result.statusBadge === 'acceptable' ? 'warning' : 'danger',
      },
      details: [
        { label: 'Recommended', value: result.recommendedCableSize ? `${result.recommendedCableSize} mm²` : (language === 'hi' ? 'कोई नहीं' : 'None') },
        { label: 'Min Acceptable', value: result.minimumAcceptableSize ? `${result.minimumAcceptableSize} mm²` : (language === 'hi' ? 'कोई नहीं' : 'None') },
        { label: 'Pro Choice', value: result.professionalChoiceSize ? `${result.professionalChoiceSize} mm²` : (language === 'hi' ? 'कोई नहीं' : 'None') },
        { label: 'Per Speaker', value: `${perSpeakerImpedance}Ω` },
        { label: 'Speakers', value: `${speakerQuantity} spk (${wiring})` },
        { label: 'Impedance Load', value: `${formattedImpedance}Ω` },
        { label: 'Resistance Ratio', value: `${result.resistanceRatioPercent}%` },
        { label: 'Power Loss', value: `${result.actualPowerLossPercent}% (${result.powerLossWatts}W)` },
        { label: 'Level Loss', value: `${result.levelLossDb} dB` },
        { label: 'Power Delivered', value: `${result.powerDeliveredWatts}W` },
        { label: 'Efficiency', value: `${result.estimatedEfficiency}%` },
        { label: 'Material', value: material === 'cca' ? 'CCA' : 'Pure Copper' },
        { label: 'Run', value: `${cableLength}m @ ${formattedImpedance}Ω (${power}W)` },
      ],
    });

    setViewMode('result');
    window.scrollTo({ top: 0, behavior: 'smooth' });

    setTimeout(() => {
      isCalculatingRef.current = false;
    }, 400);
  };

  const handleCalculate = () => {
    if (!isValid || !isImpedanceSupported || !result || isCalculatingRef.current) return;

    // 1. Active subscribers bypass ad checks
    if (subscriptionService.isPremium()) {
      executeCalculation();
      return;
    }

    // 2. If 60-minute unlock is still active across all calculators, show result immediately
    if (adService.hasActiveRewardPass()) {
      executeCalculation();
      return;
    }

    setIsRewardModalOpen(true);
  };

  const handleModifyInputs = () => {
    setViewMode('input');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Available speaker impedance options (4Ω, 8Ω, 16Ω, plus 2Ω for subwoofers)
  const perSpeakerImpedanceOptions: number[] = [2, 4, 8, 16];

  // Visual configuration for Status Badges
  const statusBadgeConfig = {
    excellent: {
      bg: isNightMode ? 'bg-emerald-950/40 border-emerald-800/80 text-emerald-200' : 'bg-emerald-50 border-emerald-200 text-emerald-900',
      pillBg: 'bg-emerald-600 text-white',
      accentText: 'text-emerald-500',
      icon: CheckCircle2,
      label: 'Excellent',
      emoji: '🟢',
      summary: language === 'hi' 
        ? 'अत्यधिक कम पावर लॉस (< 2.5%)। बेस एकदम टाइट, पंचदार और क्रिस्टल क्लियर रहेगा।' 
        : 'Negligible power loss (< 2.5%). Tight transient bass response and high damping factor.'
    },
    recommended: {
      bg: isNightMode ? 'bg-emerald-950/40 border-emerald-800/80 text-emerald-200' : 'bg-emerald-50 border-emerald-200 text-emerald-900',
      pillBg: 'bg-emerald-600 text-white',
      accentText: 'text-emerald-500',
      icon: CheckCircle2,
      label: 'Recommended',
      emoji: '🟢',
      summary: language === 'hi'
        ? 'प्रो लाइव साउंड स्टैंडर्ड (< 5% लॉस)। स्टेज और डीजे दोनों के लिए आदर्श संतुलन।'
        : 'Pro live sound standard (< 5% loss). Optimal balance of acoustic punch and efficiency.'
    },
    acceptable: {
      bg: isNightMode ? 'bg-amber-950/40 border-amber-800/80 text-amber-200' : 'bg-amber-50 border-amber-200 text-amber-900',
      pillBg: 'bg-amber-500 text-white',
      accentText: 'text-amber-500',
      icon: AlertTriangle,
      label: 'Acceptable',
      emoji: '🟡',
      summary: language === 'hi'
        ? 'सामान्य प्लेबैक के लिए स्वीकार्य (5%–8%), लेकिन भारी सबवूफर के लिए प्रोफेशनल चॉइस चुनें।'
        : 'Acceptable for vocal/general playback (5%–8%). For high-demand subwoofers, step up to Pro Choice.'
    },
    high_loss: {
      bg: isNightMode ? 'bg-orange-950/40 border-orange-800/80 text-orange-200' : 'bg-orange-50 border-orange-200 text-orange-900',
      pillBg: 'bg-orange-600 text-white',
      accentText: 'text-orange-500',
      icon: AlertTriangle,
      label: 'High Loss',
      emoji: '🟠',
      summary: language === 'hi'
        ? 'काफी अधिक पावर नुकसान (8%–12%)। केबल गर्म होगी और बेस का पंच कमजोर पड़ेगा।'
        : 'Significant cable power dissipation (8%–12%). Cable will heat up and bass punch will soften.'
    },
    not_recommended: {
      bg: isNightMode ? 'bg-red-950/40 border-red-800/80 text-red-200' : 'bg-red-50 border-red-200 text-red-900',
      pillBg: 'bg-red-600 text-white',
      accentText: 'text-red-500',
      icon: ShieldAlert,
      label: 'Not Recommended',
      emoji: '🔴',
      summary: language === 'hi'
        ? 'अत्यधिक पावर लॉस (> 12%)। यह दूरी या लोड इस साइज के लिए उपयुक्त नहीं है।'
        : 'Severe power loss (> 12%). Distance is too long or wire is too thin for this speaker impedance.'
    },
  }[result?.statusBadge || 'recommended'];

  // Helper info for the 3 recommendation tiers (only generated if result exists)
  // Dynamic Hero Card visuals matching Ohm and Amplifier calculators:
  // 2Ω load or high loss/warning -> ORANGE / AMBER
  // Severe loss / not recommended -> RED
  // Safe load (4Ω, 8Ω etc.) and normal loss -> GREEN
  const getHeroCardVisuals = () => {
    const is2OhmLoad = Math.abs(calculatedImpedance - 2) < 0.1 || calculatedImpedance < 2.5;
    const isSevereLoss = result?.statusBadge === 'not_recommended';
    const isWarningLoss = result?.statusBadge === 'acceptable' || result?.statusBadge === 'high_loss';

    if (isSevereLoss) {
      return {
        bannerBg: 'from-[#550C16] via-[#821422] to-[#36080E]',
        glowShadow: 'shadow-[0_10px_30px_rgba(220,38,38,0.45)]',
        borderHighlight: 'border-red-500/80',
        textColor: 'text-red-200',
        accentColor: 'text-red-300',
        badgeBg: 'bg-red-500 text-white',
        tierHighlight: 'text-red-500 dark:text-red-400',
        tierBadgeStyle: 'bg-red-600 text-white border-red-500 shadow-xs',
      };
    }

    if (is2OhmLoad || isWarningLoss) {
      return {
        bannerBg: 'from-[#522004] via-[#85360A] to-[#331302]',
        glowShadow: 'shadow-[0_10px_30px_rgba(234,88,12,0.45)]',
        borderHighlight: 'border-amber-500/80',
        textColor: 'text-amber-200',
        accentColor: 'text-amber-300',
        badgeBg: 'bg-amber-400 text-slate-950 font-black',
        tierHighlight: 'text-amber-600 dark:text-amber-400',
        tierBadgeStyle: 'bg-amber-500 text-slate-950 border-amber-400 font-bold shadow-xs',
      };
    }

    // Safe load (4Ω, 8Ω etc.) with good/recommended loss -> GREEN
    return {
      bannerBg: 'from-[#064E3B] via-[#065F46] to-[#022C22]',
      glowShadow: 'shadow-[0_10px_30px_rgba(16,185,129,0.35)]',
      borderHighlight: 'border-emerald-500/80',
      textColor: 'text-emerald-200',
      accentColor: 'text-emerald-300',
      badgeBg: 'bg-emerald-400 text-slate-950 font-black',
      tierHighlight: 'text-emerald-600 dark:text-emerald-400',
      tierBadgeStyle: 'bg-emerald-600 text-white border-emerald-400 font-bold shadow-xs',
    };
  };

  const heroCardVisuals = getHeroCardVisuals();

  // Helper info for the 3 recommendation tiers (only generated if result exists)
  const tierDetails = result ? [
    {
      id: 'min-acceptable',
      label: t.cableLossMinAcceptable || 'Minimum Acceptable',
      size: result.minimumAcceptableSize,
      awg: result.minimumAcceptableSize ? getAwgEquivalent(result.minimumAcceptableSize) : '',
      desc: result.minimumAcceptableSize ? (t.cableLossMinAcceptableDesc || 'Functional baseline for budget / vocal runs') : (language === 'hi' ? 'कोई भी साइज लक्ष्य पूरा नहीं करता' : 'No size meets target'),
      badge: 'Minimum',
      badgeStyle: isNightMode ? 'bg-slate-800 text-slate-300 border-slate-700' : 'bg-slate-100 text-slate-700 border-slate-200',
    },
    {
      id: 'recommended',
      label: result.meetsTarget ? (t.cableLossCardRecommendedSize || 'Recommended Cable Size') : (t.cableLossLowestLossAlternative || 'Lowest Loss Alternative'),
      size: result.meetsTarget ? result.recommendedCableSize : result.displayCableSize,
      awg: getAwgEquivalent(result.meetsTarget ? result.recommendedCableSize : result.displayCableSize),
      desc: result.meetsTarget ? (t.cableLossRecommendedDesc || 'Optimal balance for live sound & DJ systems') : (language === 'hi' ? 'उपलब्ध गेज में सबसे कम नुकसान (लक्ष्य से अधिक)' : 'Lowest-loss available standard gauge (exceeds target)'),
      badge: result.meetsTarget ? 'Recommended' : 'Alternative',
      badgeStyle: heroCardVisuals.tierBadgeStyle,
      isPrimary: true,
    },
    {
      id: 'pro-choice',
      label: t.cableLossProfessionalChoice || 'Professional Choice',
      size: result.professionalChoiceSize,
      awg: result.professionalChoiceSize ? getAwgEquivalent(result.professionalChoiceSize) : '',
      desc: result.professionalChoiceSize ? (t.cableLossProfessionalChoiceDesc || 'Touring grade for high damping factor & punchy subwoofers') : (language === 'hi' ? 'कोई भी उपलब्ध साइज ≤2.5% प्रो टूरिंग बेंचमार्क पूरा नहीं करता' : 'No available size meets the ≤2.5% touring benchmark'),
      badge: 'Pro Choice',
      badgeStyle: isNightMode ? 'bg-amber-950/60 text-amber-300 border-amber-800' : 'bg-amber-100 text-amber-900 border-amber-200',
    },
  ] : [];

  // Professional Tips for Did You Know? card
  const professionalTips = [
    {
      en: "Speaker cable resistance directly reduces the effective damping factor of your amplifier. Using thicker wire maintains tight, punchy low-frequency transient control.",
      hi: "केबल प्रतिरोध एम्प्लीफायर के डैम्पिंग फैक्टर को घटाता है। मोटी केबल का उपयोग करने से सबवूफर्स का बास टाइट व पंचदार बना रहता है।"
    },
    {
      en: "Damping factor degrades significantly on long cable runs. For subwoofers, keeping cable resistance low is essential for preserving punchy transient response.",
      hi: "लंबी केबल दूरी पर डैम्पिंग फैक्टर काफी घट जाता है। सबवूफर के लिए केबल प्रतिरोध कम रखना पंचदार बास बनाए रखने के लिए अनिवार्य है।"
    },
    {
      en: "2Ω loads draw double the current of 4Ω systems. At 2Ω, even small cable resistance results in noticeable power loss and heating.",
      hi: "2Ω लोड 4Ω सिस्टम की तुलना में दोगुना करंट खींचता है। 2Ω पर मामूली केबल रेजिस्टेंस भी ज्यादा पावर लॉस और केबल हीटिंग पैदा कर सकता है।"
    },
    {
      en: "For runs exceeding 50 meters, moving amplifiers closer to speakers and running balanced XLR signal lines is far more efficient than very long heavy speaker cables.",
      hi: "50 मीटर से अधिक दूरी के लिए, एम्प्लीफायर को स्पीकर के पास रखना और लंबी बैलेंस्ड XLR लाइन चलाना भारी स्पीकर केबल की तुलना में कहीं बेहतर है।"
    }
  ];

  // ==========================================
  // DEDICATED RESULT SCREEN
  // ==========================================
  if (viewMode === 'result') {
    const StatusIcon = statusBadgeConfig.icon;

    return (
      <div className={`min-h-full flex flex-col transition-colors duration-200 ${isNightMode ? 'bg-[#070B14]' : 'bg-[#F8FAFC]'}`}>
        {/* 1. Curved Blue Hero Header */}
        <CalculatorHeroHeader
          title={t.cableLossResultTitle}
          subtitle={t.cableLossResultSubtitle}
          onBack={handleModifyInputs}
        />

        {/* 2. Main Sheet Container */}
        <div className={`flex-1 rounded-t-[36px] -mt-5 relative z-20 px-4 pt-6 pb-28 min-h-[calc(100vh-180px)] transition-colors duration-200 ${
          isNightMode 
            ? 'bg-[#0E1526] text-slate-100 shadow-[0_-10px_35px_rgba(0,0,0,0.5)] border-t border-slate-800/80' 
            : 'bg-white text-slate-900 shadow-[0_-10px_35px_rgba(0,0,0,0.06)]'
        }`}>
          {/* STATUS BADGE BANNER */}
          <div id="banner-status-badge" className={`rounded-2xl p-4 border mb-4 transition-all ${statusBadgeConfig.bg}`}>
            <div className="flex items-center justify-between gap-2 mb-1.5">
              <div className="flex items-center gap-2">
                <span className="text-lg leading-none" role="img" aria-label={statusBadgeConfig.label}>
                  {statusBadgeConfig.emoji}
                </span>
                <span className="font-black text-sm uppercase tracking-wide">
                  {statusBadgeConfig.label}
                </span>
              </div>
              <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${statusBadgeConfig.pillBg}`}>
                {result.powerLossPercent}% Loss
              </span>
            </div>
            <p className="text-xs leading-relaxed opacity-90">
              {statusBadgeConfig.summary}
            </p>
          </div>

          {/* PRIMARY RESULT CARD: RECOMMENDED CABLE SIZE */}
          <div 
            id="card-primary-recommended-size" 
            className={`rounded-2xl p-5 border shadow-sm mb-4 relative transition-all duration-300 ${
              isNightMode 
                ? 'bg-[#131B2A] border-[#1E293B] text-slate-100 shadow-[0_4px_16px_rgba(0,0,0,0.3)]' 
                : 'bg-white border-slate-200 text-slate-900 shadow-[0_4px_16px_rgba(0,0,0,0.04)]'
            }`}
          >
            <div className="flex items-center justify-between mb-3 relative z-10">
              <div className="flex items-center gap-2">
                <span className={`text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full text-white ${
                  result.meetsTarget ? 'bg-emerald-600' : 'bg-red-600'
                }`}>
                  {result.meetsTarget ? t.cableLossCardRecommendedSize : (language === 'hi' ? `लक्ष्य से अधिक (> ${result.maxAcceptableLoss}%)` : `TARGET EXCEEDED (> ${result.maxAcceptableLoss}%)`)}
                </span>
              </div>
              <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1.5 ${
                material === 'cca'
                  ? (isNightMode ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'bg-amber-50 text-amber-800 border border-amber-200')
                  : (isNightMode ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40' : 'bg-blue-50 text-blue-800 border border-blue-200')
              }`}>
                <span>{material === 'cca' ? 'CCA Conductor' : 'OFC Pure Copper'}</span>
              </span>
            </div>

            <div className="mt-2 relative z-10">
              {result.meetsTarget ? (
                <div className="flex items-baseline gap-2">
                  <span className={`text-5xl sm:text-6xl font-black tracking-tight ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                    {result.recommendedCableSize}
                  </span>
                  <span className="text-2xl font-extrabold text-blue-600 dark:text-blue-400">
                    mm²
                  </span>
                  <span className="text-lg font-bold text-slate-400 ml-1">
                    ({getAwgEquivalent(result.recommendedCableSize)})
                  </span>
                </div>
              ) : (
                <div className="py-1">
                  <div className="text-xl sm:text-2xl font-black text-red-500">
                    {t.cableLossNoCableMeetsTarget || 'No available cable meets this target'}
                  </div>
                  <div className="text-xs font-semibold text-slate-400 mt-1.5 flex items-center gap-1.5 flex-wrap">
                    <span>{t.cableLossLowestLossAlternative || 'Lowest-Loss Alternative'}:</span>
                    <span className={`font-black ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                      {result.displayCableSize} mm² ({getAwgEquivalent(result.displayCableSize)})
                    </span>
                    <span className="text-red-400 font-bold">
                      ({result.resistanceRatioPercent}% ratio)
                    </span>
                  </div>
                </div>
              )}

              {/* System Input Specs Summary Grid (Amp Watts, Distance, Speaker Ohms, Total Load) */}
              <div className={`my-3 p-3 rounded-xl border grid grid-cols-2 gap-2 text-xs ${
                isNightMode 
                  ? 'bg-[#0E1526]/80 border-slate-800 text-slate-200' 
                  : 'bg-slate-50/90 border-slate-200 text-slate-700'
              }`}>
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-md bg-amber-500/15 text-amber-500 flex items-center justify-center shrink-0">
                    <Zap className="w-3.5 h-3.5" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-[10px] text-slate-400 font-semibold">{language === 'hi' ? 'एम्प्लीफायर' : 'Amp Power'}</div>
                    <div className="font-extrabold truncate">{power} W</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-md bg-sky-500/15 text-sky-500 flex items-center justify-center shrink-0">
                    <Navigation className="w-3.5 h-3.5" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-[10px] text-slate-400 font-semibold">{language === 'hi' ? 'केबल दूरी' : 'Cable Run'}</div>
                    <div className="font-extrabold truncate">{cableLength} m</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-md bg-purple-500/15 text-purple-500 flex items-center justify-center shrink-0">
                    <Volume2 className="w-3.5 h-3.5" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-[10px] text-slate-400 font-semibold">{language === 'hi' ? 'स्पीकर' : 'Speakers'}</div>
                    <div className="font-extrabold truncate">
                      {speakerQuantity} × {perSpeakerImpedance}Ω ({wiring === 'series' ? (language === 'hi' ? 'सीरीज' : 'Series') : (language === 'hi' ? 'पैरेलल' : 'Parallel')})
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-md bg-emerald-500/15 text-emerald-500 flex items-center justify-center shrink-0">
                    <Layers className="w-3.5 h-3.5" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-[10px] text-slate-400 font-semibold">{language === 'hi' ? 'कुल इम्पीडेंस' : 'Total Load'}</div>
                    <div className="font-extrabold truncate">{formattedImpedance}Ω</div>
                  </div>
                </div>
              </div>

              <p className={`text-xs mt-2 leading-relaxed ${isNightMode ? 'text-slate-300' : 'text-slate-600'}`}>
                {result.meetsTarget
                  ? (language === 'hi' 
                    ? `${cableLength} मीटर की एक तरफा दूरी और ${calculatedImpedance}Ω लोड के लिए ${result.recommendedCableSize} mm² (${getAwgEquivalent(result.recommendedCableSize)}) ${material === 'cca' ? 'CCA' : 'प्योर कॉपर'} सबसे संतुलित व सुरक्षित केबल साइज है।`
                    : `For ${cableLength}m distance into ${calculatedImpedance}Ω load, ${result.recommendedCableSize} mm² (${getAwgEquivalent(result.recommendedCableSize)}) ${material === 'cca' ? 'CCA' : 'pure copper'} is the optimal gauge to preserve acoustic energy and punchy bass.`)
                  : (language === 'hi'
                    ? `${cableLength}m @ ${calculatedImpedance}Ω लोड पर कोई भी उपलब्ध केबल साइज ${result.maxAcceptableLoss}% लक्ष्य पूरा नहीं करता। 10 mm² (${getAwgEquivalent(10)}) न्यूनतम लॉस विकल्प (${result.allSizes[result.allSizes.length - 1].powerLossPercent}%) है।`
                    : `No available cable size meets the ${result.maxAcceptableLoss}% target for ${cableLength}m @ ${calculatedImpedance}Ω load. 10 mm² (${getAwgEquivalent(10)}) provides the lowest loss (${result.allSizes[result.allSizes.length - 1].powerLossPercent}%).`)}
              </p>
              {result.recommendationReason && (
                <div className={`mt-2.5 pt-2 border-t flex items-start gap-1.5 text-[11px] ${
                  isNightMode ? 'border-slate-800 text-slate-300' : 'border-slate-200 text-slate-600'
                }`}>
                  <Info className="w-3.5 h-3.5 shrink-0 mt-0.5 text-amber-500" />
                  <span>{result.recommendationReason}</span>
                </div>
              )}
            </div>
          </div>

          {/* AdMob Banner Area */}
          <div id="banner-ad-result-centered" className="my-3">
            <AdBannerPlaceholder placement="result_bottom" />
          </div>

          {/* 4 PRIMARY RESULT METRICS (Power Lost, Actual Power Loss, Level Loss, Target Status) */}
          <div className="grid grid-cols-2 gap-2.5 sm:gap-3 mb-4">
            {/* CARD 1: POWER LOST */}
            <div 
              id="card-power-loss" 
              className={`rounded-2xl p-3.5 sm:p-4 border transition-all ${
                isNightMode 
                  ? 'bg-[#131B2A] border-[#1E293B] shadow-sm' 
                  : 'bg-white border-slate-200 shadow-xs'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-1.5">
                  <div className="w-6 h-6 rounded-lg bg-amber-500/10 text-amber-500 flex items-center justify-center shrink-0">
                    <Flame className="w-3.5 h-3.5" />
                  </div>
                  <span className={`text-[10px] sm:text-[11px] font-bold uppercase tracking-wider truncate ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                    {t.cableLossPowerLostInCable || 'Power Lost'}
                  </span>
                </div>
              </div>

              <div className="flex items-baseline gap-1 mt-1">
                <span className={`text-2xl sm:text-3xl font-black ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                  {result.powerLossWatts}
                </span>
                <span className="text-xs font-bold text-slate-400">
                  W
                </span>
              </div>
              <p className={`text-[10.5px] mt-1 leading-tight ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                {language === 'hi' ? 'केबल में हीट बनकर नष्ट' : 'Dissipated as heat'}
              </p>
            </div>

            {/* CARD 2: ACTUAL POWER LOSS (%) */}
            <div 
              id="card-actual-power-loss" 
              className={`rounded-2xl p-3.5 sm:p-4 border transition-all ${
                isNightMode 
                  ? 'bg-[#131B2A] border-[#1E293B] shadow-sm' 
                  : 'bg-white border-slate-200 shadow-xs'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-1.5">
                  <div className="w-6 h-6 rounded-lg bg-orange-500/10 text-orange-500 flex items-center justify-center shrink-0">
                    <Gauge className="w-3.5 h-3.5" />
                  </div>
                  <span className={`text-[10px] sm:text-[11px] font-bold uppercase tracking-wider truncate ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                    {t.cableLossActualPowerLoss || 'Actual Loss'}
                  </span>
                </div>
                <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full ${statusBadgeConfig.pillBg}`}>
                  {result.actualPowerLossPercent}%
                </span>
              </div>

              <div className="flex items-baseline gap-1 mt-1">
                <span className={`text-2xl sm:text-3xl font-black ${
                  result.actualPowerLossPercent <= 3.0 ? 'text-emerald-500' :
                  result.actualPowerLossPercent <= 8.0 ? 'text-amber-500' : 'text-red-500'
                }`}>
                  {result.actualPowerLossPercent}%
                </span>
              </div>

              {/* Progress bar */}
              <div className="mt-2">
                <div className={`w-full h-1.5 rounded-full overflow-hidden ${isNightMode ? 'bg-slate-800' : 'bg-slate-100'}`}>
                  <div 
                    className={`h-full transition-all duration-500 ${
                      result.actualPowerLossPercent <= 3.0 ? 'bg-emerald-500' :
                      result.actualPowerLossPercent <= 8.0 ? 'bg-amber-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${Math.min(100, Math.max(5, result.actualPowerLossPercent * 6.5))}%` }}
                  />
                </div>
              </div>
            </div>

            {/* CARD 3: LEVEL LOSS (dB) */}
            <div 
              id="card-level-loss" 
              className={`rounded-2xl p-3.5 sm:p-4 border transition-all ${
                isNightMode 
                  ? 'bg-[#131B2A] border-[#1E293B] shadow-sm' 
                  : 'bg-white border-slate-200 shadow-xs'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-1.5">
                  <div className="w-6 h-6 rounded-lg bg-sky-500/10 text-sky-500 flex items-center justify-center shrink-0">
                    <Volume2 className="w-3.5 h-3.5" />
                  </div>
                  <span className={`text-[10px] sm:text-[11px] font-bold uppercase tracking-wider truncate ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                    {t.cableLossLevelLoss || 'Level Loss'}
                  </span>
                </div>
              </div>

              <div className="flex items-baseline gap-1 mt-1">
                <span className={`text-2xl sm:text-3xl font-black ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                  {result.levelLossDb}
                </span>
                <span className="text-xs font-bold text-slate-400">
                  dB
                </span>
              </div>
              <p className={`text-[10.5px] mt-1 leading-tight ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                {language === 'hi' ? 'सिग्नल SPL दबाव में कमी' : 'Signal level attenuation'}
              </p>
            </div>

            {/* CARD 4: STATUS & EFFICIENCY */}
            <div 
              id="card-cable-efficiency" 
              className={`rounded-2xl p-3.5 sm:p-4 border transition-all ${
                isNightMode 
                  ? 'bg-[#131B2A] border-[#1E293B] shadow-sm' 
                  : 'bg-white border-slate-200 shadow-xs'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-1.5">
                  <div className="w-6 h-6 rounded-lg bg-emerald-500/10 text-emerald-500 flex items-center justify-center shrink-0">
                    <ShieldCheck className="w-3.5 h-3.5" />
                  </div>
                  <span className={`text-[10px] sm:text-[11px] font-bold uppercase tracking-wider truncate ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                    {result.meetsTarget ? (t.cableLossStatusMeetsTarget || 'Meets Target') : (t.cableLossStatusTargetExceeded || 'Target Exceeded')}
                  </span>
                </div>
                <span className={`text-[9.5px] font-bold px-1.5 py-0.2 rounded-full ${
                  result.meetsTarget ? 'bg-emerald-500/15 text-emerald-500' : 'bg-red-500/15 text-red-500'
                }`}>
                  {result.meetsTarget ? 'PASS' : 'EXCEEDED'}
                </span>
              </div>

              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-2xl sm:text-3xl font-black text-emerald-500">
                  {result.estimatedEfficiency}%
                </span>
              </div>
              <p className={`text-[10.5px] mt-1 leading-tight truncate ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                {result.powerDeliveredWatts}W delivered
              </p>
            </div>
          </div>

          {/* ADDITIONAL INFORMATION CARD: RECOMMENDATION TIERS */}
          <div 
            id="card-recommendation-tiers" 
            className={`rounded-2xl p-4 sm:p-5 border mb-4 transition-all ${
              isNightMode 
                ? 'bg-[#131B2A] border-[#1E293B] shadow-sm' 
                : 'bg-white border-slate-200 shadow-xs'
            }`}
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-blue-500/10 text-blue-500 flex items-center justify-center">
                  <Award className="w-4 h-4" />
                </div>
                <h3 className={`text-xs font-bold uppercase tracking-wider ${isNightMode ? 'text-slate-200' : 'text-slate-800'}`}>
                  {language === 'hi' ? 'केबल साइज सुझाव श्रेणियां' : 'Cable Size Recommendation Tiers'}
                </h3>
              </div>
              <span className={`text-[10.5px] font-medium ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                {language === 'hi' ? 'दूरी व लोड अनुसार' : 'Recommendation-Based'}
              </span>
            </div>

            <p className={`text-xs mb-3 ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
              {language === 'hi'
                ? 'यह सुझाव निश्चित आवश्यकता नहीं बल्कि सिस्टम की आवश्यकता व बजट के अनुसार 3 स्तरों में उपलब्ध हैं:'
                : 'Recommendations are tiered based on sound quality requirements and operational demands:'}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {tierDetails.map((tier) => (
                <div 
                  key={tier.id}
                  id={`tier-card-${tier.id}`}
                  className={`rounded-xl p-3 border transition-all ${
                    tier.isPrimary
                      ? isNightMode
                        ? 'bg-blue-950/30 border-blue-700/80 shadow-xs ring-1 ring-blue-600/40'
                        : 'bg-blue-50/70 border-blue-300 shadow-xs ring-1 ring-blue-400/40'
                      : isNightMode
                        ? 'bg-[#0E1526]/60 border-slate-800'
                        : 'bg-slate-50/80 border-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full border ${tier.badgeStyle}`}>
                      {tier.badge}
                    </span>
                    {tier.isPrimary && (
                      <span className={`text-[10px] font-extrabold ${heroCardVisuals.tierHighlight} uppercase tracking-wider`}>
                        ★ {language === 'hi' ? 'सर्वोत्तम' : 'Best Choice'}
                      </span>
                    )}
                  </div>

                  <div className="flex items-baseline gap-1.5 my-1">
                    {tier.size ? (
                      <>
                        <span className={`text-2xl font-black ${
                          tier.isPrimary 
                            ? heroCardVisuals.tierHighlight 
                            : isNightMode ? 'text-white' : 'text-slate-900'
                        }`}>
                          {tier.size}
                        </span>
                        <span className="text-xs font-bold text-slate-400">
                          mm²
                        </span>
                        <span className="text-xs font-semibold text-slate-400 ml-0.5">
                          ({tier.awg})
                        </span>
                      </>
                    ) : (
                      <span className="text-lg font-bold text-red-500">
                        {language === 'hi' ? 'उपलब्ध नहीं' : 'None'}
                      </span>
                    )}
                  </div>

                  <p className={`text-[11px] leading-snug ${isNightMode ? 'text-slate-400' : 'text-slate-600'}`}>
                    {tier.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* CONTEXTUAL SMART WARNINGS (MANDATED FOR RUNS >50m, >100m, 2Ω, CCA, LOSS >10%) */}
          {result.contextualWarnings && result.contextualWarnings.length > 0 && (
            <div id="section-contextual-warnings" className="space-y-2.5 mb-4">
              {result.contextualWarnings.map((warn) => {
                const isDanger = warn.type === 'danger';
                return (
                  <div 
                    key={warn.id}
                    id={`warning-${warn.id}`}
                    className={`rounded-2xl p-4 border flex items-start gap-3 transition-all ${
                      isDanger
                        ? isNightMode
                          ? 'bg-red-950/40 border-red-800/80 text-red-200'
                          : 'bg-red-50 border-red-300 text-red-900'
                        : isNightMode
                          ? 'bg-amber-950/30 border-amber-800/80 text-amber-200'
                          : 'bg-amber-50 border-amber-300 text-amber-900'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
                      isDanger
                        ? 'bg-red-500/20 text-red-500'
                        : 'bg-amber-500/20 text-amber-500'
                    }`}>
                      {warn.iconType === 'extreme_run' ? (
                        <Navigation className="w-4 h-4" />
                      ) : warn.iconType === 'high_loss' ? (
                        <Flame className="w-4 h-4" />
                      ) : warn.iconType === 'high_current' ? (
                        <Zap className="w-4 h-4" />
                      ) : (
                        <AlertTriangle className="w-4 h-4" />
                      )}
                    </div>
                    <div className="flex-1">
                      <h4 className="text-xs font-black uppercase tracking-wide mb-0.5 flex items-center gap-1.5">
                        <span>{warn.title}</span>
                      </h4>
                      <p className="text-xs leading-relaxed font-medium">
                        {warn.message}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* ADVANCED DETAILS & CALCULATIONS ACCORDION (Requirement 5) */}
          <div id="section-advanced-toggle" className="mb-4">
            <button
              type="button"
              id="btn-toggle-result-advanced"
              onClick={() => setShowResultAdvanced(!showResultAdvanced)}
              className={`w-full p-4 rounded-2xl border flex items-center justify-between transition-all ${
                isNightMode
                  ? 'bg-[#131B2A] border-[#1E293B] text-slate-200 hover:bg-[#182337]'
                  : 'bg-white border-slate-200 text-slate-800 hover:bg-slate-50'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-blue-500/10 text-blue-500 flex items-center justify-center shrink-0">
                  <SlidersHorizontal className="w-4 h-4" />
                </div>
                <div className="text-left">
                  <div className="text-xs font-bold uppercase tracking-wide">
                    {t.cableLossAdvancedDetails || 'Advanced Details & Calculations'}
                  </div>
                  <div className="text-[11px] text-slate-400">
                    {showResultAdvanced 
                      ? (t.cableLossHideAdvanced || 'Hide Advanced Details') 
                      : (t.cableLossShowAdvanced || 'Show Resistance Ratio, Loop Resistance & Full Matrix')}
                  </div>
                </div>
              </div>
              {showResultAdvanced ? (
                <ChevronUp className="w-4 h-4 text-slate-400 shrink-0" />
              ) : (
                <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
              )}
            </button>
          </div>

          {showResultAdvanced && (
            <div id="section-result-advanced-content" className="space-y-4 mb-4">
              {/* ADVANCED ELECTRICAL METRICS */}
              <div 
                id="card-advanced-electrical-breakdown" 
                className={`rounded-2xl p-4 sm:p-5 border transition-all ${
                  isNightMode 
                    ? 'bg-[#131B2A] border-[#1E293B] shadow-sm' 
                    : 'bg-white border-slate-200 shadow-xs'
                }`}
              >
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-7 h-7 rounded-lg bg-blue-500/10 text-blue-500 flex items-center justify-center">
                    <Zap className="w-4 h-4" />
                  </div>
                  <h3 className={`text-xs font-bold uppercase tracking-wider ${isNightMode ? 'text-slate-200' : 'text-slate-800'}`}>
                    {language === 'hi' ? 'विद्युत गणना एवं सूत्र' : 'Electrical Calculations & Formulations'}
                  </h3>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className={`p-3 rounded-xl border ${isNightMode ? 'bg-[#0E1526]/80 border-slate-800' : 'bg-slate-50/90 border-slate-200'}`}>
                    <div className="text-[10px] text-slate-400 font-semibold uppercase">{t.cableLossResistanceRatio || 'Resistance Ratio'}</div>
                    <div className="text-lg font-black mt-0.5 text-blue-500">{result.resistanceRatioPercent}%</div>
                    <div className="text-[9.5px] text-slate-400 mt-0.5">(R_loop / R_load) × 100</div>
                  </div>

                  <div className={`p-3 rounded-xl border ${isNightMode ? 'bg-[#0E1526]/80 border-slate-800' : 'bg-slate-50/90 border-slate-200'}`}>
                    <div className="text-[10px] text-slate-400 font-semibold uppercase">{t.cableLossLoopResistance || 'Loop Resistance'}</div>
                    <div className={`text-lg font-black mt-0.5 ${isNightMode ? 'text-white' : 'text-slate-900'}`}>{result.loopResistance} Ω</div>
                    <div className="text-[9.5px] text-slate-400 mt-0.5">2 × rho × L / Area</div>
                  </div>

                  <div className={`p-3 rounded-xl border ${isNightMode ? 'bg-[#0E1526]/80 border-slate-800' : 'bg-slate-50/90 border-slate-200'}`}>
                    <div className="text-[10px] text-slate-400 font-semibold uppercase">{t.cableLossPowerDeliveredSpeaker || 'Speaker Power'}</div>
                    <div className="text-lg font-black mt-0.5 text-emerald-500">{result.powerDeliveredWatts} W</div>
                    <div className="text-[9.5px] text-slate-400 mt-0.5">I² × R_load (rated {power}W)</div>
                  </div>

                  <div className={`p-3 rounded-xl border ${isNightMode ? 'bg-[#0E1526]/80 border-slate-800' : 'bg-slate-50/90 border-slate-200'}`}>
                    <div className="text-[10px] text-slate-400 font-semibold uppercase">{t.cableLossCardVoltDrop || 'Loop Voltage Drop'}</div>
                    <div className={`text-lg font-black mt-0.5 ${isNightMode ? 'text-white' : 'text-slate-900'}`}>{result.voltageDrop} V</div>
                    <div className="text-[9.5px] text-slate-400 mt-0.5">{result.voltageDropPercent}% of V_source</div>
                  </div>
                </div>
              </div>

              {/* NOMINAL RESISTIVE LOAD ASSUMPTION CARD */}
              <div 
                id="card-resistive-load-assumption" 
                className={`rounded-2xl p-4 border flex items-start gap-3 transition-all ${
                  isNightMode 
                    ? 'bg-slate-900/40 border-slate-800 text-slate-300' 
                    : 'bg-slate-50/90 border-slate-200 text-slate-700'
                }`}
              >
                <div className="w-7 h-7 rounded-lg bg-amber-500/10 text-amber-500 flex items-center justify-center shrink-0 mt-0.5">
                  <Info className="w-4 h-4" />
                </div>
                <div className="flex-1">
                  <h4 className={`text-xs font-bold uppercase tracking-wider mb-1 ${isNightMode ? 'text-slate-200' : 'text-slate-800'}`}>
                    {t.cableLossResistiveLoadNoteTitle || 'Nominal Resistive Load Assumption'}
                  </h4>
                  <p className="text-[11px] leading-relaxed opacity-90">
                    {t.cableLossResistiveLoadNoteBody || 'Calculations model the loudspeaker as a nominal resistive load driven by an ideal amplifier voltage source. Dynamic loudspeaker impedance is complex and varies with frequency due to voice-coil inductance and mechanical resonance; real-world results are engineering estimates.'}
                  </p>
                </div>
              </div>

              {/* ALL STANDARD SIZES COMPARISON MATRIX */}
              <div 
                id="card-all-sizes-comparison" 
                className={`rounded-2xl p-4 sm:p-5 border transition-all ${
                  isNightMode 
                    ? 'bg-[#131B2A] border-[#1E293B] shadow-sm' 
                    : 'bg-white border-slate-200 shadow-xs'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-purple-500/10 text-purple-500 flex items-center justify-center">
                      <Layers className="w-4 h-4" />
                    </div>
                    <h3 className={`text-xs font-bold uppercase tracking-wider ${isNightMode ? 'text-slate-200' : 'text-slate-800'}`}>
                      {t.cableLossAllSizesComparison || 'All Standard Cable Sizes Comparison'}
                    </h3>
                  </div>
                  <span className={`text-[10px] font-medium ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                    {cableLength}m @ {calculatedImpedance}Ω
                  </span>
                </div>

                {/* Comparison Table */}
                <div className="overflow-x-auto -mx-2 sm:mx-0">
                  <table className="w-full text-xs text-left border-collapse">
                    <thead>
                      <tr className={`border-b ${isNightMode ? 'border-slate-800 text-slate-400' : 'border-slate-200 text-slate-500'}`}>
                        <th className="py-2 px-2 font-bold uppercase">Size</th>
                        <th className="py-2 px-2 font-bold uppercase">Loop R</th>
                        <th className="py-2 px-2 font-bold uppercase">Ratio</th>
                        <th className="py-2 px-2 font-bold uppercase">Loss</th>
                        <th className="py-2 px-2 font-bold uppercase">Level</th>
                        <th className="py-2 px-2 font-bold uppercase text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className={`divide-y ${isNightMode ? 'divide-slate-800/80' : 'divide-slate-100'}`}>
                      {result.allSizes.map((item) => {
                        const isRec = result.meetsTarget && item.size === result.recommendedCableSize;
                        const isMin = result.meetsTarget && item.size === result.minimumAcceptableSize && !isRec;
                        const isPro = result.meetsTarget && item.size === result.professionalChoiceSize && !isRec;

                        return (
                          <tr 
                            key={item.size}
                            className={`transition-colors ${
                              isRec 
                                ? isNightMode ? 'bg-blue-950/40 font-bold' : 'bg-blue-50/80 font-bold'
                                : ''
                            }`}
                          >
                            <td className="py-2.5 px-2">
                              <div className="flex items-center gap-1.5">
                                <span className={isRec ? 'text-blue-600 dark:text-blue-400 font-extrabold' : ''}>
                                  {item.size} mm²
                                </span>
                                <span className="text-[11px] text-slate-400 font-medium">
                                  ({getAwgEquivalent(item.size)})
                                </span>
                                {isRec && (
                                  <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-blue-600 text-white font-black">
                                    REC
                                  </span>
                                )}
                                {isPro && (
                                  <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-500 font-bold">
                                    PRO
                                  </span>
                                )}
                                {isMin && (
                                  <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-slate-500/20 text-slate-400 font-bold">
                                    MIN
                                  </span>
                                )}
                              </div>
                            </td>
                            <td className={`py-2.5 px-2 ${isNightMode ? 'text-slate-300' : 'text-slate-700'}`}>
                              {item.loopResistance} Ω
                            </td>
                            <td className={`py-2.5 px-2 font-semibold ${item.isCompliant ? 'text-blue-500' : 'text-slate-400'}`}>
                              {item.resistanceRatioPercent}%
                            </td>
                            <td className={`py-2.5 px-2 font-bold ${
                              item.actualPowerLossPercent <= 3.0 ? 'text-emerald-500' :
                              item.actualPowerLossPercent <= 8.0 ? 'text-amber-500' : 'text-red-500'
                            }`}>
                              {item.actualPowerLossPercent}%
                            </td>
                            <td className={`py-2.5 px-2 font-medium ${isNightMode ? 'text-slate-300' : 'text-slate-700'}`}>
                              {item.levelLossDb} dB
                            </td>
                            <td className="py-2.5 px-2 text-right">
                              <span className="inline-flex items-center gap-1 font-semibold text-[11px]">
                                <span>{item.badgeEmoji}</span>
                                <span className="hidden sm:inline">{item.badgeLabel}</span>
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
                <p className={`text-[10px] mt-2.5 italic ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                  * {t.cableLossAwgNote || 'AWG values are approximate equivalents.'}
                </p>
              </div>

              {/* SYSTEM SPECIFICATIONS CARD */}
              <div 
                id="card-system-specifications" 
                className={`rounded-2xl p-4 sm:p-5 border transition-all ${
                  isNightMode 
                    ? 'bg-[#131B2A] border-[#1E293B] shadow-sm' 
                    : 'bg-white border-slate-200 shadow-xs'
                }`}
              >
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-7 h-7 rounded-lg bg-slate-500/10 text-slate-500 flex items-center justify-center">
                    <SlidersHorizontal className="w-4 h-4" />
                  </div>
                  <h3 className={`text-xs font-bold uppercase tracking-wider ${isNightMode ? 'text-slate-200' : 'text-slate-800'}`}>
                    {t.specifications}
                  </h3>
                </div>

                <div className={`divide-y text-xs ${isNightMode ? 'divide-slate-800' : 'divide-slate-100'}`}>
                  <div className="flex justify-between py-2">
                    <span className={isNightMode ? 'text-slate-400' : 'text-slate-500'}>
                      {t.cableLossLossTargetUsed || 'Loss Target Used'}
                    </span>
                    <span className="font-bold text-blue-600 dark:text-blue-400">
                      {effectiveMaxLoss}% {language === 'hi' ? 'रेजिस्टेंस अनुपात लक्ष्य' : 'Resistance-Ratio Target'}
                    </span>
                  </div>

                  <div className="flex justify-between py-2">
                    <span className={isNightMode ? 'text-slate-400' : 'text-slate-500'}>
                      {language === 'hi' ? 'स्पीकर संख्या' : 'Speaker Quantity'}
                    </span>
                    <span className={`font-bold ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                      {speakerQuantity} {speakerQuantity === 1 ? (language === 'hi' ? 'स्पीकर' : 'speaker') : (language === 'hi' ? 'स्पीकर्स' : 'speakers')}
                    </span>
                  </div>

                  <div className="flex justify-between py-2">
                    <span className={isNightMode ? 'text-slate-400' : 'text-slate-500'}>
                      {language === 'hi' ? 'वायरिंग प्रकार' : 'Wiring Configuration'}
                    </span>
                    <span className={`font-bold ${wiring === 'parallel' ? 'text-blue-600 dark:text-blue-400' : 'text-purple-600 dark:text-purple-400'}`}>
                      {wiring === 'parallel' ? (language === 'hi' ? 'पैरलल' : 'Parallel') : (language === 'hi' ? 'सीरीज' : 'Series')}
                    </span>
                  </div>

                  <div className="flex justify-between py-2">
                    <span className={isNightMode ? 'text-slate-400' : 'text-slate-500'}>
                      {t.cableLossPower}
                    </span>
                    <span className={`font-bold ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                      {power} {t.units.watts} / Channel
                    </span>
                  </div>

                  <div className="flex justify-between py-2">
                    <span className={isNightMode ? 'text-slate-400' : 'text-slate-500'}>
                      {t.cableLossLoad}
                    </span>
                    <span className={`font-bold ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                      {calculatedImpedance} {t.units.ohms}
                    </span>
                  </div>

                  <div className="flex justify-between py-2">
                    <span className={isNightMode ? 'text-slate-400' : 'text-slate-500'}>
                      {t.cableLossLength}
                    </span>
                    <span className={`font-bold ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                      {cableLength} {t.cableLossLengthUnit}
                    </span>
                  </div>

                  <div className="py-2">
                    <div className="flex justify-between">
                      <span className={isNightMode ? 'text-slate-400' : 'text-slate-500'}>
                        {t.cableLossLoopLength || 'Loop Length'}
                      </span>
                      <span className={`font-bold ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                        {cableLength * 2} m
                      </span>
                    </div>
                    <p className={`text-[10px] mt-0.5 leading-normal ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                      {t.cableLossLoopLengthHelper || 'Loop length includes both outgoing and return conductors.'}
                    </p>
                  </div>

                  <div className="flex justify-between py-2">
                    <span className={isNightMode ? 'text-slate-400' : 'text-slate-500'}>
                      {t.cableLossMaterial}
                    </span>
                    <span className={`font-bold ${material === 'cca' ? 'text-amber-500' : 'text-emerald-500'}`}>
                      {result.materialName}
                    </span>
                  </div>

                  <div className="flex justify-between py-2">
                    <span className={isNightMode ? 'text-slate-400' : 'text-slate-500'}>
                      {t.cableLossLoopResistance} ({result.displayCableSize} mm² / {getAwgEquivalent(result.displayCableSize)})
                    </span>
                    <span className="font-bold text-blue-600 dark:text-blue-400">
                      {result.loopResistance} {t.units.ohms}
                    </span>
                  </div>

                  <div className="flex justify-between py-2">
                    <span className={isNightMode ? 'text-slate-400' : 'text-slate-500'}>
                      {t.cableLossResistanceRatio || 'Resistance Ratio'}
                    </span>
                    <span className="font-bold text-blue-600 dark:text-blue-400">
                      {result.resistanceRatioPercent}%
                    </span>
                  </div>

                  <div className="flex justify-between py-2">
                    <span className={isNightMode ? 'text-slate-400' : 'text-slate-500'}>
                      {t.cableLossTotalImpedance}
                    </span>
                    <span className={`font-bold ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                      {Math.round((calculatedImpedance + result.loopResistance) * 1000) / 1000} {t.units.ohms}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* "DID YOU KNOW?" EDUCATIONAL TIP CARD */}
          <div 
            id="card-did-you-know" 
            className={`rounded-2xl p-4 border mb-4 flex items-start gap-3 transition-all ${
              isNightMode 
                ? 'bg-blue-950/20 border-blue-900/60 text-blue-200' 
                : 'bg-blue-50/70 border-blue-200 text-blue-950'
            }`}
          >
            <div className="w-8 h-8 rounded-xl bg-blue-500/20 text-blue-500 flex items-center justify-center shrink-0 mt-0.5">
              <Sparkles className="w-4 h-4" />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between mb-1">
                <h4 className="text-xs font-black uppercase tracking-wide text-blue-600 dark:text-blue-400">
                  {t.cableLossDidYouKnow || 'Did You Know?'}
                </h4>
                <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                  isNightMode ? 'bg-blue-900/40 text-blue-300' : 'bg-blue-100 text-blue-800'
                }`}>
                  {t.cableLossProfessionalTipTitle || 'Professional Tip'}
                </span>
              </div>
              <p className="text-xs leading-relaxed opacity-90 font-medium">
                {language === 'hi'
                  ? professionalTips[tipIndex % professionalTips.length].hi
                  : professionalTips[tipIndex % professionalTips.length].en}
              </p>
            </div>
          </div>

          {/* SHARE RESULT BUTTON */}
          <ShareResultButton
            calculatorTitle="CABLE LOSS CALCULATION"
            systemDetails={[
              `One-Way Run: ${cableLength} Meters (${cableLength * 2}m loop)`,
              `Total Power: ${power}W RMS`,
              `Speaker Load: ${calculatedImpedance}Ω`,
              `Conductor: ${result.materialName}`,
              `Target Loss: Max ${effectiveMaxLoss}%`,
            ]}
            finalResults={[
              {
                label: 'Recommended Gauge',
                value: result.recommendedCableSize ? `${result.recommendedCableSize} mm²` : 'None (Target Exceeded)',
              },
              {
                label: 'Min Acceptable',
                value: result.minimumAcceptableSize ? `${result.minimumAcceptableSize} mm²` : 'None',
              },
              {
                label: 'Pro Touring Choice',
                value: result.professionalChoiceSize ? `${result.professionalChoiceSize} mm²` : 'None',
              },
              {
                label: 'Resistance Ratio',
                value: `${result.resistanceRatioPercent}%`,
              },
              {
                label: 'Actual Power Loss',
                value: `${result.actualPowerLossPercent}% (${result.powerLossWatts}W)`,
              },
              {
                label: 'Level Loss',
                value: `${result.levelLossDb} dB`,
              },
              {
                label: 'Power to Speaker',
                value: `${result.powerDeliveredWatts} W`,
              },
              {
                label: 'Delivery Efficiency',
                value: `${result.estimatedEfficiency}%`,
              },
              {
                label: 'Loop Resistance',
                value: `${result.loopResistance} Ω`,
              },
            ]}
            warning={
              result.contextualWarnings && result.contextualWarnings.length > 0 
                ? result.contextualWarnings.map(w => w.message).join(' | ') 
                : null
            }
            className="mb-3"
          />

          {/* BOTTOM MODIFY INPUTS CTA BUTTON */}
          <button
            type="button"
            id="btn-modify-inputs-bottom"
            onClick={handleModifyInputs}
            className="w-full flex items-center justify-center gap-2 bg-[#FBBF24] hover:bg-[#F59E0B] text-[#0F172A] font-black py-3.5 px-4 rounded-xl shadow-md transition active:scale-[0.99] border border-amber-300/80"
          >
            <ArrowLeft className="w-4 h-4 stroke-[2.5]" />
            <span>{t.cableLossModifyInputs}</span>
          </button>
        </div>
      </div>
    );
  }

  // ==========================================
  // INPUT VIEW (DEDICATED SCREEN)
  // ==========================================
  return (
    <div className={`min-h-full flex flex-col transition-colors duration-200 ${isNightMode ? 'bg-[#070B14]' : 'bg-[#F8FAFC]'}`}>
      {/* 1. Curved Blue Hero Header */}
      <CalculatorHeroHeader
        title={t.cableLossCalcTitle}
        subtitle={t.cableLossCalcDesc}
        onBack={onBack}
        actions={
          <div className="bg-black/20 backdrop-blur-md p-1 rounded-full border border-white/20 inline-flex items-center">
            <button
              type="button"
              onClick={() => setLanguage('en')}
              className={`px-3 py-1 rounded-full text-[11px] font-bold transition-all ${
                language === 'en'
                  ? 'bg-white text-[#1D4ED8] shadow-xs'
                  : 'text-white/80 hover:text-white'
              }`}
            >
              English
            </button>
            <button
              type="button"
              onClick={() => setLanguage('hi')}
              className={`px-3 py-1 rounded-full text-[11px] font-bold transition-all ${
                language === 'hi'
                  ? 'bg-white text-[#1D4ED8] shadow-xs'
                  : 'text-white/80 hover:text-white'
              }`}
            >
              हिंदी
            </button>
          </div>
        }
      />

      {/* 2. Main Sheet Container */}
      <div className={`flex-1 rounded-t-[36px] -mt-5 relative z-20 px-4 pt-6 pb-36 min-h-[calc(100vh-180px)] transition-colors duration-200 ${
        isNightMode 
          ? 'bg-[#0E1526] text-slate-100 shadow-[0_-10px_35px_rgba(0,0,0,0.5)] border-t border-slate-800/80' 
          : 'bg-white text-slate-900 shadow-[0_-10px_35px_rgba(0,0,0,0.06)]'
      }`}>
        <div className="space-y-4">
          {/* INPUT 1: AMPLIFIER POWER (PER CHANNEL) */}
          <div 
            id="input-card-amplifier-power"
            className={`rounded-2xl p-4 sm:p-5 border transition-all ${
              isNightMode 
                ? 'bg-[#131B2A] border-[#1E293B] shadow-sm' 
                : 'bg-white border-slate-200 shadow-xs'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <label htmlFor="input-amplifier-power" className={`text-xs font-bold uppercase tracking-wide ${isNightMode ? 'text-slate-100' : 'text-slate-900'}`}>
                1. {t.cableLossPower}
              </label>
              <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${isNightMode ? 'bg-slate-800 text-slate-300' : 'bg-slate-100 text-slate-600'}`}>
                {t.cableLossPowerUnit} (W)
              </span>
            </div>

            <div className={`flex items-center justify-between p-1.5 sm:p-2 rounded-[20px] border shadow-2xs transition-colors ${
              isNightMode ? 'bg-[#141C30] border-slate-800' : 'bg-[#F8FAFC] border-slate-200'
            }`}>
              <button
                type="button"
                id="btn-power-decrease"
                onClick={() => setPower(prev => Math.max(50, prev - 50))}
                className={`w-11 h-11 rounded-[16px] flex items-center justify-center font-bold transition active:scale-95 shrink-0 ${
                  isNightMode 
                    ? 'bg-slate-800 border border-slate-700/60 hover:bg-slate-700 text-slate-100' 
                    : 'bg-[#EEF2F8] border border-slate-200/80 hover:bg-slate-200 text-slate-800'
                }`}
                aria-label="Decrease power by 50W"
              >
                <Minus className="w-4 h-4 stroke-[3]" />
              </button>

              <div className="flex-1 flex items-baseline justify-center gap-1.5 min-w-0">
                <input
                  id="input-amplifier-power"
                  type="number"
                  min={1}
                  step={50}
                  value={power === 0 ? '' : power}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    setPower(isNaN(val) ? 0 : val);
                  }}
                  className={`text-center text-2xl font-black tracking-tight bg-transparent border-b-2 border-transparent hover:border-slate-400 focus:border-[#1D4ED8] focus:outline-none py-0.5 transition [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none ${
                    !isPowerValid 
                      ? 'text-red-500' 
                      : isNightMode ? 'text-white' : 'text-slate-900'
                  }`}
                  style={{ width: `${Math.max(3, String(power || '').length + 1)}ch` }}
                  placeholder="500"
                />
                <span className="text-xs font-semibold text-slate-400 select-none shrink-0">
                  {language === 'hi' ? 'वाट' : 'Watts'}
                </span>
              </div>

              <button
                type="button"
                id="btn-power-increase"
                onClick={() => setPower(prev => prev + 50)}
                className={`w-11 h-11 rounded-[16px] flex items-center justify-center font-bold transition active:scale-95 shrink-0 ${
                  isNightMode 
                    ? 'bg-slate-800 border border-slate-700/60 hover:bg-slate-700 text-slate-100' 
                    : 'bg-[#EEF2F8] border border-slate-200/80 hover:bg-slate-200 text-slate-800'
                }`}
                aria-label="Increase power by 50W"
              >
                <Plus className="w-4 h-4 stroke-[3]" />
              </button>
            </div>

            {!isPowerValid && (
              <div id="power-validation-warning" className="flex items-start gap-1.5 mt-2 p-2 bg-red-50 border border-red-200 rounded-lg text-red-800 text-xs">
                <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                <span>{t.cableLossPowerMinWarning}</span>
              </div>
            )}
          </div>

          {/* INPUT 2, 3, 4: SPEAKER LOAD, WIRING & QUANTITY */}
          <div 
            id="input-card-speaker-load"
            className={`rounded-2xl p-4 sm:p-5 border transition-all ${
              isNightMode 
                ? 'bg-[#131B2A] border-[#1E293B] shadow-sm' 
                : 'bg-white border-slate-200 shadow-xs'
            }`}
          >
            {/* Step 2: Per Speaker Impedance */}
            <div className="mb-3 pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center justify-between mb-1.5">
                <label className={`text-xs font-bold uppercase tracking-wide ${isNightMode ? 'text-slate-100' : 'text-slate-900'}`}>
                  2. {language === 'hi' ? 'प्रति स्पीकर ओम' : 'Per-Speaker Impedance'}
                </label>
                <span className={`text-[11px] font-bold px-2 py-0.5 rounded-md ${isNightMode ? 'bg-slate-800 text-slate-300' : 'bg-slate-100 text-slate-600'}`}>
                  {perSpeakerImpedance}Ω
                </span>
              </div>

              <div className="grid grid-cols-4 gap-1.5">
                {perSpeakerImpedanceOptions.map((imp) => (
                  <button
                    key={imp}
                    type="button"
                    id={`btn-per-speaker-imp-${imp}`}
                    onClick={() => handlePerSpeakerImpedanceChange(imp)}
                    className={`py-2 rounded-xl border text-center font-bold text-sm transition active:scale-95 ${
                      perSpeakerImpedance === imp
                        ? 'bg-[#1D4ED8] text-white border-blue-600 shadow-xs'
                        : isNightMode
                          ? 'bg-slate-800/80 hover:bg-slate-800 text-slate-300 border-slate-700'
                          : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                    }`}
                  >
                    {imp}Ω
                  </button>
                ))}
              </div>
            </div>

            {/* Step 3: Wiring Method (Parallel vs Series) */}
            <div className="mb-3 pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center justify-between mb-1.5">
                <label className={`text-xs font-bold uppercase tracking-wide ${isNightMode ? 'text-slate-100' : 'text-slate-900'}`}>
                  3. {language === 'hi' ? 'वायरिंग प्रकार' : 'Wiring Method'}
                </label>
                <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-md ${
                  wiring === 'parallel'
                    ? isNightMode ? 'bg-blue-950/60 text-blue-300 border border-blue-800/80' : 'bg-blue-50 text-blue-700 border border-blue-200'
                    : isNightMode ? 'bg-purple-950/60 text-purple-300 border border-purple-800/80' : 'bg-purple-50 text-purple-700 border border-purple-200'
                }`}>
                  {wiring === 'parallel' ? (language === 'hi' ? 'पैरलल' : 'Parallel') : (language === 'hi' ? 'सीरीज' : 'Series')}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  id="btn-wiring-parallel"
                  onClick={() => handleWiringChange('parallel')}
                  className={`py-2 px-3 rounded-xl border text-center font-bold text-xs sm:text-sm transition active:scale-95 flex items-center justify-center gap-1.5 ${
                    wiring === 'parallel'
                      ? 'bg-[#1D4ED8] text-white border-blue-600 shadow-xs'
                      : isNightMode
                        ? 'bg-slate-800/80 hover:bg-slate-800 text-slate-300 border-slate-700'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                  }`}
                >
                  <span>{language === 'hi' ? 'पैरलल' : 'Parallel'}</span>
                </button>

                <button
                  type="button"
                  id="btn-wiring-series"
                  onClick={() => handleWiringChange('series')}
                  className={`py-2 px-3 rounded-xl border text-center font-bold text-xs sm:text-sm transition active:scale-95 flex items-center justify-center gap-1.5 ${
                    wiring === 'series'
                      ? 'bg-[#1D4ED8] text-white border-blue-600 shadow-xs'
                      : isNightMode
                        ? 'bg-slate-800/80 hover:bg-slate-800 text-slate-300 border-slate-700'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                  }`}
                >
                  <span>{language === 'hi' ? 'सीरीज' : 'Series'}</span>
                </button>
              </div>
            </div>

            {/* Step 4: Speaker Quantity with +/- Stepper */}
            <div className="mb-3 pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center justify-between mb-1.5">
                <label className={`text-xs font-bold uppercase tracking-wide ${isNightMode ? 'text-slate-100' : 'text-slate-900'}`}>
                  4. {language === 'hi' ? 'स्पीकर संख्या' : 'Speaker Quantity'}
                </label>
                <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-md ${isNightMode ? 'bg-slate-800 text-slate-400' : 'bg-slate-100 text-slate-500'}`}>
                  {language === 'hi' ? 'प्रति चैनल' : 'Per Channel'}
                </span>
              </div>

              {/* Standardized Unified Stepper */}
              <div className={`flex items-center justify-between p-1.5 sm:p-2 rounded-[20px] border shadow-2xs transition-colors ${
                isNightMode ? 'bg-[#141C30] border-slate-800' : 'bg-[#F8FAFC] border-slate-200'
              }`}>
                <button
                  type="button"
                  id="btn-speaker-qty-minus"
                  disabled={speakerQuantity <= 1}
                  onClick={() => handleSpeakerQuantityChange(speakerQuantity - 1)}
                  className={`w-11 h-11 rounded-[16px] flex items-center justify-center font-bold transition active:scale-95 disabled:opacity-30 disabled:pointer-events-none shrink-0 ${
                    isNightMode 
                      ? 'bg-slate-800 border border-slate-700/60 hover:bg-slate-700 text-slate-100' 
                      : 'bg-[#EEF2F8] border border-slate-200/80 hover:bg-slate-200 text-slate-800'
                  }`}
                  aria-label="Decrease speaker quantity"
                >
                  <Minus className="w-4 h-4 stroke-[3]" />
                </button>

                <div className="flex-1 flex items-baseline justify-center gap-1.5 min-w-0">
                  <span className={`text-2xl font-black tracking-tight ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                    {speakerQuantity}
                  </span>
                  <span className="text-xs font-semibold text-slate-400 select-none shrink-0">
                    {speakerQuantity === 1 
                      ? (language === 'hi' ? 'स्पीकर' : 'speaker') 
                      : (language === 'hi' ? 'स्पीकर्स' : 'speakers')}
                  </span>
                </div>

                <button
                  type="button"
                  id="btn-speaker-qty-plus"
                  disabled={speakerQuantity >= 32}
                  onClick={() => handleSpeakerQuantityChange(speakerQuantity + 1)}
                  className={`w-11 h-11 rounded-[16px] flex items-center justify-center font-bold transition active:scale-95 disabled:opacity-30 disabled:pointer-events-none shrink-0 ${
                    isNightMode 
                      ? 'bg-slate-800 border border-slate-700/60 hover:bg-slate-700 text-slate-100' 
                      : 'bg-[#EEF2F8] border border-slate-200/80 hover:bg-slate-200 text-slate-800'
                  }`}
                  aria-label="Increase speaker quantity"
                >
                  <Plus className="w-4 h-4 stroke-[3]" />
                </button>
              </div>
            </div>

            {/* Step 2d: Final System Impedance (Safe Standard Range) */}
            <div className="pt-2">
              <div
                id="display-calculated-impedance"
                className={`p-3 rounded-xl border flex items-center justify-between transition-colors ${
                  !isImpedanceSupported
                    ? isNightMode ? 'bg-red-950/30 border-red-800/60 text-red-200' : 'bg-red-50 border-red-200 text-red-900'
                    : isNightMode ? 'bg-[#1E293B] border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                }`}
              >
                <div>
                  <div className="text-[11px] font-bold opacity-80 uppercase tracking-wider">
                    {language === 'hi' ? 'फाइनल सिस्टम लोड' : 'Total System Load'}
                  </div>
                  <div className="text-xs opacity-75 mt-0.5">
                    {speakerQuantity} × {perSpeakerImpedance}Ω ({wiring === 'parallel' ? 'Parallel' : 'Series'})
                  </div>
                </div>
                <div className="text-right">
                  <span className={`text-xl font-black ${
                    !isImpedanceSupported 
                      ? 'text-red-500 dark:text-red-400' 
                      : 'text-blue-600 dark:text-blue-400'
                  }`}>
                    {formattedImpedance}Ω
                  </span>
                  <div className={`text-[10px] font-bold mt-0.5 ${
                    isImpedanceSupported ? 'text-emerald-500' : 'text-red-500'
                  }`}>
                    {isImpedanceSupported 
                      ? (language === 'hi' ? 'सेफ लोड (2Ω–16Ω)' : 'Safe Standard (2Ω–16Ω)') 
                      : (language === 'hi' ? 'अमान्य सीमा' : 'Invalid Range')}
                  </div>
                </div>
              </div>

              {/* Impedance Warning if outside 2Ω-16Ω */}
              {!isImpedanceSupported && (
                <div 
                  id="impedance-warning-compact"
                  className={`p-2.5 mt-2 rounded-xl border text-xs flex items-center gap-2 ${
                    isNightMode ? 'bg-red-950/40 border-red-800/80 text-red-200' : 'bg-red-50 border-red-300 text-red-900'
                  }`}
                >
                  <ShieldAlert className="w-4 h-4 text-red-500 shrink-0" />
                  <span>
                    {isImpedanceTooLow
                      ? (language === 'hi' ? 'इम्पीडेंस 2Ω से कम है। स्पीकर संख्या घटाएं या सीरीज वायरिंग चुनें।' : 'Impedance below 2Ω. Reduce speaker quantity or switch to series wiring.')
                      : (language === 'hi' ? 'इम्पीडेंस 16Ω से अधिक है। स्पीकर संख्या घटाएं या पैरलल वायरिंग चुनें।' : 'Impedance above 16Ω. Reduce speaker quantity or switch to parallel wiring.')}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Ad Banner Placement below Safe Standard Range */}
          <div id="banner-ad-below-safe-standard" className="my-1">
            <AdBannerPlaceholder placement="result_bottom" />
          </div>

          {/* INPUT 5: CABLE LENGTH (ONE WAY) */}
          <div 
            id="input-card-cable-length"
            className={`rounded-2xl p-3.5 sm:p-4 border transition-all ${
              isNightMode 
                ? 'bg-[#131B2A] border-[#1E293B] shadow-xs' 
                : 'bg-white border-slate-200 shadow-xs'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <label htmlFor="input-cable-length" className={`text-xs font-bold uppercase tracking-wide ${isNightMode ? 'text-slate-100' : 'text-slate-900'}`}>
                5. {t.cableLossLength}
              </label>
              <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${isNightMode ? 'bg-slate-800 text-slate-300' : 'bg-slate-100 text-slate-600'}`}>
                {t.cableLossLengthUnit} (m)
              </span>
            </div>

            {/* Standardized Unified Stepper for Cable Length */}
            <div className={`flex items-center justify-between p-1.5 sm:p-2 rounded-[20px] border shadow-2xs transition-colors ${
              isNightMode ? 'bg-[#141C30] border-slate-800' : 'bg-[#F8FAFC] border-slate-200'
            }`}>
              <button
                type="button"
                id="btn-cable-length-minus"
                disabled={cableLength <= 1}
                onClick={() => setCableLength(prev => Math.max(1, prev - 5))}
                className={`w-11 h-11 rounded-[16px] flex items-center justify-center font-bold transition active:scale-95 disabled:opacity-30 disabled:pointer-events-none shrink-0 ${
                  isNightMode 
                    ? 'bg-slate-800 border border-slate-700/60 hover:bg-slate-700 text-slate-100' 
                    : 'bg-[#EEF2F8] border border-slate-200/80 hover:bg-slate-200 text-slate-800'
                }`}
                aria-label="Decrease cable length"
              >
                <Minus className="w-4 h-4 stroke-[3]" />
              </button>

              <div className="flex-1 flex items-baseline justify-center gap-1.5 min-w-0">
                <input
                  id="input-cable-length"
                  type="number"
                  min={1}
                  max={500}
                  step={1}
                  value={cableLength === 0 ? '' : cableLength}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    setCableLength(isNaN(val) ? 0 : Math.min(500, val));
                  }}
                  className={`text-center text-2xl font-black tracking-tight bg-transparent border-b-2 border-transparent hover:border-slate-400 focus:border-[#1D4ED8] focus:outline-none py-0.5 transition [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none ${
                    !isLengthValid 
                      ? 'text-red-500' 
                      : isNightMode ? 'text-white' : 'text-slate-900'
                  }`}
                  style={{ width: `${Math.max(3, String(cableLength || '').length + 1)}ch` }}
                  placeholder="20"
                />
                <span className="text-xs font-semibold text-slate-400 select-none shrink-0">
                  {language === 'hi' ? 'मीटर' : 'm (One Way)'}
                </span>
              </div>

              <button
                type="button"
                id="btn-cable-length-plus"
                onClick={() => setCableLength(prev => Math.min(500, prev + 5))}
                className={`w-11 h-11 rounded-[16px] flex items-center justify-center font-bold transition active:scale-95 shrink-0 ${
                  isNightMode 
                    ? 'bg-slate-800 border border-slate-700/60 hover:bg-slate-700 text-slate-100' 
                    : 'bg-[#EEF2F8] border border-slate-200/80 hover:bg-slate-200 text-slate-800'
                }`}
                aria-label="Increase cable length"
              >
                <Plus className="w-4 h-4 stroke-[3]" />
              </button>
            </div>

            {!isLengthValid && (
              <div id="length-validation-warning" className="flex items-start gap-1.5 mt-2 p-2 bg-red-50 border border-red-200 rounded-lg text-red-800 text-xs">
                <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                <span>{t.cableLossLengthMinWarning}</span>
              </div>
            )}
          </div>

          {/* INPUT 6: CABLE MATERIAL (COPPER VS CCA) */}
          <div 
            id="input-card-cable-material"
            className={`rounded-2xl p-3.5 sm:p-4 border transition-all ${
              isNightMode 
                ? 'bg-[#131B2A] border-[#1E293B] shadow-xs' 
                : 'bg-white border-slate-200 shadow-xs'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <label className={`text-xs font-bold uppercase tracking-wide ${isNightMode ? 'text-slate-100' : 'text-slate-900'}`}>
                6. {t.cableLossMaterial}
              </label>
              <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${
                material === 'copper' 
                  ? 'bg-emerald-500/10 text-emerald-500' 
                  : 'bg-amber-500/10 text-amber-500'
              }`}>
                {material === 'copper' ? 'OFC Pure' : 'CCA (~1.6x R)'}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {/* Option 1: Pure Copper */}
              <button
                type="button"
                id="btn-material-copper"
                onClick={() => setMaterial('copper')}
                className={`py-2 px-2.5 rounded-xl border text-center transition active:scale-[0.99] ${
                  material === 'copper'
                    ? isNightMode
                      ? 'bg-blue-950/40 border-blue-600 ring-1 ring-blue-500 shadow-xs'
                      : 'bg-blue-50 border-blue-600 ring-1 ring-blue-500 shadow-xs'
                    : isNightMode
                      ? 'bg-slate-800/60 hover:bg-slate-800 border-slate-700 text-slate-300'
                      : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
                }`}
              >
                <div className={`font-bold text-xs sm:text-sm ${material === 'copper' ? 'text-blue-600 dark:text-blue-400' : ''}`}>
                  {t.cableLossMaterialCopper}
                </div>
                <div className="text-[10px] text-slate-400">
                  {language === 'hi' ? 'मानक तांबा' : 'Pure Copper'}
                </div>
              </button>

              {/* Option 2: CCA */}
              <button
                type="button"
                id="btn-material-cca"
                onClick={() => setMaterial('cca')}
                className={`py-2 px-2.5 rounded-xl border text-center transition active:scale-[0.99] ${
                  material === 'cca'
                    ? isNightMode
                      ? 'bg-amber-950/40 border-amber-600 ring-1 ring-amber-500 shadow-xs'
                      : 'bg-amber-50 border-amber-600 ring-1 ring-amber-500 shadow-xs'
                    : isNightMode
                      ? 'bg-slate-800/60 hover:bg-slate-800 border-slate-700 text-slate-300'
                      : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
                }`}
              >
                <div className={`font-bold text-xs sm:text-sm ${material === 'cca' ? 'text-amber-600 dark:text-amber-400' : ''}`}>
                  {t.cableLossMaterialCca}
                </div>
                <div className="text-[10px] text-slate-400">
                  {language === 'hi' ? 'बजट / उच्च R' : 'High Resistance'}
                </div>
              </button>
            </div>

            {/* In-form CCA Notice when selected */}
            {material === 'cca' && (
              <div id="input-cca-warning" className="flex items-start gap-1.5 mt-2 p-2 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-600 dark:text-amber-300 text-xs">
                <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <span className="leading-snug">{t.cableLossCcaWarning}</span>
              </div>
            )}
          </div>

          {/* ADVANCED OPTIONS (COLLAPSIBLE / ACCORDION) */}
          <div 
            id="section-advanced-options"
            className={`rounded-2xl border transition-all overflow-hidden ${
              isNightMode 
                ? 'bg-[#131B2A] border-[#1E293B]' 
                : 'bg-white border-slate-200'
            }`}
          >
            <button
              type="button"
              id="btn-toggle-advanced-options"
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="w-full p-4 flex items-center justify-between text-left transition hover:opacity-90"
            >
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-lg bg-blue-500/10 text-blue-500 flex items-center justify-center">
                  <SlidersHorizontal className="w-3.5 h-3.5" />
                </div>
                <div>
                  <span className={`text-xs font-bold uppercase tracking-wide block ${isNightMode ? 'text-slate-100' : 'text-slate-900'}`}>
                    {t.cableLossAdvancedOptions || 'Advanced Options'}
                  </span>
                  <span className={`text-[11px] ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                    {t.cableLossMaxAcceptableLoss}: {maxAcceptableLoss !== null ? `${maxAcceptableLoss}%` : (language === 'hi' ? 'कोई नहीं चुना गया (डिफ़ॉल्ट 5%)' : 'None Selected (Default 5%)')}
                  </span>
                </div>
              </div>
              {showAdvanced ? (
                <ChevronUp className="w-4 h-4 text-slate-400" />
              ) : (
                <ChevronDown className="w-4 h-4 text-slate-400" />
              )}
            </button>

            {showAdvanced && (
              <div className={`p-4 pt-0 border-t ${isNightMode ? 'border-slate-800' : 'border-slate-100'}`}>
                <div className="mt-3">
                  <label className={`text-xs font-bold uppercase tracking-wide block mb-1 ${isNightMode ? 'text-slate-200' : 'text-slate-800'}`}>
                    {t.cableLossMaxAcceptableLoss || 'Maximum Acceptable Cable Loss'}
                  </label>
                  <p className={`text-xs mb-3 ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                    {t.cableLossMaxAcceptableLossDesc || 'Choose how much power loss you are willing to accept in your speaker cable. Lower loss may require a thicker, more expensive cable.'}
                  </p>

                  <div className="grid grid-cols-3 gap-2">
                    {([3, 5, 10] as MaxAcceptableLossOption[]).map((val) => {
                      const title = val === 3 
                        ? (t.cableLossTarget3Title || 'Low Loss') 
                        : val === 5 
                          ? (t.cableLossTarget5Title || 'Balanced') 
                          : (t.cableLossTarget10Title || 'Budget');
                      const subtitle = val === 3 
                        ? (t.cableLossTarget3Subtitle || 'Less power wasted') 
                        : val === 5 
                          ? (t.cableLossTarget5Subtitle || 'Balance of loss and cost') 
                          : (t.cableLossTarget10Subtitle || 'More power may be wasted');

                      return (
                        <button
                          key={val}
                          type="button"
                          id={`btn-max-loss-${val}`}
                          onClick={() => setMaxAcceptableLoss(prev => prev === val ? null : val)}
                          className={`p-2 rounded-xl border text-center transition active:scale-95 ${
                            maxAcceptableLoss === val
                              ? 'bg-[#1D4ED8] text-white border-blue-600 shadow-sm'
                              : isNightMode
                                ? 'bg-slate-800/80 hover:bg-slate-800 text-slate-300 border-slate-700'
                                : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                          }`}
                        >
                          <span className="block text-sm font-bold">{val}%</span>
                          <span className={`text-[11px] font-bold block leading-tight mt-0.5 ${
                            maxAcceptableLoss === val ? 'text-white' : (isNightMode ? 'text-slate-200' : 'text-slate-800')
                          }`}>
                            {title}
                          </span>
                          <span className={`text-[9.5px] block leading-tight mt-0.5 ${
                            maxAcceptableLoss === val 
                              ? 'text-blue-100' 
                              : 'text-slate-400'
                          }`}>
                            {subtitle}
                          </span>
                        </button>
                      );
                    })}
                  </div>

                  <p className={`text-[11px] italic mt-2.5 ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                    {maxAcceptableLoss === 3
                      ? (t.cableLossTarget3Helper || 'A stricter target that may require a thicker cable.')
                      : maxAcceptableLoss === 10
                        ? (t.cableLossTarget10Helper || 'Allows greater cable loss; check the actual result before choosing.')
                        : (t.cableLossTarget5Helper || 'A middle-ground target for comparing cable options.')}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* CALCULATE RECOMMENDATION BUTTON (In-form) */}
          <div className="pt-2">
            <button
              type="button"
              id="btn-calculate-cable-loss"
              onClick={handleCalculate}
              disabled={!isValid}
              className={`w-full flex items-center justify-center gap-2 py-3.5 px-4 rounded-xl text-sm shadow-md transition active:scale-[0.99] ${
                language === 'hi' ? 'font-semibold tracking-normal' : 'font-black tracking-wide'
              } ${
                isValid
                  ? 'bg-[#FBBF24] hover:bg-[#F59E0B] text-[#0F172A] cursor-pointer border border-amber-300/80 shadow-amber-900/10'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed border border-slate-300'
              }`}
            >
              <span>{t.cableLossCalculateButton}</span>
              <ArrowRight className="w-4 h-4 stroke-[2.5]" />
            </button>

            {!isValid && (
              <p className="text-center text-[11px] text-red-600 mt-2 font-medium">
                {!isImpedanceSupported
                  ? (language === 'hi' 
                      ? 'सिस्टम इम्पीडेंस 2Ω से 16Ω के बीच होना चाहिए।' 
                      : 'Final system impedance must be between 2Ω and 16Ω inclusive.')
                  : (language === 'hi'
                      ? 'कृपया सही लंबाई और पावर मान दर्ज करें।'
                      : 'Please enter valid values (Length > 0m and Power > 0W) to calculate.')}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Sticky Bottom Floating Calculate Bar - Avoids swiping to calculate */}
      <div 
        id="sticky-calculate-container"
        className={`fixed bottom-0 left-0 right-0 z-30 px-4 py-3 backdrop-blur-md border-t transition-all ${
          isNightMode 
            ? 'bg-[#0E1526]/95 border-slate-800 shadow-[0_-4px_24px_rgba(0,0,0,0.5)]' 
            : 'bg-white/95 border-slate-200 shadow-[0_-4px_24px_rgba(0,0,0,0.08)]'
        }`}
      >
        <div className="max-w-xl mx-auto flex items-center gap-3">
          <div className="flex-1 min-w-0">
            <div className="text-[11px] font-bold text-slate-400 dark:text-slate-400 truncate">
              {power}W • {formattedImpedance}Ω • {cableLength}m
            </div>
            <div className={`text-xs font-bold truncate ${!isValid ? 'text-red-500' : 'text-emerald-500'}`}>
              {!isImpedanceSupported 
                ? (language === 'hi' ? 'अमान्य लोड (2Ω-16Ω)' : 'Load must be 2Ω-16Ω')
                : !isValid 
                  ? (language === 'hi' ? 'इनपुट पूरा करें' : 'Enter valid inputs') 
                  : (language === 'hi' ? 'कैलकुलेशन के लिए तैयार' : 'Ready to calculate')}
            </div>
          </div>
          <button
            type="button"
            id="btn-sticky-calculate-cable-loss"
            onClick={handleCalculate}
            disabled={!isValid}
            className={`flex items-center gap-2 py-2.5 px-5 rounded-xl text-sm shadow-md transition active:scale-95 shrink-0 ${
              language === 'hi' ? 'font-semibold tracking-normal' : 'font-black tracking-wide'
            } ${
              isValid
                ? 'bg-[#FBBF24] hover:bg-[#F59E0B] text-[#0F172A] cursor-pointer border border-amber-300/80 shadow-amber-900/15'
                : 'bg-slate-200 text-slate-400 cursor-not-allowed border border-slate-300'
            }`}
          >
            <span>{t.cableLossCalculateButton}</span>
            <ArrowRight className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>
      </div>

      {/* Unlock Dialog: Watch Ad (Top) OR Remove Ads/Subscription (Bottom) */}
      <CalculatorUnlockModal
        isOpen={isRewardModalOpen}
        calculatorTitle={t.cableLossCalcTitle}
        onClose={() => setIsRewardModalOpen(false)}
        onUnlocked={() => {
          setIsRewardModalOpen(false);
          executeCalculation();
        }}
        onOpenSubscription={() => {
          setIsRewardModalOpen(false);
          onOpenSubscription?.();
        }}
      />
    </div>
  );
};
