import React from 'react';
import { ChevronLeft, RotateCcw, Sun, Moon } from 'lucide-react';
import { useTheme } from '../../theme/ThemeContext';

interface CalculatorHeroHeaderProps {
  title: string;
  subtitle: string;
  onBack: () => void;
  onReset?: () => void;
  resetAriaLabel?: string;
  actions?: React.ReactNode;
  badge?: React.ReactNode;
  showThemeToggle?: boolean;
}

export const CalculatorHeroHeader: React.FC<CalculatorHeroHeaderProps> = ({
  title,
  subtitle,
  onBack,
  onReset,
  resetAriaLabel = 'Reset',
  actions,
  badge,
  showThemeToggle = false,
}) => {
  const { isNightMode, toggleTheme } = useTheme();

  return (
    <div className={`relative px-5 pt-3 pb-8 text-white overflow-hidden select-none transition-colors duration-200 ${
      isNightMode 
        ? 'bg-gradient-to-b from-[#070B14] via-[#0E1526] to-[#141E34] border-b border-slate-800/80' 
        : 'bg-gradient-to-b from-[#1D4ED8] via-[#2563EB] to-[#3B82F6]'
    }`}>
      {/* Curved ambient light overlays matching uploaded design */}
      <div className={`absolute -top-12 -right-12 w-64 h-64 rounded-full blur-3xl pointer-events-none ${
        isNightMode ? 'bg-blue-600/10' : 'bg-white/20'
      }`} />
      <div className={`absolute top-0 right-0 w-80 h-80 rounded-full pointer-events-none ${
        isNightMode 
          ? 'bg-[radial-gradient(circle_at_75%_25%,rgba(56,189,248,0.15),transparent_65%)]' 
          : 'bg-[radial-gradient(circle_at_75%_25%,rgba(255,255,255,0.28),transparent_65%)]'
      }`} />
      <div className={`absolute -bottom-10 -left-10 w-72 h-44 rounded-full pointer-events-none ${
        isNightMode 
          ? 'bg-[radial-gradient(ellipse_at_30%_50%,rgba(37,99,235,0.2),transparent_70%)]' 
          : 'bg-[radial-gradient(ellipse_at_30%_50%,rgba(147,197,253,0.35),transparent_70%)]'
      }`} />
      
      {/* Soft sweeping curved ambient lines matching reference screenshot */}
      <svg
        className={`absolute inset-0 w-full h-full pointer-events-none ${isNightMode ? 'opacity-10' : 'opacity-20'}`}
        preserveAspectRatio="none"
        viewBox="0 0 400 200"
      >
        <path
          d="M-40,50 C120,10 220,140 440,30"
          fill="none"
          stroke="white"
          strokeWidth="50"
          filter="blur(22px)"
        />
        <path
          d="M-20,120 C110,60 260,170 420,80"
          fill="none"
          stroke="white"
          strokeWidth="35"
          filter="blur(18px)"
        />
      </svg>

      {/* Top action row */}
      <div className="relative z-10 flex items-center justify-between gap-3 mb-3">
        <button
          type="button"
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-white/20 hover:bg-white/30 active:scale-95 backdrop-blur-md border border-white/30 flex items-center justify-center text-white transition shadow-xs shrink-0"
          aria-label="Back"
        >
          <ChevronLeft className="w-6 h-6 text-white stroke-[2.5]" />
        </button>

        <div className="flex items-center gap-2">
          {actions}

          {/* Theme Toggle Button (Day / Night) - Only when explicitly enabled */}
          {showThemeToggle && (
            <button
              type="button"
              onClick={toggleTheme}
              className={`w-10 h-10 rounded-full flex items-center justify-center transition active:scale-95 shadow-xs border backdrop-blur-md shrink-0 ${
                isNightMode 
                  ? 'bg-slate-800/90 border-amber-400/50 text-amber-400 hover:bg-slate-700' 
                  : 'bg-white/20 hover:bg-white/30 border-white/35 text-white'
              }`}
              title={isNightMode ? "Switch to Day Mode" : "Switch to Night Mode"}
              aria-label="Toggle Night Mode"
            >
              {isNightMode ? (
                <Sun className="w-4 h-4 stroke-[2.2] text-amber-400" />
              ) : (
                <Moon className="w-4 h-4 stroke-[2.2] text-white" />
              )}
            </button>
          )}
          
          {onReset && (
            <button
              type="button"
              onClick={onReset}
              className="w-10 h-10 rounded-full bg-white/20 hover:bg-white/30 active:scale-95 backdrop-blur-md border border-white/30 flex items-center justify-center text-white transition shadow-xs shrink-0"
              title={resetAriaLabel}
              aria-label={resetAriaLabel}
            >
              <RotateCcw className="w-4 h-4 text-white" />
            </button>
          )}
        </div>
      </div>

      {/* Badge (Optional e.g. Transferred from Ohm Calc) */}
      {badge && (
        <div className="relative z-10 mb-2">
          {badge}
        </div>
      )}

      {/* Calculator Title and Subtitle in crisp white typography */}
      <div className="relative z-10 pt-0.5 pb-1">
        {(() => {
          const isHindiTitle = /[\u0900-\u097F]/.test(title);
          const isHindiSubtitle = /[\u0900-\u097F]/.test(subtitle);
          return (
            <>
              <h1 className={`text-2xl sm:text-[27px] text-white drop-shadow-xs ${
                isHindiTitle
                  ? 'font-semibold tracking-normal leading-[1.28]'
                  : 'font-extrabold tracking-tight leading-tight'
              }`}>
                {title}
              </h1>
              <p className={`text-xs sm:text-[13px] mt-1.5 max-w-md ${
                isHindiSubtitle
                  ? 'font-medium tracking-normal leading-[1.38]'
                  : 'font-medium tracking-tight leading-snug'
              } ${
                isNightMode ? 'text-slate-400' : 'text-blue-100'
              }`}>
                {subtitle}
              </p>
            </>
          );
        })()}
      </div>
    </div>
  );
};
