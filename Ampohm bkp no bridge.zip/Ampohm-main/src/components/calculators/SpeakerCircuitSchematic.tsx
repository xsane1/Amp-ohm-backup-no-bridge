import React from 'react';

interface SpeakerCircuitSchematicProps {
  speakerCount: number;
  speakerImpedance: number;
  wiring: 'parallel' | 'series';
  totalImpedance: number;
  isNightMode: boolean;
}

export const SpeakerCircuitSchematic: React.FC<SpeakerCircuitSchematicProps> = ({
  speakerCount,
  speakerImpedance,
  wiring,
  totalImpedance,
  isNightMode,
}) => {
  // Determine how many speaker boxes to display in schematic (up to 8 full boxes, with smooth horizontal scroll)
  const displayCount = Math.min(speakerCount, 12);
  const isTruncated = speakerCount > displayCount;

  // Dimensions
  const ampWidth = 52;
  const ampHeight = 64;
  const speakerWidth = 62;
  const speakerHeight = 66;
  const gap = 30; // gap between speakers
  const ampToFirstSpeaker = 44;
  const startX = 14;
  const svgHeight = 126;

  // Calculate overall width
  const totalSvgWidth = startX + ampWidth + ampToFirstSpeaker + displayCount * speakerWidth + (displayCount - 1) * gap + 24;

  const ampX = startX;
  const ampY = (svgHeight - ampHeight) / 2;
  const ampPosTerminalY = ampY + 18;
  const ampNegTerminalY = ampY + ampHeight - 18;

  // Calculate speaker X positions
  const speakerPositions = Array.from({ length: displayCount }, (_, i) => {
    return startX + ampWidth + ampToFirstSpeaker + i * (speakerWidth + gap);
  });

  const speakerY = (svgHeight - speakerHeight) / 2;
  const topWireY = ampPosTerminalY;
  const bottomWireY = ampNegTerminalY;

  // Color definitions
  const posColor = '#EF4444'; // Red (+)
  const negColor = isNightMode ? '#94A3B8' : '#0F172A'; // Dark slate (-)
  const ampBg = isNightMode ? '#1D4ED8' : '#1E40AF';
  const cabinetBg = isNightMode ? '#131B2E' : '#FFFFFF';
  const cabinetBorder = isNightMode ? '#3B82F6' : '#2563EB';
  const speakerConeOuter = isNightMode ? '#1E293B' : '#E2E8F0';
  const speakerConeInner = isNightMode ? '#334155' : '#CBD5E1';
  const speakerDustCap = '#2563EB';

  return (
    <div className={`rounded-2xl p-4 sm:p-5 border shadow-sm transition-colors ${
      isNightMode 
        ? 'bg-[#141C30] border-slate-800 text-slate-100' 
        : 'bg-white border-slate-200 text-slate-800'
    }`}>
      {/* Title Header with Pill Badge */}
      <div className="flex items-center justify-between gap-2 mb-3">
        <h3 className={`text-xs sm:text-sm font-bold tracking-wider uppercase ${
          isNightMode ? 'text-blue-400' : 'text-[#1D4ED8]'
        }`}>
          {wiring === 'parallel' ? 'PARALLEL WIRING DIAGRAM' : 'SERIES WIRING DIAGRAM'}
        </h3>
        
        <span className={`text-xs font-bold px-3 py-0.5 rounded-full border shadow-2xs ${
          isNightMode 
            ? 'bg-blue-950/80 text-blue-300 border-blue-800/60' 
            : 'bg-blue-50 text-blue-700 border-blue-200'
        }`}>
          Total: {totalImpedance} Ω
        </span>
      </div>

      {/* Interactive / Visual SVG Schematic Canvas with smooth horizontal scroll */}
      <div className={`w-full overflow-x-auto rounded-xl p-2 sm:p-3 border scrollbar-thin ${
        isNightMode ? 'bg-[#0B1120] border-slate-800/80' : 'bg-slate-50/70 border-slate-100'
      }`}>
        <div style={{ minWidth: `${Math.max(340, totalSvgWidth)}px` }} className="flex justify-center">
          <svg
            width={totalSvgWidth}
            height={svgHeight}
            viewBox={`0 0 ${totalSvgWidth} ${svgHeight}`}
            className="select-none overflow-visible"
          >
            <defs>
              <filter id="boxShadow" x="-10%" y="-10%" width="120%" height="120%">
                <feDropShadow dx="0" dy="2" stdDeviation="2" floodOpacity={isNightMode ? "0.4" : "0.08"} />
              </filter>
            </defs>

            {/* ======================================================== */}
            {/* 1. WIRING RUNS: PARALLEL                                  */}
            {/* ======================================================== */}
            {wiring === 'parallel' && (
              <g id="parallel-wiring-layer">
                {/* Positive Red Rail (+): from Amp output to last speaker */}
                <line
                  x1={ampX + ampWidth}
                  y1={topWireY}
                  x2={speakerPositions[speakerPositions.length - 1] + speakerWidth / 2}
                  y2={topWireY}
                  stroke={posColor}
                  strokeWidth="2.5"
                  strokeLinecap="round"
                />

                {/* Negative Dark Rail (-): from Amp output to last speaker */}
                <line
                  x1={ampX + ampWidth}
                  y1={bottomWireY}
                  x2={speakerPositions[speakerPositions.length - 1] + speakerWidth / 2}
                  y2={bottomWireY}
                  stroke={negColor}
                  strokeWidth="2.5"
                  strokeLinecap="round"
                />

                {/* Drop lines into each speaker */}
                {speakerPositions.map((spkX, idx) => {
                  const spkMidX = spkX + speakerWidth / 2;
                  const spkTopY = speakerY;
                  const spkBottomY = speakerY + speakerHeight;

                  return (
                    <g key={`drop-${idx}`}>
                      {/* Positive (+) drop line from top rail to speaker top */}
                      <line
                        x1={spkMidX}
                        y1={topWireY}
                        x2={spkMidX}
                        y2={spkTopY}
                        stroke={posColor}
                        strokeWidth="2.5"
                      />
                      {/* Top Junction solder dot */}
                      <circle cx={spkMidX} cy={topWireY} r="3" fill={posColor} />
                      {/* Speaker (+) Terminal dot */}
                      <circle cx={spkMidX} cy={spkTopY} r="2.5" fill={posColor} />

                      {/* Negative (-) drop line from bottom rail to speaker bottom */}
                      <line
                        x1={spkMidX}
                        y1={bottomWireY}
                        x2={spkMidX}
                        y2={spkBottomY}
                        stroke={negColor}
                        strokeWidth="2.5"
                      />
                      {/* Bottom Junction solder dot */}
                      <circle cx={spkMidX} cy={bottomWireY} r="3" fill={negColor} />
                      {/* Speaker (-) Terminal dot */}
                      <circle cx={spkMidX} cy={spkBottomY} r="2.5" fill={negColor} />
                    </g>
                  );
                })}
              </g>
            )}

            {/* ======================================================== */}
            {/* 2. WIRING RUNS: SERIES                                    */}
            {/* ======================================================== */}
            {wiring === 'series' && (
              <g id="series-wiring-layer">
                {/* Amp (+) to Speaker 1 top (+) */}
                {speakerPositions.length > 0 && (
                  <path
                    d={`M ${ampX + ampWidth} ${ampPosTerminalY} L ${speakerPositions[0] + speakerWidth / 2} ${ampPosTerminalY} L ${speakerPositions[0] + speakerWidth / 2} ${speakerY}`}
                    fill="none"
                    stroke={posColor}
                    strokeWidth="2.5"
                    strokeLinecap="round"
                  />
                )}

                {/* Inter-speaker series jumpers: from speaker [i] bottom to speaker [i+1] top */}
                {speakerPositions.map((spkX, idx) => {
                  if (idx === speakerPositions.length - 1) return null;
                  const curMidX = spkX + speakerWidth / 2;
                  const curBottomY = speakerY + speakerHeight;
                  const nextMidX = speakerPositions[idx + 1] + speakerWidth / 2;
                  const nextTopY = speakerY;

                  // Stepped jumper path
                  return (
                    <g key={`series-jumper-${idx}`}>
                      <path
                        d={`M ${curMidX} ${curBottomY} L ${curMidX} ${curBottomY + 12} L ${nextMidX} ${curBottomY + 12} L ${nextMidX} ${nextTopY}`}
                        fill="none"
                        stroke="#3B82F6"
                        strokeWidth="2.5"
                        strokeLinecap="round"
                      />
                      <circle cx={curMidX} cy={curBottomY} r="2.5" fill={negColor} />
                      <circle cx={nextMidX} cy={nextTopY} r="2.5" fill={posColor} />
                    </g>
                  );
                })}

                {/* Return wire from last speaker bottom back to Amp (-) */}
                {speakerPositions.length > 0 && (
                  <g>
                    <path
                      d={`M ${speakerPositions[speakerPositions.length - 1] + speakerWidth / 2} ${speakerY + speakerHeight} L ${speakerPositions[speakerPositions.length - 1] + speakerWidth / 2} ${bottomWireY + 14} L ${ampX + ampWidth / 2} ${bottomWireY + 14} L ${ampX + ampWidth / 2} ${ampNegTerminalY} L ${ampX + ampWidth} ${ampNegTerminalY}`}
                      fill="none"
                      stroke={negColor}
                      strokeWidth="2.5"
                      strokeLinecap="round"
                    />
                    <circle
                      cx={speakerPositions[speakerPositions.length - 1] + speakerWidth / 2}
                      cy={speakerY + speakerHeight}
                      r="2.5"
                      fill={negColor}
                    />
                  </g>
                )}
              </g>
            )}

            {/* ======================================================== */}
            {/* 3. AMPLIFIER CABINET (AMP)                                */}
            {/* ======================================================== */}
            <g id="amp-cabinet" filter="url(#boxShadow)">
              <rect
                x={ampX}
                y={ampY}
                width={ampWidth}
                height={ampHeight}
                rx="8"
                fill={ampBg}
                stroke={isNightMode ? '#3B82F6' : '#1D4ED8'}
                strokeWidth="1.5"
              />
              {/* Amp Label */}
              <text
                x={ampX + ampWidth / 2}
                y={ampY + 28}
                textAnchor="middle"
                fill="#FFFFFF"
                fontSize="11"
                fontWeight="900"
                letterSpacing="1"
                className="font-mono select-none"
              >
                AMP
              </text>
              {/* Power LED Indicator */}
              <circle cx={ampX + 12} cy={ampY + ampHeight - 12} r="2.5" fill="#22C55E" />
              <text
                x={ampX + 22}
                y={ampY + ampHeight - 10}
                fill={isNightMode ? '#93C5FD' : '#BFDBFE'}
                fontSize="7"
                fontWeight="700"
                className="font-mono select-none"
              >
                PWR
              </text>

              {/* Terminal Connection Nodes on AMP */}
              <circle cx={ampX + ampWidth} cy={ampPosTerminalY} r="3" fill={posColor} />
              <circle cx={ampX + ampWidth} cy={ampNegTerminalY} r="3" fill={negColor} />
            </g>

            {/* ======================================================== */}
            {/* 4. SPEAKER CABINETS                                      */}
            {/* ======================================================== */}
            {speakerPositions.map((spkX, idx) => {
              const cx = spkX + speakerWidth / 2;
              const cy = speakerY + 28;

              return (
                <g key={`speaker-${idx}`} filter="url(#boxShadow)">
                  {/* Cabinet Box */}
                  <rect
                    x={spkX}
                    y={speakerY}
                    width={speakerWidth}
                    height={speakerHeight}
                    rx="8"
                    fill={cabinetBg}
                    stroke={cabinetBorder}
                    strokeWidth="1.8"
                  />

                  {/* Woofer Chassis / Outer Surround Ring */}
                  <circle
                    cx={cx}
                    cy={cy}
                    r="19"
                    fill={speakerConeOuter}
                    stroke={isNightMode ? '#475569' : '#CBD5E1'}
                    strokeWidth="1"
                  />

                  {/* Inner Cone Ring */}
                  <circle
                    cx={cx}
                    cy={cy}
                    r="13"
                    fill={speakerConeInner}
                    stroke={isNightMode ? '#64748B' : '#94A3B8'}
                    strokeWidth="1"
                  />

                  {/* Speaker Dust Cap (Vibrant Blue) */}
                  <circle
                    cx={cx}
                    cy={cy}
                    r="5.5"
                    fill={speakerDustCap}
                  />

                  {/* Dust Cap Highlight reflection */}
                  <circle
                    cx={cx - 1.5}
                    cy={cy - 1.5}
                    r="1.8"
                    fill="#93C5FD"
                    opacity="0.9"
                  />

                  {/* Impedance Label Below Driver */}
                  <text
                    x={cx}
                    y={speakerY + speakerHeight - 8}
                    textAnchor="middle"
                    fill={isNightMode ? '#F1F5F9' : '#0F172A'}
                    fontSize="10"
                    fontWeight="800"
                    className="font-sans select-none"
                  >
                    {speakerImpedance} Ω
                  </text>
                </g>
              );
            })}
          </svg>
        </div>
      </div>
    </div>
  );
};
