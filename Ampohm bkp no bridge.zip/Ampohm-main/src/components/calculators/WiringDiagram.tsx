import React from 'react';
import { useLanguage } from '../../localization/LanguageContext';
import { useTheme } from '../../theme/ThemeContext';
import { GitBranch } from 'lucide-react';

interface WiringDiagramProps {
  wiring: 'parallel' | 'series';
  speakerCount: number;
  speakerImpedance: number;
}

export const WiringDiagram: React.FC<WiringDiagramProps> = ({
  wiring,
  speakerCount,
  speakerImpedance,
}) => {
  const { language } = useLanguage();
  const { isNightMode } = useTheme();

  const isParallel = wiring === 'parallel';
  const isSingle = speakerCount <= 1;

  // Exact colors dynamically adapting to Day Mode and Night Mode
  const redWire = isNightMode ? '#F87171' : '#EF4444';
  const blackWire = isNightMode ? '#94A3B8' : '#1E293B'; // Clearly visible slate wire in night mode
  const ampBg = isNightMode ? '#1D4ED8' : '#2563EB'; // Vibrant blue AMP box
  const ampBorder = isNightMode ? '#3B82F6' : '#1D4ED8';
  const speakerBoxFill = isNightMode ? '#172033' : '#FFFFFF'; // Dark slate cabinet in night mode, pure white in day mode
  const speakerBorder = isNightMode ? '#38BDF8' : '#2563EB'; // High-contrast cyan-blue border in night mode
  const textColor = isNightMode ? '#F1F5F9' : '#1E293B';

  // Dynamic speaker calculations (support 1, 2, 3, 4, 5, 6+ speakers)
  const count = Math.max(1, speakerCount);
  const maxToDraw = Math.min(count, 5);

  // Spacing tailored to fit neatly without clutter
  const spkWidth = 44;
  const spkHeight = 54;
  const spkSpacing = maxToDraw <= 2 ? 100 : maxToDraw === 3 ? 75 : maxToDraw === 4 ? 64 : 54;
  const startX = 86;

  // Calculate X position for each speaker
  const spkPositions = Array.from({ length: maxToDraw }, (_, i) => startX + i * spkSpacing);
  const lastSpkX = spkPositions[spkPositions.length - 1];

  // Dynamic SVG width & height with comfortable margins so speakers and wires never cut off
  const rightMargin = isParallel ? 28 : 38;
  const viewBoxWidth = lastSpkX + spkWidth + rightMargin;
  const viewBoxHeight = 92;

  return (
    <div className={`rounded-xl p-2 sm:p-2.5 border transition-colors ${
      isNightMode 
        ? 'bg-[#131B2A] border-[#1E293B] text-slate-200' 
        : 'bg-white border-slate-200 text-slate-800 shadow-2xs'
    }`}>
      {/* 1-Line Compact Header */}
      <div className="flex items-center justify-between text-xs mb-1 px-0.5">
        <div className="flex items-center gap-1.5">
          <GitBranch className={`w-3.5 h-3.5 ${isNightMode ? 'text-[#38BDF8]' : 'text-blue-600'}`} />
          <span className={`text-[11px] font-bold uppercase tracking-wider ${
            isNightMode ? 'text-slate-300' : 'text-slate-700'
          }`}>
            {language === 'hi' ? 'वायरिंग डायग्राम' : 'WIRING DIAGRAM'}
          </span>
          <span
            className={`text-[10px] font-bold px-2 py-0.2 rounded-full uppercase tracking-wide border ${
              isParallel
                ? isNightMode 
                  ? 'bg-blue-950/60 text-blue-400 border-blue-800/60' 
                  : 'bg-blue-50 text-blue-600 border-blue-200'
                : isNightMode
                  ? 'bg-amber-950/60 text-amber-400 border-amber-800/60'
                  : 'bg-amber-50 text-amber-700 border-amber-300'
            }`}
          >
            {isSingle
              ? (language === 'hi' ? '1 स्पीकर' : '1 Speaker')
              : isParallel
                ? (language === 'hi' ? 'Parallel (पैरेलल)' : 'Parallel')
                : (language === 'hi' ? 'Series (सीरीज़)' : 'Series')}
          </span>
        </div>

        <span className={`text-[11px] font-bold ${isNightMode ? 'text-blue-400' : 'text-blue-700'}`}>
          {speakerCount} {speakerCount === 1 ? 'Speaker' : 'Speakers'} ({speakerImpedance}Ω)
        </span>
      </div>

      {/* SVG Canvas - Adapts seamlessly to Day and Night Mode */}
      <div className={`w-full rounded-lg p-1 border overflow-hidden flex items-center justify-center transition-colors ${
        isNightMode 
          ? 'bg-[#0B0F19] border-slate-800' 
          : 'bg-white border-slate-100'
      }`}>
        <svg
          viewBox={`0 0 ${viewBoxWidth} ${viewBoxHeight}`}
          className="w-full h-auto max-h-[96px] select-none"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* ============================================================ */}
          {/* 1. AMPLIFIER BLOCK (LEFT)                                    */}
          {/* ============================================================ */}
          <g>
            <rect
              x="12"
              y="8"
              width="42"
              height={spkHeight}
              rx="9"
              fill={ampBg}
              stroke={ampBorder}
              strokeWidth={isNightMode ? '1.5' : '0'}
            />

            {/* White italic serif AMP text */}
            <text
              x="33"
              y="39"
              fill="#FFFFFF"
              fontSize="13"
              fontFamily="Georgia, serif, system-ui"
              fontStyle="italic"
              fontWeight="bold"
              textAnchor="middle"
            >
              AMP
            </text>

            {/* Red Terminal Dot (+) on right edge */}
            <circle cx="54" cy="20" r="4.5" fill={redWire} />

            {/* Black Terminal Dot (-) on right edge */}
            <circle cx="54" cy="48" r="4.5" fill={blackWire} />

            {/* Minus "-" sign next to Black terminal as in user's image */}
            <text
              x="63"
              y="49"
              fill={blackWire}
              fontSize="10"
              fontWeight="900"
              fontFamily="system-ui, sans-serif"
            >
              -
            </text>
          </g>

          {/* ============================================================ */}
          {/* 2. WIRES CONFIGURATION                                       */}
          {/* ============================================================ */}
          {isSingle ? (
            /* SINGLE SPEAKER DIRECT (1 Speaker) */
            <g id="wire-layer-single">
              {/* Red wire from AMP (+) to Speaker (+) */}
              <line x1="54" y1="20" x2={spkPositions[0] + 7} y2="20" stroke={redWire} strokeWidth="2.5" strokeLinecap="round" />
              {/* Black wire from Speaker (-) back to AMP (-) */}
              <line x1={spkPositions[0] + 39} y1="48" x2="54" y2="48" stroke={blackWire} strokeWidth="2.5" strokeLinecap="round" />
            </g>
          ) : isParallel ? (
            /* PARALLEL WIRING (STRAIGHT CONTINUOUS RAILS CONNECTING ALL SPEAKERS) */
            <g id="wire-layer-parallel">
              {/* Continuous Red Wire straight through across top (+) */}
              <line
                x1="54"
                y1="20"
                x2={lastSpkX + 7}
                y2="20"
                stroke={redWire}
                strokeWidth="2.5"
                strokeLinecap="round"
              />
              <circle cx={lastSpkX + 7} cy="20" r="2.5" fill={redWire} />

              {/* Continuous Black Wire straight through across bottom (-) */}
              <line
                x1="54"
                y1="48"
                x2={lastSpkX + 39}
                y2="48"
                stroke={blackWire}
                strokeWidth="2.5"
                strokeLinecap="round"
              />
              <circle cx={lastSpkX + 39} cy="48" r="2.5" fill={blackWire} />
            </g>
          ) : (
            /* SERIES WIRING (DAISY-CHAIN LOOP FROM NEGATIVE TO POSITIVE) */
            <g id="wire-layer-series">
              {/* 1. Red Wire from AMP (+) straight to Speaker 1 (+) */}
              <line
                x1="54"
                y1="20"
                x2={spkPositions[0] + 7}
                y2="20"
                stroke={redWire}
                strokeWidth="2.5"
                strokeLinecap="round"
              />

              {/* Red wire indicator tick mark */}
              <line
                x1="66"
                y1="16"
                x2="66"
                y2="24"
                stroke={redWire}
                strokeWidth="1.5"
                strokeLinecap="round"
              />

              {/* 2. Jumper wires connecting Speaker i (-) to Speaker i+1 (+) */}
              {spkPositions.slice(0, -1).map((currentX, idx) => {
                const nextX = spkPositions[idx + 1];
                const fromX = currentX + 39; // (-) terminal of current speaker
                const toX = nextX + 7;       // (+) terminal of next speaker
                const midX = (fromX + toX) / 2;

                return (
                  <path
                    key={`series-jumper-${idx}`}
                    d={`M ${fromX} 48 L ${midX} 48 L ${midX} 20 L ${toX} 20`}
                    stroke={redWire}
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    fill="none"
                  />
                );
              })}

              {/* 3. Black Dashed Return Wire from Last Speaker (-) back underneath to AMP (-) */}
              <path
                d={`M ${lastSpkX + 39} 48 L ${lastSpkX + 46 + 8} 48 L ${lastSpkX + 46 + 8} 74 L 54 74 L 54 48`}
                stroke={blackWire}
                strokeWidth="2.2"
                strokeDasharray="4 3"
                fill="none"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </g>
          )}

          {/* ============================================================ */}
          {/* 3. DYNAMIC SPEAKERS: AUTHENTIC LOUDSPEAKER DRIVER DESIGN    */}
          {/* ============================================================ */}
          {spkPositions.map((spkX, index) => {
            const cx = spkX + 23;
            const cy = 29;

            return (
              <g key={`speaker-${index}`}>
                {/* Speaker Cabinet Baffle Box */}
                <rect
                  x={spkX}
                  y="8"
                  width={spkWidth}
                  height={spkHeight}
                  rx="9"
                  fill={speakerBoxFill}
                  stroke={speakerBorder}
                  strokeWidth="2"
                />

                {/* 4 Corner Screws for Realistic PA Cabinet/Driver Frame */}
                <circle cx={spkX + 4.5} cy="12.5" r="1.1" fill={isNightMode ? '#475569' : '#94A3B8'} />
                <circle cx={spkX + spkWidth - 4.5} cy="12.5" r="1.1" fill={isNightMode ? '#475569' : '#94A3B8'} />
                <circle cx={spkX + 4.5} cy={spkHeight + 3.5} r="1.1" fill={isNightMode ? '#475569' : '#94A3B8'} />
                <circle cx={spkX + spkWidth - 4.5} cy={spkHeight + 3.5} r="1.1" fill={isNightMode ? '#475569' : '#94A3B8'} />

                {/* Outer Speaker Basket Rim */}
                <circle
                  cx={cx}
                  cy={cy}
                  r="16.5"
                  fill={isNightMode ? '#0B0F19' : '#F8FAFC'}
                  stroke={isNightMode ? '#38BDF8' : '#2563EB'}
                  strokeWidth="1.2"
                />

                {/* Rubber Surround Roll Ring */}
                <circle
                  cx={cx}
                  cy={cy}
                  r="14.2"
                  fill="none"
                  stroke={isNightMode ? '#1E293B' : '#64748B'}
                  strokeWidth="1.8"
                />

                {/* Deep Acoustic Woofer Cone Diaphragm */}
                <circle
                  cx={cx}
                  cy={cy}
                  r="12.6"
                  fill={isNightMode ? '#0F172A' : '#1E293B'}
                />

                {/* Concentric Ribbed Cone Ridges (Acoustic Corrugation) */}
                <circle
                  cx={cx}
                  cy={cy}
                  r="9.5"
                  fill="none"
                  stroke={isNightMode ? '#38BDF8' : '#94A3B8'}
                  strokeWidth="0.7"
                  opacity="0.45"
                />
                <circle
                  cx={cx}
                  cy={cy}
                  r="6.8"
                  fill="none"
                  stroke={isNightMode ? '#38BDF8' : '#94A3B8'}
                  strokeWidth="0.7"
                  opacity="0.45"
                />

                {/* Center Dome Dust Cap */}
                <circle
                  cx={cx}
                  cy={cy}
                  r="4.2"
                  fill={isNightMode ? '#1D4ED8' : '#3B82F6'}
                  stroke={isNightMode ? '#60A5FA' : '#1E40AF'}
                  strokeWidth="0.8"
                />

                {/* Dust Cap 3D Specular Highlight Dot */}
                <circle
                  cx={cx - 1.2}
                  cy={cy - 1.2}
                  r="1.1"
                  fill="#FFFFFF"
                  opacity="0.9"
                />

                {/* Impedance Text e.g. 8Ω below the woofer cone */}
                <text
                  x={cx}
                  y="57"
                  fill={isNightMode ? '#93C5FD' : '#1D4ED8'}
                  fontSize="8.5"
                  fontFamily="system-ui, -apple-system, sans-serif"
                  fontWeight="900"
                  textAnchor="middle"
                >
                  {speakerImpedance}Ω
                </text>

                {/* Speaker Terminals: Clearly designated (+) Red and (-) Black */}
                {/* 1. Positive Terminal (+) at top-left of speaker */}
                <circle cx={spkX + 7} cy="20" r="4.2" fill={redWire} stroke="#FFFFFF" strokeWidth="0.8" />
                <text
                  x={spkX + 7}
                  y="22.5"
                  fill="#FFFFFF"
                  fontSize="7.5"
                  fontWeight="900"
                  fontFamily="system-ui, sans-serif"
                  textAnchor="middle"
                >
                  +
                </text>

                {/* 2. Negative Terminal (-) at bottom-right of speaker */}
                <circle cx={spkX + 39} cy="48" r="4.2" fill={blackWire} stroke="#FFFFFF" strokeWidth="0.8" />
                <text
                  x={spkX + 39}
                  y="50.2"
                  fill="#FFFFFF"
                  fontSize="8.5"
                  fontWeight="900"
                  fontFamily="system-ui, sans-serif"
                  textAnchor="middle"
                >
                  -
                </text>
              </g>
            );
          })}

          {/* Tag for any extra speakers if count > maxToDraw (e.g. 8 speakers) */}
          {count > maxToDraw && (
            <g>
              <rect
                x={viewBoxWidth - 26}
                y="28"
                width="22"
                height="14"
                rx="3"
                fill={isNightMode ? '#1E293B' : '#EFF6FF'}
                stroke={isNightMode ? '#38BDF8' : '#3B82F6'}
                strokeWidth="1"
              />
              <text
                x={viewBoxWidth - 15}
                y="38"
                fill={isNightMode ? '#93C5FD' : '#1D4ED8'}
                fontSize="7.5"
                fontWeight="bold"
                textAnchor="middle"
              >
                +{count - maxToDraw}
              </text>
            </g>
          )}
        </svg>
      </div>

      {/* 1-Line Explanation footer */}
      <div className={`mt-1 text-[11px] font-medium leading-tight flex items-center justify-between px-0.5 ${
        isNightMode ? 'text-slate-400' : 'text-slate-600'
      }`}>
        <span>
          {isSingle
            ? (language === 'hi'
                ? 'एम्प (+) से स्पीकर (+), और एम्प (-) से स्पीकर (-)।'
                : 'Amp (+) to Speaker (+), Amp (-) to Speaker (-).')
            : isParallel
              ? (language === 'hi'
                  ? `पैरेलल: सभी ${speakerCount} स्पीकर्स के (+) एम्प (+), और (-) एम्प (-) से जुड़ेंगे।`
                  : `Parallel: All ${speakerCount} speakers (+) to Amp (+), and (-) to Amp (-).`)
              : (language === 'hi'
                  ? `सीरीज़: एम्प (+) से 1st स्पीकर, बीच में रेड (+) लिंक, और आखिरी स्पीकर से ब्लैक रिटर्न (-)।`
                  : `Series: Amp (+) to 1st speaker, red (+) link between speakers, black return to Amp (-).`)}
        </span>
        <span className={`text-[10px] font-semibold shrink-0 ml-2 ${
          isNightMode ? 'text-slate-500' : 'text-slate-400'
        }`}>
          {isParallel ? 'Parallel' : isSingle ? 'Direct' : 'Series'}
        </span>
      </div>
    </div>
  );
};
