import React, { useState, useMemo, useRef } from 'react';
import { useLanguage } from '../../localization/LanguageContext';
import { useTheme } from '../../theme/ThemeContext';
import { calculateOhm, formatStatusMessage, formatLoadValue } from '../../calculators/calculations';
import { analyticsService } from '../../services/analyticsService';
import { historyService } from '../../services/historyService';
import { adService } from '../../services/adService';
import { subscriptionService } from '../../services/subscriptionService';
import { AdBannerPlaceholder } from '../ads/AdBannerPlaceholder';
import { CalculatorUnlockModal } from '../subscription/CalculatorUnlockModal';
import { WiringDiagram } from './WiringDiagram';
import { ShareResultButton } from '../ShareResultButton';
import { CalculatorHeroHeader } from './CalculatorHeroHeader';
import { 
  ChevronLeft,
  RotateCcw, 
  Zap, 
  AlertTriangle, 
  CheckCircle2, 
  Info, 
  ArrowRight, 
  SlidersHorizontal, 
  Layers, 
  Minus,
  Plus
} from 'lucide-react';

export interface OhmTransferToAmpData {
  speakerRms: number;
  speakerCount: number;
  speakerImpedance: number;
  wiring: 'parallel' | 'series';
  finalLoad: number;
  totalSystemRms: number;
}

export interface OhmSavedState {
  speakerRms: number;
  speakerCount: number;
  speakerImpedance: number;
  wiring: 'parallel' | 'series';
  viewMode: 'input' | 'result';
}

interface OhmCalculatorViewProps {
  onBack: () => void;
  onNavigateToAmp?: (data: OhmTransferToAmpData) => void;
  savedState?: OhmSavedState | null;
  onOpenSubscription?: () => void;
}

export const OhmCalculatorView: React.FC<OhmCalculatorViewProps> = ({ 
  onBack,
  onNavigateToAmp,
  savedState,
  onOpenSubscription,
}) => {
  const { language, setLanguage, t } = useLanguage();
  const { isNightMode } = useTheme();

  // Screen View Mode: 'input' vs 'result'
  const [viewMode, setViewMode] = useState<'input' | 'result'>(savedState?.viewMode ?? 'input');

  // Input states matching the exact values in the approved design screenshot
  const [speakerRms, setSpeakerRms] = useState<number>(savedState?.speakerRms ?? 300);
  const [speakerCount, setSpeakerCount] = useState<number>(savedState?.speakerCount ?? 2);
  const [speakerImpedance, setSpeakerImpedance] = useState<number>(savedState?.speakerImpedance ?? 8);
  const [wiring, setWiring] = useState<'parallel' | 'series'>(savedState?.wiring ?? 'parallel');

  const handleRmsInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    if (raw === '') {
      setSpeakerRms(0);
      return;
    }
    const val = parseInt(raw, 10);
    if (!isNaN(val)) {
      setSpeakerRms(Math.min(20000, Math.max(0, val)));
    }
  };

  const handleRmsInputBlur = () => {
    if (speakerRms < 10) {
      setSpeakerRms(50);
    }
  };

  // Validation
  const isImpedanceValid = speakerImpedance > 0;
  const isCountValid = speakerCount >= 1;
  const isValid = isImpedanceValid && isCountValid;

  const handleReset = () => {
    setSpeakerRms(300);
    setSpeakerCount(2);
    setSpeakerImpedance(8);
    setWiring('parallel');
    setViewMode('input');
  };

  // Calculation result
  const result = useMemo(() => {
    return calculateOhm({
      speakerRms,
      speakerCount,
      speakerImpedance,
      wiring,
    });
  }, [speakerRms, speakerCount, speakerImpedance, wiring]);

  const [isRewardModalOpen, setIsRewardModalOpen] = useState(false);
  const isCalculatingRef = useRef(false);

  // Core execution of calculation
  const executeCalculation = () => {
    isCalculatingRef.current = true;

    analyticsService.logCalculationCompleted('ohm_calculator', {
      speakerRms,
      speakerCount,
      speakerImpedance,
      wiring,
      totalImpedance: result.totalImpedance,
      classification: result.classification,
    });

    // Save to local device history
    historyService.addEntry({
      calculatorId: 'calc_ohm',
      calculatorName: 'Ohm Calculator',
      resultSummary: `${result.totalImpedance.toFixed(2)} Ω`,
      badge: {
        text: result.classification === 'extreme' 
          ? 'Extreme Load' 
          : result.classification === 'uncommon'
            ? 'Uncommon Load'
            : result.classification === 'safe' 
              ? 'Safe Load' 
              : 'High Load',
        type: result.classification === 'extreme' 
          ? 'danger' 
          : (result.classification === 'safe' || result.classification === 'pro_load') 
            ? 'safe' 
            : 'warning',
      },
      details: [
        { label: 'Speakers', value: `${speakerCount} × ${speakerImpedance}Ω` },
        { label: 'Wiring', value: wiring === 'parallel' ? 'Parallel' : 'Series' },
        { label: 'Total RMS', value: `${result.totalSystemRms}W` },
      ],
    });

    setViewMode('result');
    window.scrollTo({ top: 0, behavior: 'smooth' });

    setTimeout(() => {
      isCalculatingRef.current = false;
    }, 400);
  };

  // Navigate to result screen: active subscribers or users with an active 60-min unlock see results directly
  const handleCalculate = () => {
    if (!isValid || isCalculatingRef.current) return;

    // 1. Active subscribers bypass ad checks
    if (subscriptionService.isPremium()) {
      executeCalculation();
      return;
    }

    // 2. If 60-minute unlock is still active across all calculators, show result immediately
    if (adService.hasActiveRewardPass()) {
      executeCalculation();
      return;
    }

    setIsRewardModalOpen(true);
  };

  // Modify Inputs: returns to input screen with state preserved
  const handleModifyInputs = () => {
    setViewMode('input');
  };

  // Color config according to load classification:
  // RED = Extreme load / Overload / Danger (< 2Ω)
  // ORANGE = 2Ω / Caution / High Current / Uncommon
  // GREEN = Safe Pro Load (4Ω, 8Ω)
  const getBadgeVisuals = () => {
    switch (result.classification) {
      case 'extreme':
        return {
          bannerBg: 'from-[#550C16] via-[#821422] to-[#36080E]',
          glowShadow: 'shadow-[0_10px_30px_rgba(220,38,38,0.45)]',
          borderHighlight: 'border-red-500/80',
          statusTheme: 'red' as const,
          bg: 'bg-red-600 text-white border-red-500 font-bold shadow-xs',
          titleColor: 'text-red-200',
          innerBoxBg: 'bg-black/40 border border-red-400/40 text-red-100',
          icon: <AlertTriangle className="w-5 h-5 text-red-400 shrink-0" />,
        };
      case 'requires_2ohm':
      case 'high_current':
      case 'uncommon':
        return {
          bannerBg: 'from-[#522004] via-[#85360A] to-[#331302]',
          glowShadow: 'shadow-[0_10px_30px_rgba(234,88,12,0.45)]',
          borderHighlight: 'border-amber-500/80',
          statusTheme: 'orange' as const,
          bg: 'bg-amber-500 text-slate-950 border-amber-400 font-black shadow-xs',
          titleColor: 'text-amber-200',
          innerBoxBg: 'bg-black/40 border border-amber-400/40 text-amber-100',
          icon: <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />,
        };
      case 'safe':
      case 'pro_load':
      default:
        return {
          bannerBg: 'from-[#064E3B] via-[#065F46] to-[#022C22]',
          glowShadow: 'shadow-[0_10px_30px_rgba(16,185,129,0.35)]',
          borderHighlight: 'border-emerald-500/80',
          statusTheme: 'green' as const,
          bg: 'bg-emerald-600 text-white border-emerald-400 font-bold shadow-xs',
          titleColor: 'text-emerald-200',
          innerBoxBg: 'bg-black/40 border border-emerald-400/40 text-emerald-100',
          icon: <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />,
        };
    }
  };

  const visuals = getBadgeVisuals();
  const statusTitle = (t as any)[result.statusTitleKey] || result.classification;
  const rawStatusMessage = (t as any)[result.statusMessageKey] || '';
  const statusMessage = formatStatusMessage(rawStatusMessage, result.totalImpedance);

  return (
    <div className={`min-h-full flex flex-col transition-colors duration-200 ${isNightMode ? 'bg-[#070B14]' : 'bg-[#F8FAFC]'}`}>
      {/* 1. Curved Blue Hero Header (Matching user's reference image) */}
      <CalculatorHeroHeader
        title={viewMode === 'result' 
          ? (language === 'hi' ? 'एनालिसिस रिजल्ट' : 'Analysis Result')
          : (language === 'hi' ? 'ओम कैलकुलेटर' : 'Ohm Calculator')
        }
        subtitle={viewMode === 'result'
          ? (language === 'hi' ? 'लोड और इम्पीडेंस कैलकुलेशन परिणाम' : 'Load and impedance circuit calculation breakdown')
          : (language === 'hi' ? 'स्पीकर वायरिंग और लोड एनालिसिस' : 'Speaker wiring, impedance & load analysis')
        }
        onBack={viewMode === 'result' ? handleModifyInputs : onBack}
        actions={
          <div className="bg-black/20 backdrop-blur-md p-1 rounded-full border border-white/20 inline-flex items-center">
            <button
              type="button"
              onClick={() => setLanguage('en')}
              className={`px-3 py-1 rounded-full text-[11px] font-bold transition-all ${
                language === 'en'
                  ? 'bg-white text-[#1D4ED8] shadow-xs'
                  : 'text-white/80 hover:text-white'
              }`}
            >
              English
            </button>
            <button
              type="button"
              onClick={() => setLanguage('hi')}
              className={`px-3 py-1 rounded-full text-[11px] font-bold transition-all ${
                language === 'hi'
                  ? 'bg-white text-[#1D4ED8] shadow-xs'
                  : 'text-white/80 hover:text-white'
              }`}
            >
              हिंदी
            </button>
          </div>
        }
      />

      {/* 2. Main Sheet */}
      <div className={`flex-1 rounded-t-[36px] -mt-5 relative z-20 px-4 pt-6 pb-28 min-h-[calc(100vh-180px)] transition-colors duration-200 ${
        isNightMode 
          ? 'bg-[#0E1526] text-slate-100 shadow-[0_-10px_35px_rgba(0,0,0,0.5)] border-t border-slate-800/80' 
          : 'bg-white text-slate-900 shadow-[0_-10px_35px_rgba(0,0,0,0.06)]'
      }`}>
        {/* ========================================================= */}
        {/* VIEW 1: INPUTS SCREEN                                     */}
        {/* ========================================================= */}
        {viewMode === 'input' && (
          <div className="space-y-5">
            {/* Section 1: Speaker RMS Power (Per Driver) */}
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="w-5 h-5 rounded-full bg-[#1D4ED8] text-white text-[11px] font-bold flex items-center justify-center shrink-0">
                  1
                </span>
                <h3 className={`font-bold text-sm ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                  {language === 'hi' ? 'स्पीकर RMS पावर (प्रति स्पीकर)' : 'Speaker RMS Power (Per Driver)'}
                </h3>
              </div>

            <div className={`border-[1.5px] rounded-[22px] p-2 flex items-center justify-between shadow-2xs transition-colors ${
              isNightMode 
                ? 'border-slate-800 bg-[#141C30]' 
                : 'border-[#DCE4F0] bg-[#FBFDFF]'
            }`}>
              <button
                type="button"
                id="btn-rms-minus"
                onClick={() => setSpeakerRms((prev) => Math.max(50, (prev || 0) - 50))}
                className={`w-11 h-11 rounded-[16px] flex items-center justify-center active:scale-95 transition shrink-0 ${
                  isNightMode 
                    ? 'bg-slate-800 text-slate-200 hover:bg-slate-700' 
                    : 'bg-[#EEF2F8] text-slate-700 hover:bg-slate-200'
                }`}
                aria-label="Decrease RMS"
              >
                <Minus className="w-4 h-4 stroke-[3]" />
              </button>

              <div className="flex-1 flex items-baseline justify-center gap-1.5 min-w-0">
                <input
                  type="number"
                  id="input-speaker-rms"
                  value={speakerRms === 0 ? '' : speakerRms}
                  onChange={handleRmsInputChange}
                  onBlur={handleRmsInputBlur}
                  placeholder="0"
                  className={`font-black text-2xl tracking-tight text-center bg-transparent border-b-2 border-transparent hover:border-slate-500 focus:border-[#2563EB] focus:outline-none rounded-md py-0.5 transition [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none ${
                    isNightMode ? 'text-white' : 'text-slate-900'
                  }`}
                  style={{ width: `${Math.max(3, String(speakerRms || '').length + 1)}ch` }}
                  aria-label="Speaker RMS Wattage"
                />
                <span className="text-xs font-semibold text-slate-400 select-none shrink-0">
                  {language === 'hi' ? 'वाट' : 'Watts'}
                </span>
              </div>

              <button
                type="button"
                id="btn-rms-plus"
                onClick={() => setSpeakerRms((prev) => Math.min(20000, (prev || 0) + 50))}
                className={`w-11 h-11 rounded-[16px] flex items-center justify-center active:scale-95 transition shrink-0 ${
                  isNightMode 
                    ? 'bg-slate-800 text-slate-200 hover:bg-slate-700' 
                    : 'bg-[#EEF2F8] text-slate-700 hover:bg-slate-200'
                }`}
                aria-label="Increase RMS"
              >
                <Plus className="w-4 h-4 stroke-[3]" />
              </button>
            </div>
          </div>

          {/* Section 2: Number of Speakers */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-5 h-5 rounded-full bg-[#1D4ED8] text-white text-[11px] font-bold flex items-center justify-center shrink-0">
                2
              </span>
              <h3 className={`font-bold text-sm ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                {language === 'hi' ? 'स्पीकर संख्या' : 'Number of Speakers'}
              </h3>
            </div>

            <div className={`border-[1.5px] rounded-[22px] p-2 flex items-center justify-between shadow-2xs transition-colors ${
              isNightMode 
                ? 'border-slate-800 bg-[#141C30]' 
                : 'border-[#DCE4F0] bg-[#FBFDFF]'
            }`}>
              <button
                type="button"
                id="btn-speakers-minus"
                disabled={speakerCount <= 1}
                onClick={() => setSpeakerCount((prev) => Math.max(1, prev - 1))}
                className={`w-11 h-11 rounded-[16px] flex items-center justify-center active:scale-95 disabled:opacity-40 transition ${
                  isNightMode 
                    ? 'bg-slate-800 text-slate-200 hover:bg-slate-700' 
                    : 'bg-[#EEF2F8] text-slate-700 hover:bg-slate-200'
                }`}
                aria-label="Decrease speaker count"
              >
                <Minus className="w-4 h-4 stroke-[3]" />
              </button>

              <div className="flex-1 flex items-baseline justify-center gap-1.5 min-w-0">
                <span className={`font-black text-2xl tracking-tight ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                  {speakerCount}
                </span>
                <span className="text-xs font-semibold text-slate-400 select-none shrink-0">
                  {language === 'hi' 
                    ? (speakerCount === 1 ? 'स्पीकर' : 'स्पीकर्स') 
                    : (speakerCount === 1 ? 'speaker' : 'speakers')}
                </span>
              </div>

              <button
                type="button"
                id="btn-speakers-plus"
                disabled={speakerCount >= 32}
                onClick={() => setSpeakerCount((prev) => Math.min(32, prev + 1))}
                className={`w-11 h-11 rounded-[16px] flex items-center justify-center active:scale-95 disabled:opacity-40 transition ${
                  isNightMode 
                    ? 'bg-slate-800 text-slate-200 hover:bg-slate-700' 
                    : 'bg-[#EEF2F8] text-slate-700 hover:bg-slate-200'
                }`}
                aria-label="Increase speaker count"
              >
                <Plus className="w-4 h-4 stroke-[3]" />
              </button>
            </div>
          </div>

          {/* Section 3: Speaker Impedance (Ohm) — Per Speaker */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-5 h-5 rounded-full bg-[#1D4ED8] text-white text-[11px] font-bold flex items-center justify-center shrink-0">
                3
              </span>
              <h3 className={`font-bold text-sm ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                {language === 'hi' ? 'स्पीकर ओम (प्रति स्पीकर)' : 'Speaker Impedance (Ohm) — Per Speaker'}
              </h3>
            </div>

            <div className="grid grid-cols-5 gap-2">
              {[2, 4, 6, 8, 16].map((imp) => {
                const isSelected = speakerImpedance === imp;
                return (
                  <button
                    key={imp}
                    type="button"
                    id={`btn-imp-${imp}`}
                    onClick={() => setSpeakerImpedance(imp)}
                    className={`rounded-[20px] py-3 px-1 transition-all text-center flex flex-col items-center justify-center shadow-2xs active:scale-95 ${
                      isSelected
                        ? isNightMode
                          ? 'border-2 border-blue-500 bg-blue-950/60 shadow-[0_0_12px_rgba(59,130,246,0.3)]'
                          : 'border-2 border-[#1D4ED8] bg-white'
                        : isNightMode
                          ? 'border border-slate-800 bg-[#141C30] hover:border-slate-700'
                          : 'border border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    <span className={`font-bold text-base ${
                      isSelected 
                        ? isNightMode ? 'text-blue-400' : 'text-[#1D4ED8]' 
                        : isNightMode ? 'text-slate-200' : 'text-slate-800'
                    }`}>
                      {imp}
                    </span>
                    <span className={`text-[11px] mt-0.5 font-semibold ${
                      isSelected 
                        ? isNightMode ? 'text-blue-400' : 'text-[#1D4ED8]' 
                        : 'text-slate-400'
                    }`}>
                      Ω
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section 4: Connection Type */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-5 h-5 rounded-full bg-[#1D4ED8] text-white text-[11px] font-bold flex items-center justify-center shrink-0">
                4
              </span>
              <h3 className={`font-bold text-sm ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                {language === 'hi' ? 'वायरिंग प्रकार' : 'Connection Type'}
              </h3>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {/* Parallel */}
              <button
                type="button"
                id="btn-connection-parallel"
                onClick={() => setWiring('parallel')}
                className={`rounded-[22px] py-3.5 px-4 text-center transition-all flex flex-col items-center justify-center shadow-2xs active:scale-98 ${
                  wiring === 'parallel'
                    ? isNightMode
                      ? 'border-2 border-blue-500 bg-blue-950/60 shadow-[0_0_12px_rgba(59,130,246,0.3)]'
                      : 'border-2 border-[#1D4ED8] bg-white'
                    : isNightMode
                      ? 'border border-slate-800 bg-[#141C30] hover:border-slate-700'
                      : 'border border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                <div className={`w-8 h-1 rounded-full mb-1.5 ${wiring === 'parallel' ? 'bg-[#1D4ED8]' : isNightMode ? 'bg-slate-700' : 'bg-slate-200'}`} />
                <span className={`font-bold text-xs sm:text-sm tracking-wide uppercase ${
                  wiring === 'parallel' 
                    ? isNightMode ? 'text-blue-400' : 'text-[#1D4ED8]' 
                    : isNightMode ? 'text-slate-300' : 'text-slate-600'
                }`}>
                  PARALLEL
                </span>
              </button>

              {/* Series */}
              <button
                type="button"
                id="btn-connection-series"
                onClick={() => setWiring('series')}
                className={`rounded-[22px] py-3.5 px-4 text-center transition-all flex flex-col items-center justify-center shadow-2xs active:scale-98 ${
                  wiring === 'series'
                    ? isNightMode
                      ? 'border-2 border-blue-500 bg-blue-950/60 shadow-[0_0_12px_rgba(59,130,246,0.3)]'
                      : 'border-2 border-[#1D4ED8] bg-white'
                    : isNightMode
                      ? 'border border-slate-800 bg-[#141C30] hover:border-slate-700'
                      : 'border border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                <div className={`w-8 h-1 rounded-full mb-1.5 ${wiring === 'series' ? 'bg-[#1D4ED8]' : isNightMode ? 'bg-slate-700' : 'bg-slate-200'}`} />
                <span className={`font-bold text-xs sm:text-sm tracking-wide uppercase ${
                  wiring === 'series' 
                    ? isNightMode ? 'text-blue-400' : 'text-[#1D4ED8]' 
                    : isNightMode ? 'text-slate-300' : 'text-slate-600'
                }`}>
                  SERIES
                </span>
              </button>
            </div>

            <p className={`text-xs leading-relaxed mt-3 mb-5 px-1 font-normal ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>
              {wiring === 'parallel'
                ? (language === 'hi' 
                    ? 'पैरलल वायरिंग कुल इम्पीडेंस को कम करती है और सभी स्पीकर्स की कुल RMS पावर जोड़ती है।' 
                    : 'Parallel wiring divides total impedance (Ohm) and sums total RMS power across all drivers.')
                : (language === 'hi' 
                    ? 'सीरीज वायरिंग कुल इम्पीडेंस को जोड़ती है और सभी स्पीकर्स की कुल RMS पावर जोड़ती है।' 
                    : 'Series wiring adds total impedance (Ohm) and sums total RMS power across all drivers.')}
            </p>

            {/* Action Button: ANALYZE LOAD & IMPEDANCE */}
            <button
              type="button"
              id="btn-analyze-load"
              onClick={handleCalculate}
              className={`w-full py-4 rounded-[22px] bg-[#FBBF24] hover:bg-[#F59E0B] text-[#0F172A] flex items-center justify-center gap-2 shadow-md active:scale-[0.98] transition-all border border-amber-300/80 ${
                language === 'hi'
                  ? 'font-semibold text-sm tracking-normal'
                  : 'font-black text-sm tracking-wide uppercase'
              }`}
            >
              <Zap className="w-5 h-5 text-[#0F172A] fill-[#0F172A]" />
              <span>{language === 'hi' ? 'लोड और इम्पीडेंस चेक करें' : 'ANALYZE LOAD & IMPEDANCE'}</span>
            </button>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* VIEW 2: DEDICATED RESULT SCREEN                           */}
      {/* ========================================================= */}
      {viewMode === 'result' && (
        <div className="space-y-4">
          {/* Main Load Result Banner */}
          <div className={`bg-gradient-to-br ${visuals.bannerBg} rounded-[28px] p-5 text-white ${visuals.glowShadow} border ${visuals.borderHighlight} relative overflow-hidden`}>
            <div className="flex items-start justify-between gap-2 mb-3">
              <div>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-[11px] font-semibold tracking-wider uppercase text-white/80">
                    {t.ohmResultTotalLoad}
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-white/20 text-white tracking-wide uppercase backdrop-blur-xs border border-white/20">
                    {t.perChannelBadge}
                  </span>
                </div>
                <div className="flex items-baseline gap-1.5 mt-0.5">
                  <span className="text-5xl font-extrabold tracking-tight text-white">
                    {result.totalImpedance.toFixed(2)}
                  </span>
                  <span className="text-2xl font-bold text-amber-300">Ω</span>
                  <span className="text-xs font-semibold text-white/70 ml-1">
                    {t.perChannelSuffix}
                  </span>
                </div>
              </div>

              {/* Status Classification Badge */}
              <div className={`px-3 py-1 rounded-full text-xs font-bold border uppercase tracking-wider ${visuals.bg}`}>
                {statusTitle}
              </div>
            </div>

            {/* Load Status Explanatory Card */}
            <div className={`mt-3 p-3 rounded-xl ${visuals.innerBoxBg} text-xs flex items-start gap-2.5`}>
              {visuals.icon}
              <div className="leading-relaxed">
                <div className={`font-bold mb-0.5 ${visuals.titleColor}`}>
                  {statusTitle}
                </div>
                <p className="text-[11px] text-white/90">
                  {statusMessage}
                </p>
              </div>
            </div>
          </div>

          {/* Per-Channel Clarification Banner */}
          <div className={`px-3 py-2 rounded-xl border flex items-center gap-2 transition-colors ${
            isNightMode 
              ? 'bg-blue-950/40 border-blue-900/40 text-blue-300' 
              : 'bg-blue-50/80 border-blue-200/80 text-blue-800'
          }`}>
            <Info className="w-4 h-4 text-blue-500 shrink-0" />
            <p className="text-[11px] font-medium leading-tight">
              {t.perChannelNotice}
            </p>
          </div>

          {/* AdMob Banner Area */}
          <div className="my-1">
            <AdBannerPlaceholder placement="result_bottom" />
          </div>

          {/* Compact Wiring Connection Diagram */}
          <WiringDiagram
            wiring={result.wiring}
            speakerCount={result.speakerCount}
            speakerImpedance={result.speakerImpedance}
          />

          {/* System Summary Card */}
          <div className={`rounded-[28px] p-5 border shadow-sm transition-colors ${
            isNightMode 
              ? 'bg-[#141C30] border-slate-800 text-slate-100' 
              : 'bg-white border-slate-200 text-slate-800'
          }`}>
            <div className={`flex items-center gap-2 mb-3 pb-2 border-b ${isNightMode ? 'border-slate-800' : 'border-slate-100'}`}>
              <Layers className="w-4 h-4 text-[#2563EB]" />
              <h3 className={`text-xs font-bold uppercase tracking-wider ${isNightMode ? 'text-slate-200' : 'text-slate-800'}`}>
                {t.ohmSummaryTitle}
              </h3>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className={`p-3 rounded-xl border ${
                isNightMode ? 'bg-[#19233C] border-slate-800' : 'bg-slate-50 border-slate-100'
              }`}>
                <span className={`text-[11px] block ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>{t.ohmSummaryTotalSpeakers}</span>
                <span className={`text-base font-bold mt-0.5 block ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                  {result.speakerCount} {result.speakerCount === 1 ? 'Speaker' : 'Speakers'}
                </span>
              </div>

              <div className={`p-3 rounded-xl border ${
                isNightMode ? 'bg-[#19233C] border-slate-800' : 'bg-slate-50 border-slate-100'
              }`}>
                <span className={`text-[11px] block ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>{t.ohmSummarySpeakerRms}</span>
                <span className={`text-base font-bold mt-0.5 block ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                  {result.speakerRms} <span className="text-xs font-semibold text-slate-400">Watts</span>
                </span>
              </div>

              <div className={`p-3 rounded-xl border ${
                isNightMode ? 'bg-[#19233C] border-slate-800' : 'bg-slate-50 border-slate-100'
              }`}>
                <span className={`text-[11px] block ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>{t.ohmSummaryTotalRms}</span>
                <span className={`text-base font-bold mt-0.5 block ${isNightMode ? 'text-blue-400' : 'text-[#1D4ED8]'}`}>
                  {result.totalSystemRms} <span className="text-xs font-semibold">Watts Total</span>
                </span>
              </div>

              <div className={`p-3 rounded-xl border ${
                isNightMode ? 'bg-[#19233C] border-slate-800' : 'bg-slate-50 border-slate-100'
              }`}>
                <span className={`text-[11px] block ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>{t.ohmSummaryWiring}</span>
                <span className={`text-sm font-bold mt-0.5 block capitalize ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                  {result.wiring === 'parallel' ? 'Parallel' : 'Series'}
                </span>
              </div>

              <div className={`p-3 rounded-xl border col-span-2 flex items-center justify-between ${
                isNightMode ? 'bg-[#19233C] border-slate-800' : 'bg-slate-50 border-slate-100'
              }`}>
                <div>
                  <span className={`text-[11px] block ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>{t.ohmSummaryCabinetImp}</span>
                  <span className={`text-sm font-bold ${isNightMode ? 'text-white' : 'text-slate-900'}`}>
                    {result.speakerImpedance} Ω each
                  </span>
                </div>
                <div className="text-right">
                  <span className={`text-[11px] block ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>Load Distribution</span>
                  <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                    result.classification === 'extreme'
                      ? (isNightMode ? 'text-red-400 bg-red-950/60 border border-red-800/40' : 'text-red-800 bg-red-50 border border-red-200')
                      : (result.classification === 'uncommon' || result.classification === 'requires_2ohm' || result.classification === 'high_current')
                        ? (isNightMode ? 'text-amber-400 bg-amber-950/60 border border-amber-800/40' : 'text-amber-800 bg-amber-50 border border-amber-200')
                        : (isNightMode ? 'text-emerald-400 bg-emerald-950/60 border border-emerald-800/40' : 'text-emerald-800 bg-emerald-50 border border-emerald-200')
                  }`}>
                    {result.classification === 'extreme' 
                      ? 'Unsafe' 
                      : result.classification === 'uncommon' 
                        ? 'Uncommon' 
                        : 'Balanced'}
                  </span>
                </div>
              </div>

              <div className={`p-3 rounded-xl border col-span-2 flex items-center justify-between ${
                isNightMode ? 'bg-[#19233C] border-slate-800' : 'bg-slate-50 border-slate-100'
              }`}>
                <div>
                  <span className={`text-[11px] block ${isNightMode ? 'text-slate-400' : 'text-slate-500'}`}>{t.perChannelScopeLabel}</span>
                  <span className={`text-sm font-bold ${isNightMode ? 'text-blue-300' : 'text-blue-700'}`}>
                    {t.perChannelScopeValue}
                  </span>
                </div>
                <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                  isNightMode ? 'text-blue-400 bg-blue-950/60 border border-blue-800/40' : 'text-blue-800 bg-blue-50 border border-blue-200'
                }`}>
                  1 Output
                </span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-2.5 pt-1">
            {/* Find Recommended Amplifier */}
            {result.canRecommendAmp && onNavigateToAmp && (
              <button
                type="button"
                id="btn-find-recommended-amp"
                onClick={() => onNavigateToAmp({
                  speakerRms: result.speakerRms,
                  speakerCount: result.speakerCount,
                  speakerImpedance: result.speakerImpedance,
                  wiring: result.wiring,
                  finalLoad: result.totalImpedance,
                  totalSystemRms: result.totalSystemRms,
                })}
                className="w-full py-3.5 px-4 rounded-[22px] font-black text-sm bg-[#FBBF24] hover:bg-[#F59E0B] text-[#0F172A] shadow-md active:scale-98 transition flex items-center justify-center gap-2 border border-amber-300/80"
              >
                <Zap className="w-4 h-4 text-[#0F172A] fill-[#0F172A]" />
                <span>{t.ohmFindAmp}</span>
                <ArrowRight className="w-4 h-4 ml-auto stroke-[2.5]" />
              </button>
            )}

            {/* Clear reason in result section if recommendation is restricted */}
            {!result.canRecommendAmp && (
              <div className={`p-4 rounded-[22px] border text-xs flex items-start gap-3 transition-colors ${
                isNightMode
                  ? 'bg-red-950/40 border-red-900/50 text-red-300'
                  : 'bg-red-50 border-red-200 text-red-900'
              }`}>
                <AlertTriangle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                <div className="leading-relaxed">
                  <div className="font-bold mb-0.5">
                    {language === 'hi' ? 'एम्पलीफायर सुझाव उपलब्ध नहीं' : 'Amplifier Recommendation Restricted'}
                  </div>
                  <p className="text-[11px] opacity-90">
                    {t.ampRecRestrictedReason || (language === 'hi'
                      ? 'सिस्टम लोड 2.0Ω (अत्यधिक लोड) से कम है। स्टैंडर्ड एम्पलीफायर 2.0Ω से नीचे सेफ नहीं चलते।'
                      : 'System load is below 2.0Ω (Extreme Load). Standard power amplifiers cannot safely drive loads below 2.0Ω.')}
                  </p>
                </div>
              </div>
            )}

            {/* Share Result Button */}
            <ShareResultButton
              calculatorTitle="OHM & LOAD CALCULATION"
              systemDetails={[
                `Cabinet Drivers: ${result.speakerCount} ${result.speakerCount === 1 ? 'Speaker' : 'Speakers'}`,
                `Cabinet Impedance: ${result.speakerImpedance}Ω each`,
                `Wiring Configuration: ${result.wiring === 'parallel' ? 'Parallel' : 'Series'}`,
                `Per Driver RMS: ${result.speakerRms}W RMS`,
                `Total System Power: ${result.totalSystemRms}W RMS`,
              ]}
              finalResults={[
                {
                  label: 'Total Net Load',
                  value: `${formatLoadValue(result.totalImpedance)}Ω (Per Channel)`,
                },
                {
                  label: 'Safety Classification',
                  value:
                    result.classification === 'extreme'
                      ? 'EXTREME LOAD (< 2Ω DANGER)'
                      : result.classification === 'requires_2ohm'
                        ? 'REQUIRED 2 OHM STABLE AMPLIFIER'
                        : result.classification === 'high_current'
                          ? 'HIGH CURRENT (2Ω STABLE AMP REQUIRED)'
                          : result.classification === 'safe'
                            ? 'SAFE OPERATING LOAD (4Ω–8Ω)'
                            : result.classification === 'pro_load'
                              ? 'PROFESSIONAL LOAD (8Ω–16Ω)'
                              : 'UNCOMMON LOAD (> 16Ω)',
                },
                {
                  label: 'Amplifier Recommendation',
                  value: result.totalImpedance >= 2.0
                    ? 'Compatible with 2Ω-8Ω stable amplifiers'
                    : 'Requires specialized sub-2Ω amplifier',
                },
              ]}
              warning={
                result.classification === 'extreme'
                  ? `This system load is ${formatLoadValue(result.totalImpedance)}Ω. May not be safe for standard audio amplifiers.`
                  : result.classification === 'uncommon'
                    ? `This system load is ${formatLoadValue(result.totalImpedance)}Ω. Uncommon for PA amplifiers. Verify amplifier compatibility.`
                    : result.totalImpedance < 4.0
                      ? `This system load is ${formatLoadValue(result.totalImpedance)}Ω. Check that your amplifier is 2Ω stable.`
                      : null
              }
            />

            {/* Modify Inputs Button */}
            <button
              type="button"
              id="btn-modify-inputs"
              onClick={handleModifyInputs}
              className={`w-full py-3.5 px-4 rounded-[22px] font-bold text-sm active:scale-98 transition flex items-center justify-center gap-2 shadow-2xs ${
                isNightMode 
                  ? 'bg-[#141C30] text-slate-200 border border-slate-800 hover:bg-[#19233C]' 
                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              <SlidersHorizontal className="w-4 h-4 text-slate-400" />
              <span>{t.ohmModifyInputs}</span>
            </button>
          </div>
        </div>
      )}

      {/* Unlock Dialog: Watch Ad (Top) OR Remove Ads/Subscription (Bottom) */}
      <CalculatorUnlockModal
        isOpen={isRewardModalOpen}
        calculatorTitle={t.ohmCalcTitle}
        onClose={() => setIsRewardModalOpen(false)}
        onUnlocked={() => {
          setIsRewardModalOpen(false);
          executeCalculation();
        }}
        onOpenSubscription={() => {
          setIsRewardModalOpen(false);
          onOpenSubscription?.();
        }}
      />
      </div>
    </div>
  );
};
