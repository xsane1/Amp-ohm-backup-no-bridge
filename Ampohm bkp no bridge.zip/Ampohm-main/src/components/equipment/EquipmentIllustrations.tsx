import React from 'react';

/**
 * Realistic Professional Audio & Lighting Equipment Artworks
 * Crafted specifically to match the reference image:
 * - Woofer driver with rubber surround, cone, dust cap & mounting frame
 * - 3-tier rack-mounted power amplifier stack with handles & VU meters
 * - 2-way PA cabinet loudspeaker with horn flare & woofer
 * - Coiled XLR stage cable bundle with blue metal connector barrels
 * - Moving head stage fixture with glowing cyan lens
 */

export const WooferIllustration: React.FC<{ className?: string }> = ({ className = "w-full h-full" }) => {
  return (
    <svg viewBox="0 0 160 160" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
      <defs>
        {/* Outer cast basket metallic gradient */}
        <radialGradient id="wfBasket" cx="50%" cy="50%" r="50%">
          <stop offset="70%" stopColor="#1e242b" />
          <stop offset="85%" stopColor="#374151" />
          <stop offset="92%" stopColor="#111827" />
          <stop offset="100%" stopColor="#4b5563" />
        </radialGradient>

        {/* Rubber surround gradient */}
        <radialGradient id="wfSurround" cx="44%" cy="40%" r="55%">
          <stop offset="0%" stopColor="#0b0f14" />
          <stop offset="50%" stopColor="#252c36" />
          <stop offset="80%" stopColor="#12171f" />
          <stop offset="100%" stopColor="#080c10" />
        </radialGradient>

        {/* Cone body gradient */}
        <radialGradient id="wfCone" cx="48%" cy="46%" r="50%">
          <stop offset="0%" stopColor="#1f2730" />
          <stop offset="45%" stopColor="#141920" />
          <stop offset="80%" stopColor="#0b0e13" />
          <stop offset="100%" stopColor="#05070a" />
        </radialGradient>

        {/* Dust cap gradient */}
        <radialGradient id="wfDustCap" cx="42%" cy="38%" r="50%">
          <stop offset="0%" stopColor="#3d4957" />
          <stop offset="40%" stopColor="#1a222c" />
          <stop offset="90%" stopColor="#0a0e13" />
          <stop offset="100%" stopColor="#030507" />
        </radialGradient>

        {/* Specular highlight on surround */}
        <linearGradient id="wfSurroundGlaze" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.4" />
          <stop offset="35%" stopColor="#ffffff" stopOpacity="0.05" />
          <stop offset="100%" stopColor="#000000" stopOpacity="0.6" />
        </linearGradient>

        {/* Screw highlight */}
        <linearGradient id="wfScrew" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#cbd5e1" />
          <stop offset="50%" stopColor="#64748b" />
          <stop offset="100%" stopColor="#334155" />
        </linearGradient>
      </defs>

      {/* Shadow */}
      <circle cx="82" cy="84" r="72" fill="#000000" fillOpacity="0.25" filter="blur(4px)" />

      {/* Outer rim */}
      <circle cx="80" cy="80" r="72" fill="url(#wfBasket)" stroke="#111827" strokeWidth="2" />
      <circle cx="80" cy="80" r="70" stroke="#4b5563" strokeWidth="0.75" fill="none" opacity="0.6" />

      {/* Gasket & rubber surround */}
      <circle cx="80" cy="80" r="64" fill="url(#wfSurround)" stroke="#090d12" strokeWidth="1.5" />
      <circle cx="80" cy="80" r="64" fill="url(#wfSurroundGlaze)" />

      {/* Surround inner valley */}
      <circle cx="80" cy="80" r="54" fill="none" stroke="#05070a" strokeWidth="2.5" />
      <circle cx="80" cy="80" r="53" fill="none" stroke="#2a333e" strokeWidth="0.7" opacity="0.8" />

      {/* Speaker cone */}
      <circle cx="80" cy="80" r="52" fill="url(#wfCone)" />

      {/* Concentric acoustic damping rings */}
      <circle cx="80" cy="80" r="44" stroke="#222b35" strokeWidth="0.8" fill="none" opacity="0.7" />
      <circle cx="80" cy="80" r="38" stroke="#1c242e" strokeWidth="0.8" fill="none" opacity="0.8" />
      <circle cx="80" cy="80" r="32" stroke="#151b22" strokeWidth="0.8" fill="none" opacity="0.9" />

      {/* Voice coil neck */}
      <circle cx="80" cy="80" r="26" fill="#0c1015" stroke="#05070a" strokeWidth="1" />

      {/* Center dust cap */}
      <circle cx="80" cy="80" r="23" fill="url(#wfDustCap)" stroke="#0f141a" strokeWidth="1" />

      {/* Specular sheen on dust cap */}
      <path
        d="M68 70 Q 78 62 90 67 Q 78 68 68 70 Z"
        fill="#ffffff"
        opacity="0.35"
      />
      <circle cx="75" cy="72" r="2.5" fill="#ffffff" opacity="0.4" />

      {/* 8 Perimeter Mounting Screws */}
      {[0, 45, 90, 135, 180, 225, 270, 315].map((deg, i) => {
        const rad = (deg * Math.PI) / 180;
        const cx = 80 + 68 * Math.cos(rad);
        const cy = 80 + 68 * Math.sin(rad);
        return (
          <g key={i}>
            <circle cx={cx} cy={cy} r="2.8" fill="url(#wfScrew)" stroke="#1e293b" strokeWidth="0.5" />
            <circle cx={cx} cy={cy} r="1.2" fill="#0f172a" />
          </g>
        );
      })}
    </svg>
  );
};

export const RackAmplifierIllustration: React.FC<{ className?: string; isAnimated?: boolean }> = ({ 
  className = "w-full h-full",
  isAnimated = false 
}) => {
  return (
    <svg viewBox="0 0 160 160" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
      <defs>
        <linearGradient id="ampChassis" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#11161d" />
          <stop offset="10%" stopColor="#1e2631" />
          <stop offset="85%" stopColor="#171e27" />
          <stop offset="100%" stopColor="#0c1015" />
        </linearGradient>

        <linearGradient id="ampHandle" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#4b5563" />
          <stop offset="50%" stopColor="#9ca3af" />
          <stop offset="100%" stopColor="#374151" />
        </linearGradient>

        <linearGradient id="ampKnob" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#374151" />
          <stop offset="50%" stopColor="#111827" />
          <stop offset="100%" stopColor="#030712" />
        </linearGradient>

        {/* Music-Reactive Up & Down Rising/Falling VU Meter Keyframes (Active in Night Mode) */}
        <style>{`
          /* Channel A: Synchronized Audio Level Rise & Fall (Up & Down on Bass Beats) */
          /* At 0%, level is low (only bottom green lit) */
          /* As beat hits (14%), column shoots UP: Green -> Lime -> Yellow -> Amber -> RED CLIP */
          /* From 18% to 40%, level decays DOWN: Red off -> Amber off -> Yellow off -> back to Green */
          @keyframes vuLadderRiseFallA_Clip {
            0%, 12% { opacity: 0.1; filter: none; }
            14%, 20% { opacity: 1; filter: drop-shadow(0 0 3.5px #ef4444); }
            24%, 60% { opacity: 0.1; filter: none; }
            64%, 68% { opacity: 0.95; filter: drop-shadow(0 0 3px #ef4444); }
            72%, 100% { opacity: 0.1; filter: none; }
          }
          @keyframes vuLadderRiseFallA_Amber {
            0%, 10% { opacity: 0.12; filter: none; }
            13%, 26% { opacity: 1; filter: drop-shadow(0 0 2.5px #f59e0b); }
            30%, 58% { opacity: 0.12; filter: none; }
            62%, 72% { opacity: 0.95; filter: drop-shadow(0 0 2.5px #f59e0b); }
            76%, 100% { opacity: 0.12; filter: none; }
          }
          @keyframes vuLadderRiseFallA_Yellow {
            0%, 8% { opacity: 0.15; filter: none; }
            11%, 34% { opacity: 1; filter: drop-shadow(0 0 2px #facc15); }
            38%, 56% { opacity: 0.15; filter: none; }
            60%, 78% { opacity: 0.95; filter: drop-shadow(0 0 2px #facc15); }
            82%, 100% { opacity: 0.15; filter: none; }
          }
          @keyframes vuLadderRiseFallA_Lime {
            0%, 6% { opacity: 0.25; filter: none; }
            9%, 44% { opacity: 1; filter: drop-shadow(0 0 1.8px #22c55e); }
            48%, 54% { opacity: 0.25; filter: none; }
            58%, 86% { opacity: 1; filter: drop-shadow(0 0 1.8px #22c55e); }
            90%, 100% { opacity: 0.25; filter: none; }
          }
          @keyframes vuLadderRiseFallA_Green {
            0%, 100% { opacity: 0.95; filter: drop-shadow(0 0 1.5px #10b981); }
            14%, 64% { opacity: 1; filter: drop-shadow(0 0 2.5px #10b981); }
            45%, 92% { opacity: 0.7; filter: drop-shadow(0 0 1px #10b981); }
          }

          /* Channel B: Stereo Audio Bounce (Slight delay & stereo groove) */
          @keyframes vuLadderRiseFallB_Clip {
            0%, 16% { opacity: 0.1; filter: none; }
            18%, 23% { opacity: 1; filter: drop-shadow(0 0 3.5px #ef4444); }
            27%, 66% { opacity: 0.1; filter: none; }
            70%, 74% { opacity: 0.95; filter: drop-shadow(0 0 3px #ef4444); }
            78%, 100% { opacity: 0.1; filter: none; }
          }
          @keyframes vuLadderRiseFallB_Amber {
            0%, 14% { opacity: 0.12; filter: none; }
            17%, 29% { opacity: 1; filter: drop-shadow(0 0 2.5px #f59e0b); }
            33%, 63% { opacity: 0.12; filter: none; }
            67%, 77% { opacity: 0.95; filter: drop-shadow(0 0 2.5px #f59e0b); }
            81%, 100% { opacity: 0.12; filter: none; }
          }
          @keyframes vuLadderRiseFallB_Yellow {
            0%, 11% { opacity: 0.15; filter: none; }
            14%, 37% { opacity: 1; filter: drop-shadow(0 0 2px #facc15); }
            41%, 60% { opacity: 0.15; filter: none; }
            64%, 82% { opacity: 0.95; filter: drop-shadow(0 0 2px #facc15); }
            86%, 100% { opacity: 0.15; filter: none; }
          }
          @keyframes vuLadderRiseFallB_Lime {
            0%, 8% { opacity: 0.25; filter: none; }
            11%, 46% { opacity: 1; filter: drop-shadow(0 0 1.8px #22c55e); }
            50%, 57% { opacity: 0.25; filter: none; }
            61%, 88% { opacity: 1; filter: drop-shadow(0 0 1.8px #22c55e); }
            92%, 100% { opacity: 0.25; filter: none; }
          }
          @keyframes vuLadderRiseFallB_Green {
            0%, 100% { opacity: 0.95; filter: drop-shadow(0 0 1.5px #10b981); }
            18%, 70% { opacity: 1; filter: drop-shadow(0 0 2.5px #10b981); }
            48%, 94% { opacity: 0.7; filter: drop-shadow(0 0 1px #10b981); }
          }

          @keyframes ampPowerPulse {
            0%, 100% { opacity: 0.85; filter: drop-shadow(0 0 1.5px #38bdf8); }
            50% { opacity: 1; filter: drop-shadow(0 0 3px #38bdf8); }
          }

          .amp-anim .vu-clip-a   { animation: vuLadderRiseFallA_Clip 0.92s cubic-bezier(0.1, 0.9, 0.2, 1) infinite; }
          .amp-anim .vu-amber-a  { animation: vuLadderRiseFallA_Amber 0.92s cubic-bezier(0.1, 0.9, 0.2, 1) infinite; }
          .amp-anim .vu-yellow-a { animation: vuLadderRiseFallA_Yellow 0.92s cubic-bezier(0.1, 0.9, 0.2, 1) infinite; }
          .amp-anim .vu-lime-a   { animation: vuLadderRiseFallA_Lime 0.92s cubic-bezier(0.1, 0.9, 0.2, 1) infinite; }
          .amp-anim .vu-green-a  { animation: vuLadderRiseFallA_Green 0.92s ease-in-out infinite; }

          .amp-anim .vu-clip-b   { animation: vuLadderRiseFallB_Clip 0.92s cubic-bezier(0.1, 0.9, 0.2, 1) infinite; }
          .amp-anim .vu-amber-b  { animation: vuLadderRiseFallB_Amber 0.92s cubic-bezier(0.1, 0.9, 0.2, 1) infinite; }
          .amp-anim .vu-yellow-b { animation: vuLadderRiseFallB_Yellow 0.92s cubic-bezier(0.1, 0.9, 0.2, 1) infinite; }
          .amp-anim .vu-lime-b   { animation: vuLadderRiseFallB_Lime 0.92s cubic-bezier(0.1, 0.9, 0.2, 1) infinite; }
          .amp-anim .vu-green-b  { animation: vuLadderRiseFallB_Green 0.92s ease-in-out infinite; }

          .amp-anim .amp-power-pilot { animation: ampPowerPulse 2s ease-in-out infinite; }
        `}</style>
      </defs>

      {/* Drop Shadow */}
      <rect x="22" y="24" width="124" height="116" rx="6" fill="#000000" fillOpacity="0.3" filter="blur(6px)" />

      {/* Rack Case Stack: 3 Units */}
      {[0, 1, 2].map((idx) => {
        const y = 22 + idx * 38;
        const delay = (idx * -0.28).toFixed(2) + 's';

        return (
          <g key={idx} className={isAnimated ? 'amp-anim' : ''}>
            {/* Unit Faceplate */}
            <rect
              x="20"
              y={y}
              width="126"
              height="35"
              rx="4"
              fill="url(#ampChassis)"
              stroke="#2e3846"
              strokeWidth="1"
            />
            {/* Top edge metallic bevel */}
            <line x1="22" y1={y + 1} x2="144" y2={y + 1} stroke="#475569" strokeWidth="0.8" opacity="0.6" />

            {/* Left 19" Rack Ear & Holes */}
            <rect x="20" y={y} width="10" height="35" fill="#141a22" stroke="#2a3441" strokeWidth="0.6" />
            <circle cx="25" cy={y + 8} r="2" fill="#0a0e13" stroke="#4b5563" strokeWidth="0.7" />
            <circle cx="25" cy={y + 27} r="2" fill="#0a0e13" stroke="#4b5563" strokeWidth="0.7" />

            {/* Right 19" Rack Ear & Holes */}
            <rect x="136" y={y} width="10" height="35" fill="#141a22" stroke="#2a3441" strokeWidth="0.6" />
            <circle cx="141" cy={y + 8} r="2" fill="#0a0e13" stroke="#4b5563" strokeWidth="0.7" />
            <circle cx="141" cy={y + 27} r="2" fill="#0a0e13" stroke="#4b5563" strokeWidth="0.7" />

            {/* Heavy Duty Left Handle */}
            <rect x="33" y={y + 5} width="4.5" height="25" rx="2" fill="url(#ampHandle)" stroke="#1f2937" strokeWidth="0.5" />

            {/* Power Switch & Glowing Pilot LED (Fully Down / Off in Day Mode, Glowing in Night Mode) */}
            <rect x="40" y={y + 14} width="3" height="7" rx="1" fill="#0b0f15" stroke="#334155" strokeWidth="0.5" />
            <circle 
              cx="41.5" 
              cy={y + 16} 
              r="1.1" 
              fill={isAnimated ? "#38bdf8" : "#1e293b"} 
              className={isAnimated ? "amp-power-pilot" : ""} 
              style={{ 
                opacity: isAnimated ? undefined : 0.15,
                animationDelay: `${idx * -0.4}s` 
              }} 
            />

            {/* Center Cooling Grill / Vents */}
            <g opacity="0.8">
              {[0, 4, 8, 12].map((vy) => (
                <line
                  key={vy}
                  x1="47"
                  y1={y + 11 + vy}
                  x2="77"
                  y2={y + 11 + vy}
                  stroke="#080c10"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                />
              ))}
            </g>

            {/* Channel A & B Level Knobs */}
            <circle cx="87" cy={y + 17} r="5.5" fill="url(#ampKnob)" stroke="#4b5563" strokeWidth="0.8" />
            <line x1="87" y1={y + 12.5} x2="87" y2={y + 15} stroke="#2563EB" strokeWidth="1.5" />

            <circle cx="102" cy={y + 17} r="5.5" fill="url(#ampKnob)" stroke="#4b5563" strokeWidth="0.8" />
            <line x1="102" y1={y + 12.5} x2="102" y2={y + 15} stroke="#2563EB" strokeWidth="1.5" />

            {/* DUAL STEREO LED VU METER LADDERS (Channel A & Channel B) */}
            {/* Dark Bezel Background Plate */}
            <rect x="113.5" y={y + 7.5} width="8.5" height="20" rx="1.5" fill="#080c10" stroke="#1f2937" strokeWidth="0.5" />

            {/* Channel A Column (Left) */}
            <g>
              {/* Segment 5 (Top - Red CLIP/PEAK LED) */}
              <rect x="114.5" y={y + 8.5} width="2.8" height="2.5" rx="0.5" fill="#2d1013" />
              <rect 
                x="114.5" 
                y={y + 8.5} 
                width="2.8" 
                height="2.5" 
                rx="0.5" 
                fill="#ef4444" 
                className="vu-clip-a" 
                style={{ 
                  opacity: isAnimated ? undefined : 0.05,
                  animationDelay: delay 
                }} 
              />

              {/* Segment 4 (Amber LIMIT / 0dB LED) */}
              <rect x="114.5" y={y + 12} width="2.8" height="2.5" rx="0.5" fill="#2b1a07" />
              <rect 
                x="114.5" 
                y={y + 12} 
                width="2.8" 
                height="2.5" 
                rx="0.5" 
                fill="#f59e0b" 
                className="vu-amber-a" 
                style={{ 
                  opacity: isAnimated ? undefined : 0.05,
                  animationDelay: delay 
                }} 
              />

              {/* Segment 3 (Yellow -6dB LED) */}
              <rect x="114.5" y={y + 15.5} width="2.8" height="2.5" rx="0.5" fill="#282207" />
              <rect 
                x="114.5" 
                y={y + 15.5} 
                width="2.8" 
                height="2.5" 
                rx="0.5" 
                fill="#facc15" 
                className="vu-yellow-a" 
                style={{ 
                  opacity: isAnimated ? undefined : 0.05,
                  animationDelay: delay 
                }} 
              />

              {/* Segment 2 (Lime Green -12dB LED) */}
              <rect x="114.5" y={y + 19} width="2.8" height="2.5" rx="0.5" fill="#0b2413" />
              <rect 
                x="114.5" 
                y={y + 19} 
                width="2.8" 
                height="2.5" 
                rx="0.5" 
                fill="#22c55e" 
                className="vu-lime-a" 
                style={{ 
                  opacity: isAnimated ? undefined : 0.05,
                  animationDelay: delay 
                }} 
              />

              {/* Segment 1 (Bottom - Bright Green SIGNAL LED) */}
              <rect x="114.5" y={y + 22.5} width="2.8" height="2.5" rx="0.5" fill="#082216" />
              <rect 
                x="114.5" 
                y={y + 22.5} 
                width="2.8" 
                height="2.5" 
                rx="0.5" 
                fill="#10b981" 
                className="vu-green-a" 
                style={{ 
                  opacity: isAnimated ? undefined : 0.05,
                  animationDelay: delay 
                }} 
              />
            </g>

            {/* Channel B Column (Right) */}
            <g>
              {/* Segment 5 (Top - Red CLIP/PEAK LED) */}
              <rect x="118.2" y={y + 8.5} width="2.8" height="2.5" rx="0.5" fill="#2d1013" />
              <rect 
                x="118.2" 
                y={y + 8.5} 
                width="2.8" 
                height="2.5" 
                rx="0.5" 
                fill="#ef4444" 
                className="vu-clip-b" 
                style={{ 
                  opacity: isAnimated ? undefined : 0.05,
                  animationDelay: delay 
                }} 
              />

              {/* Segment 4 (Amber LIMIT / 0dB LED) */}
              <rect x="118.2" y={y + 12} width="2.8" height="2.5" rx="0.5" fill="#2b1a07" />
              <rect 
                x="118.2" 
                y={y + 12} 
                width="2.8" 
                height="2.5" 
                rx="0.5" 
                fill="#f59e0b" 
                className="vu-amber-b" 
                style={{ 
                  opacity: isAnimated ? undefined : 0.05,
                  animationDelay: delay 
                }} 
              />

              {/* Segment 3 (Yellow -6dB LED) */}
              <rect x="118.2" y={y + 15.5} width="2.8" height="2.5" rx="0.5" fill="#282207" />
              <rect 
                x="118.2" 
                y={y + 15.5} 
                width="2.8" 
                height="2.5" 
                rx="0.5" 
                fill="#facc15" 
                className="vu-yellow-b" 
                style={{ 
                  opacity: isAnimated ? undefined : 0.05,
                  animationDelay: delay 
                }} 
              />

              {/* Segment 2 (Lime Green -12dB LED) */}
              <rect x="118.2" y={y + 19} width="2.8" height="2.5" rx="0.5" fill="#0b2413" />
              <rect 
                x="118.2" 
                y={y + 19} 
                width="2.8" 
                height="2.5" 
                rx="0.5" 
                fill="#22c55e" 
                className="vu-lime-b" 
                style={{ 
                  opacity: isAnimated ? undefined : 0.05,
                  animationDelay: delay 
                }} 
              />

              {/* Segment 1 (Bottom - Bright Green SIGNAL LED) */}
              <rect x="118.2" y={y + 22.5} width="2.8" height="2.5" rx="0.5" fill="#082216" />
              <rect 
                x="118.2" 
                y={y + 22.5} 
                width="2.8" 
                height="2.5" 
                rx="0.5" 
                fill="#10b981" 
                className="vu-green-b" 
                style={{ 
                  opacity: isAnimated ? undefined : 0.05,
                  animationDelay: delay 
                }} 
              />
            </g>

            {/* Right Heavy Duty Handle */}
            <rect x="126" y={y + 5} width="4.5" height="25" rx="2" fill="url(#ampHandle)" stroke="#1f2937" strokeWidth="0.5" />
          </g>
        );
      })}
    </svg>
  );
};

export const TopSpeakerIllustration: React.FC<{ className?: string }> = ({ className = "w-full h-full" }) => {
  return (
    <svg viewBox="0 0 160 160" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
      <defs>
        <linearGradient id="cabBody" x1="0" y1="0" x2="1" y2="0.3">
          <stop offset="0%" stopColor="#1e242c" />
          <stop offset="50%" stopColor="#13181f" />
          <stop offset="100%" stopColor="#0a0d11" />
        </linearGradient>

        <linearGradient id="hornThroat" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#080a0d" />
          <stop offset="50%" stopColor="#181f28" />
          <stop offset="100%" stopColor="#050709" />
        </linearGradient>

        <radialGradient id="spkCone" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#2c3540" />
          <stop offset="40%" stopColor="#192027" />
          <stop offset="85%" stopColor="#0c1015" />
          <stop offset="100%" stopColor="#05070a" />
        </radialGradient>
      </defs>

      {/* Drop shadow */}
      <rect x="36" y="16" width="94" height="134" rx="10" fill="#000000" fillOpacity="0.25" filter="blur(5px)" />

      {/* Trapezoidal PA Enclosure Cabinet */}
      <rect
        x="34"
        y="14"
        width="92"
        height="132"
        rx="8"
        fill="url(#cabBody)"
        stroke="#2c3644"
        strokeWidth="1.2"
      />

      {/* Inner baffle recess */}
      <rect
        x="40"
        y="20"
        width="80"
        height="120"
        rx="5"
        fill="#0d1116"
        stroke="#1a212a"
        strokeWidth="1"
      />

      {/* Top High-Frequency Horn Flare */}
      <path
        d="M48 30 L112 30 L104 60 L56 60 Z"
        fill="url(#hornThroat)"
        stroke="#26313d"
        strokeWidth="1"
      />
      {/* Horn Compression Driver Throat ellipse */}
      <ellipse cx="80" cy="45" rx="12" ry="5" fill="#050709" stroke="#334150" strokeWidth="0.8" />
      <ellipse cx="80" cy="45" rx="7" ry="2.5" fill="#00b4a0" fillOpacity="0.3" />

      {/* Horn flare horizontal expansion ridges */}
      <line x1="53" y1="38" x2="107" y2="38" stroke="#1d252f" strokeWidth="0.8" />
      <line x1="55" y1="52" x2="105" y2="52" stroke="#1d252f" strokeWidth="0.8" />

      {/* Lower Mid/Bass 15-inch Woofer */}
      <circle cx="80" cy="100" r="32" fill="#070a0e" stroke="#1d2530" strokeWidth="1.5" />
      {/* Rubber surround */}
      <circle cx="80" cy="100" r="29" fill="none" stroke="#252f3c" strokeWidth="2.5" opacity="0.9" />
      {/* Cone */}
      <circle cx="80" cy="100" r="26" fill="url(#spkCone)" />
      {/* Dust cap */}
      <circle cx="80" cy="100" r="11" fill="#131921" stroke="#080c10" strokeWidth="1" />
      <circle cx="77" cy="97" r="1.5" fill="#ffffff" opacity="0.4" />

      {/* Dual Bass Reflex Ports at bottom */}
      <circle cx="50" cy="132" r="3.5" fill="#050709" stroke="#1f2833" strokeWidth="0.8" />
      <circle cx="110" cy="132" r="3.5" fill="#050709" stroke="#1f2833" strokeWidth="0.8" />
    </svg>
  );
};

export const CableLossIllustration: React.FC<{ className?: string }> = ({ className = "w-full h-full" }) => {
  return (
    <svg viewBox="0 0 160 160" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
      <defs>
        {/* Rubber cable sheen */}
        <linearGradient id="cableSheen" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#2e3846" />
          <stop offset="50%" stopColor="#151b22" />
          <stop offset="100%" stopColor="#080b0f" />
        </linearGradient>

        {/* Anodized Blue Neutrik connector ring */}
        <linearGradient id="neutrikBlue" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#38bdf8" />
          <stop offset="40%" stopColor="#0284c7" />
          <stop offset="100%" stopColor="#0369a1" />
        </linearGradient>

        {/* Chrome metallic barrel */}
        <linearGradient id="chromeBarrel" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#475569" />
          <stop offset="30%" stopColor="#94a3b8" />
          <stop offset="70%" stopColor="#cbd5e1" />
          <stop offset="100%" stopColor="#334155" />
        </linearGradient>
      </defs>

      {/* Drop shadow */}
      <ellipse cx="80" cy="115" rx="65" ry="28" fill="#000000" fillOpacity="0.25" filter="blur(6px)" />

      {/* Coiled Cable Loops */}
      {/* Outer loop */}
      <circle
        cx="92"
        cy="70"
        r="48"
        stroke="url(#cableSheen)"
        strokeWidth="11"
        fill="none"
      />
      <circle
        cx="92"
        cy="70"
        r="48"
        stroke="#ffffff"
        strokeWidth="1"
        strokeDasharray="40 100"
        strokeDashoffset="20"
        fill="none"
        opacity="0.2"
      />

      {/* Mid loop */}
      <circle
        cx="94"
        cy="72"
        r="38"
        stroke="url(#cableSheen)"
        strokeWidth="10"
        fill="none"
      />

      {/* Inner loop */}
      <circle
        cx="95"
        cy="74"
        r="28"
        stroke="url(#cableSheen)"
        strokeWidth="9"
        fill="none"
      />

      {/* Cable leads extending forward */}
      <path
        d="M60 85 Q 48 105 40 120"
        stroke="#11161d"
        strokeWidth="9"
        strokeLinecap="round"
        fill="none"
      />
      <path
        d="M75 88 Q 66 108 58 126"
        stroke="#18202a"
        strokeWidth="9"
        strokeLinecap="round"
        fill="none"
      />

      {/* Heavy Duty XLR / Speakon Connector 1 (Left) */}
      <g transform="rotate(-30 40 120)">
        {/* Rubber strain relief boot */}
        <rect x="36" y="96" width="8" height="15" rx="1.5" fill="#0b0e12" stroke="#1f2937" strokeWidth="0.5" />
        {/* Blue anodized collar */}
        <rect x="35" y="86" width="10" height="10" rx="1" fill="url(#neutrikBlue)" stroke="#0284c7" strokeWidth="0.5" />
        {/* Chrome metallic barrel */}
        <rect x="34.5" y="68" width="11" height="18" rx="1.5" fill="url(#chromeBarrel)" stroke="#1e293b" strokeWidth="0.5" />
        {/* Pin contacts face */}
        <circle cx="40" cy="65" r="5" fill="#0f172a" stroke="#475569" strokeWidth="0.8" />
        <circle cx="38" cy="64" r="0.9" fill="#f8fafc" />
        <circle cx="42" cy="64" r="0.9" fill="#f8fafc" />
        <circle cx="40" cy="67" r="0.9" fill="#f8fafc" />
      </g>

      {/* Heavy Duty XLR / Speakon Connector 2 (Right) */}
      <g transform="rotate(-25 68 128)">
        {/* Rubber strain relief boot */}
        <rect x="64" y="102" width="8" height="15" rx="1.5" fill="#0b0e12" stroke="#1f2937" strokeWidth="0.5" />
        {/* Blue anodized collar */}
        <rect x="63" y="92" width="10" height="10" rx="1" fill="url(#neutrikBlue)" stroke="#0284c7" strokeWidth="0.5" />
        {/* Chrome metallic barrel */}
        <rect x="62.5" y="74" width="11" height="18" rx="1.5" fill="url(#chromeBarrel)" stroke="#1e293b" strokeWidth="0.5" />
        {/* Pin contacts face */}
        <circle cx="68" cy="71" r="5" fill="#0f172a" stroke="#475569" strokeWidth="0.8" />
        <circle cx="66" cy="70" r="0.9" fill="#f8fafc" />
        <circle cx="70" cy="70" r="0.9" fill="#f8fafc" />
        <circle cx="68" cy="73" r="0.9" fill="#f8fafc" />
      </g>
    </svg>
  );
};

export const DmxMovingHeadIllustration: React.FC<{ className?: string; isAnimated?: boolean }> = ({ 
  className = "w-full h-full",
  isAnimated = false 
}) => {
  return (
    <svg viewBox="65 10 130 142" overflow="visible" fill="none" xmlns="http://www.w3.org/2000/svg" className={`${className} overflow-visible`}>
      <defs>
        {/* Realistic Fixture matte black body with metallic specular gradient */}
        <linearGradient id="sharpyBody" x1="0" y1="0" x2="1" y2="0.6">
          <stop offset="0%" stopColor="#242c3b" />
          <stop offset="25%" stopColor="#1a202c" />
          <stop offset="60%" stopColor="#111620" />
          <stop offset="100%" stopColor="#080b10" />
        </linearGradient>

        {/* Chassis Top Edge Highlight */}
        <linearGradient id="sharpyEdgeHighlight" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#334155" stopOpacity="0.4" />
          <stop offset="50%" stopColor="#94a3b8" stopOpacity="0.8" />
          <stop offset="100%" stopColor="#334155" stopOpacity="0.4" />
        </linearGradient>

        {/* Authentic Clay Paky Sharpy Head Casing Gradient */}
        <linearGradient id="sharpyHeadHousing" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#0f1520" />
          <stop offset="15%" stopColor="#1e2638" />
          <stop offset="35%" stopColor="#2e3b50" />
          <stop offset="65%" stopColor="#1a2232" />
          <stop offset="85%" stopColor="#121824" />
          <stop offset="100%" stopColor="#080b10" />
        </linearGradient>

        {/* Sharpy Molded Shoulder Bevel Highlight */}
        <linearGradient id="sharpyShoulderGleam" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#94a3b8" stopOpacity="0.7" />
          <stop offset="40%" stopColor="#475569" stopOpacity="0.3" />
          <stop offset="100%" stopColor="#1e293b" stopOpacity="0.0" />
        </linearGradient>

        {/* Stepped Front Projector Snout Collar */}
        <linearGradient id="sharpySnoutCollar" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#0b0f17" />
          <stop offset="25%" stopColor="#1e2838" />
          <stop offset="50%" stopColor="#33435c" />
          <stop offset="75%" stopColor="#1c2535" />
          <stop offset="100%" stopColor="#090d14" />
        </linearGradient>

        {/* Anodized Aluminum Lens Bezel Ring */}
        <linearGradient id="sharpyBezelRing" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#64748b" />
          <stop offset="30%" stopColor="#1e293b" />
          <stop offset="70%" stopColor="#475569" />
          <stop offset="100%" stopColor="#0f172a" />
        </linearGradient>

        {/* Deep Optical Cavity Baffle */}
        <radialGradient id="sharpyBaffleDepth" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#020617" />
          <stop offset="60%" stopColor="#050811" />
          <stop offset="90%" stopColor="#0b1120" />
          <stop offset="100%" stopColor="#1e293b" />
        </radialGradient>

        {/* Multi-Coated Sharpy Convex Objective Glass */}
        <radialGradient id="sharpyGlassCoating" cx="42%" cy="40%" r="58%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.95" />
          <stop offset="18%" stopColor="#bae6fd" stopOpacity="0.90" />
          <stop offset="40%" stopColor="#38bdf8" stopOpacity="0.82" />
          <stop offset="70%" stopColor="#0284c7" stopOpacity="0.88" />
          <stop offset="92%" stopColor="#1e3a8a" stopOpacity="0.95" />
          <stop offset="100%" stopColor="#091124" stopOpacity="1.0" />
        </radialGradient>

        {/* Glowing stage royal blue lens beam */}
        <radialGradient id="dmxCyanGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#cffafe" />
          <stop offset="25%" stopColor="#38bdf8" />
          <stop offset="60%" stopColor="#2563eb" />
          <stop offset="100%" stopColor="#0f172a" />
        </radialGradient>

        <linearGradient id="dmxGlass" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.75" />
          <stop offset="45%" stopColor="#93c5fd" stopOpacity="0.3" />
          <stop offset="100%" stopColor="#172554" stopOpacity="0.85" />
        </linearGradient>

        {/* Realistic High-Power Sharpy Stage Beam Cone Gradients (Super Long & Ultra Bright) */}
        <linearGradient id="sharpyStageBeam" x1="0.5" y1="1" x2="0.5" y2="0">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.95" />
          <stop offset="8%" stopColor="#67e8f9" stopOpacity="0.92" />
          <stop offset="28%" stopColor="#38bdf8" stopOpacity="0.82" />
          <stop offset="58%" stopColor="#0ea5e9" stopOpacity="0.65" />
          <stop offset="82%" stopColor="#2563eb" stopOpacity="0.45" />
          <stop offset="100%" stopColor="#1d4ed8" stopOpacity="0.10" />
        </linearGradient>

        <linearGradient id="sharpyCoreRay" x1="0.5" y1="1" x2="0.5" y2="0">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="1.0" />
          <stop offset="20%" stopColor="#ffffff" stopOpacity="0.98" />
          <stop offset="50%" stopColor="#e0f2fe" stopOpacity="0.88" />
          <stop offset="80%" stopColor="#38bdf8" stopOpacity="0.75" />
          <stop offset="100%" stopColor="#0284c7" stopOpacity="0.35" />
        </linearGradient>

        <linearGradient id="sharpyLaserNeedle" x1="0.5" y1="1" x2="0.5" y2="0">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="1.0" />
          <stop offset="35%" stopColor="#ffffff" stopOpacity="1.0" />
          <stop offset="70%" stopColor="#f0f9ff" stopOpacity="0.92" />
          <stop offset="100%" stopColor="#7dd3fc" stopOpacity="0.55" />
        </linearGradient>

        <radialGradient id="sharpyApertureFlare" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="1.0" />
          <stop offset="25%" stopColor="#ffffff" stopOpacity="0.95" />
          <stop offset="50%" stopColor="#38bdf8" stopOpacity="0.90" />
          <stop offset="75%" stopColor="#0284c7" stopOpacity="0.50" />
          <stop offset="100%" stopColor="#0284c7" stopOpacity="0.0" />
        </radialGradient>

        <style>{`
          @keyframes sharpySweep {
            0%, 100% {
              transform: rotate(-12deg);
              opacity: 0.94;
            }
            50% {
              transform: rotate(10deg);
              opacity: 1;
            }
          }
          @keyframes sharpyPulse {
            0%, 100% { 
              opacity: 0.92; 
              filter: drop-shadow(0 0 16px rgba(56, 189, 248, 0.7)) drop-shadow(0 0 32px rgba(14, 165, 233, 0.5)); 
            }
            50% { 
              opacity: 1; 
              filter: drop-shadow(0 0 26px rgba(56, 189, 248, 0.98)) drop-shadow(0 0 54px rgba(56, 189, 248, 0.75)); 
            }
          }
          .sharpy-beam-active {
            transform-origin: 131px 56px;
            animation: sharpySweep 4.2s ease-in-out infinite, sharpyPulse 2.1s ease-in-out infinite;
          }
        `}</style>
      </defs>

      {/* 1. Stage Floor Drop Shadow under Base */}
      <ellipse cx="130" cy="142" rx="46" ry="6" fill="#000000" fillOpacity="0.35" filter="blur(3px)" />

      {/* 2. Heavy-duty Rubber Base Feet with Ground Grip */}
      <rect x="94" y="137" width="13" height="4" rx="1.5" fill="#080c12" stroke="#1e293b" strokeWidth="0.6" />
      <line x1="97" y1="138.5" x2="104" y2="138.5" stroke="#334155" strokeWidth="0.8" />
      <rect x="153" y="137" width="13" height="4" rx="1.5" fill="#080c12" stroke="#1e293b" strokeWidth="0.6" />
      <line x1="156" y1="138.5" x2="163" y2="138.5" stroke="#334155" strokeWidth="0.8" />

      {/* 3. Rugged Sharpy Base Chassis (Stage Grade Housing) */}
      <rect x="88" y="122" width="84" height="16" rx="4" fill="url(#sharpyBody)" stroke="#2b3747" strokeWidth="1" />
      {/* Top chamfer edge highlight */}
      <line x1="90" y1="123" x2="170" y2="123" stroke="url(#sharpyEdgeHighlight)" strokeWidth="1" />

      {/* Molded Side Carry Handles */}
      <rect x="90" y="126" width="3.5" height="8" rx="1.5" fill="#05080d" stroke="#1e293b" strokeWidth="0.5" />
      <rect x="166.5" y="126" width="3.5" height="8" rx="1.5" fill="#05080d" stroke="#1e293b" strokeWidth="0.5" />

      {/* Front DMX Control Console Inset */}
      <rect x="108" y="125" width="44" height="11" rx="2" fill="#070b13" stroke="#1e293b" strokeWidth="0.75" />

      {/* Backlit Digital LCD Screen with Address 'd001' */}
      <rect x="110" y="126.5" width="22" height="8" rx="1" fill="#040d1e" stroke="#2563eb" strokeWidth="0.6" />
      <text x="121" y="132.8" fill="#38bdf8" fontSize="5.2" fontWeight="900" fontFamily="monospace" textAnchor="middle" letterSpacing="0.6">d001</text>

      {/* Dual Status Indicator LEDs */}
      {/* Green Signal LED (Glow) */}
      <circle cx="134.5" cy="128.5" r="1.1" fill="#10b981" />
      <circle cx="134.5" cy="128.5" r="2.2" fill="#10b981" opacity="0.35" />
      {/* Red Power LED */}
      <circle cx="134.5" cy="132.5" r="0.9" fill="#ef4444" />

      {/* 4 Tactile Micro Navigation Buttons (Menu, Up, Down, Enter) */}
      <circle cx="138.8" cy="128.5" r="1.1" fill="#94a3b8" stroke="#334155" strokeWidth="0.4" />
      <circle cx="142.5" cy="128.5" r="1.1" fill="#cbd5e1" stroke="#334155" strokeWidth="0.4" />
      <circle cx="146.2" cy="128.5" r="1.1" fill="#cbd5e1" stroke="#334155" strokeWidth="0.4" />
      <circle cx="150" cy="128.5" r="1.1" fill="#38bdf8" stroke="#0284c7" strokeWidth="0.4" />

      {/* 4. Pan Turntable Platform & Pan Ring */}
      <rect x="96" y="117" width="68" height="6" rx="2" fill="#131924" stroke="#232e3f" strokeWidth="0.8" />
      <rect x="118" y="112" width="24" height="6" rx="1.5" fill="#1c2432" stroke="#334155" strokeWidth="0.8" />
      {/* Pan Degree Index Scale Marks */}
      <line x1="123" y1="115" x2="137" y2="115" stroke="#64748b" strokeWidth="0.6" strokeDasharray="1,1" />

      {/* 5. Sculpted Dual Yoke Heavy Arms (Cast Aluminum Forks) */}
      {/* Left arm */}
      <path
        d="M102 118 L102 80 Q102 72 112 72 L116 72"
        stroke="url(#sharpyBody)"
        strokeWidth="13"
        strokeLinecap="round"
        fill="none"
      />
      <path
        d="M96 116 L96 80 Q96 66 112 66"
        stroke="#475569"
        strokeWidth="0.8"
        strokeLinecap="round"
        fill="none"
        opacity="0.5"
      />

      {/* Right arm */}
      <path
        d="M158 118 L158 80 Q158 72 148 72 L144 72"
        stroke="url(#sharpyBody)"
        strokeWidth="13"
        strokeLinecap="round"
        fill="none"
      />
      <path
        d="M164 116 L164 80 Q164 66 148 66"
        stroke="#475569"
        strokeWidth="0.8"
        strokeLinecap="round"
        fill="none"
        opacity="0.5"
      />

      {/* Side Tilt-Lock Knob on Right Yoke Pivot */}
      <circle cx="164" cy="74" r="3.4" fill="#0c1017" stroke="#475569" strokeWidth="0.8" />
      <line x1="162" y1="74" x2="166" y2="74" stroke="#94a3b8" strokeWidth="0.8" />

      {/* 6. Authentic Clay Paky Sharpy Moving Head Projector (Angled dynamically across card with lens) */}
      <g transform="rotate(-24 130 75)">
        {/* 1. Main Aerodynamic Sharpy Head Casing (Sculpted Body Shell) */}
        <path
          d="M112 36 Q131 34 150 36 L153 45 Q158 56 157 66 Q156 74 158 84 Q159 96 152 103 Q143 107 131 107 Q119 107 110 103 Q103 96 104 84 Q106 74 105 66 Q104 56 109 45 Z"
          fill="url(#sharpyHeadHousing)"
          stroke="#334155"
          strokeWidth="1.2"
        />

        {/* Outer Perimeter Chamfer Highlight along Aerodynamic Shoulder */}
        <path
          d="M112 38 Q131 36 150 38 L152 46 Q156 56 155 65"
          fill="none"
          stroke="url(#sharpyShoulderGleam)"
          strokeWidth="1"
          strokeLinecap="round"
        />
        <path
          d="M110 46 Q106 56 107 65"
          fill="none"
          stroke="#475569"
          strokeWidth="0.8"
          strokeLinecap="round"
          opacity="0.6"
        />

        {/* Central Molded Parting Seam Line (Clay Paky Dual-Shell Cast) */}
        <line x1="131" y1="36" x2="131" y2="106" stroke="#080c10" strokeWidth="0.8" opacity="0.6" />
        <line x1="131.5" y1="36" x2="131.5" y2="106" stroke="#475569" strokeWidth="0.4" opacity="0.4" />

        {/* Ergonomic Molded Side Handle Grip Recesses (Left & Right Waist) */}
        {/* Left handle recess */}
        <path
          d="M104.5 70 Q107.5 75 107.5 80 Q107.5 85 104.5 90"
          fill="#080c12"
          stroke="#1e293b"
          strokeWidth="0.8"
        />
        <line x1="105" y1="74" x2="106.5" y2="74" stroke="#334155" strokeWidth="0.7" />
        <line x1="105.2" y1="78" x2="107" y2="78" stroke="#334155" strokeWidth="0.7" />
        <line x1="105.2" y1="82" x2="107" y2="82" stroke="#334155" strokeWidth="0.7" />
        <line x1="105" y1="86" x2="106.5" y2="86" stroke="#334155" strokeWidth="0.7" />

        {/* Right handle recess */}
        <path
          d="M157.5 70 Q154.5 75 154.5 80 Q154.5 85 157.5 90"
          fill="#080c12"
          stroke="#1e293b"
          strokeWidth="0.8"
        />
        <line x1="155.5" y1="74" x2="157" y2="74" stroke="#334155" strokeWidth="0.7" />
        <line x1="155" y1="78" x2="156.8" y2="78" stroke="#334155" strokeWidth="0.7" />
        <line x1="155" y1="82" x2="156.8" y2="82" stroke="#334155" strokeWidth="0.7" />
        <line x1="155.5" y1="86" x2="157" y2="86" stroke="#334155" strokeWidth="0.7" />

        {/* Rear Aerodynamic Cooling Louvers / Heat Dissipation Gills */}
        <path d="M116 88 L146 88" stroke="#06090e" strokeWidth="2.4" strokeLinecap="round" />
        <line x1="117" y1="87.2" x2="145" y2="87.2" stroke="#334155" strokeWidth="0.5" />

        <path d="M117 93 L145 93" stroke="#06090e" strokeWidth="2.4" strokeLinecap="round" />
        <line x1="118" y1="92.2" x2="144" y2="92.2" stroke="#334155" strokeWidth="0.5" />

        <path d="M119 98 L143 98" stroke="#06090e" strokeWidth="2.4" strokeLinecap="round" />
        <line x1="120" y1="97.2" x2="142" y2="97.2" stroke="#334155" strokeWidth="0.5" />

        <path d="M122 103 L140 103" stroke="#06090e" strokeWidth="2.0" strokeLinecap="round" />

        {/* Hex Socket Cap Assembly Screws (Signature Sharpy Hardware) */}
        {/* Screw 1: Top-Left */}
        <circle cx="111" cy="54" r="1.5" fill="#1e293b" stroke="#475569" strokeWidth="0.5" />
        <rect x="110.3" y="53.3" width="1.4" height="1.4" fill="#030712" />
        {/* Screw 2: Top-Right */}
        <circle cx="151" cy="54" r="1.5" fill="#1e293b" stroke="#475569" strokeWidth="0.5" />
        <rect x="150.3" y="53.3" width="1.4" height="1.4" fill="#030712" />
        {/* Screw 3: Mid-Left */}
        <circle cx="110" cy="85" r="1.5" fill="#1e293b" stroke="#475569" strokeWidth="0.5" />
        <rect x="109.3" y="84.3" width="1.4" height="1.4" fill="#030712" />
        {/* Screw 4: Mid-Right */}
        <circle cx="152" cy="85" r="1.5" fill="#1e293b" stroke="#475569" strokeWidth="0.5" />
        <rect x="151.3" y="84.3" width="1.4" height="1.4" fill="#030712" />

        {/* 2. Projecting Front Lens Snout & Optical Bezel Assembly */}
        {/* Stepped Front Cylindrical Lens Collar Housing */}
        <rect
          x="108"
          y="35"
          width="46"
          height="24"
          rx="6"
          fill="url(#sharpySnoutCollar)"
          stroke="#2d3a4f"
          strokeWidth="1.2"
        />
        {/* Collar Upper Edge Highlight */}
        <line x1="112" y1="36" x2="150" y2="36" stroke="#64748b" strokeWidth="0.9" />

        {/* Sharpy Outer Protective Heavy Rubber Bumper Rim (Notched Shock Ring) */}
        <circle cx="131" cy="56" r="23" fill="#0a0d14" stroke="#253043" strokeWidth="1.8" />
        
        {/* Fluted Rubber Shock Bumper Grips / Radial Notches around Rim */}
        <line x1="131" y1="33" x2="131" y2="36" stroke="#475569" strokeWidth="1.4" strokeLinecap="round" />
        <line x1="131" y1="76" x2="131" y2="79" stroke="#334155" strokeWidth="1.4" strokeLinecap="round" />
        <line x1="108" y1="56" x2="111" y2="56" stroke="#334155" strokeWidth="1.4" strokeLinecap="round" />
        <line x1="151" y1="56" x2="154" y2="56" stroke="#475569" strokeWidth="1.4" strokeLinecap="round" />
        <line x1="114.7" y1="39.7" x2="116.8" y2="41.8" stroke="#334155" strokeWidth="1.4" strokeLinecap="round" />
        <line x1="145.2" y1="70.2" x2="147.3" y2="72.3" stroke="#334155" strokeWidth="1.4" strokeLinecap="round" />
        <line x1="147.3" y1="39.7" x2="145.2" y2="41.8" stroke="#475569" strokeWidth="1.4" strokeLinecap="round" />
        <line x1="116.8" y1="70.2" x2="114.7" y2="72.3" stroke="#334155" strokeWidth="1.4" strokeLinecap="round" />

        {/* Stepped Anodized Aluminum Retaining Bezel with Chamfer */}
        <circle cx="131" cy="56" r="20.8" fill="url(#sharpyBezelRing)" stroke="#475569" strokeWidth="1.2" />
        <circle cx="131" cy="56" r="19.5" fill="none" stroke="#64748b" strokeWidth="0.6" strokeDasharray="1.5,1.5" />

        {/* Deep Optical Baffle Tube Cavity (Stepped light traps) */}
        <circle cx="131" cy="56" r="18.8" fill="url(#sharpyBaffleDepth)" />
        <circle cx="131" cy="56" r="17.8" fill="none" stroke="#000000" strokeWidth="0.8" opacity="0.8" />

        {/* Sharpy Massive 115mm Convex Objective Glass Lens with Sapphire AR Coating */}
        <circle cx="131" cy="56" r="17.2" fill="url(#sharpyGlassCoating)" />
        <circle cx="131" cy="56" r="17.2" fill="url(#dmxGlass)" />

        {/* Precision Multi-layer Optical Fresnel Rings */}
        <circle cx="131" cy="56" r="14.2" stroke="#ffffff" strokeWidth="0.65" fill="none" opacity="0.35" />
        <circle cx="131" cy="56" r="11" stroke="#ffffff" strokeWidth="0.65" fill="none" opacity="0.45" />
        <circle cx="131" cy="56" r="7.8" stroke="#ffffff" strokeWidth="0.7" fill="none" opacity="0.60" />
        <circle cx="131" cy="56" r="4.5" stroke="#ffffff" strokeWidth="0.75" fill="none" opacity="0.75" />
        <circle cx="131" cy="56" r="1.8" fill="#ffffff" opacity="0.9" />

        {/* Spherical Convex Meniscus Reflection Arcs (Glass Surface Gleams) */}
        {/* Upper main curved glare */}
        <path
          d="M119 46 Q 131 40 143 44 Q 131 48 119 46 Z"
          fill="#ffffff"
          opacity="0.85"
        />
        {/* Lower counter-reflection */}
        <path
          d="M123 65 Q 131 68 139 66 Q 131 67 123 65 Z"
          fill="#38bdf8"
          opacity="0.55"
        />

        {/* SHARPY STAGE LIGHT BEAM CONE (Active exclusively in Night Mode: Super Long, Multi-layer & Ultra Bright) */}
        {isAnimated && (
          <g className="sharpy-beam-active">
            {/* Layer 1: Broad Volumetric Stage Light Cone (Reaches far across the card) */}
            <polygon
              points="112,44 150,44 340,-520 -100,-520"
              fill="url(#sharpyStageBeam)"
            />

            {/* Layer 2: Mid-Intensity Volumetric Core Cone */}
            <polygon
              points="120,44 142,44 240,-520 10,-520"
              fill="url(#sharpyStageBeam)"
              opacity="0.9"
            />

            {/* Layer 3: Concentrated Intense Center Ray */}
            <polygon
              points="125,44 137,44 180,-520 65,-520"
              fill="url(#sharpyCoreRay)"
            />

            {/* Layer 4: Ultra-Bright Pure White Laser Needle (Blinding laser core) */}
            <polygon
              points="128.5,44 133.5,44 142,-520 112,-520"
              fill="url(#sharpyLaserNeedle)"
            />

            {/* Lens Optical Starburst Diffraction Spikes */}
            <polygon points="131,22 133,56 131,90 129,56" fill="#ffffff" opacity="0.85" />
            <polygon points="97,56 131,58 165,56 131,54" fill="#ffffff" opacity="0.85" />

            {/* Lens Aperture Flare Bloom (Ultra Radiant) */}
            <circle
              cx="131"
              cy="56"
              r="32"
              fill="url(#sharpyApertureFlare)"
              className="pointer-events-none"
            />
            <circle
              cx="131"
              cy="56"
              r="12"
              fill="#ffffff"
              opacity="0.9"
              className="pointer-events-none"
            />
          </g>
        )}
      </g>
    </svg>
  );
};
