import React from 'react';
import { Volume2, Languages, Sun, Moon, Settings } from 'lucide-react';
import { useLanguage } from '../localization/LanguageContext';
import { useTheme } from '../theme/ThemeContext';

interface HeaderProps {
  onOpenFlutterExport?: () => void;
  onOpenSettings?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenFlutterExport, onOpenSettings }) => {
  const { language, setLanguage, isHindi } = useLanguage();
  const { isNightMode, toggleTheme } = useTheme();

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'hi' : 'en');
  };

  return (
    <header className={`shadow-xs sticky top-0 z-30 border-b transition-colors duration-200 ${
      isNightMode 
        ? 'bg-[#0E1524] text-white border-slate-800' 
        : 'bg-white text-[#071d27] border-slate-100'
    }`}>
      {/* App Bar */}
      <div className="max-w-4xl mx-auto px-4 pt-2.5 pb-2.5">
        <div className="flex items-center justify-between gap-3">
          {/* Left: App Logo + Titles */}
          <div className="flex items-center gap-1.5 min-w-0 pr-1">
            <div className="w-7.5 h-7.5 sm:w-8 sm:h-8 flex items-center justify-center shrink-0">
              <img src="/app-logo.png" alt="AMP OHM" className="w-full h-full object-contain drop-shadow-xs" />
            </div>

            <div className="min-w-0">
              <h1 className={`text-base sm:text-lg font-black tracking-tight leading-tight ${
                isNightMode ? 'text-white' : 'text-[#0F172A]'
              }`}>
                AMP <span className="text-[#2563EB]">OHM</span>
              </h1>
              <p className={`text-[8.5px] sm:text-[9.5px] font-semibold tracking-tight mt-0.5 leading-none truncate ${
                isNightMode ? 'text-slate-400' : 'text-[#6B7280]'
              }`}>
                Audio &amp; Lighting Tools
              </p>
            </div>
          </div>

          {/* Right: Day/Night mode + Language toggle + Settings button */}
          <div className="flex items-center gap-1.5">
            {/* Theme Toggle Button */}
            <button
              type="button"
              onClick={toggleTheme}
              className={`w-8 h-8 rounded-full flex items-center justify-center transition active:scale-95 shadow-xs border ${
                isNightMode 
                  ? 'bg-slate-800/90 border-amber-400/40 text-amber-400 hover:bg-slate-700' 
                  : 'bg-slate-50 border-slate-200 text-[#475569] hover:text-[#0F172A] hover:bg-slate-100'
              }`}
              title={isNightMode ? "Switch to Day Mode" : "Switch to Night Mode"}
              aria-label="Toggle Night Mode"
            >
              {isNightMode ? (
                <Sun className="w-3.5 h-3.5 stroke-[2.2] text-amber-400" />
              ) : (
                <Moon className="w-3.5 h-3.5 stroke-[2.2] text-[#475569]" />
              )}
            </button>

            {/* Language Toggle in Header */}
            <button
              type="button"
              onClick={toggleLanguage}
              className={`h-8 px-2.5 rounded-full shadow-xs border flex items-center gap-1 font-bold text-[11px] transition active:scale-95 ${
                isNightMode 
                  ? 'bg-slate-800/80 hover:bg-slate-700 text-slate-200 border-slate-700' 
                  : 'bg-slate-50 hover:bg-slate-100 text-[#071d27] border-slate-200'
              }`}
              title={language === 'en' ? 'हिन्दी में बदलें' : 'Switch to English'}
              aria-label="Toggle Language"
            >
              <Languages className="w-3.5 h-3.5 text-[#2563EB]" />
              <span>{language === 'en' ? 'हिन्दी' : 'ENG'}</span>
            </button>

            {/* Settings Button */}
            {onOpenSettings && (
              <button
                type="button"
                onClick={onOpenSettings}
                className={`w-8 h-8 rounded-full shadow-xs border flex items-center justify-center transition active:scale-95 ${
                  isNightMode
                    ? 'bg-slate-800/80 border-slate-700 text-slate-300 hover:text-white hover:bg-slate-700'
                    : 'bg-white border-[#CBD5E1] text-[#475569] hover:text-[#0F172A] hover:bg-slate-50'
                }`}
                title="Settings"
                aria-label="Settings"
              >
                <Settings className="w-3.5 h-3.5 stroke-[2.2]" />
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
