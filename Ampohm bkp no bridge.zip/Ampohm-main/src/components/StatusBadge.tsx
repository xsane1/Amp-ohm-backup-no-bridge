import React from 'react';
import { StatusLevel } from '../types';
import { CheckCircle2, AlertTriangle, AlertOctagon, Info } from 'lucide-react';
import { useLanguage } from '../localization/LanguageContext';

interface StatusBadgeProps {
  status: StatusLevel;
  customText?: string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, customText }) => {
  const { t } = useLanguage();

  const configs = {
    safe: {
      bg: 'bg-emerald-50 text-emerald-800 border-emerald-300',
      icon: <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />,
      defaultText: t.safe,
      dotColor: 'bg-emerald-500'
    },
    warning: {
      bg: 'bg-amber-50 text-amber-900 border-amber-300',
      icon: <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />,
      defaultText: t.warning,
      dotColor: 'bg-amber-500'
    },
    danger: {
      bg: 'bg-red-50 text-red-900 border-red-300',
      icon: <AlertOctagon className="w-4 h-4 text-red-600 shrink-0" />,
      defaultText: t.danger,
      dotColor: 'bg-red-500'
    },
    info: {
      bg: 'bg-blue-50 text-blue-900 border-blue-300',
      icon: <Info className="w-4 h-4 text-blue-600 shrink-0" />,
      defaultText: t.info,
      dotColor: 'bg-blue-500'
    },
  };

  const config = configs[status] || configs.info;

  return (
    <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-semibold tracking-wide shadow-xs ${config.bg}`}>
      {config.icon}
      <span>{customText || config.defaultText}</span>
    </div>
  );
};
