export type Language = 'en' | 'hi';

export type ToolCategory = 'all' | 'audio' | 'lighting' | 'future';

export type ActiveScreen = 
  | 'home' 
  | 'history'
  | 'guide'
  | 'more_tools' 
  | 'settings' 
  | 'calc_ohm' 
  | 'calc_amp' 
  | 'calc_cable_loss' 
  | 'calc_dmx';

export type StatusLevel = 'safe' | 'warning' | 'danger' | 'info';

export interface CalculatorCardInfo {
  id: ActiveScreen;
  titleKey: string;
  descKey: string;
  category: 'audio' | 'lighting';
  icon: string;
  badgeKey?: string;
}

export interface ComingSoonItem {
  id: string;
  titleKey: string;
  descKey: string;
  category: 'audio';
  icon: string;
}

export type LoadClassification = 
  | 'extreme'       // < 2Ω: Extreme Load (Red)
  | 'requires_2ohm'  // 2Ω: Requires 2Ω Stable Amp (Yellow)
  | 'high_current'   // > 2Ω and < 4Ω: High Current Load (Yellow)
  | 'safe'           // 4Ω to 8Ω: Safe Load (Green)
  | 'pro_load'       // > 8Ω and <= 16Ω: Professional Load (Blue)
  | 'uncommon';      // > 16Ω: Uncommon PA Load (Blue)

export interface OhmResult {
  totalImpedance: number;
  speakerRms: number;
  speakerCount: number;
  totalSystemRms: number;
  perSpeakerPower: number;
  speakerImpedance: number;
  wiring: 'parallel' | 'series';
  classification: LoadClassification;
  status: StatusLevel;
  badgeColor: 'red' | 'yellow' | 'green' | 'blue';
  statusTitleKey: string;
  statusMessageKey: string;
  canRecommendAmp: boolean;
}

export type HeadroomMultiplier = 1.25 | 1.50 | 2.00;

export interface AmpCalculationParams {
  speakerRms: number;       // Watts RMS (validated >= 200W)
  speakerCount: number;     // 1 to 32
  speakerImpedance: number; // 2, 4, 6, 8, 16
  wiring: 'parallel' | 'series';
  headroom: HeadroomMultiplier;
}

export interface AmpResult {
  speakerRms: number;
  speakerCount: number;
  totalSystemRms: number;
  speakerImpedance: number;
  wiring: 'parallel' | 'series';
  headroom: HeadroomMultiplier;
  finalLoad: number;
  recommendedAmpPower: number; // Total RMS * headroom
  classification: LoadClassification;
  badgeColor: 'red' | 'yellow' | 'green' | 'blue';
  status: StatusLevel;
  statusTitleKey: string;
  statusMessageKey: string;
  isRecommendationAvailable: boolean; // false if load < 2Ω or load > 16Ω
}


export type CableSizeOption = 1.5 | 2.5 | 4 | 6 | 10;
export type CableLoadOption = 2 | 4 | 6 | 8 | 16;
export type CableMaterialOption = 'copper' | 'cca';
export type MaxAcceptableLossOption = 3 | 5 | 10;
export type CableWarningLevel = 'green' | 'yellow' | 'red';
export type CableStatusBadgeLevel = 'excellent' | 'recommended' | 'acceptable' | 'high_loss' | 'not_recommended';

export interface ContextualWarningItem {
  id: string;
  type: 'warning' | 'danger';
  title: string;
  message: string;
  iconType: 'long_run' | 'extreme_run' | 'high_current' | 'cca' | 'high_loss';
}

export interface CableLossCalculationParams {
  cableLength: number; // One-way meters (> 0)
  power: number; // Watts per channel (> 0)
  load: number; // Final system load impedance in Ω (2 to 16 Ω)
  material: CableMaterialOption; // 'copper' | 'cca'
  maxAcceptableLoss?: MaxAcceptableLossOption; // 3, 5 (default), 10 (%)
  cableSize?: CableSizeOption; // Optional custom evaluated size
}

export interface CableSizeAnalysis {
  size: CableSizeOption;
  loopResistance: number;
  resistanceRatioPercent: number; // (R_loop / R_load) * 100
  actualPowerLossPercent: number; // (R_loop / (R_load + R_loop)) * 100
  powerLossWatts: number;
  powerDeliveredWatts: number;
  levelLossDb: number; // 20 * log10(R_load / (R_load + R_loop))
  voltageDrop: number;
  powerLossPercent: number; // backward compatibility alias for actualPowerLossPercent
  efficiencyPercent: number;
  isCompliant: boolean;
  statusBadge: CableStatusBadgeLevel;
  badgeLabel: string;
  badgeEmoji: string;
}

export interface CableLossResult {
  cableLength: number;
  power: number;
  load: number;
  material: CableMaterialOption;
  materialName: string;
  maxAcceptableLoss: MaxAcceptableLossOption;
  loopResistance: number;
  resistanceRatioPercent: number; // (R_loop / R_load) * 100
  actualPowerLossPercent: number; // (R_loop / (R_load + R_loop)) * 100
  levelLossDb: number; // 20 * log10(R_load / (R_load + R_loop))
  voltageDrop: number; // Volts
  voltageDropPercent: number; // %
  powerLossWatts: number; // Watts dissipated in cable
  powerLossPercent: number; // % (actual power loss)
  estimatedEfficiency: number; // %
  powerDeliveredWatts: number; // Watts delivered to speaker (I^2 * R_load)
  // Recommendations
  recommendedCableSize: CableSizeOption | null; // Smallest size meeting target; null if none meets target
  displayCableSize: CableSizeOption; // recommended size or lowest-loss alternative (10 mm²)
  recommendationReason: string; // Short explanation why this cable size was selected
  minimumAcceptableSize: CableSizeOption | null; // Minimum Acceptable (null if no size meets target)
  professionalChoiceSize: CableSizeOption | null; // Professional Choice (null if no size meets target)
  meetsTarget: boolean;
  // Status Badge
  statusBadge: CableStatusBadgeLevel;
  badgeLabel: string;
  badgeEmoji: string;
  statusSummary: string;
  // Warning
  isCca: boolean;
  ccaWarning: string;
  contextualWarnings: ContextualWarningItem[];
  // Detailed all-sizes matrix
  allSizes: CableSizeAnalysis[];
  // Backward compatibility fields
  cableSize: number;
  warningLevel: CableWarningLevel;
  status: StatusLevel;
  statusTitleKey: string;
  statusMessageKey: string;
}

export interface DmxCalculationParams {
  startAddress: number; // 1–512
  channelCount: number; // Channels per fixture
  fixtureCount?: number; // Number of fixtures
}

export interface DmxFixtureSequence {
  fixtureNumber: number;
  startAddress: number;
  endAddress: number;
  nextAddress: number;
  rangeString: string;
  formattedStart: string; // e.g. "001"
  formattedEnd: string; // e.g. "016"
  exceeds512: boolean;
}

export interface DmxResult {
  currentAddress: number; // Start Address
  channelCount: number;
  fixtureCount: number;
  nextFixtureAddress: number; // Next Free Address
  formattedNextFreeAddress: string; // e.g. "065"
  addressRange: string; // e.g. "001–016"
  endAddress: number; // End address of last fixture
  isValid: boolean;
  exceedsUniverse: boolean;
  fixtures: DmxFixtureSequence[];
  subsequentFixtures: DmxFixtureSequence[];
}

export interface DmxFixtureEntry {
  fixtureIndex: number;
  startChannel: number;
  endChannel: number;
  universe: number;
}
