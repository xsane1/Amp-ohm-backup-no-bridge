import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language } from '../types';
import { translations } from './translations';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  isHindi: boolean;
  t: typeof translations.en;
}

const STORAGE_KEY = 'proaudio_toolkit_lang';

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved === 'en' || saved === 'hi') {
        return saved;
      }
    } catch {
      // Ignore localStorage access issues
    }
    return 'en';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    try {
      localStorage.setItem(STORAGE_KEY, lang);
    } catch {
      // Ignore
    }
  };

  useEffect(() => {
    // Keep html lang and class updated
    document.documentElement.lang = language;
    if (language === 'hi') {
      document.documentElement.classList.add('lang-hi', 'hindi-mode');
    } else {
      document.documentElement.classList.remove('lang-hi', 'hindi-mode');
    }
  }, [language]);

  const t = translations[language] || translations.en;

  const isHindi = language === 'hi';

  return (
    <LanguageContext.Provider value={{ language, setLanguage, isHindi, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
